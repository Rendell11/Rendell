<?php
/**
 * disaster_ai_summary.php — AI Analytics for Disaster Analytics (JSON, POST).
 * Same behavior as the Resident / Household / Legal Document analytics:
 *   - called ONLY when "Generate AI Analytics" is clicked (never automatically)
 *   - start, end (optional — empty = all records), category, csrf_token
 *   - cached_only=1 → return an analysis generated before for the same data (no Gemini call)
 * Only aggregated figures are sent (no resident data). The result is cached by data snapshot,
 * so the Save PDF / Print report can include it without calling Gemini again.
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_permission($pdo, 'announcements', 'read');
require_once __DIR__ . '/csrf_helper.php';
require_once __DIR__ . '/../../ai_helper.php';
require_once __DIR__ . '/disaster_analytics_data.php';

header('Content-Type: application/json; charset=utf-8');
$out = function (array $d, int $code = 200) { http_response_code($code); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; };

if ($_SERVER['REQUEST_METHOD'] !== 'POST') $out(['success' => false, 'error' => 'Method not allowed.'], 405);
if (!verify_csrf_token($_POST['csrf_token'] ?? '')) $out(['success' => false, 'error' => 'Your session has expired. Please refresh the page and try again.'], 403);

try {
    $p = ra_params($_POST);
    $d = disaster_analytics_compute($pdo, $p, trim((string)($_POST['category'] ?? 'All')));
} catch (Throwable $e) {
    error_log('[Disaster AI] data: ' . $e->getMessage());
    $out(['success' => false, 'error' => 'Could not read the disaster records.'], 500);
}

$snapshot = disaster_analytics_snapshot($d);
$ns = 'disaster_analytics';
if (!empty($_POST['cached_only'])) {
    $c = ai_cache_get($ns, $snapshot);
    $out($c ? $c + ['cached' => true] : ['success' => true, 'none' => true]);
}
$s = $d['summary'];
if (!$s['total_alerts'] && !$s['reports']) $out(['success' => false, 'error' => 'There are no disaster records for ' . $d['range']['label'] . ', so there is nothing to analyse.']);
if (ai_api_key() === '') $out(['success' => false, 'error' => 'AI is not configured. Set GEMINI_API_KEY in the CAPS .env file.']);

$prompt = "You are a data analyst for a Philippine barangay Disaster Risk Reduction and Management (DRRM) office. Analyze ONLY the aggregated disaster data below "
    . "for the date range: " . $d['range']['label'] . ($d['category'] !== 'All' ? ' (category: ' . $d['category'] . ')' : '') . ". "
    . "Alerts are counted by the date they were issued; impact figures come from the final reports filed when each alert was deactivated. "
    . "Do not invent numbers, dates, places or names; cite the actual figures and percentages. Keep each detail to one or two short sentences. If the data is thin, say so briefly.\n"
    . "- key_findings: the most important facts (alerts, most frequent type, severity, impact).\n"
    . "- demographic_trends: trends over time (per day / month, weekday, comparison with the previous period).\n"
    . "- patterns: significant patterns (types vs severity, report status, time from alert to final report).\n"
    . "- population_observations: impact and response observations (affected, evacuees, injuries, casualties, notification channels, SMS delivery).\n"
    . "- recommendations: practical actions for the barangay (preparedness, drills, advisories, evacuation-centre readiness, SMS list upkeep), each tied to a finding.\n\n"
    . "Return JSON: {\"summary\": string (1-2 sentences), "
    . "\"key_findings\": [{\"title\": string, \"detail\": string}] (3-4 items), "
    . "\"demographic_trends\": [{\"title\": string, \"detail\": string}] (2-3 items), "
    . "\"patterns\": [{\"title\": string, \"detail\": string}] (2-3 items), "
    . "\"population_observations\": [{\"title\": string, \"detail\": string}] (2-3 items), "
    . "\"recommendations\": [{\"action\": string, \"reason\": string, \"priority\": \"high\"|\"medium\"|\"low\"}] (3-4 items)}.\n\n"
    . "DATA:\n" . json_encode($snapshot, JSON_UNESCAPED_UNICODE);

$r = ai_call([['text' => $prompt]], '', ['temperature' => 0.3]);
$parsed = $r['ok'] ? ai_parse_json($r['text']) : null;
if (!is_array($parsed) || empty($parsed['key_findings'])) $out(['success' => false, 'error' => ($r['error'] ?? '') ?: 'The AI service returned an unreadable answer. Please try again.']);

$clean = fn($v) => mb_substr(trim((string)$v), 0, 600);
$items = function ($list) use ($clean): array {
    $res = [];
    foreach (is_array($list) ? $list : [] as $x) {
        if (!is_array($x) || trim((string)($x['title'] ?? '')) === '') continue;
        $res[] = ['title' => $clean($x['title']), 'detail' => $clean($x['detail'] ?? '')];
    }
    return array_slice($res, 0, 5);
};
$recs = [];
foreach (is_array($parsed['recommendations'] ?? null) ? $parsed['recommendations'] : [] as $x) {
    if (!is_array($x) || trim((string)($x['action'] ?? '')) === '') continue;
    $recs[] = ['action' => $clean($x['action']), 'reason' => $clean($x['reason'] ?? ''),
               'priority' => in_array($x['priority'] ?? '', ['high', 'medium', 'low'], true) ? $x['priority'] : 'medium'];
}
$result = [
    'success' => true, 'ai' => true, 'model' => $r['model'] ?? '', 'generated_at' => date('F j, Y g:i A'), 'period' => $p, 'category' => $d['category'],
    'summary' => $clean($parsed['summary'] ?? ''),
    'key_findings' => $items($parsed['key_findings']),
    'demographic_trends' => $items($parsed['demographic_trends'] ?? []),
    'patterns' => $items($parsed['patterns'] ?? []),
    'population_observations' => $items($parsed['population_observations'] ?? []),
    'recommendations' => array_slice($recs, 0, 5),
];
ai_cache_put($ns, $snapshot, $result);
try {
    require_once __DIR__ . '/../../activity_log_helper.php';
    log_activity('Announcements', 'Generate AI Analytics', 'Generated disaster AI analytics for ' . $d['range']['label']);
} catch (Throwable $e) { /* optional */ }
$out($result);
