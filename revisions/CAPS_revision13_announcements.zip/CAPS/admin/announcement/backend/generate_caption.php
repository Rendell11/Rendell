<?php
/**
 * generate_caption.php
 * AJAX endpoint used by new_ann.php ("Create New Announcement").
 *
 * Generates a ready-to-use announcement caption/content body using Google
 * Gemini (free-tier model, same as the rest of the system — see
 * ai_chat_handler.php / ai_reply.php / ai_proxy.php).
 *
 * Two modes:
 *   - Image mode: one or more images were attached in "Attachments & Media" —
 *     the AI looks at the image(s) and writes a caption based on what it sees.
 *   - Prompt mode: no image was attached — the admin instead types a short
 *     description of what the announcement is about, and the AI writes the
 *     content body from that text alone.
 *
 * The AI also gets the Announcement Title, the admin's prompt and the relevant
 * barangay facts from the database (barangay name / address, the current Barangay
 * Captain and the other current officials) so e.g. "Happy Birthday Kap" uses the
 * real Captain's name instead of an invented person. It must not invent other data.
 * language = English | Tagalog (the language of the generated announcement).
 */

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_permission($pdo, 'announcements', 'create');
require_once __DIR__ . '/csrf_helper.php';
require_once __DIR__ . '/ai_config.php';

header('Content-Type: application/json; charset=utf-8');

// ── Only POST ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

// ── CSRF (verified without rotating — admin may generate more than once) ───
$token = $_POST['csrf_token'] ?? '';
if (!function_exists('verify_csrf_token') || !verify_csrf_token($token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Your session has expired. Please refresh the page and try again.']);
    exit;
}

$title    = trim($_POST['title']    ?? '');
$category = trim($_POST['category'] ?? '');
$prompt   = trim($_POST['prompt']   ?? '');
$language = ($_POST['language'] ?? 'English') === 'Tagalog' ? 'Tagalog' : 'English';

/** Barangay facts from the database that the AI may use (names / positions only, no personal data). */
function caption_db_context(PDO $pdo): array
{
    $ctx = ['barangay' => null, 'address' => null, 'captain' => null, 'officials' => []];
    try {
        $bp = $pdo->query("SELECT * FROM barangay_profile WHERE id = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: [];
        $ctx['barangay'] = trim((string)($bp['brgy_name'] ?? '')) ?: null;
        $ctx['address'] = trim((string)($bp['address'] ?? '')) ?: trim(implode(', ', array_filter([$bp['municipality_name'] ?? '', $bp['province_name'] ?? '']))) ?: null;
    } catch (Throwable $e) { /* optional */ }
    try {
        // Current officials: not ended, term not over (same rule as the Officials module).
        $rows = $pdo->query("SELECT o.Position, r.FirstName, r.MiddleName, r.LastName, r.Suffix, r.Sex
                               FROM officials o JOIN residents r ON r.ResidentID = o.ResidentID
                              WHERE o.ActualEndDate IS NULL AND (o.TermEnd IS NULL OR o.TermEnd >= CURDATE())
                              ORDER BY o.TermStart DESC")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        try {
            $rows = $pdo->query("SELECT o.Position, r.FirstName, r.MiddleName, r.LastName, r.Suffix, r.Sex
                                   FROM officials o JOIN residents r ON r.ResidentID = o.ResidentID
                                  WHERE (o.TermEnd IS NULL OR o.TermEnd >= CURDATE())")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e2) { $rows = []; }
    }
    $seen = [];
    foreach ($rows as $r) {
        $name = trim(preg_replace('/\s+/', ' ', implode(' ', [$r['FirstName'] ?? '', $r['MiddleName'] ? mb_substr($r['MiddleName'], 0, 1) . '.' : '', $r['LastName'] ?? '', $r['Suffix'] ?? ''])));
        $pos = trim((string)$r['Position']);
        if ($name === '' || isset($seen[$pos . $name])) continue;
        $seen[$pos . $name] = true;
        if (!$ctx['captain'] && (stripos($pos, 'captain') !== false || stripos($pos, 'punong') !== false)) {
            $ctx['captain'] = ['name' => $name, 'position' => $pos, 'sex' => $r['Sex'] ?? null];
        }
        if (count($ctx['officials']) < 20) $ctx['officials'][] = $pos . ': ' . $name;
    }
    return $ctx;
}
$ctx = caption_db_context($pdo);

// ── Collect image attachments (max 3, images only) ─────────────────────────
$imageParts = [];
if (!empty($_FILES['images']['name'][0])) {
    $maxImages   = 3;
    $maxFileSize = 10 * 1024 * 1024; // matches save_ann.php limit
    $count       = min(count($_FILES['images']['name']), $maxImages);

    for ($i = 0; $i < $count; $i++) {
        if ($_FILES['images']['error'][$i] !== UPLOAD_ERR_OK) continue;
        if (!is_uploaded_file($_FILES['images']['tmp_name'][$i])) continue;
        if ($_FILES['images']['size'][$i] > $maxFileSize) continue;

        $tmp  = $_FILES['images']['tmp_name'][$i];
        $mime = mime_content_type($tmp);
        // Admin chose "Prompt + attachment" — Gemini can read images and PDFs inline
        if (!$mime || (!str_starts_with($mime, 'image/') && $mime !== 'application/pdf')) continue;

        $data = file_get_contents($tmp);
        if ($data === false) continue;

        $imageParts[] = [
            'inline_data' => [
                'mime_type' => $mime,
                'data'      => base64_encode($data),
            ],
        ];
    }
}

if (empty($imageParts) && $prompt === '') {
    echo json_encode([
        'success' => false,
        'error'   => 'Please describe what the announcement is about, or attach a readable file first.',
    ]);
    exit;
}

// ── API key — same env-based pattern used across the system ────────────────
$apiKey = gemini_api_key(); // from ai_config.php (env var wins over the file)
if (empty($apiKey)) {
    echo json_encode([
        'success' => false,
        'error'   => 'AI generation is not configured yet. Please set the Gemini API key in ai_config.php.',
    ]);
    exit;
}

// ── Build the prompt ─────────────────────────────────────────────────────
$langRule = $language === 'Tagalog'
    ? "- Write the whole announcement in Tagalog / Filipino (natural, respectful barangay tone). Common English terms may stay as they are.\n"
    : "- Write the whole announcement in clear, simple English.\n";
$facts = [];
if ($ctx['barangay']) $facts[] = 'Barangay: ' . $ctx['barangay'] . ($ctx['address'] ? ' (' . $ctx['address'] . ')' : '');
if ($ctx['captain']) $facts[] = 'Current Barangay Captain (Punong Barangay, "Kap" / "Kapitan"): Hon. ' . $ctx['captain']['name'];
if ($ctx['officials']) $facts[] = "Current barangay officials:\n  - " . implode("\n  - ", $ctx['officials']);
$factsText = $facts ? implode("\n", $facts) : 'No barangay records are available.';

$systemPrompt =
    "You are a content writer for the official announcements of a Barangay in the Philippines.\n" .
    "Write a clear, respectful and professional announcement based on the Announcement Title, the admin's prompt / instructions, the attached image(s) if any, and the barangay records below.\n\n" .
    "BARANGAY RECORDS FROM THE DATABASE (real data — use them whenever the title or prompt refers to them):\n" . $factsText . "\n\n" .
    "Rules:\n" .
    $langRule .
    "- When the title or prompt mentions a barangay official or role (e.g. \"Kap\", \"Kapitan\", \"Captain\", \"Punong Barangay\", \"Kagawad\", \"Secretary\"), use that person's REAL name from the records above. Never invent a different person.\n" .
    "- If the needed information is not in the records, the title, the prompt or the image, do not invent it (no made-up names, dates, times, places, numbers or contact details) — write around it or leave it general.\n" .
    "- Put the important details clearly; bullets / emoji (✅, 📅, 📍) may be used when suitable.\n" .
    "- Keep it short — 3 to 6 short paragraphs or bullet lines.\n" .
    "- Output only the announcement text itself — no introduction, no AI disclaimer, no markdown code fences.";

$userTextParts = [];
if ($title !== '')    $userTextParts[] = "Announcement Title: {$title}";
if ($category !== '') $userTextParts[] = "Category: {$category}";
if ($prompt !== '')   $userTextParts[] = "Admin's prompt / instructions: {$prompt}";
$userTextParts[] = "Language: {$language}";
if (!empty($imageParts)) {
    $userTextParts[] = ($prompt === '')
        ? 'Write the announcement based on the attached image(s).'
        : 'Also use the attached image(s) as additional basis.';
}
$userText = implode("\n", $userTextParts);

$parts = array_merge([['text' => $userText]], $imageParts);

$payload = [
    'system_instruction' => ['parts' => [['text' => $systemPrompt]]],
    'contents'           => [[
        'role'  => 'user',
        'parts' => $parts,
    ]],
    'generationConfig' => [
        'maxOutputTokens' => 3000,
        'temperature'     => 0.8,
        // gemini-3.x "thinks" by default and those tokens count against
        // maxOutputTokens — thinkingBudget=>0 is rejected (400) by
        // gemini-3.6-flash, so use thinkingLevel instead. 'minimal' leaves
        // the most room possible for the actual caption text.
        'thinkingConfig'  => ['thinkingLevel' => 'minimal'],
    ],
];

$model = GEMINI_MODEL; // configured in ai_config.php
$url   = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent?key=' . urlencode($apiKey);

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_SSL_VERIFYPEER => true,
]);

$response  = curl_exec($ch);
$httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    echo json_encode(['success' => false, 'error' => 'Could not reach the AI service: ' . $curlError]);
    exit;
}

$data = json_decode($response, true);
$text         = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
$finishReason = $data['candidates'][0]['finishReason'] ?? '';

// The model ran out of its output budget (thinking + answer together) before
// finishing — retry once with a much bigger budget instead of returning a
// silently truncated caption.
if ($httpCode === 200 && $finishReason === 'MAX_TOKENS') {
    $payload['generationConfig']['maxOutputTokens'] = 6000;
    $ch2 = curl_init($url);
    curl_setopt_array($ch2, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 45,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $response2 = curl_exec($ch2);
    $httpCode2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
    curl_close($ch2);

    $data2 = json_decode($response2, true);
    $text2 = $data2['candidates'][0]['content']['parts'][0]['text'] ?? '';
    if ($httpCode2 === 200 && trim($text2) !== '') {
        $data = $data2; $text = $text2; $httpCode = $httpCode2;
        $finishReason = $data2['candidates'][0]['finishReason'] ?? '';
    }
}

if ($httpCode !== 200 || trim($text) === '') {
    $errMsg = $data['error']['message'] ?? 'The AI did not return any content. Please try again.';
    echo json_encode(['success' => false, 'error' => $errMsg]);
    exit;
}

if ($finishReason === 'MAX_TOKENS') {
    echo json_encode([
        'success' => false,
        'error'   => 'The AI response got cut off before it could finish. Please try again, or use a shorter prompt.',
    ]);
    exit;
}

echo json_encode(['success' => true, 'caption' => trim($text)]);
