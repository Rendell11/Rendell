<?php
/**
 * ann_engagement_helper.php — resident interactions with announcements (resident app + admin).
 *
 *   announcement_reads      (existing) a resident opened / saw the announcement  → views / reach
 *   announcement_reactions  one reaction per resident: 'like' (❤️) or 'dislike' (👎)
 *   announcement_comments   resident comments (💬); soft-deleted with deleted_at
 *
 * Used by: user/backend/announcements.php (react / comment API for the app),
 *          admin/announcement/backend/get_ann_engagement.php (view page overview + names),
 *          admin/announcement/backend/announcement_analytics_data.php (analytics).
 * The tables are created here on first use; database/announcement_engagement.sql has the same DDL.
 */

if (!function_exists('ann_engagement_migrate')) {
    function ann_engagement_migrate(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $done = true;
        $cs = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS announcement_reads (
                resident_id INT NOT NULL, announcement_id INT UNSIGNED NOT NULL,
                read_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (resident_id, announcement_id)) $cs");
            $pdo->exec("CREATE TABLE IF NOT EXISTS announcement_reactions (
                announcement_id INT UNSIGNED NOT NULL, resident_id INT NOT NULL,
                reaction ENUM('like','dislike') NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NULL DEFAULT NULL,
                PRIMARY KEY (announcement_id, resident_id),
                KEY idx_ar_reaction (announcement_id, reaction), KEY idx_ar_created (created_at)) $cs");
            $pdo->exec("CREATE TABLE IF NOT EXISTS announcement_comments (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT, announcement_id INT UNSIGNED NOT NULL, resident_id INT NOT NULL,
                comment TEXT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at DATETIME NULL DEFAULT NULL,
                PRIMARY KEY (id), KEY idx_ac_ann (announcement_id, deleted_at), KEY idx_ac_created (created_at)) $cs");
        } catch (Throwable $e) {
            error_log('[ann_engagement] migrate: ' . $e->getMessage());
        }
    }
}

if (!function_exists('ann_engagement_name')) {
    function ann_engagement_name(array $r): string
    {
        $n = trim(preg_replace('/\s+/', ' ', implode(' ', [$r['FirstName'] ?? '', $r['LastName'] ?? '', $r['Suffix'] ?? ''])));
        return $n !== '' ? $n : 'Resident #' . (int)($r['resident_id'] ?? 0);
    }
}

if (!function_exists('ann_engagement_counts')) {
    /** [announcement_id => ['views','likes','dislikes','comments']] for the given ids. */
    function ann_engagement_counts(PDO $pdo, array $ids): array
    {
        ann_engagement_migrate($pdo);
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        $out = [];
        foreach ($ids as $id) $out[$id] = ['views' => 0, 'likes' => 0, 'dislikes' => 0, 'comments' => 0];
        if (!$ids) return $out;
        $in = implode(',', $ids);
        try {
            foreach ($pdo->query("SELECT announcement_id i, COUNT(*) n FROM announcement_reads WHERE announcement_id IN ($in) GROUP BY i") as $r) $out[(int)$r['i']]['views'] = (int)$r['n'];
            foreach ($pdo->query("SELECT announcement_id i, SUM(reaction='like') l, SUM(reaction='dislike') d FROM announcement_reactions WHERE announcement_id IN ($in) GROUP BY i") as $r) {
                $out[(int)$r['i']]['likes'] = (int)$r['l']; $out[(int)$r['i']]['dislikes'] = (int)$r['d'];
            }
            foreach ($pdo->query("SELECT announcement_id i, COUNT(*) n FROM announcement_comments WHERE deleted_at IS NULL AND announcement_id IN ($in) GROUP BY i") as $r) $out[(int)$r['i']]['comments'] = (int)$r['n'];
        } catch (Throwable $e) {
            error_log('[ann_engagement] counts: ' . $e->getMessage());
        }
        return $out;
    }
}

if (!function_exists('ann_engagement_people')) {
    /**
     * Residents who interacted with one announcement.
     * $type: like | dislike | comment | view — comments include the text.
     */
    function ann_engagement_people(PDO $pdo, int $annId, string $type, int $limit = 500): array
    {
        ann_engagement_migrate($pdo);
        $limit = max(1, min(1000, $limit));
        if ($type === 'comment') {
            $s = $pdo->prepare("SELECT c.id, c.resident_id, c.comment, c.created_at, r.FirstName, r.LastName, r.Suffix
                                FROM announcement_comments c LEFT JOIN residents r ON r.ResidentID = c.resident_id
                                WHERE c.announcement_id = ? AND c.deleted_at IS NULL ORDER BY c.created_at DESC, c.id DESC LIMIT $limit");
            $s->execute([$annId]);
            return array_map(fn($r) => ['id' => (int)$r['id'], 'resident_id' => (int)$r['resident_id'], 'name' => ann_engagement_name($r),
                'comment' => (string)$r['comment'], 'at' => date('M j, Y g:i A', strtotime($r['created_at']))], $s->fetchAll(PDO::FETCH_ASSOC));
        }
        if ($type === 'view') {
            $s = $pdo->prepare("SELECT x.resident_id, x.read_at AS at, r.FirstName, r.LastName, r.Suffix FROM announcement_reads x
                                LEFT JOIN residents r ON r.ResidentID = x.resident_id WHERE x.announcement_id = ? ORDER BY x.read_at DESC LIMIT $limit");
            $s->execute([$annId]);
        } else {
            $s = $pdo->prepare("SELECT x.resident_id, COALESCE(x.updated_at, x.created_at) AS at, r.FirstName, r.LastName, r.Suffix FROM announcement_reactions x
                                LEFT JOIN residents r ON r.ResidentID = x.resident_id WHERE x.announcement_id = ? AND x.reaction = ? ORDER BY at DESC LIMIT $limit");
            $s->execute([$annId, $type === 'dislike' ? 'dislike' : 'like']);
        }
        return array_map(fn($r) => ['resident_id' => (int)$r['resident_id'], 'name' => ann_engagement_name($r),
            'at' => $r['at'] ? date('M j, Y g:i A', strtotime($r['at'])) : ''], $s->fetchAll(PDO::FETCH_ASSOC));
    }
}
