<?php
/**
 * Disaster Analytics Report — opened from Disaster Analytics with ?start&end&category&mode=print|pdf&ai=1|0.
 * Same shared CAPS report layout (officials report_common.php) and behavior as the Resident,
 * Household and Legal Document Analytics reports: data / table focused, with interpretation.
 *   ai=0 → "No AI – Data and tables only" (no charts)
 *   ai=1 → "Include AI – Data, charts, and AI explanation": supporting charts + the AI Analytics already
 *          generated on the page for the same data (AI cache — never calls Gemini).
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_permission($pdo, 'announcements', 'read');
require_once __DIR__ . '/../../ai_helper.php';
require_once __DIR__ . '/../../officials/backend/report_common.php';
require_once __DIR__ . '/disaster_analytics_data.php';

$mode = report_mode();
$p = ra_params($_GET);
$d = disaster_analytics_compute($pdo, $p, trim((string)($_GET['category'] ?? 'All')));
$s = $d['summary'];
$withAi = ($_GET['ai'] ?? '0') === '1';
$ai = $withAi ? ai_cache_get('disaster_analytics', disaster_analytics_snapshot($d)) : null;
$showCharts = $ai !== null;
$notes = disaster_analytics_interpretation($d);

$brgy = report_barangay_profile($pdo);
$bAddr = trim((string)($brgy['address'] ?? '')) ?: implode(', ', array_filter([
    $brgy['barangay_name'] ?? '', $brgy['municipality_name'] ?? '', $brgy['province_name'] ?? '', $brgy['region_name'] ?? '',
], fn($x) => trim((string)$x) !== ''));
$captain = report_current_captain($pdo);
$generatedBy = report_generated_by($pdo);
$generatedRole = ($_SESSION['role'] ?? '') === 'admin' ? 'Administrator' : 'Barangay Staff';
if ($mode !== '') {
    try {
        require_once __DIR__ . '/../../activity_log_helper.php';
        log_activity('Announcements', 'Disaster Analytics Report', ($mode === 'pdf' ? 'Saved PDF' : 'Printed') . ' disaster analytics report · ' . $d['range']['label'] . ($ai ? ' · with AI findings' : ''));
    } catch (Throwable $e) { /* optional */ }
}

$n = fn($v) => number_format((float)$v);
$pc = fn($v, $t) => ra_pct($v, $t) . '%';
$A = max(1, (int)$s['total_alerts']);
function dar_table(array $head, array $rows, string $empty = 'No data for the selected range.', array $right = []): void {
    if (!$rows) { echo '<p class="empty-note">' . rh($empty) . '</p>'; return; }
    echo '<table><thead><tr>';
    foreach ($head as $i => $h) echo '<th' . (in_array($i, $right, true) ? ' class="num"' : '') . '>' . rh($h) . '</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr' . (($row[0] ?? '') === 'Total' ? ' class="total"' : '') . '>';
        foreach (array_values($row) as $i => $c) echo '<td' . (in_array($i, $right, true) ? ' class="num"' : '') . '>' . rh($c) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
}
$dist = function (array $counts, int $base) use ($n, $pc): array {
    $rows = [];
    foreach ($counts as $k => $v) $rows[] = [(string)$k, $n($v), $pc($v, $base)];
    if ($rows) $rows[] = ['Total', $n(array_sum($counts)), $pc(array_sum($counts), $base)];
    return $rows;
};
$fd = fn($v, $f = 'M j, Y') => $v ? date($f, strtotime((string)$v)) : '—';

$title = 'Disaster Analytics Report';
report_head($title, $mode);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<?php report_toolbar($mode, 'disaster_analytics_' . ($p['start'] ?: 'all') . '_to_' . ($p['end'] ?: 'all'), 'landscape'); ?>
<style>
    .brgy-addr{text-align:center;font-size:11px;color:#64748b;margin:-12px 0 14px}
    .report-page{max-width:1100px}
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 24px}
    table.kv th{width:42%;background:transparent;font-size:10.5px;color:#64748b}
    table.kv td{font-weight:700}
    td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
    tr.total td{font-weight:800;border-top:1.5px solid #94a3b8;background:#f8fafc}
    .note{margin:10px 0 0;font-size:11.5px;line-height:1.55;color:#334155}
    .sub{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#0d9488;margin:14px 0 4px}
    .sub:first-child{margin-top:0}
    .chart-wrap{position:relative;height:200px;margin:6px 0 4px}
    .chart-cap{font-size:10px;color:#64748b;margin:0 0 4px}
    ol.interp{margin:0;padding-left:18px;font-size:12px;line-height:1.6}
    .ai-item{padding:6px 0;border-bottom:1px solid #e2e8f0;font-size:12px}
    .ai-item:last-child{border-bottom:0}
    .ai-pri{display:inline-block;padding:1px 6px;border-radius:99px;font-size:9px;font-weight:800;text-transform:uppercase;margin-left:6px}
    .pri-high{background:#fee2e2;color:#b91c1c}.pri-medium{background:#fef3c7;color:#b45309}.pri-low{background:#f1f5f9;color:#475569}
    table.recs th,table.recs td{font-size:10.5px;padding:6px 5px}
    .section-wrap{page-break-inside:auto;break-inside:auto}
    tr,.chart-wrap,.stat-grid,.signature-block,.certify-line{page-break-inside:avoid;break-inside:avoid}
    h2.section{page-break-after:avoid;break-after:avoid}
</style>
<div class="report-page" id="reportRoot">
    <?php report_letterhead($brgy, 'Disaster Risk Reduction & Management'); ?>
    <?php if ($bAddr): ?><p class="brgy-addr"><?php echo rh($bAddr); ?></p><?php endif; ?>
    <?php report_title_block($title, 'Disaster alerts, impact and response · ' . $d['range']['label'], 'Announcements · Disaster Analytics'); ?>

    <?php report_section_open('Report Information'); ?>
    <div class="info-grid">
        <table class="kv"><tbody>
            <tr><th>Date range</th><td><?php echo rh($d['range']['label']); ?></td></tr>
            <tr><th>Category</th><td><?php echo rh($d['category'] === 'All' ? 'All categories' : $d['category']); ?></td></tr>
            <tr><th>Basis</th><td>Alerts by date issued; impact from final reports</td></tr>
        </tbody></table>
        <table class="kv"><tbody>
            <tr><th>Generated by</th><td><?php echo rh($generatedBy); ?></td></tr>
            <tr><th>Date generated</th><td><?php echo rh(date('F j, Y g:i A')); ?></td></tr>
            <tr><th>Barangay Captain</th><td><?php echo rh($captain ? 'Hon. ' . $captain['full_name'] : 'Not assigned'); ?></td></tr>
        </tbody></table>
    </div>
    <?php report_section_close(); ?>

    <?php report_section_open('Disaster Records (' . count($d['reports']) . ')'); ?>
    <?php dar_table(['Ref. No.', 'Disaster', 'Type', 'Severity', 'Issued', 'Deactivated', 'Affected', 'Evacuees', 'Injuries', 'Casualties', 'Status'],
        array_map(fn($r) => [$r['ReportNo'], $r['Title'] ?: 'Untitled', $r['Type'] ?: '—', $r['AlertSeverity'] ?: ($r['Severity'] ?? '—'), $fd($r['AlertCreatedAt'] ?? null), $fd($r['CreatedAt'] ?? null),
            $n($r['AffectedResidents'] ?? 0), $n($r['Evacuees'] ?? 0), $n($r['Injuries'] ?? 0), $n($r['Casualties'] ?? 0), $r['Status'] ?: 'Resolved'], $d['reports']),
        'No disaster reports in this date range.', [6, 7, 8, 9]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Summary'); ?>
    <?php report_stat_cards([
        ['value' => $n($s['total_alerts']), 'label' => 'Disaster Alerts', 'variant' => 'a'],
        ['value' => $n($s['reports']), 'label' => 'Final Reports', 'variant' => 'b'],
        ['value' => $n($s['affected']), 'label' => 'Affected Residents', 'variant' => 'c'],
        ['value' => $n($s['casualties']), 'label' => 'Casualties', 'variant' => 'd'],
    ]); ?>
    <div style="margin-top:12px"></div>
    <?php dar_table(['Indicator', 'Value'], [
        ['Active alerts / deactivated', $n($s['active_alerts']) . ' / ' . $n($s['deactivated_alerts'])],
        ['High / Critical / Extreme alerts', $n($s['high_severity']) . ' (' . $pc($s['high_severity'], $A) . ')'],
        ['Evacuees', $n($s['evacuees'])],
        ['Injuries', $n($s['injuries'])],
        ['Most frequent type', $s['most_frequent'] ?: '—'],
        ['Busiest ' . ($d['trend']['granularity'] === 'day' ? 'day' : 'month'), $s['peak_label'] ? $s['peak_label'] . ' (' . $s['peak_count'] . ')' : '—'],
        ['Average time from alert to final report', $s['avg_resolve_hours'] === null ? '—' : $s['avg_resolve_hours'] . ' hour(s)'],
        ['SMS broadcasts / recipients / delivered', $n($s['sms_broadcasts']) . ' / ' . $n($s['sms_recipients']) . ' / ' . $n($s['sms_sent'])],
    ], '', [1]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Category Breakdown'); ?>
    <?php $rows = array_map(fn($t) => [$t['type'], $n($t['alerts']), $pc($t['alerts'], $A), $n($t['reports']), $n($t['affected']), $n($t['evacuees']), $n($t['injuries']), $n($t['casualties'])], $d['by_type']);
    if ($rows) $rows[] = ['Total', $n($s['total_alerts']), '100%', $n($s['reports']), $n($s['affected']), $n($s['evacuees']), $n($s['injuries']), $n($s['casualties'])];
    dar_table(['Category', 'Alerts', 'Share', 'Reports', 'Affected', 'Evacuees', 'Injuries', 'Casualties'], $rows, 'No records.', [1, 2, 3, 4, 5, 6, 7]); ?>
    <?php if ($showCharts && $d['by_type']): ?>
    <p class="chart-cap">Figure 1. Alerts and impact by category</p>
    <div class="chart-wrap"><canvas id="rc-type"></canvas></div>
    <?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Severity, Status & Notification'); ?>
    <p class="sub">Alerts by severity</p>
    <?php dar_table(['Severity', 'Alerts', 'Share'], $dist($d['by_severity'], $A), 'No alerts.', [1, 2]); ?>
    <p class="sub">Final report status</p>
    <?php dar_table(['Status', 'Reports', 'Share'], $dist($d['by_report_status'], max(1, (int)$s['reports'])), 'No reports.', [1, 2]); ?>
    <p class="sub">Notification channels</p>
    <?php dar_table(['Channel', 'Alerts', 'Share'], $dist($d['channels'], $A), 'No alerts.', [1, 2]); ?>
    <p class="sub">Alerts by day of the week</p>
    <?php dar_table(['Day', 'Alerts', 'Share'], $dist($d['weekday'], $A), 'No alerts.', [1, 2]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Trend & Comparison'); ?>
    <?php $rows = [];
    foreach ($d['trend']['labels'] as $i => $lbl) {
        $tot = 0; $cells = [];
        foreach ($d['trend']['datasets'] as $ds) { $cells[] = $n($ds['data'][$i] ?? 0); $tot += (int)($ds['data'][$i] ?? 0); }
        if ($tot || $d['trend']['granularity'] === 'month') $rows[] = array_merge([$lbl], $cells, [$n($tot)]);
    }
    dar_table(array_merge([$d['trend']['granularity'] === 'day' ? 'Day' : 'Month'], array_column($d['trend']['datasets'], 'label'), ['Total']), $rows, 'No alerts in this range.', range(1, count($d['trend']['datasets']) + 1)); ?>
    <?php if ($showCharts && count($d['trend']['labels']) > 1): ?>
    <p class="chart-cap">Figure 2. Alerts over time by category</p>
    <div class="chart-wrap"><canvas id="rc-trend"></canvas></div>
    <?php endif; ?>
    <?php if ($d['comparison']): ?>
    <p class="sub">Selected period vs previous period (<?php echo rh($d['comparison']['previous_label']); ?>)</p>
    <?php dar_table(['Indicator', 'Selected period', 'Previous period', 'Change'], array_map(function ($r) use ($n) { $x = $r['current'] - $r['previous']; return [$r['metric'], $n($r['current']), $n($r['previous']), ($x > 0 ? '+' : '') . $n($x)]; }, $d['comparison']['rows']), '', [1, 2, 3]); ?>
    <?php else: ?><p class="note">Set both a Start Date and an End Date to compare with the previous period of the same length.</p><?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Data Interpretation'); ?>
    <ol class="interp"><?php foreach ($notes as $x): ?><li><?php echo rh($x); ?></li><?php endforeach; ?></ol>
    <?php report_section_close(); ?>

    <?php if ($ai): ?>
    <?php report_section_open('AI Findings'); ?>
        <?php if (!empty($ai['summary'])): ?><p class="note"><?php echo rh($ai['summary']); ?></p><?php endif; ?>
        <?php foreach ([['Key Findings', 'key_findings'], ['Trends', 'demographic_trends'], ['Significant Changes / Patterns', 'patterns'], ['Impact & Response Observations', 'population_observations']] as [$lbl, $key]):
            if (empty($ai[$key])) continue; ?>
            <p class="sub"><?php echo rh($lbl); ?></p>
            <?php foreach ($ai[$key] as $f): ?><div class="ai-item"><strong><?php echo rh($f['title']); ?></strong> — <?php echo rh($f['detail']); ?></div><?php endforeach; ?>
        <?php endforeach; ?>
        <?php if (!empty($ai['recommendations'])): ?>
            <p class="sub">Recommended Actions</p>
            <?php foreach ($ai['recommendations'] as $i => $f): ?><div class="ai-item"><?php echo $i + 1; ?>. <strong><?php echo rh($f['action']); ?></strong><span class="ai-pri pri-<?php echo rh($f['priority']); ?>"><?php echo rh($f['priority']); ?></span><br><span style="color:#64748b"><?php echo rh($f['reason']); ?></span></div><?php endforeach; ?>
        <?php endif; ?>
        <p style="margin:8px 0 0;font-size:10px;color:#64748b">AI-generated (Gemini) · <?php echo rh($ai['generated_at'] ?? ''); ?> · based on the aggregated disaster records of <?php echo rh($d['range']['label']); ?>. Verify against the tables above.</p>
    <?php report_section_close(); ?>
    <?php elseif ($withAi): ?>
    <?php report_section_open('AI Findings'); ?><p class="note">No AI Analytics has been generated for this data yet.</p><?php report_section_close(); ?>
    <?php endif; ?>

    <?php report_certify_and_signatures($brgy['brgy_name'] ?? 'Barangay', $generatedBy, $generatedRole, $captain); ?>
    <?php report_footer_strip($brgy['brgy_name'] ?? 'Barangay'); ?>
</div>
<script>
(function () {
    if (!window.Chart) return;
    Chart.defaults.animation = false;
    Chart.defaults.font.family = 'Arial, Helvetica, sans-serif';
    Chart.defaults.font.size = 10;
    Chart.defaults.color = '#475569';
    const grid = { color: '#e2e8f0' };
    const types = <?php echo json_encode($d['by_type'], JSON_UNESCAPED_UNICODE); ?>;
    const tEl = document.getElementById('rc-type');
    if (tEl) new Chart(tEl, { type: 'bar', data: { labels: types.map(t => t.type), datasets: [
        { label: 'Alerts', data: types.map(t => t.alerts), backgroundColor: '#2a78d6', borderRadius: 3, maxBarThickness: 22 },
        { label: 'Affected', data: types.map(t => t.affected), backgroundColor: '#eb6834', borderRadius: 3, maxBarThickness: 22 }] },
        options: { maintainAspectRatio: false, plugins: { legend: { position: 'top', align: 'end', labels: { boxWidth: 10 } } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
    const trend = <?php echo json_encode($d['trend'], JSON_UNESCAPED_UNICODE); ?>;
    const palette = ['#2a78d6', '#eb6834', '#1baf7a', '#94a3b8', '#8b5cf6', '#e11d48'];
    const rEl = document.getElementById('rc-trend');
    if (rEl) new Chart(rEl, { type: 'line', data: { labels: trend.labels, datasets: trend.datasets.map((ds, i) => ({ label: ds.label, data: ds.data, borderColor: palette[i % 6], backgroundColor: palette[i % 6], borderWidth: 2, pointRadius: trend.labels.length > 40 ? 0 : 2, tension: 0 })) },
        options: { maintainAspectRatio: false, plugins: { legend: { position: 'top', align: 'end', labels: { boxWidth: 10 } } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
})();
</script>
<?php report_foot(); ?>
