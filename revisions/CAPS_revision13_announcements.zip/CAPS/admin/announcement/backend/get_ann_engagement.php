<?php
/**
 * get_ann_engagement.php — Engagement Overview of one announcement (admin View Announcement).
 *   GET ?id=N  → counts (views / likes / dislikes / comments) + who liked / disliked / commented
 * Read-only; data comes from the resident app (announcement_reactions / announcement_comments / announcement_reads).
 */
ob_start();
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_permission($pdo, 'announcements', 'read');
require_once __DIR__ . '/ann_engagement_helper.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Invalid announcement.']); exit; }
try {
    $counts = ann_engagement_counts($pdo, [$id])[$id];
    echo json_encode(['success' => true, 'counts' => $counts, 'people' => [
        'like' => ann_engagement_people($pdo, $id, 'like'),
        'dislike' => ann_engagement_people($pdo, $id, 'dislike'),
        'comment' => ann_engagement_people($pdo, $id, 'comment'),
    ]], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('[get_ann_engagement] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not load the engagement.']);
}
