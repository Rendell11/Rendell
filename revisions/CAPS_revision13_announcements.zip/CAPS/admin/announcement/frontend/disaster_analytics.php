<?php
/**
 * disaster_analytics.php — Disaster Analytics (Announcement module).
 * Same structure / behavior as Resident, Household and Legal Document Analytics:
 *   Start / End Date (+ category) → Apply; empty dates = all records
 *   Disaster Records directly below the dates, then AI Analytics (manual only),
 *   Data Interpretation, summary cards, charts and tables.
 *   Save PDF / Print → ../backend/disaster_analytics_report.php (shared CAPS report layout),
 *   asking whether to include the AI findings (never generates AI automatically).
 */

require_once __DIR__ . '/partials/analytics_bootstrap.php';
require_once __DIR__ . '/../backend/disaster_analytics_data.php';

$daParams = ra_params($_GET);
$daCategory = in_array($_GET['category'] ?? '', disaster_analytics_categories(), true) ? $_GET['category'] : 'All';
$daData = null;
try {
    $daData = disaster_analytics_compute($pdo, $daParams, $daCategory);
    $daData['interpretation'] = disaster_analytics_interpretation($daData);
} catch (Throwable $e) {
    error_log('[Disaster analytics] ' . $e->getMessage());
}

// ── AJAX: analytics data for the selected date range ─────────────────────────
if (($_GET['action'] ?? '') === 'data') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($daData ? ['success' => true] + $daData : ['success' => false, 'error' => 'Could not load the disaster analytics.'], JSON_UNESCAPED_UNICODE);
    exit;
}
$page_title = 'Disaster Analytics';
?>
<!DOCTYPE html>
<html <?php echo $theme_attrs['html']; ?>>

<head>
    <?php include __DIR__ . '/partials/analytics_head.php'; ?>
    <style>
        .kpi2 { border: 1px solid #eef2f7; border-radius: 20px; padding: 16px 18px; background: #fff }
        .kpi2 .k-label { font-size: 9px; font-weight: 900; text-transform: uppercase; letter-spacing: .08em; color: #64748b }
        .kpi2 .k-value { font-size: 26px; font-weight: 900; color: #0f172a; line-height: 1.1; margin-top: 4px; font-variant-numeric: tabular-nums }
        .kpi2 .k-sub { font-size: 10px; font-weight: 700; color: #94a3b8; margin-top: 2px }
        .chart-card { border: 1px solid #eef2f7; border-radius: 24px; padding: 20px; background: #fff; display: flex; flex-direction: column; min-width: 0 }
        .chart-card h3 { font-size: 14px; font-weight: 900; color: #1e293b }
        .chart-card .c-sub { font-size: 10px; font-weight: 700; color: #94a3b8; margin-top: 2px }
        .chart-box2 { position: relative; height: 250px; margin-top: 14px }
        details.tv { margin-top: 10px }
        details.tv summary { cursor: pointer; font-size: 10px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: .06em }
        table.dt { width: 100%; border-collapse: collapse; font-size: 12px }
        table.dt th { text-align: left; font-size: 9px; text-transform: uppercase; letter-spacing: .06em; color: #94a3b8; font-weight: 900; padding: 8px 10px; border-bottom: 1px solid #eef2f7; background: #f8fafc }
        table.dt td { padding: 8px 10px; border-bottom: 1px solid #f1f5f9; color: #334155; font-weight: 600 }
        table.dt td.num, table.dt th.num { text-align: right; font-variant-numeric: tabular-nums }
        table.dt tr.total td { font-weight: 900; border-top: 1.5px solid #cbd5e1; background: #f8fafc }
        .empty { font-size: 12px; color: #94a3b8; font-style: italic; text-align: center; padding: 40px 10px }
        .pill { display: inline-flex; align-items: center; padding: .15rem .55rem; border-radius: .5rem; font-size: 10px; font-weight: 800; text-transform: uppercase; }
    </style>
</head>

<body <?php echo $theme_attrs['body']; ?>>
    <div class="flex min-h-screen">
        <?php include __DIR__ . '/../../sidebar.php'; ?>

        <div class="flex-1 flex flex-col min-w-0 main-wrapper">
            <?php include __DIR__ . '/../../header.php'; ?>

            <main class="p-4 md:p-6 lg:p-8 space-y-7">
                <section class="rounded-2xl p-6 md:p-8 text-white relative overflow-hidden"
                    style="background: linear-gradient(135deg, var(--accent-700) 0%, var(--accent-600) 50%, var(--accent-700) 100%);">
                    <div class="absolute -right-12 -top-12 w-64 h-64 opacity-10 rounded-full blur-3xl pointer-events-none" style="background: var(--accent-400);"></div>
                    <div class="relative z-10 flex flex-col xl:flex-row xl:items-center xl:justify-between gap-5">
                        <div>
                            <div class="flex items-center gap-2 text-white/60 text-[10px] font-black uppercase tracking-[0.18em] mb-2"><span class="material-symbols-outlined text-base">crisis_alert</span>Announcements</div>
                            <h1 class="text-2xl md:text-3xl font-black tracking-tight leading-none">Disaster Analytics</h1>
                            <p class="text-white/65 text-sm mt-2 font-medium max-w-2xl">Disaster records, alerts, impact and response from the actual disaster data.</p>
                        </div>
                        <div class="flex flex-wrap items-center gap-3">
                            <button type="button" onclick="openReport('pdf')" class="btn bg-white text-slate-900 hover:bg-slate-100 shadow-lg"><span class="material-symbols-outlined" style="font-size:18px">picture_as_pdf</span>Save PDF</button>
                            <button type="button" onclick="openReport('print')" class="btn bg-white/10 hover:bg-white/20 border border-white/20 text-white"><span class="material-symbols-outlined" style="font-size:18px">print</span>Print</button>
                            <a href="ann.php" class="btn bg-white/10 hover:bg-white/20 border border-white/20 text-white"><span class="material-symbols-outlined" style="font-size:18px">arrow_back</span>Back to Announcements</a>
                        </div>
                    </div>
                </section>

                <!-- Date range -->
                <section class="panel p-5 md:p-6">
                    <form id="rangeForm" class="flex flex-wrap items-end gap-4" onsubmit="applyRange(event)">
                        <div><label for="startDate" class="section-title block mb-1.5">Start Date</label>
                            <input type="date" id="startDate" max="9999-12-31" class="field" value="<?php echo htmlspecialchars($daParams['start']); ?>"></div>
                        <div><label for="endDate" class="section-title block mb-1.5">End Date</label>
                            <input type="date" id="endDate" max="9999-12-31" class="field" value="<?php echo htmlspecialchars($daParams['end']); ?>"></div>
                        <div><label for="category" class="section-title block mb-1.5">Category</label>
                            <select id="category" class="field cursor-pointer pr-8">
                                <option value="All">All Categories</option>
                                <?php foreach (disaster_analytics_categories() as $c): ?>
                                    <option value="<?php echo $c; ?>" <?php echo $daCategory === $c ? 'selected' : ''; ?>><?php echo $c; ?></option>
                                <?php endforeach; ?>
                            </select></div>
                        <button type="submit" class="btn btn-dark"><span class="material-symbols-outlined" style="font-size:16px">filter_alt</span>Apply</button>
                        <button type="button" onclick="clearRange()" class="btn btn-light">Clear</button>
                        <div class="ml-auto text-right">
                            <p class="section-title">Showing</p>
                            <p id="rangeLabel" class="text-sm font-black text-slate-800"></p>
                            <p id="rangeBasis" class="text-[10px] font-bold text-slate-400"></p>
                        </div>
                    </form>
                </section>

                <!-- Disaster Records (directly below the dates) -->
                <section class="panel overflow-hidden">
                    <div class="px-6 pt-6 pb-4 flex flex-wrap items-end justify-between gap-3">
                        <div class="flex items-center gap-3">
                            <span class="material-symbols-outlined text-white bg-primary p-2 rounded-xl">folder_open</span>
                            <div><h2 class="text-lg font-black text-slate-800">Disaster Records</h2>
                                <p class="text-[10px] text-slate-400 font-bold">Every disaster report in the selected range. Click View to open, print or download a single report.</p></div>
                        </div>
                        <div class="relative w-full sm:w-64">
                            <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" style="font-size:16px">search</span>
                            <input type="text" id="recordSearch" placeholder="Search title, type or ref no…" oninput="renderRecords()" class="field w-full !pl-9">
                        </div>
                    </div>
                    <div class="overflow-x-auto max-h-[560px] overflow-y-auto">
                        <table class="w-full data-table">
                            <thead class="sticky top-0 z-[1]"><tr><th>Disaster</th><th>Severity</th><th>Date Issued</th><th>Date Deactivated</th><th class="!text-right">Affected</th><th class="!text-right">Evacuees</th><th class="!text-right">Injuries</th><th class="!text-right">Casualties</th><th>Status</th><th class="!text-right">Actions</th></tr></thead>
                            <tbody id="recordsBody"></tbody>
                        </table>
                    </div>
                    <p class="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase border-t border-slate-100" id="recordsCount">—</p>
                </section>

                <!-- AI Analytics (manual only) -->
                <section class="panel p-6 md:p-8">
                    <div class="flex flex-wrap items-center justify-between gap-4">
                        <div class="flex items-center gap-3">
                            <span class="material-symbols-outlined text-white bg-indigo-600 p-2 rounded-xl">auto_awesome</span>
                            <div><h2 class="text-lg font-black text-slate-800">AI Analytics</h2>
                                <p id="aiStatus" class="text-[10px] text-slate-400 font-bold">Not generated. AI runs only when you click the button.</p></div>
                        </div>
                        <button type="button" id="aiBtn" onclick="generateAi()" class="btn btn-dark"><span class="material-symbols-outlined" style="font-size:16px">auto_awesome</span><span id="aiBtnText">Generate AI Analytics</span></button>
                    </div>
                    <div id="aiBody" class="mt-6"></div>
                </section>

                <!-- Data Interpretation (directly below AI Analytics) -->
                <div id="raInterp"></div>
                <div id="raBody" class="space-y-7"></div>
            </main>
        </div>
    </div>

    <!-- Save PDF / Print: include AI findings? -->
    <div id="reportModal" class="fixed inset-0 z-[999] hidden bg-slate-900/70 items-center justify-center p-4" onclick="if (event.target === this) closeReport()">
        <div class="bg-white rounded-[2rem] shadow-2xl w-full max-w-md p-8" role="dialog" aria-modal="true" aria-labelledby="rmTitle">
            <div class="flex items-start justify-between gap-4">
                <div>
                    <h3 id="rmTitle" class="text-2xl font-black text-slate-900 tracking-tight">Save as PDF</h3>
                    <p class="text-[11px] font-black text-indigo-600 uppercase tracking-widest mt-1">Disaster Analytics Report</p>
                    <p id="rmRange" class="text-xs font-bold text-slate-400 mt-1"></p>
                </div>
                <button type="button" onclick="closeReport()" class="p-1 text-slate-400 hover:text-slate-700" aria-label="Close"><span class="material-symbols-outlined">close</span></button>
            </div>
            <p class="text-sm font-bold text-slate-700 mt-6 mb-3">Include AI findings in the report?</p>
            <div class="space-y-3">
                <label class="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 cursor-pointer hover:border-indigo-300">
                    <input type="radio" name="rmAi" value="0" class="mt-1 text-indigo-600 focus:ring-indigo-500" checked>
                    <span><span class="block text-sm font-black text-slate-800">No AI – Data and tables only</span>
                        <span class="block text-[11px] font-semibold text-slate-400">Records, summary, statistics, tables and data interpretation.</span></span>
                </label>
                <label class="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 cursor-pointer hover:border-indigo-300">
                    <input type="radio" name="rmAi" value="1" class="mt-1 text-indigo-600 focus:ring-indigo-500">
                    <span><span class="block text-sm font-black text-slate-800">Include AI – Data, charts, and AI explanation</span>
                        <span class="block text-[11px] font-semibold text-slate-400">Uses the AI Analytics already generated on this page.</span></span>
                </label>
            </div>
            <p id="rmError" class="hidden mt-4 text-xs font-bold text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-3 py-2">Please generate AI Analytics first.</p>
            <div class="flex justify-end gap-3 mt-8">
                <button type="button" onclick="closeReport()" class="btn btn-light">Cancel</button>
                <button type="button" onclick="continueReport()" class="btn btn-dark">Continue</button>
            </div>
        </div>
    </div>

    <!-- ── View Disaster Report Modal (Disaster ID · Title · Type · Severity · Message · Channels · SMS Live · Deactivation Report) ── -->
    <div id="viewDisasterReportModal"
        class="fixed inset-0 z-[110] hidden bg-slate-900/80 flex items-center justify-center p-6">
        <div
            class="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-2xl overflow-hidden border border-white/20 max-h-[92vh] flex flex-col">
            <div class="px-10 pt-10 pb-6 flex items-start justify-between border-b border-slate-100 flex-shrink-0">
                <div class="min-w-0">
                    <div class="flex items-center gap-2 mb-2">
                        <span id="drv_severity_badge"
                            class="inline-block px-3 py-1 rounded-full text-[8px] font-black text-white"></span>
                        <span id="drv_status_badge"
                            class="inline-block px-3 py-1 rounded-full text-[8px] font-black uppercase"></span>
                    </div>
                    <h3 id="drv_title" class="text-xl font-black tracking-tight text-slate-900 leading-tight truncate">
                    </h3>
                    <p
                        class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1.5 flex items-center gap-3">
                        <span id="drv_id"></span>
                        <span class="text-slate-300">•</span>
                        <span id="drv_type" class="flex items-center gap-1"></span>
                    </p>
                </div>
                <button onclick="closeModal('viewDisasterReportModal')"
                    class="p-2 hover:bg-orange-50 rounded-full text-slate-400 hover:text-primary transition-colors shrink-0">
                    <span class="material-symbols-outlined">close</span>
                </button>
            </div>

            <div class="p-8 overflow-y-auto space-y-5">
                <div class="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                    <label class="text-[9px] font-black uppercase text-slate-400 tracking-[0.2em] block mb-2">Message /
                        Emergency Instructions</label>
                    <p id="drv_message" class="text-slate-700 text-sm font-medium leading-relaxed"></p>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div class="flex items-center gap-3 bg-slate-50 border border-slate-100 rounded-xl py-3.5 px-4">
                        <span class="material-symbols-outlined text-slate-400" style="font-size:18px">smartphone</span>
                        <div>
                            <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest">App Notification
                            </p>
                            <p id="drv_notify_app" class="text-xs font-black text-slate-700"></p>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 bg-slate-50 border border-slate-100 rounded-xl py-3.5 px-4">
                        <span class="material-symbols-outlined text-slate-400" style="font-size:18px">sms</span>
                        <div>
                            <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest">SMS Broadcast</p>
                            <p id="drv_notify_sms" class="text-xs font-black text-slate-700"></p>
                        </div>
                    </div>
                </div>

                <!-- SMS Live — shows whether the text for this disaster actually went out -->
                <div>
                    <label class="text-[9px] font-black uppercase text-slate-400 tracking-[0.2em] block mb-2">SMS Live
                        Status</label>
                    <div id="drv_sms_live" class="space-y-2"></div>
                </div>

                <!-- Deactivation / final report form data submitted by admin -->
                <div class="pt-2 border-t border-slate-100">
                    <label class="text-[9px] font-black uppercase text-slate-400 tracking-[0.2em] block mb-3">Final
                        Report (submitted on deactivation)</label>
                    <div class="grid grid-cols-4 gap-2 mb-3">
                        <div class="p-3 bg-slate-50 rounded-xl text-center">
                            <p class="text-[8px] font-bold text-slate-400 uppercase">Affected</p>
                            <p id="drv_affected" class="text-sm font-black text-slate-700"></p>
                        </div>
                        <div class="p-3 bg-slate-50 rounded-xl text-center">
                            <p class="text-[8px] font-bold text-slate-400 uppercase">Evacuees</p>
                            <p id="drv_evacuees" class="text-sm font-black text-slate-700"></p>
                        </div>
                        <div class="p-3 bg-amber-50 rounded-xl text-center">
                            <p class="text-[8px] font-bold text-amber-500 uppercase">Injuries</p>
                            <p id="drv_injuries" class="text-sm font-black text-amber-700"></p>
                        </div>
                        <div class="p-3 bg-rose-50 rounded-xl text-center">
                            <p class="text-[8px] font-bold text-rose-500 uppercase">Casualties</p>
                            <p id="drv_casualties" class="text-sm font-black text-rose-700"></p>
                        </div>
                    </div>
                    <div class="space-y-3">
                        <div class="p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100">
                            <p class="text-[9px] font-bold text-indigo-600 uppercase tracking-widest mb-1">Damage
                                Assessment</p>
                            <p id="drv_damage" class="text-xs text-slate-600 font-medium"></p>
                        </div>
                        <div class="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100">
                            <p class="text-[9px] font-bold text-emerald-600 uppercase tracking-widest mb-1">Response
                                Actions</p>
                            <p id="drv_actions" class="text-xs text-slate-600 font-medium"></p>
                        </div>
                    </div>
                    <!-- Signatories — duty officer is the account that deactivated the disaster -->
                    <div class="grid grid-cols-2 gap-3 mt-3">
                        <div class="flex items-center gap-3 bg-slate-50 border border-slate-100 rounded-xl py-3.5 px-4">
                            <span class="material-symbols-outlined text-slate-400" style="font-size:18px">badge</span>
                            <div class="min-w-0">
                                <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Duty Officer
                                </p>
                                <p id="drv_duty_officer" class="text-xs font-black text-slate-700 truncate"></p>
                            </div>
                        </div>
                        <div class="flex items-center gap-3 bg-slate-50 border border-slate-100 rounded-xl py-3.5 px-4">
                            <span class="material-symbols-outlined text-slate-400"
                                style="font-size:18px">workspace_premium</span>
                            <div class="min-w-0">
                                <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Barangay
                                    Captain</p>
                                <p id="drv_captain" class="text-xs font-black text-slate-700 truncate"></p>
                            </div>
                        </div>
                    </div>

                    <p class="text-right text-[10px] font-bold text-slate-400 uppercase mt-3">Date Deactivated: <span
                            id="drv_date"></span></p>
                </div>
            </div>

            <div class="p-6 bg-slate-50/50 border-t border-slate-100 flex-shrink-0 flex flex-wrap gap-3 justify-end">
                <button onclick="closeModal('viewDisasterReportModal')"
                    class="px-6 py-3.5 text-xs font-black uppercase text-slate-400 hover:text-slate-700 border border-slate-200 hover:border-slate-300 rounded-2xl transition-all">Close</button>
                <button onclick="downloadCurrentDisasterReportPDF()"
                    class="flex items-center gap-2 px-6 py-3.5 bg-indigo-50 text-indigo-600 rounded-2xl text-xs font-black uppercase hover:bg-indigo-100 transition-all">
                    <span class="material-symbols-outlined" style="font-size:16px">picture_as_pdf</span> Download PDF
                </button>
                <button onclick="printCurrentDisasterReport()"
                    class="flex items-center gap-2 px-6 py-3.5 btn-dark rounded-2xl text-xs font-black uppercase shadow-lg active:scale-95 transition-all">
                    <span class="material-symbols-outlined" style="font-size:16px">print</span> Print
                </button>
            </div>
        </div>
    </div>

    <script src="assets/analytics_report.js"></script>
    <script>
        const TYPE_COLORS = { Flood: '#2a78d6', Fire: '#e11d48', Earthquake: '#eb6834', Typhoon: '#1baf7a' };
        const EXTRA_COLORS = ['#6366f1', '#8b5cf6', '#14b8a6', '#eab308', '#ec4899', '#64748b'];
        const SEV_COLORS = { Low: '#10b981', Medium: '#f59e0b', High: '#f97316', Critical: '#e11d48', Extreme: '#9f1239' };
        const disasterIconMap = { Typhoon: 'cyclone', Flood: 'waves', Fire: 'local_fire_department', Earthquake: 'landslide' };
        const COLORS = { s1: '#2a78d6', s2: '#eb6834', s3: '#1baf7a', muted: '#94a3b8', grid: '#eef2f7' };
        const charts = {};
        let DATA = <?php echo json_encode($daData ? ['success' => true] + $daData : null, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?>;
        let DA_AI = null;
        const esc = AnalyticsReport.esc, num = AnalyticsReport.num;
        const pct = (v, d) => d ? (Math.round(Number(v || 0) / d * 1000) / 10) + '%' : '0%';
        const sum = o => Object.values(o).reduce((s, v) => s + Number(v || 0), 0);

        function openModal(id) { document.getElementById(id).classList.remove('hidden'); }
        function closeModal(id) { document.getElementById(id).classList.add('hidden'); }
        function showToast(type, msg) { alert(msg); }
        function typeColor(t, i) { return TYPE_COLORS[t] || EXTRA_COLORS[i % EXTRA_COLORS.length]; }
        function fmtDate(d, withTime) {
            if (!d) return '—';
            const dt = new Date(String(d).replace(' ', 'T'));
            if (isNaN(dt)) return d;
            const s = dt.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
            return withTime ? s + ' · ' + dt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) : s;
        }
        if (window.Chart) {
            Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";
            Chart.defaults.font.size = 11;
            Chart.defaults.color = '#64748b';
            Chart.defaults.plugins.tooltip.backgroundColor = '#0f172a';
            Chart.defaults.plugins.tooltip.padding = 10;
        }

        /* ───────── Rendering helpers (same as the other analytics pages) ───────── */
        function kpi(label, value, sub) { return `<div class="kpi2"><p class="k-label">${esc(label)}</p><p class="k-value">${esc(value)}</p>${sub ? `<p class="k-sub">${esc(sub)}</p>` : ''}</div>`; }
        function card(id, title, sub, opts = {}) {
            return `<div class="chart-card ${opts.span || ''}"><h3>${esc(title)}</h3><p class="c-sub">${esc(sub)}</p>
                ${opts.empty ? `<p class="empty">${esc(opts.empty)}</p>` : `<div class="chart-box2"><canvas id="${id}" role="img" aria-label="${esc(title)}"></canvas></div>`}
                ${opts.table ? `<details class="tv"><summary>View table</summary><div class="mt-2 overflow-x-auto">${opts.table}</div></details>` : ''}</div>`;
        }
        function table(head, rows, numCols = []) {
            if (!rows.length) return '<p class="empty">No data for the selected range.</p>';
            return `<table class="dt"><thead><tr>${head.map((h, i) => `<th class="${numCols.includes(i) ? 'num' : ''}">${esc(h)}</th>`).join('')}</tr></thead><tbody>` +
                rows.map(r => `<tr class="${r[0] === 'Total' ? 'total' : ''}">${r.map((c, i) => `<td class="${numCols.includes(i) ? 'num' : ''}">${esc(c)}</td>`).join('')}</tr>`).join('') + '</tbody></table>';
        }
        function distRows(obj, base) {
            const rows = Object.entries(obj).map(([k, v]) => [k, num(v), pct(v, base)]);
            if (rows.length) rows.push(['Total', num(sum(obj)), pct(sum(obj), base)]);
            return rows;
        }
        function section(icon, title, sub, inner) {
            return `<section class="panel p-6 md:p-8"><div class="flex items-center gap-3 mb-6"><span class="material-symbols-outlined text-white bg-primary p-2 rounded-xl">${icon}</span>
                <div><h2 class="text-lg font-black text-slate-800">${esc(title)}</h2><p class="text-[10px] text-slate-400 font-bold">${esc(sub)}</p></div></div>${inner}</section>`;
        }
        const axisCount = { beginAtZero: true, ticks: { precision: 0 }, grid: { color: COLORS.grid }, border: { display: false } };
        const noGrid = { grid: { display: false }, border: { display: false } };
        const legendTop = { position: 'top', align: 'end', labels: { boxWidth: 10, boxHeight: 10 } };
        function mk(id, cfg) { const el = document.getElementById(id); if (!el) return; cfg.options = Object.assign({ maintainAspectRatio: false }, cfg.options || {}); charts[id] = new Chart(el, cfg); }
        function donut(id, obj, colorOf, base) {
            const e = Object.entries(obj).filter(([, v]) => v > 0);
            mk(id, { type: 'doughnut', data: { labels: e.map(x => x[0]), datasets: [{ data: e.map(x => x[1]), backgroundColor: e.map((x, i) => colorOf(x[0], i)), borderColor: '#fff', borderWidth: 2 }] },
                options: { cutout: '62%', plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, boxHeight: 10 } }, tooltip: { callbacks: { label: c => ` ${c.label}: ${num(c.raw)} (${pct(c.raw, base)})` } } } } });
        }

        /* ───────── Page ───────── */
        function render() {
            Object.values(charts).forEach(c => c.destroy());
            for (const k in charts) delete charts[k];
            const body = document.getElementById('raBody');
            document.getElementById('raInterp').innerHTML = '';
            if (!DATA) { body.innerHTML = '<section class="panel p-8"><p class="empty">Unable to load the disaster analytics.</p></section>'; renderRecords(); return; }
            const d = DATA, s = d.summary, A = s.total_alerts;
            document.getElementById('rangeLabel').textContent = d.range.label + (d.category !== 'All' ? ' · ' + d.category : '');
            document.getElementById('rangeBasis').textContent = d.range.open ? 'All disaster records on file' : 'Alerts issued within the range';

            let html = section('crisis_alert', 'Disaster Summary', 'Alerts by date issued; impact figures from the final reports · ' + d.range.label,
                `<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
                    ${kpi('Disaster Alerts', num(A), d.comparison ? (A - s.prev_total >= 0 ? '+' : '') + (A - s.prev_total) + ' vs previous period' : 'alerts issued')}
                    ${kpi('Still Active', num(s.active_alerts), num(s.deactivated_alerts) + ' deactivated')}
                    ${kpi('Final Reports', num(s.reports), 'filed on deactivation')}
                    ${kpi('High / Critical', num(s.high_severity), pct(s.high_severity, A) + ' of alerts')}
                    ${kpi('Most Frequent', s.most_frequent || '—', s.peak_label ? 'peak ' + s.peak_label : '')}
                    ${kpi('Affected Residents', num(s.affected), 'from final reports')}
                    ${kpi('Evacuees', num(s.evacuees), 'from final reports')}
                    ${kpi('Injuries', num(s.injuries), 'from final reports')}
                    ${kpi('Casualties', num(s.casualties), 'from final reports')}
                    ${kpi('SMS Delivered', num(s.sms_sent), num(s.sms_broadcasts) + ' broadcast(s) · ' + num(s.sms_recipients) + ' recipients')}
                </div>`);

            const typeRows = d.by_type.map(t => [t.type, num(t.alerts), pct(t.alerts, A), num(t.reports), num(t.affected), num(t.evacuees), num(t.injuries), num(t.casualties)]);
            if (typeRows.length) typeRows.push(['Total', num(A), A ? '100%' : '0%', num(s.reports), num(s.affected), num(s.evacuees), num(s.injuries), num(s.casualties)]);
            html += section('category', 'Categories & Impact', 'Alerts, reports and impact per disaster category',
                `<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    ${card('c-cat', 'Category Breakdown', 'Share of alerts', { empty: A ? '' : 'No alerts in this range.' })}
                    ${card('c-impact', 'Impact by Category', 'Affected, evacuees, injuries and casualties', { span: 'lg:col-span-2', empty: s.reports ? '' : 'No final reports in this range.' })}
                </div>
                <div class="mt-6 chart-card"><h3>Category Breakdown Summary</h3><p class="c-sub">Per disaster category</p>
                    <div class="mt-3 overflow-x-auto">${table(['Category', 'Alerts', 'Share', 'Reports', 'Affected', 'Evacuees', 'Injuries', 'Casualties'], typeRows, [1, 2, 3, 4, 5, 6, 7])}</div></div>`);

            html += section('donut_large', 'Severity, Status & Notification', 'How the alerts were classified, closed out and sent',
                `<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    ${card('c-sev', 'Severity Levels', 'Alerts per severity', { empty: A ? '' : 'No alerts.', table: table(['Severity', 'Alerts', 'Share'], distRows(d.by_severity, A), [1, 2]) })}
                    ${card('c-status', 'Final Report Status', 'Resolved / Closed / Cancelled', { empty: s.reports ? '' : 'No reports.', table: table(['Status', 'Reports', 'Share'], distRows(d.by_report_status, s.reports), [1, 2]) })}
                    ${card('c-channel', 'Notification Channels', 'App, SMS, both or none', { empty: A ? '' : 'No alerts.', table: table(['Channel', 'Alerts', 'Share'], distRows(d.channels, A), [1, 2]) })}
                </div>`);

            let comparison = '';
            if (d.comparison) comparison = `<div class="chart-card"><h3>Selected Period vs Previous Period</h3><p class="c-sub">Previous period: ${esc(d.comparison.previous_label)}</p>
                <div class="chart-box2"><canvas id="c-compare"></canvas></div>
                <div class="mt-3 overflow-x-auto">${table(['Indicator', 'Selected', 'Previous', 'Change'], d.comparison.rows.map(r => [r.metric, num(r.current), num(r.previous), (r.current - r.previous > 0 ? '+' : '') + num(r.current - r.previous)]), [1, 2, 3])}</div></div>`;
            html += section('insights', 'Trend & Comparison', 'Alerts over time, by weekday and against the previous period',
                `<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    ${card('c-trend', 'Alerts over Time', 'Per ' + d.trend.granularity + ', by category', { span: 'lg:col-span-2', empty: d.trend.labels.length > 1 ? '' : 'Not enough data for a trend.' })}
                    ${card('c-weekday', 'Alerts by Day of Week', 'Which days alerts were issued', { empty: A ? '' : 'No alerts.', table: table(['Day', 'Alerts', 'Share'], distRows(d.weekday, A), [1, 2]) })}
                    ${comparison}
                </div>`);

            document.getElementById('raInterp').innerHTML = section('fact_check', 'Data Interpretation', 'Automatic summary of the disaster figures (no AI) · ' + d.range.label,
                `<ol class="list-decimal pl-5 space-y-2 text-sm text-slate-600 font-medium">${(d.interpretation || []).map(x => `<li>${esc(x)}</li>`).join('')}</ol>`);
            body.innerHTML = html;
            renderRecords();

            if (!window.Chart) return;
            if (A) donut('c-cat', Object.fromEntries(d.by_type.map(t => [t.type, t.alerts])), (k, i) => typeColor(k, i), A);
            if (s.reports) mk('c-impact', { type: 'bar', data: { labels: d.by_type.map(t => t.type), datasets: [
                { label: 'Affected', data: d.by_type.map(t => t.affected), backgroundColor: COLORS.s1, borderRadius: 4, maxBarThickness: 22 },
                { label: 'Evacuees', data: d.by_type.map(t => t.evacuees), backgroundColor: COLORS.s3, borderRadius: 4, maxBarThickness: 22 },
                { label: 'Injuries', data: d.by_type.map(t => t.injuries), backgroundColor: '#f59e0b', borderRadius: 4, maxBarThickness: 22 },
                { label: 'Casualties', data: d.by_type.map(t => t.casualties), backgroundColor: '#e11d48', borderRadius: 4, maxBarThickness: 22 }] },
                options: { plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
            if (A) mk('c-sev', { type: 'bar', data: { labels: Object.keys(d.by_severity), datasets: [{ label: 'Alerts', data: Object.values(d.by_severity), backgroundColor: Object.keys(d.by_severity).map(k => SEV_COLORS[k] || COLORS.muted), borderRadius: 4, maxBarThickness: 36 }] },
                options: { plugins: { legend: { display: false } }, scales: { x: noGrid, y: axisCount } } });
            if (s.reports) donut('c-status', d.by_report_status, k => ({ Resolved: COLORS.s3, Closed: COLORS.s1, Cancelled: COLORS.muted })[k] || COLORS.s2, s.reports);
            if (A) donut('c-channel', d.channels, k => ({ 'App Notification': COLORS.s1, 'SMS Broadcast': COLORS.s2, 'Both': COLORS.s3, 'None': '#cbd5e1' })[k], A);
            if (d.trend.labels.length > 1) mk('c-trend', { type: 'line', data: { labels: d.trend.labels, datasets: d.trend.datasets.map((ds, i) => ({ label: ds.label, data: ds.data, borderColor: typeColor(ds.label, i), backgroundColor: typeColor(ds.label, i), borderWidth: 2, pointRadius: d.trend.labels.length > 40 ? 0 : 3, tension: 0 })) },
                options: { interaction: { mode: 'index', intersect: false }, plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
            if (A) mk('c-weekday', { type: 'bar', data: { labels: Object.keys(d.weekday), datasets: [{ label: 'Alerts', data: Object.values(d.weekday), backgroundColor: COLORS.s1, borderRadius: 4, maxBarThickness: 36 }] },
                options: { plugins: { legend: { display: false } }, scales: { x: noGrid, y: axisCount } } });
            if (d.comparison) mk('c-compare', { type: 'bar', data: { labels: d.comparison.rows.map(r => r.metric), datasets: [
                { label: 'Selected period', data: d.comparison.rows.map(r => r.current), backgroundColor: COLORS.s1, borderRadius: 4, maxBarThickness: 40 },
                { label: 'Previous period', data: d.comparison.rows.map(r => r.previous), backgroundColor: COLORS.muted, borderRadius: 4, maxBarThickness: 40 }] },
                options: { plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
        }

        function filteredRecords() {
            const q = (document.getElementById('recordSearch').value || '').toLowerCase().trim();
            return (DATA ? DATA.reports : []).filter(r => !q || [r.Title, r.Type, r.ReportNo].some(v => String(v || '').toLowerCase().includes(q)));
        }
        function renderRecords() {
            const tb = document.getElementById('recordsBody');
            if (!DATA) { tb.innerHTML = ''; document.getElementById('recordsCount').textContent = '—'; return; }
            const list = filteredRecords();
            document.getElementById('recordsCount').textContent = `Showing ${list.length} of ${DATA.reports.length} report(s)`;
            if (!list.length) {
                tb.innerHTML = `<tr><td colspan="10" class="!py-14 text-center"><span class="material-symbols-outlined !text-4xl text-slate-200">folder_off</span>
                    <p class="text-[10px] font-bold text-slate-400 uppercase mt-2 tracking-widest">No disaster records found</p></td></tr>`;
                return;
            }
            tb.innerHTML = list.map(r => {
                const sev = r.AlertSeverity || r.Severity || 'Medium';
                const idx = DATA.reports.indexOf(r);
                return `<tr class="border-l-4 ${drAccentClass(sev)}">
                    <td><div class="flex items-center gap-3">
                        <span class="w-8 h-8 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center flex-shrink-0"><span class="material-symbols-outlined" style="font-size:16px">${disasterIconMap[r.Type] || 'emergency'}</span></span>
                        <div class="min-w-0"><p class="text-xs font-bold text-slate-700 truncate max-w-[220px]">${esc(r.Title || 'Untitled Report')}</p>
                        <p class="text-[10px] font-medium text-slate-400 uppercase">${esc(r.Type || 'Unknown')} · ${esc(r.ReportNo)}</p></div></div></td>
                    <td><span class="pill ${drSeverityClass(sev)}">${esc(sev)}</span></td>
                    <td class="whitespace-nowrap">${fmtDate(r.AlertCreatedAt)}</td>
                    <td class="whitespace-nowrap">${fmtDate(r.CreatedAt, true)}</td>
                    <td class="text-right">${num(r.AffectedResidents || 0)}</td><td class="text-right">${num(r.Evacuees || 0)}</td>
                    <td class="text-right">${num(r.Injuries || 0)}</td><td class="text-right">${num(r.Casualties || 0)}</td>
                    <td><span class="pill ${drStatusClass(r.Status || 'Resolved')}">${esc(r.Status || 'Resolved')}</span></td>
                    <td class="text-right"><button type="button" onclick="openDisasterReportModal(DATA.reports[${idx}])"
                        class="inline-flex items-center gap-1 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-lg px-3 py-1.5 text-[10px] font-black uppercase tracking-widest">
                        <span class="material-symbols-outlined" style="font-size:14px">visibility</span> View</button></td>
                </tr>`;
            }).join('');
        }

        /* ───────── Date range ───────── */
        function rangeParams() {
            return { start: document.getElementById('startDate').value, end: document.getElementById('endDate').value, category: document.getElementById('category').value };
        }
        async function applyRange(e) {
            if (e) e.preventDefault();
            const p = rangeParams();
            if (p.start && p.end && p.start > p.end) { alert('The Start Date must be on or before the End Date.'); return; }
            const q = new URLSearchParams(p);
            history.replaceState({}, '', location.pathname + '?' + q.toString());
            document.getElementById('raBody').style.opacity = '.5';
            try {
                const r = await fetch('disaster_analytics.php?action=data&' + q.toString(), { credentials: 'same-origin' });
                const j = await r.json();
                if (!j.success) throw new Error(j.error || 'Unable to load the disaster analytics.');
                DATA = j;
            } catch (err) { alert(err.message); }
            document.getElementById('raBody').style.opacity = '';
            render(); resetAi(); loadCachedAi();
        }
        function clearRange() { document.getElementById('startDate').value = ''; document.getElementById('endDate').value = ''; document.getElementById('category').value = 'All'; applyRange(); }

        /* ───────── AI Analytics (only on click) ───────── */
        function resetAi() {
            DA_AI = null;
            document.getElementById('aiBody').innerHTML = '';
            document.getElementById('aiStatus').textContent = 'Not generated for this date range. AI runs only when you click the button.';
            document.getElementById('aiBtnText').textContent = 'Generate AI Analytics';
        }
        function renderAi(x) {
            DA_AI = x;
            document.getElementById('aiStatus').textContent = 'Generated ' + (x.generated_at || '') + ' · ' + (x.period?.label || '') + (x.cached ? ' · saved result' : '');
            document.getElementById('aiBtnText').textContent = 'Regenerate AI Analytics';
            const group = (title, icon, list) => list && list.length ? `<div class="rounded-2xl border border-indigo-100 bg-indigo-50/40 p-5"><div class="flex items-center gap-2 mb-3"><span class="material-symbols-outlined text-indigo-600">${icon}</span><h5 class="text-[10px] font-black uppercase tracking-widest text-indigo-700">${esc(title)}</h5></div>
                <ul class="space-y-2">${list.map(f => `<li class="text-xs leading-relaxed text-slate-600"><strong class="text-slate-800">${esc(f.title)}</strong> — ${esc(f.detail)}</li>`).join('')}</ul></div>` : '';
            const recs = (x.recommendations || []).map((f, i) => `<li class="text-xs leading-relaxed text-slate-600"><strong class="text-slate-800">${i + 1}. ${esc(f.action)}</strong>
                <span class="ml-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${f.priority === 'high' ? 'bg-rose-100 text-rose-700' : f.priority === 'low' ? 'bg-slate-100 text-slate-600' : 'bg-amber-100 text-amber-700'}">${esc(f.priority)}</span><br>${esc(f.reason)}</li>`).join('');
            document.getElementById('aiBody').innerHTML =
                (x.summary ? `<p class="text-sm font-semibold text-slate-700 mb-5">${esc(x.summary)}</p>` : '') +
                `<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">${group('Key Findings', 'insights', x.key_findings)}${group('Trends', 'trending_up', x.demographic_trends)}
                 ${group('Significant Changes / Patterns', 'timeline', x.patterns)}${group('Impact & Response Observations', 'emergency', x.population_observations)}</div>` +
                (recs ? `<div class="rounded-2xl border border-indigo-100 bg-white p-5 mt-4"><div class="flex items-center gap-2 mb-3"><span class="material-symbols-outlined text-indigo-600">task_alt</span><h5 class="text-[10px] font-black uppercase tracking-widest text-indigo-700">Recommended Actions</h5></div><ul class="space-y-3">${recs}</ul></div>` : '') +
                '<p class="text-[10px] text-slate-400 font-bold mt-4">AI-generated from aggregated disaster figures only. Verify against the tables below.</p>';
        }
        async function aiRequest(cachedOnly) {
            const fd = new FormData();
            fd.append('csrf_token', CSRF_TOKEN);
            fd.append('start', DATA?.period?.start || '');
            fd.append('end', DATA?.period?.end || '');
            fd.append('category', DATA?.category || 'All');
            if (cachedOnly) fd.append('cached_only', '1');
            const r = await fetch('../backend/disaster_ai_summary.php', { method: 'POST', body: fd, credentials: 'same-origin' });
            let j = null; try { j = await r.json(); } catch (e) { throw new Error('The AI service returned an invalid response.'); }
            if (!j || !j.success) throw new Error(j?.error || 'AI Analytics is unavailable right now.');
            return j;
        }
        async function generateAi() {
            if (!DATA) return;
            const btn = document.getElementById('aiBtn');
            btn.disabled = true;
            document.getElementById('aiBtnText').textContent = 'Generating…';
            document.getElementById('aiStatus').textContent = 'Generating AI Analytics for ' + DATA.range.label + '…';
            try { renderAi(await aiRequest(false)); }
            catch (e) { document.getElementById('aiStatus').textContent = e.message; document.getElementById('aiBtnText').textContent = DA_AI ? 'Regenerate AI Analytics' : 'Generate AI Analytics'; }
            btn.disabled = false;
        }
        async function loadCachedAi() { if (!DATA) return; try { const j = await aiRequest(true); if (j.ai) renderAi(j); } catch (e) { } }

        /* ───────── Save PDF / Print ───────── */
        let _reportMode = 'pdf';
        function openReport(mode) {
            _reportMode = mode;
            document.getElementById('rmTitle').textContent = mode === 'pdf' ? 'Save as PDF' : 'Print';
            document.getElementById('rmRange').textContent = DATA ? DATA.range.label + (DATA.category !== 'All' ? ' · ' + DATA.category : '') : '';
            document.querySelector('input[name="rmAi"][value="0"]').checked = true;
            document.getElementById('rmError').classList.add('hidden');
            const m = document.getElementById('reportModal'); m.classList.remove('hidden'); m.classList.add('flex');
        }
        function closeReport() { const m = document.getElementById('reportModal'); m.classList.add('hidden'); m.classList.remove('flex'); }
        function continueReport() {
            const withAi = document.querySelector('input[name="rmAi"]:checked')?.value === '1';
            // Never generates AI here — only uses the analysis already generated on this page.
            if (withAi && !DA_AI) { document.getElementById('rmError').classList.remove('hidden'); return; }
            const q = new URLSearchParams({ mode: _reportMode, start: DATA?.period?.start || '', end: DATA?.period?.end || '', category: DATA?.category || 'All', ai: withAi ? '1' : '0' });
            closeReport();
            window.open('../backend/disaster_analytics_report.php?' + q.toString(), '_blank');
        }
        document.addEventListener('keydown', e => { if (e.key === 'Escape') closeReport(); });
        document.querySelectorAll('input[name="rmAi"]').forEach(r => r.addEventListener('change', () => document.getElementById('rmError').classList.add('hidden')));

        // ── Single disaster report: View / Print / Download PDF (moved from ann.php) ──
        let currentDisasterReport = null;
        const drTypeIcons = { Typhoon: 'cyclone', Flood: 'waves', Fire: 'local_fire_department', Earthquake: 'landslide' };

        function drSeverityClass(sev) {
            if (['Critical', 'Extreme'].includes(sev)) return 'bg-rose-100 text-rose-600';
            if (sev === 'High') return 'bg-orange-100 text-orange-600';
            if (sev === 'Medium') return 'bg-amber-100 text-amber-600';
            if (sev === 'Low') return 'bg-emerald-100 text-emerald-600';
            return 'bg-slate-100 text-slate-600';
        }
        function drAccentClass(sev) {
            if (['Critical', 'Extreme'].includes(sev)) return 'border-l-rose-400';
            if (sev === 'High') return 'border-l-orange-400';
            if (sev === 'Medium') return 'border-l-amber-400';
            return 'border-l-emerald-400';
        }
        function drStatusClass(status) {
            if (status === 'Resolved') return 'bg-emerald-100 text-emerald-600';
            if (status === 'Closed') return 'bg-blue-100 text-blue-600';
            if (status === 'Cancelled') return 'bg-slate-200 text-slate-500';
            return 'bg-slate-100 text-slate-500';
        }

        function escapeHtml(str) {
            return String(str ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
        }

        // ── View Disaster Report modal ──────────────────────────────────────────────
        function openDisasterReportModal(report) {
            currentDisasterReport = report;

            const type = report.Type || 'Unknown';
            const severity = report.AlertSeverity || report.Severity || 'Medium';
            const status = report.Status || 'Resolved';
            const icon = disasterIconMap[type] || 'emergency';

            document.getElementById('drv_title').innerText = report.Title || 'Untitled Report';
            document.getElementById('drv_id').innerText = drReportNo(report);
            document.getElementById('drv_type').innerHTML = `<span class="material-symbols-outlined !text-sm">${icon}</span> ${escapeHtml(type)}`;
            document.getElementById('drv_message').innerText = report.AlertMessage || 'No message on record for this disaster.';

            const sevBadge = document.getElementById('drv_severity_badge');
            sevBadge.innerText = severity;
            sevBadge.className = 'inline-block px-3 py-1 rounded-full text-[8px] font-black text-white '
                + (['Critical', 'Extreme'].includes(severity) ? 'bg-rose-500' : severity === 'High' ? 'bg-orange-500' : severity === 'Medium' ? 'bg-amber-500' : 'bg-emerald-500');

            const statusBadge = document.getElementById('drv_status_badge');
            statusBadge.innerText = status;
            statusBadge.className = 'inline-block px-3 py-1 rounded-full text-[8px] font-black uppercase ' + drStatusClass(status);

            const notifyApp = !!(report.AlertNotifyApp && report.AlertNotifyApp != 0);
            const notifySms = !!(report.AlertNotifySms && report.AlertNotifySms != 0);
            document.getElementById('drv_notify_app').innerText = notifyApp ? 'Sent' : 'Not used';
            document.getElementById('drv_notify_sms').innerText = notifySms ? 'Enabled' : 'Not used';

            // SMS Live — actual send status per broadcast for this disaster
            const smsLogs = report.SmsLogs || [];
            const smsContainer = document.getElementById('drv_sms_live');
            if (!smsLogs.length) {
                smsContainer.innerHTML = '<p class="text-[11px] font-bold text-slate-400 uppercase text-center py-3">No SMS broadcast recorded for this disaster.</p>';
            } else {
                smsContainer.innerHTML = smsLogs.map(l => {
                    const total = parseInt(l.total_recipients ?? 0, 10);
                    const sent = parseInt(l.sent_count ?? 0, 10);
                    const pct = total > 0 ? Math.round((sent / total) * 100) : 0;
                    const when = l.created_at ? new Date(l.created_at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';
                    return `<div class="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div class="flex justify-between items-center mb-1.5">
                    <span class="text-[10px] font-bold text-slate-500">${when}</span>
                    <span class="text-[9px] font-black uppercase ${sent >= total && total > 0 ? 'text-emerald-500' : 'text-amber-500'}">${escapeHtml(l.status || 'Unknown')}</span>
                </div>
                <div class="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mb-1">
                    <div class="h-full bg-emerald-500" style="width:${pct}%"></div>
                </div>
                <p class="text-[9px] font-bold text-slate-400">${pct}% sent (${sent}/${total})</p>
            </div>`;
                }).join('');
            }

            document.getElementById('drv_affected').innerText = report.AffectedResidents ?? '0';
            document.getElementById('drv_evacuees').innerText = report.Evacuees ?? '0';
            document.getElementById('drv_injuries').innerText = report.Injuries ?? '0';
            document.getElementById('drv_casualties').innerText = report.Casualties ?? '0';
            document.getElementById('drv_damage').innerText = report.PropertyDamage || 'No damage assessment on record.';
            document.getElementById('drv_actions').innerText = report.ResponseActions || 'No response actions on record.';
            document.getElementById('drv_date').innerText = report.CreatedAt ? new Date(report.CreatedAt).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) : '—';
            document.getElementById('drv_duty_officer').innerText = drDutyOfficer(report);
            document.getElementById('drv_captain').innerText = BRGY.captain || 'Barangay Captain';

            openModal('viewDisasterReportModal');
        }

        // ─── Shared report layout ────────────────────────────────────────────────────
        // Print and Download PDF both render THIS markup, so the printed page and the
        // saved PDF are always identical. Barangay name, logo and captain come from the
        // database (BRGY); the duty officer is whoever deactivated the disaster.

        function drReportNo(r) {
            if (!r) return '—';
            if (r.ReportNo) return r.ReportNo;
            const year = r.CreatedAt ? new Date(r.CreatedAt).getFullYear() : new Date().getFullYear();
            return 'DIS-' + year + '-' + String(r.ReportID ?? 0).padStart(4, '0');
        }

        function drDutyOfficer(r) {
            return (r && (r.DutyOfficer || r.duty_officer)) || 'Not recorded';
        }

        function drSeverityHex(sev) {
            if (['Critical', 'Extreme'].includes(sev)) return '#e11d48';
            if (sev === 'High') return '#f97316';
            if (sev === 'Medium') return '#f59e0b';
            return '#10b981';
        }

        function buildDisasterReportHTML(r) {
            const type = r.Type || 'Unknown';
            const severity = r.AlertSeverity || r.Severity || 'Medium';
            const status = r.Status || 'Resolved';
            const accent = drSeverityHex(severity);
            const refNo = drReportNo(r);
            const dateStr = r.CreatedAt
                ? new Date(r.CreatedAt).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
                : '—';
            const generated = new Date().toLocaleString('en-US', {
                month: 'long', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit'
            });
            const brgyName = (BRGY.name || 'Barangay').toUpperCase();
            const captain = BRGY.captain || 'Barangay Captain';
            const officer = drDutyOfficer(r);
            const logoHtml = BRGY.logo
                ? `<img src="${BRGY.logo}" alt="" class="dr-logo">`
                : `<div class="dr-logo dr-logo-ph">${escapeHtml((BRGY.name || 'B').charAt(0).toUpperCase())}</div>`;

            const stat = (label, value, color) => `
        <div class="dr-stat">
            <div class="dr-stat-val" style="color:${color}">${value ?? 0}</div>
            <div class="dr-stat-label">${label}</div>
        </div>`;

            const section = (label, body) => `
        <div class="dr-section">
            <div class="dr-section-label"><span class="dr-bullet"></span>${label}</div>
            <div class="dr-section-body">${escapeHtml(body)}</div>
        </div>`;

            return `
    <div class="dr-page" style="--dr-accent:${accent}">
        <div class="dr-accentbar"></div>

        <div class="dr-letterhead">
            ${logoHtml}
            <div class="dr-lh-text">
                <p class="dr-lh-sup">Republic of the Philippines</p>
                ${BRGY.address ? `<p class="dr-lh-sup">${escapeHtml(BRGY.address)}</p>` : ''}
                <h1 class="dr-lh-name">${escapeHtml(brgyName)}</h1>
                <p class="dr-lh-sub">Disaster Risk Reduction &amp; Management Committee</p>
            </div>
        </div>

        <div class="dr-titleband">
            <div>
                <p class="dr-doctype">Official Disaster Report</p>
                <p class="dr-docsub">${escapeHtml(r.Title || 'Untitled Report')}</p>
            </div>
            <div class="dr-refbox">
                <span class="dr-reflabel">Reference No.</span>
                <span class="dr-refno">${escapeHtml(refNo)}</span>
            </div>
        </div>

        <div class="dr-meta">
            <div class="dr-meta-cell"><span class="dr-label">Disaster Type</span><span class="dr-value">${escapeHtml(type)}</span></div>
            <div class="dr-meta-cell"><span class="dr-label">Severity Level</span><span class="dr-value"><span class="dr-chip">${escapeHtml(severity)}</span></span></div>
            <div class="dr-meta-cell"><span class="dr-label">Report Status</span><span class="dr-value">${escapeHtml(status)}</span></div>
            <div class="dr-meta-cell"><span class="dr-label">Date of Report</span><span class="dr-value">${escapeHtml(dateStr)}</span></div>
        </div>

        ${section('Message / Emergency Instructions', r.AlertMessage || 'No message on record for this disaster.')}

        <div class="dr-section">
            <div class="dr-section-label"><span class="dr-bullet"></span>Impact Summary</div>
            <div class="dr-stats">
                ${stat('Affected Residents', r.AffectedResidents ?? 0, '#1e293b')}
                ${stat('Evacuees', r.Evacuees ?? 0, '#1e293b')}
                ${stat('Injuries', r.Injuries ?? 0, '#d97706')}
                ${stat('Casualties', r.Casualties ?? 0, '#e11d48')}
            </div>
        </div>

        ${section('Property & Damage Assessment', r.PropertyDamage || 'No significant property damage reported.')}
        ${section('Action Taken & Response', r.ResponseActions || 'Initial response protocols deployed by Barangay DRRMC.')}
        ${section('Notification Channels',
                'App Notification: ' + (r.AlertNotifyApp && r.AlertNotifyApp != 0 ? 'Sent' : 'Not used') +
                '   ·   SMS Broadcast: ' + (r.AlertNotifySms && r.AlertNotifySms != 0 ? 'Enabled' : 'Not used'))}

        <div class="dr-certify">
            This is to certify that the information contained in this report is true and correct
            based on the records of ${escapeHtml(BRGY.name || 'this barangay')}.
        </div>

        <div class="dr-signatures">
            <div class="dr-sign">
                <p class="dr-sign-role">Prepared &amp; Submitted by</p>
                <div class="dr-sign-line"></div>
                <p class="dr-sign-name">${escapeHtml(officer)}</p>
                <p class="dr-sign-title">Duty Officer</p>
            </div>
            <div class="dr-sign">
                <p class="dr-sign-role">Attested by</p>
                <div class="dr-sign-line"></div>
                <p class="dr-sign-name">${escapeHtml(captain)}</p>
                <p class="dr-sign-title">Barangay Captain</p>
            </div>
        </div>

        <div class="dr-footer">
            <span>${escapeHtml(refNo)} · ${escapeHtml(BRGY.name || 'Barangay')}</span>
            <span>Generated ${escapeHtml(generated)}</span>
        </div>
    </div>`;
        }

        function disasterReportStyles() {
            return `
    * { box-sizing: border-box; }
    body { margin: 0; background: #ffffff; }
    .dr-page {
        font-family: 'Plus Jakarta Sans', 'Segoe UI', sans-serif;
        width: 794px; margin: 0 auto; background: #fff;
        padding: 46px 56px 40px; color: #334155; position: relative;
    }
    .dr-accentbar { height: 6px; border-radius: 6px; background: var(--dr-accent); margin-bottom: 26px; }

    .dr-letterhead { display: flex; align-items: center; gap: 20px; padding-bottom: 18px; border-bottom: 2px solid #0f172a; }
    .dr-logo { width: 78px; height: 78px; object-fit: contain; border-radius: 50%; flex: 0 0 78px; }
    .dr-logo-ph {
        display: flex; align-items: center; justify-content: center;
        background: #0f172a; color: #fff; font-size: 30px; font-weight: 900;
    }
    .dr-lh-text { flex: 1; text-align: center; }
    .dr-lh-sup { margin: 0; font-size: 11px; font-weight: 600; color: #64748b; letter-spacing: .04em; }
    .dr-lh-name { margin: 3px 0 2px; font-size: 25px; font-weight: 900; color: #0f172a; letter-spacing: .04em; line-height: 1.15; }
    .dr-lh-sub { margin: 0; font-size: 10px; font-weight: 700; color: var(--dr-accent); text-transform: uppercase; letter-spacing: .18em; }

    .dr-titleband { display: flex; justify-content: space-between; align-items: flex-end; gap: 20px; margin: 22px 0 18px; }
    .dr-doctype { margin: 0; font-size: 17px; font-weight: 900; color: #0f172a; text-transform: uppercase; letter-spacing: .12em; }
    .dr-docsub { margin: 5px 0 0; font-size: 13px; font-weight: 700; color: #475569; }
    .dr-refbox {
        text-align: right; border: 1.5px solid #e2e8f0; border-radius: 12px;
        padding: 9px 14px; background: #f8fafc; white-space: nowrap;
    }
    .dr-reflabel { display: block; font-size: 8px; font-weight: 800; color: #94a3b8; text-transform: uppercase; letter-spacing: .18em; }
    .dr-refno { display: block; font-size: 14px; font-weight: 900; color: #0f172a; letter-spacing: .06em; margin-top: 2px; }

    .dr-meta {
        display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 10px; margin-bottom: 24px;
    }
    .dr-meta-cell { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 11px 13px; }
    .dr-label { display: block; font-size: 8px; font-weight: 800; color: #94a3b8; text-transform: uppercase; letter-spacing: .16em; margin-bottom: 5px; }
    .dr-value { display: block; font-size: 12px; font-weight: 800; color: #1e293b; }
    .dr-chip {
        display: inline-block;
        color: #0f172a;
        font-size: 12px; font-weight: 900; line-height: 1.3;
        text-transform: uppercase; letter-spacing: .06em;
    }

    .dr-section { margin-bottom: 20px; }
    .dr-section-label {
        display: flex; align-items: center; gap: 8px; font-size: 10px; font-weight: 900;
        color: #0f172a; text-transform: uppercase; letter-spacing: .16em; margin-bottom: 9px;
    }
    .dr-bullet { width: 14px; height: 3px; border-radius: 3px; background: var(--dr-accent); display: inline-block; }
    .dr-section-body {
        font-size: 12px; line-height: 1.75; color: #475569; font-weight: 500;
        background: #f8fafc; border-left: 3px solid #e2e8f0; border-radius: 0 12px 12px 0;
        padding: 12px 16px; white-space: pre-wrap;
    }

    .dr-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
    .dr-stat { border: 1px solid #e2e8f0; border-radius: 14px; padding: 14px 10px; text-align: center; background: #fff; }
    .dr-stat-val { font-size: 24px; font-weight: 900; line-height: 1; }
    .dr-stat-label { font-size: 8px; font-weight: 800; color: #94a3b8; text-transform: uppercase; letter-spacing: .12em; margin-top: 6px; }

    .dr-certify {
        font-size: 11px; font-style: italic; color: #64748b; line-height: 1.7;
        border-top: 1px dashed #cbd5e1; padding-top: 14px; margin-top: 26px;
    }

    .dr-signatures { display: grid; grid-template-columns: 1fr 1fr; gap: 50px; margin-top: 34px; }
    .dr-sign { text-align: center; }
    .dr-sign-role { margin: 0 0 42px; font-size: 9px; font-weight: 800; color: #94a3b8; text-transform: uppercase; letter-spacing: .14em; }
    .dr-sign-line { border-top: 1.5px solid #0f172a; margin: 0 8px; }
    .dr-sign-name { margin: 7px 0 2px; font-size: 12px; font-weight: 900; color: #0f172a; text-transform: uppercase; letter-spacing: .04em; }
    .dr-sign-title { margin: 0; font-size: 9px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: .12em; }

    .dr-footer {
        display: flex; justify-content: space-between; margin-top: 34px; padding-top: 12px;
        border-top: 1px solid #e2e8f0; font-size: 8.5px; font-weight: 700;
        color: #94a3b8; text-transform: uppercase; letter-spacing: .1em;
    }

    @page { size: A4; margin: 0; }
    @media print {
        .dr-page { width: 100%; padding: 34px 44px 30px; }
        .dr-section, .dr-signatures, .dr-stats { page-break-inside: avoid; }
    }`;
        }

        // Print — opens the browser's print dialog with the shared layout
        function printCurrentDisasterReport() {
            if (!currentDisasterReport) return;
            const r = currentDisasterReport;

            const printWindow = window.open('', '', 'height=900,width=1000');
            printWindow.document.write(`
        <html>
        <head>
            <meta charset="utf-8">
            <title>${escapeHtml(drReportNo(r))} — Disaster Report</title>
            <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
            <style>${disasterReportStyles()}</style>
        </head>
        <body>${buildDisasterReportHTML(r)}</body>
        </html>
    `);
            printWindow.document.close();
            printWindow.focus();
            // Give the webfont and logo a moment so the printed page matches the PDF
            setTimeout(() => { printWindow.print(); }, 600);
        }

        // Download PDF — rasterises the SAME layout, so the file matches the printout
        async function downloadCurrentDisasterReportPDF() {
            if (!currentDisasterReport) return;
            if (typeof window.jspdf === 'undefined' || typeof window.html2canvas === 'undefined') {
                showToast ? showToast('error', 'PDF library failed to load. Check your connection and try again.')
                    : alert('PDF library failed to load.');
                return;
            }

            const r = currentDisasterReport;
            const { jsPDF } = window.jspdf;

            // Offscreen render of the exact same markup used by Print
            const holder = document.createElement('div');
            holder.style.cssText = 'position:fixed;left:-10000px;top:0;width:794px;background:#fff;z-index:-1;';
            const styleTag = document.createElement('style');
            styleTag.textContent = disasterReportStyles();
            holder.appendChild(styleTag);
            holder.insertAdjacentHTML('beforeend', buildDisasterReportHTML(r));
            document.body.appendChild(holder);

            try {
                if (document.fonts && document.fonts.ready) { try { await document.fonts.ready; } catch (e) { } }

                const canvas = await html2canvas(holder.querySelector('.dr-page'), {
                    scale: 2, backgroundColor: '#ffffff', useCORS: true, logging: false,
                });

                const pdf = new jsPDF({ unit: 'pt', format: 'a4' });
                const pageW = pdf.internal.pageSize.getWidth();
                const pageH = pdf.internal.pageSize.getHeight();
                const imgH = (canvas.height * pageW) / canvas.width;
                const pxPerPage = (pageH * canvas.width) / pageW; // canvas pixels that fit on one page

                if (imgH <= pageH) {
                    pdf.addImage(canvas.toDataURL('image/jpeg', 0.95), 'JPEG', 0, 0, pageW, imgH, undefined, 'FAST');
                } else {
                    let offset = 0, page = 0;
                    while (offset < canvas.height) {
                        const sliceH = Math.min(pxPerPage, canvas.height - offset);
                        const slice = document.createElement('canvas');
                        slice.width = canvas.width;
                        slice.height = sliceH;
                        const sctx = slice.getContext('2d');
                        sctx.fillStyle = '#ffffff';
                        sctx.fillRect(0, 0, slice.width, slice.height);
                        sctx.drawImage(canvas, 0, offset, canvas.width, sliceH, 0, 0, canvas.width, sliceH);

                        if (page > 0) pdf.addPage();
                        pdf.addImage(slice.toDataURL('image/jpeg', 0.95), 'JPEG', 0, 0, pageW,
                            (sliceH * pageW) / canvas.width, undefined, 'FAST');
                        offset += sliceH;
                        page++;
                    }
                }

                pdf.save(`${drReportNo(r)}.pdf`);
            } catch (err) {
                console.error('Disaster report PDF error:', err);
                showToast ? showToast('error', 'Failed to generate the PDF. Please try again.')
                    : alert('Failed to generate the PDF.');
            } finally {
                holder.remove();
            }
        }

        window.addEventListener('click', e => { if (e.target === document.getElementById('viewDisasterReportModal')) closeModal('viewDisasterReportModal'); });
        render(); resetAi(); loadCachedAi();
    </script>
</body>

</html>
