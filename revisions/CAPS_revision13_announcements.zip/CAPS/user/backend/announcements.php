<?php
/**
 * user/backend/announcements.php
 * ─────────────────────────────────────────────────────────────────────────────
 * Barangay announcements — JSON API for the Flutter app (lib/announcements/).
 * Ported from the SOE resident page user/announcements.php and aligned with
 * the admin module admin/announcement/ (same tables):
 *   • not-deleted announcements that are Published, or Scheduled with a start
 *     date/time that has already passed (Drafts and future Scheduled posts
 *     stay hidden)
 *   • Emergency Notices first, then newest date_posted
 *   • attachments from announcement_attachments (images + files)
 *   • "New" badge per resident, stored in announcement_reads
 *
 * Actions (GET ?action= or POST action=):
 *   • list  (resident_id?)            → announcements + new_count; each item has
 *                                       likes / dislikes / comments / my_reaction and,
 *                                       for images, width / height (show the whole photo:
 *                                       BoxFit.contain with that aspect ratio — never crop)
 *   • read  (resident_id, id)         → mark one as seen
 *   • react (id, reaction)            → reaction = like | dislike | none (same value again = remove)
 *   • comment (id, comment)           → add a comment (max 1000 characters)
 *   • comments (id)                   → comments of one announcement (newest first)
 *   • delete_comment (comment_id)     → remove the resident's own comment
 *
 * Add &debug=1 to see the exact database error when loading fails.
 *
 * Attachment URLs are relative to this backend folder (the admin stores files
 * in admin/announcement/backend/uploads/announcements/).
 * ─────────────────────────────────────────────────────────────────────────────
 */

declare(strict_types=1);
require_once __DIR__ . '/config.php'; // respond(), handle_preflight(), db(), L()
handle_preflight();

const ANN_FILES_BASE_DIR = __DIR__ . '/../../admin/announcement/backend/';
const ANN_FILES_BASE_URL = '../../admin/announcement/backend/';
require_once __DIR__ . '/../../admin/announcement/backend/ann_engagement_helper.php'; // reactions + comments tables

$pdo    = db();
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';
$rid    = require_resident(); // verified login token (auth.php), not the resident_id sent by the app

// Per-resident "seen" list (the SOE portal kept this only in the session).
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS announcement_reads (
            resident_id     INT NOT NULL,
            announcement_id INT UNSIGNED NOT NULL,
            read_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (resident_id, announcement_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
} catch (Throwable $e) {
    error_log('[announcements.php migrate] ' . $e->getMessage());
}

function ann_file_url(string $path): ?string
{
    $path = ltrim($path, '/');
    if ($path === '' || strpos($path, '..') !== false) return null;
    return is_file(ANN_FILES_BASE_DIR . $path) ? ANN_FILES_BASE_URL . $path : null;
}

ann_engagement_migrate($pdo);

/** A live (visible) announcement id, else 0. */
function ann_visible_id(PDO $pdo, int $id): int
{
    $s = $pdo->prepare("SELECT id FROM announcements WHERE id = ? AND deleted_at IS NULL
                          AND (status = 'Published' OR (status = 'Scheduled' AND date_start IS NOT NULL
                               AND CONCAT(date_start, ' ', COALESCE(time_start, '00:00:00')) <= NOW()))");
    $s->execute([$id]);
    return (int) ($s->fetchColumn() ?: 0);
}
function ann_counts_for(PDO $pdo, int $id, int $rid): array
{
    $c = ann_engagement_counts($pdo, [$id])[$id];
    $m = $pdo->prepare("SELECT reaction FROM announcement_reactions WHERE announcement_id = ? AND resident_id = ?");
    $m->execute([$id, $rid]);
    return ['likes' => $c['likes'], 'dislikes' => $c['dislikes'], 'comments' => $c['comments'], 'my_reaction' => $m->fetchColumn() ?: null];
}

// ── REACT (❤️ like / 👎 dislike) ─────────────────────────────────────────────
if ($action === 'react') {
    $id = ann_visible_id($pdo, (int) ($_POST['id'] ?? 0));
    $reaction = strtolower(trim((string) ($_POST['reaction'] ?? '')));
    if ($id <= 0 || !in_array($reaction, ['like', 'dislike', 'none'], true)) {
        respond(false, L('Hindi wastong reaksyon.', 'Invalid reaction.'), null, 400);
    }
    try {
        $cur = $pdo->prepare("SELECT reaction FROM announcement_reactions WHERE announcement_id = ? AND resident_id = ?");
        $cur->execute([$id, $rid]);
        $old = $cur->fetchColumn();
        if ($reaction === 'none' || $old === $reaction) {       // tapping the same icon again removes it
            $pdo->prepare("DELETE FROM announcement_reactions WHERE announcement_id = ? AND resident_id = ?")->execute([$id, $rid]);
        } else {
            $pdo->prepare("INSERT INTO announcement_reactions (announcement_id, resident_id, reaction) VALUES (?, ?, ?)
                           ON DUPLICATE KEY UPDATE reaction = VALUES(reaction), updated_at = NOW()")->execute([$id, $rid, $reaction]);
        }
        $pdo->prepare("INSERT IGNORE INTO announcement_reads (resident_id, announcement_id) VALUES (?, ?)")->execute([$rid, $id]);
        respond(true, '', ann_counts_for($pdo, $id, $rid));
    } catch (Throwable $e) {
        error_log('[announcements.php react] ' . $e->getMessage());
        respond(false, L('Hindi na-save.', 'Not saved.'), null, 500);
    }
}

// ── COMMENTS (💬) ────────────────────────────────────────────────────────────
if ($action === 'comment') {
    $id = ann_visible_id($pdo, (int) ($_POST['id'] ?? 0));
    $text = trim(strip_tags((string) ($_POST['comment'] ?? '')));
    if ($id <= 0 || $text === '') respond(false, L('Isulat ang iyong komento.', 'Write your comment.'), null, 400);
    if (mb_strlen($text) > 1000) $text = mb_substr($text, 0, 1000);
    try {
        $pdo->prepare("INSERT INTO announcement_comments (announcement_id, resident_id, comment) VALUES (?, ?, ?)")->execute([$id, $rid, $text]);
        $pdo->prepare("INSERT IGNORE INTO announcement_reads (resident_id, announcement_id) VALUES (?, ?)")->execute([$rid, $id]);
        respond(true, '', ['comments' => ann_engagement_people($pdo, $id, 'comment', 200)] + ann_counts_for($pdo, $id, $rid));
    } catch (Throwable $e) {
        error_log('[announcements.php comment] ' . $e->getMessage());
        respond(false, L('Hindi na-save.', 'Not saved.'), null, 500);
    }
}
if ($action === 'comments') {
    $id = ann_visible_id($pdo, (int) ($_GET['id'] ?? $_POST['id'] ?? 0));
    if ($id <= 0) respond(false, L('Hindi nahanap ang anunsyo.', 'Announcement not found.'), null, 404);
    $list = array_map(fn($c) => $c + ['mine' => $c['resident_id'] === $rid], ann_engagement_people($pdo, $id, 'comment', 200));
    respond(true, '', ['comments' => $list] + ann_counts_for($pdo, $id, $rid));
}
if ($action === 'delete_comment') {
    $cid = (int) ($_POST['comment_id'] ?? 0);
    $s = $pdo->prepare("UPDATE announcement_comments SET deleted_at = NOW() WHERE id = ? AND resident_id = ? AND deleted_at IS NULL");
    $s->execute([$cid, $rid]);
    $s->rowCount() ? respond(true, '') : respond(false, L('Hindi nahanap ang komento.', 'Comment not found.'), null, 404);
}

// ── READ (mark seen) ─────────────────────────────────────────────────────────
if ($action === 'read') {
    $id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
    if ($rid <= 0 || $id <= 0) {
        respond(false, L('Kailangan ang resident_id at id.', 'resident_id and id are required.'), null, 400);
    }
    try {
        $pdo->prepare("INSERT IGNORE INTO announcement_reads (resident_id, announcement_id) VALUES (?, ?)")
            ->execute([$rid, $id]);
        respond(true, '');
    } catch (Throwable $e) {
        error_log('[announcements.php read] ' . $e->getMessage());
        respond(false, L('Hindi na-save.', 'Not saved.'), null, 500);
    }
}

// ── LIST ─────────────────────────────────────────────────────────────────────
if ($action === 'list') {
    try {
        $cols = $pdo->query(
            "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'announcements'"
        )->fetchAll(PDO::FETCH_COLUMN);
        $otherCol = in_array('category_other', $cols, true) ? 'a.category_other' : 'NULL';

        $rows = $pdo->query(
            "SELECT a.id, a.title, a.category, $otherCol AS category_other, a.details,
                    a.date_posted, a.date_start, a.date_end, a.time_start, a.time_end,
                    a.created_at
             FROM announcements a
             WHERE a.deleted_at IS NULL
               AND (a.status = 'Published'
                    -- Scheduled posts whose start time has passed are live even
                    -- if the admin scheduler (run on admin page load) hasn't
                    -- flipped them to Published yet — same rule as ann_scheduler.
                    OR (a.status = 'Scheduled' AND a.date_start IS NOT NULL
                        AND CONCAT(a.date_start, ' ', COALESCE(a.time_start, '00:00:00')) <= NOW()))
             ORDER BY CASE a.category WHEN 'Emergency Notice' THEN 0 ELSE 1 END,
                      a.date_posted DESC, a.created_at DESC, a.id DESC
             LIMIT 200"
        )->fetchAll(PDO::FETCH_ASSOC);

        $atts = [];
        if ($rows) {
            $ids = array_map(fn($r) => (int) $r['id'], $rows);
            $in  = implode(',', $ids);
            try {
                foreach ($pdo->query(
                    "SELECT announcement_id, original_name, file_path, file_type, file_ext,
                            file_size, is_image
                     FROM announcement_attachments
                     WHERE announcement_id IN ($in)
                     ORDER BY announcement_id, sort_order, id"
                )->fetchAll(PDO::FETCH_ASSOC) as $a) {
                    $url = ann_file_url((string) $a['file_path']);
                    if ($url === null) continue;
                    // Real size of the photo so the app can show it whole (FB style), without cropping.
                    $dim = (int) $a['is_image'] === 1 ? @getimagesize(ANN_FILES_BASE_DIR . ltrim((string) $a['file_path'], '/')) : false;
                    $atts[(int) $a['announcement_id']][] = [
                        'width'    => $dim ? (int) $dim[0] : null,
                        'height'   => $dim ? (int) $dim[1] : null,
                        'name'     => $a['original_name'],
                        'url'      => $url,
                        'ext'      => strtolower((string) $a['file_ext']),
                        'size'     => (int) $a['file_size'],
                        'is_image' => (int) $a['is_image'] === 1,
                    ];
                }
            } catch (Throwable $e) { /* no attachments table */ }
        }

        $seen = [];
        if ($rid > 0) {
            $s = $pdo->prepare("SELECT announcement_id FROM announcement_reads WHERE resident_id = ?");
            $s->execute([$rid]);
            $seen = array_flip(array_map('intval', $s->fetchAll(PDO::FETCH_COLUMN)));
        }

        $counts = $rows ? ann_engagement_counts($pdo, array_map(fn($r) => (int) $r['id'], $rows)) : [];
        $mine = [];
        if ($rows && $rid > 0) {
            $m = $pdo->prepare("SELECT announcement_id, reaction FROM announcement_reactions WHERE resident_id = ?");
            $m->execute([$rid]);
            foreach ($m->fetchAll(PDO::FETCH_ASSOC) as $x) $mine[(int) $x['announcement_id']] = $x['reaction'];
        }

        $today = date('Y-m-d');
        $out = [];
        $new = 0;
        foreach ($rows as $r) {
            $id    = (int) $r['id'];
            $isNew = $rid > 0 && !isset($seen[$id]);
            if ($isNew) $new++;
            $out[] = [
                'id'          => $id,
                'title'       => (string) $r['title'],
                'category'    => $r['category'] === 'Others' && !empty($r['category_other'])
                                    ? (string) $r['category_other'] : (string) $r['category'],
                'is_emergency'=> $r['category'] === 'Emergency Notice',
                'details'     => (string) $r['details'],
                'date_posted' => $r['date_posted'],
                'date_start'  => $r['date_start'],
                'date_end'    => $r['date_end'],
                'time_start'  => $r['time_start'],
                'time_end'    => $r['time_end'],
                'is_ended'    => !empty($r['date_end']) && $r['date_end'] < $today,
                'is_new'      => $isNew,
                'attachments' => $atts[$id] ?? [],
                'likes'       => $counts[$id]['likes'] ?? 0,
                'dislikes'    => $counts[$id]['dislikes'] ?? 0,
                'comments'    => $counts[$id]['comments'] ?? 0,
                'my_reaction' => $mine[$id] ?? null,
            ];
        }
        respond(true, '', ['announcements' => $out, 'new_count' => $new]);
    } catch (Throwable $e) {
        error_log('[announcements.php list] ' . $e->getMessage());
        respond(false, L('Hindi ma-load ang mga anunsyo.', 'Could not load the announcements.'),
            isset($_GET['debug']) ? ['error' => $e->getMessage()] : null, 500);
    }
}

respond(false, L('Hindi wastong action.', 'Invalid action.'), null, 400);
