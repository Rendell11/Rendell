-- Announcement engagement (resident app Like / Dislike / Comment).
-- Optional: the tables are also created automatically on first use (ann_engagement_helper.php).
CREATE TABLE IF NOT EXISTS announcement_reads (
    resident_id INT NOT NULL,
    announcement_id INT UNSIGNED NOT NULL,
    read_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (resident_id, announcement_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS announcement_reactions (
    announcement_id INT UNSIGNED NOT NULL,
    resident_id INT NOT NULL,
    reaction ENUM('like','dislike') NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL,
    PRIMARY KEY (announcement_id, resident_id),
    KEY idx_ar_reaction (announcement_id, reaction),
    KEY idx_ar_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS announcement_comments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    announcement_id INT UNSIGNED NOT NULL,
    resident_id INT NOT NULL,
    comment TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL DEFAULT NULL,
    PRIMARY KEY (id),
    KEY idx_ac_ann (announcement_id, deleted_at),
    KEY idx_ac_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
