<?php
/**
 * Household Master List — opened from Household Management (hero Save PDF / Print)
 * with ?mode=pdf|print&status&search&income_class. Same filters as the list page
 * (households.php, without paging) and the same shared CAPS report layout
 * (officials report_common.php) as the Resident and Household Analytics reports.
 */
declare(strict_types=1);
if (session_status() === PHP_SESSION_NONE) session_start();

define('HH_LIST_ALL', true);
require_once __DIR__ . '/households.php';          // $households, $total, $search, $statusFilter, $incomeClass
require_once __DIR__ . '/../../officials/backend/report_common.php';

$mode = report_mode();
$brgy = report_barangay_profile($pdo);
$bAddr = trim((string) ($brgy['address'] ?? '')) ?: implode(', ', array_filter([
    $brgy['barangay_name'] ?? '', $brgy['municipality_name'] ?? '', $brgy['province_name'] ?? '', $brgy['region_name'] ?? '',
], fn($x) => trim((string) $x) !== ''));
$captain = report_current_captain($pdo);
$generatedBy = report_generated_by($pdo);
$generatedRole = ($_SESSION['role'] ?? '') === 'admin' ? 'Administrator' : 'Barangay Staff';

$incomeLabels = ['low' => 'Below ₱20,000', 'mid' => '₱20,000 – ₱49,999', 'high' => '₱50,000 and above'];
$statusLabel = $statusFilter === 'inactive' ? 'Inactive Households' : 'Active Households';

// Socioeconomic Status filter chosen in the Save PDF / Print dialog: ses=all or e.g. ses=low,high.
$sesPick = array_values(array_intersect(['low', 'middle', 'high'], array_map('trim', explode(',', strtolower((string) ($_GET['ses'] ?? 'all'))))));
if (count($sesPick) === 3) $sesPick = [];
$sesLabel = $sesPick ? implode(' + ', array_map('ucfirst', $sesPick)) : 'All';

$rows = [];
$persons = 0;
$incomeSum = 0.0;
$sesCount = [];
foreach ($households as $h) {
    $isInactive = strtolower((string) ($h['status'] ?? 'active')) === 'inactive';
    $name = hh_full_name($h);
    $addr = hh_address($h);
    if ($isInactive) {
        $addr = (string) ($h['HouseholdAddress'] ?? $addr);
        if ($name === '') $name = (string) ($h['head_name'] ?? '');
    }
    $size = (int) ($h['MemberCount'] ?? 0) + 1;
    $inc = (float) ($h['CombinedIncome'] ?? $h['TotalHouseholdIncome'] ?? 0);
    $ses = hh_socioeconomic_status($inc, $size);
    if ($sesPick && !in_array(strtolower($ses['tier']), $sesPick, true)) continue;
    $persons += $size;
    $incomeSum += $inc;
    $sesCount[$ses['label']] = ($sesCount[$ses['label']] ?? 0) + 1;
    $rows[] = [
        (string) ($h['HouseholdID'] ?? '—'),
        $name ?: '—',
        $addr ?: '—',
        (string) $size,
        trim((string) ($h['ContactNumber'] ?? '')) ?: '—',
        '₱' . number_format($inc, 2),
        hh_income_class($inc),
        $ses['label'] . ' (' . $ses['tier'] . ')',
        !empty($h['DateCreated']) ? date('M j, Y', strtotime((string) $h['DateCreated'])) : '—',
        $isInactive ? 'Inactive' : 'Active',
    ];
}
$count = count($rows);

if ($mode !== '') {
    try {
        require_once __DIR__ . '/../../activity_log_helper.php';
        log_activity('Households', $mode === 'pdf' ? 'Save Household Master List PDF' : 'Print Household Master List',
            ($mode === 'pdf' ? 'Saved PDF of ' : 'Printed ') . 'household master list · ' . $statusLabel . ' · Socioeconomic Status: ' . $sesLabel . ' · ' . $count . ' household(s)');
    } catch (Throwable $e) {
        error_log('[household master list] activity log: ' . $e->getMessage());
    }
}

$title = 'Household Master List';
report_head($title, $mode);
report_toolbar($mode, 'household_master_list_' . $statusFilter . '_' . ($sesPick ? implode('_', $sesPick) . '_' : '') . date('Ymd'), 'landscape');
?>
<style>
    .brgy-addr{text-align:center;font-size:11px;color:#64748b;margin:-12px 0 14px}
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 24px}
    table.kv th{width:42%;background:transparent;font-size:10.5px;color:#64748b}
    table.kv td{font-weight:700}
    table.list th,table.list td{font-size:10.5px;padding:6px 5px;vertical-align:top}
    td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
    .report-page{max-width:1100px}
    tr,.stat-grid,.signature-block,.certify-line{page-break-inside:avoid;break-inside:avoid}
    h2.section{page-break-after:avoid;break-after:avoid}
</style>
<div class="report-page" id="reportRoot">
    <?php report_letterhead($brgy, 'Office of the Punong Barangay · Household Records'); ?>
    <?php if ($bAddr): ?><p class="brgy-addr"><?php echo rh($bAddr); ?></p><?php endif; ?>
    <?php report_title_block($title, $statusLabel . ' · Socioeconomic Status: ' . $sesLabel . ' · ' . $count . ' household(s)', 'Household Management'); ?>

    <?php report_section_open('Report Information'); ?>
    <div class="info-grid">
        <table class="kv"><tbody>
            <tr><th>Status</th><td><?php echo rh($statusLabel); ?></td></tr>
            <tr><th>Search</th><td><?php echo rh($search !== '' ? $search : 'None'); ?></td></tr>
            <tr><th>Socioeconomic Status</th><td><?php echo rh($sesLabel === 'All' ? 'All' : $sesLabel . ' only'); ?></td></tr>
            <tr><th>Combined income filter</th><td><?php echo rh($incomeLabels[$incomeClass] ?? 'All'); ?></td></tr>
        </tbody></table>
        <table class="kv"><tbody>
            <tr><th>Generated by</th><td><?php echo rh($generatedBy); ?></td></tr>
            <tr><th>Date generated</th><td><?php echo rh(date('F j, Y g:i A')); ?></td></tr>
            <tr><th>Barangay Captain</th><td><?php echo rh($captain ? 'Hon. ' . $captain['full_name'] : 'Not assigned'); ?></td></tr>
        </tbody></table>
    </div>
    <?php report_section_close(); ?>

    <?php report_section_open('Summary'); ?>
    <?php report_stat_cards([
        ['value' => number_format($count), 'label' => 'Households', 'variant' => 'a'],
        ['value' => number_format($persons), 'label' => 'Persons (Head + members)', 'variant' => 'b'],
        ['value' => $count ? round($persons / $count, 1) : '—', 'label' => 'Average Household Size', 'variant' => 'c'],
        ['value' => $count ? '₱' . number_format($incomeSum / $count, 2) : '—', 'label' => 'Avg Combined Income', 'variant' => 'd'],
    ]); ?>
    <?php if ($sesCount): ?>
    <table style="margin-top:12px"><thead><tr><th>Socioeconomic Status</th><th class="num">Households</th><th class="num">Share</th></tr></thead><tbody>
        <?php foreach ($sesCount as $k => $v): ?>
        <tr><td><?php echo rh($k); ?></td><td class="num"><?php echo number_format($v); ?></td><td class="num"><?php echo round($v / $count * 100, 1); ?>%</td></tr>
        <?php endforeach; ?>
    </tbody></table>
    <?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Household Records (' . $count . ')'); ?>
    <?php if (!$rows): ?>
        <p class="empty-note">No household records found.</p>
    <?php else: ?>
    <table class="list"><thead><tr>
        <th>#</th><th>Household ID</th><th>Household Head</th><th>Address</th><th class="num">Members</th><th>Contact</th>
        <th class="num">Combined Income</th><th>Income Status</th><th>Socioeconomic</th><th>Registered</th><th>Status</th>
    </tr></thead><tbody>
        <?php foreach ($rows as $i => $r): ?>
        <tr><td><?php echo $i + 1; ?></td>
            <?php foreach ($r as $c => $v): ?><td<?php echo in_array($c, [3, 5], true) ? ' class="num"' : ''; ?>><?php echo rh($v); ?></td><?php endforeach; ?>
        </tr>
        <?php endforeach; ?>
    </tbody></table>
    <?php endif; ?>
    <p style="margin:8px 0 0;font-size:10px;color:#64748b">Combined Income = monthly income of the Head and all living members. Socioeconomic Status compares income per member with the poverty threshold (PIDS income classes): Low = Poor / Low Income (Not Poor), Middle = Lower Middle / Middle / Upper Middle, High = Upper Income (Not Rich) / Rich.</p>
    <?php report_section_close(); ?>

    <?php report_certify_and_signatures($brgy['brgy_name'] ?? 'Barangay', $generatedBy, $generatedRole, $captain); ?>
    <?php report_footer_strip($brgy['brgy_name'] ?? 'Barangay'); ?>
</div>
<?php report_foot(); ?>
