<?php
/**
 * complaint_ai_summary.php — AI Analytics for Complaint Analytics (JSON, POST).
 * Same behavior as the other CAPS analytics: only when "Generate AI Analytics" is clicked;
 * cached_only=1 returns a result generated before for the same data (no Gemini call).
 * Only aggregated figures are sent (no names, no complaint text).
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_permission($pdo, 'complaints', 'read');
require_once __DIR__ . '/complaint_analytics_data.php';

try {
    $p = ra_params($_POST);
    $a = complaint_analytics_compute($pdo, $p);
} catch (Throwable $e) {
    error_log('[Complaint AI] ' . $e->getMessage());
    aui_json(['success' => false, 'error' => 'Could not read the complaint records.'], 500);
}
aui_ai_endpoint('complaint_analytics', complaint_analytics_snapshot($a), complaint_analytics_snapshot($a), $p, $a['totals']['total'] > 0,
    'There are no complaints for ' . $a['range']['label'] . ', so there is nothing to analyse.', 'complaints desk',
    "Focus on resident complaints: volume, status (pending / ongoing / resolved), resolution and reply rates, categories, priority (High / Urgent), anonymous complaints, puroks, when complaints are filed, and the comparison with the previous period. "
    . "key_findings = the most important facts; demographic_trends = trends over time / by weekday / hour; patterns = which categories or puroks are resolved slowly or are urgent; "
    . "population_observations = observations about complainants (anonymous vs registered residents, puroks); recommendations = practical actions for the barangay, each tied to a finding.",
    function () use ($a) {
        require_once __DIR__ . '/../../activity_log_helper.php';
        log_activity('Complaints', 'Generate AI Analytics', 'Generated complaint AI analytics for ' . $a['range']['label']);
    });
