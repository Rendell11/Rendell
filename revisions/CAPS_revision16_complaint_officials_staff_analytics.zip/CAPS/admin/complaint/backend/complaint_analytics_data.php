<?php
/**
 * complaint_analytics_data.php — every figure of Complaint Analytics, its AI Analytics and its
 * Save PDF / Print report, computed from the actual `complaints` rows.
 * Start / End Date optional (empty = all records); complaints are counted by the date filed.
 * Anonymous complaints never show the complainant's name.
 */
require_once __DIR__ . '/../../analytics_common.php';

function complaint_category_label(array $r): string {
    $c = trim((string)($r['category'] ?? '')) ?: 'Not specified';
    $o = trim((string)($r['other_category_specify'] ?? ''));
    return (strcasecmp($c, 'Others') === 0 || strcasecmp($c, 'Other') === 0) && $o !== '' ? $o : $c;
}

function complaint_analytics_compute(PDO $pdo, array $p): array {
    [$from, $to] = aui_resolve_range($p, $pdo->query("SELECT MIN(created_at) FROM complaints")->fetchColumn() ?: null);
    $open = $p['start'] === '' || $p['end'] === '';
    $s = $pdo->prepare("SELECT c.*, CASE WHEN c.is_anonymous = 1 THEN NULL ELSE COALESCE(NULLIF(TRIM(CONCAT(r.FirstName, ' ', r.LastName)), ''), c.complainant_name) END AS ComplainantName
                        FROM complaints c LEFT JOIN residents r ON r.ResidentID = c.resident_id
                        WHERE c.created_at BETWEEN ? AND ? ORDER BY c.created_at DESC");
    $s->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
    $rows = $s->fetchAll(PDO::FETCH_ASSOC);

    $b = aui_buckets($from, $to);
    $trend = ['filed' => array_fill_keys($b['keys'], 0), 'resolved' => array_fill_keys($b['keys'], 0), 'high' => array_fill_keys($b['keys'], 0)];
    $t = ['total' => count($rows), 'pending' => 0, 'ongoing' => 0, 'resolved' => 0, 'anonymous' => 0, 'high' => 0, 'replied' => 0, 'with_attachment' => 0, 'from_app' => 0];
    $byStatus = ['Pending' => 0, 'Ongoing' => 0, 'Resolved' => 0];
    $byPriority = ['Low' => 0, 'Medium' => 0, 'High (Urgent)' => 0];
    $byCat = []; $byPurok = [];
    $weekday = array_fill_keys(['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], 0);
    $hours = array_fill(0, 24, 0);
    $records = [];
    foreach ($rows as $r) {
        $st = in_array($r['status'], ['Pending', 'Ongoing', 'Resolved'], true) ? $r['status'] : 'Pending';
        $byStatus[$st]++; $t[strtolower($st)]++;
        $pr = in_array($r['priority_level'], ['Low', 'Medium', 'High (Urgent)'], true) ? $r['priority_level'] : 'Medium';
        $byPriority[$pr]++;
        if ($pr === 'High (Urgent)') $t['high']++;
        if ((int)$r['is_anonymous'] === 1) $t['anonymous']++;
        if (trim((string)$r['admin_reply']) !== '') $t['replied']++;
        if (trim((string)$r['attachment_path']) !== '') $t['with_attachment']++;
        if (!empty($r['resident_id'])) $t['from_app']++;
        $cat = complaint_category_label($r);
        $byCat[$cat] = $byCat[$cat] ?? ['category' => $cat, 'n' => 0, 'pending' => 0, 'ongoing' => 0, 'resolved' => 0, 'high' => 0];
        $byCat[$cat]['n']++; $byCat[$cat][strtolower($st)]++;
        if ($pr === 'High (Urgent)') $byCat[$cat]['high']++;
        $pk = trim((string)$r['purok']) ?: 'Not specified';
        $byPurok[$pk] = ($byPurok[$pk] ?? 0) + 1;
        $ts = strtotime($r['created_at']);
        $weekday[date('D', $ts)]++; $hours[(int)date('G', $ts)]++;
        $k = aui_bucket_key($r['created_at'], $b['granularity']);
        if (isset($trend['filed'][$k])) { $trend['filed'][$k]++; if ($st === 'Resolved') $trend['resolved'][$k]++; if ($pr === 'High (Urgent)') $trend['high'][$k]++; }
        $records[] = ['id' => $r['complaint_id'], 'title' => $r['title'], 'category' => $cat, 'priority' => $pr, 'status' => $st,
            'complainant' => (int)$r['is_anonymous'] === 1 ? 'Anonymous' : ($r['ComplainantName'] ?: '—'), 'purok' => $pk,
            'filed' => date('M j, Y g:i A', $ts), 'replied' => trim((string)$r['admin_reply']) !== ''];
    }
    usort($byCat, fn($x, $y) => $y['n'] <=> $x['n']);
    arsort($byPurok);
    $T = $t['total'];
    $t['resolution_rate'] = $T ? round($t['resolved'] / $T * 100, 1) : null;
    $t['reply_rate'] = $T ? round($t['replied'] / $T * 100, 1) : null;
    $t['per_week'] = round($T / max(1, $b['days'] / 7), 1);
    $busyDay = max($weekday) ? array_search(max($weekday), $weekday, true) : null;
    $busyHour = max($hours) ? date('g A', mktime(array_search(max($hours), $hours, true), 0)) : null;

    $a = [
        'period' => $p, 'range' => ['label' => $p['label'], 'open' => $open, 'from' => $from, 'to' => $to],
        'totals' => $t, 'by_status' => $byStatus, 'by_priority' => $byPriority, 'by_category' => array_values($byCat),
        'by_purok' => array_slice($byPurok, 0, 10, true), 'weekday' => $weekday, 'busiest_day' => $busyDay, 'busiest_hour' => $busyHour,
        'hours' => array_combine(array_map(fn($h) => date('g A', mktime($h, 0)), range(0, 23)), $hours),
        'trend' => ['granularity' => $b['granularity'], 'labels' => $b['labels'], 'filed' => array_values($trend['filed']), 'resolved' => array_values($trend['resolved']), 'high' => array_values($trend['high'])],
        'records' => $records, 'comparison' => null,
    ];
    if (!$open) {
        [$ps, $pe] = aui_prev_range($from, $to);
        $q = $pdo->prepare("SELECT COUNT(*) total, SUM(status = 'Resolved') resolved, SUM(status <> 'Resolved') open_n, SUM(priority_level = 'High (Urgent)') high, SUM(is_anonymous = 1) anon
                            FROM complaints WHERE created_at BETWEEN ? AND ?");
        $q->execute([$ps . ' 00:00:00', $pe . ' 23:59:59']);
        $pv = array_map('intval', $q->fetch(PDO::FETCH_ASSOC));
        $a['comparison'] = ['previous_label' => ra_range_label($ps, $pe), 'rows' => [
            ['metric' => 'Complaints filed', 'current' => $T, 'previous' => $pv['total']],
            ['metric' => 'Resolved', 'current' => $t['resolved'], 'previous' => $pv['resolved']],
            ['metric' => 'Pending / ongoing', 'current' => $t['pending'] + $t['ongoing'], 'previous' => $pv['open_n']],
            ['metric' => 'High priority', 'current' => $t['high'], 'previous' => $pv['high']],
            ['metric' => 'Anonymous', 'current' => $t['anonymous'], 'previous' => $pv['anon']],
        ]];
    }
    $a['interpretation'] = complaint_analytics_interpretation($a);
    return $a;
}

function complaint_analytics_interpretation(array $a): array {
    $t = $a['totals']; $L = $a['range']['label'];
    if (!$t['total']) return ['No complaints were filed for ' . $L . '.'];
    $o = [];
    $o[] = $t['total'] . ' complaint(s) were filed for ' . $L . ' (about ' . $t['per_week'] . ' per week): ' . $t['pending'] . ' pending, ' . $t['ongoing'] . ' ongoing and ' . $t['resolved'] . ' resolved.';
    $o[] = 'The resolution rate is ' . $t['resolution_rate'] . '%; ' . $t['replied'] . ' complaint(s) (' . $t['reply_rate'] . '%) already have an admin reply.';
    if ($a['by_category']) $o[] = 'The most common category is ' . $a['by_category'][0]['category'] . ' with ' . $a['by_category'][0]['n'] . ' complaint(s) (' . ra_pct($a['by_category'][0]['n'], $t['total']) . '%).';
    $o[] = $t['high'] . ' complaint(s) (' . ra_pct($t['high'], $t['total']) . '%) are marked High (Urgent).';
    $o[] = $t['anonymous'] . ' complaint(s) (' . ra_pct($t['anonymous'], $t['total']) . '%) were filed anonymously; ' . $t['from_app'] . ' came from registered residents.';
    if ($a['by_purok']) { $k = array_key_first($a['by_purok']); if ($k !== 'Not specified') $o[] = 'Most complaints came from ' . $k . ' (' . $a['by_purok'][$k] . ').'; }
    if ($a['busiest_day']) $o[] = 'Complaints are filed most on ' . $a['busiest_day'] . ($a['busiest_hour'] ? ', around ' . $a['busiest_hour'] : '') . '.';
    if ($a['comparison']) {
        $c = $a['comparison']['rows'][0]; $x = $c['current'] - $c['previous'];
        $o[] = 'Compared with the previous period (' . $a['comparison']['previous_label'] . '), complaints ' . ($x > 0 ? 'increased by ' . $x : ($x < 0 ? 'decreased by ' . abs($x) : 'stayed the same')) . ' (' . $c['previous'] . ' → ' . $c['current'] . ').';
    }
    return $o;
}

/** Aggregated figures only (no names) — what the AI sees and the key of its saved result. */
function complaint_analytics_snapshot(array $a): array {
    return ['date_range' => $a['range']['label'], 'totals' => $a['totals'], 'by_status' => $a['by_status'], 'by_priority' => $a['by_priority'],
        'by_category' => $a['by_category'], 'by_purok' => $a['by_purok'], 'weekday' => $a['weekday'], 'busiest_hour' => $a['busiest_hour'],
        'trend' => $a['trend'], 'comparison' => $a['comparison']];
}
