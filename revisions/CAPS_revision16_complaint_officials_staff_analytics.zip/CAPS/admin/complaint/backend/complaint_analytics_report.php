<?php
/**
 * Complaint Analytics Report — opened from Complaint Analytics with ?start&end&mode=print|pdf&ai=1|0.
 * Same shared CAPS report layout (officials report_common.php) and behavior as the other analytics reports:
 *   ai=0 → "No AI – Data and tables only" (no charts)
 *   ai=1 → supporting charts + the AI Analytics already generated on the page (AI cache — never calls Gemini).
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_permission($pdo, 'complaints', 'read');
require_once __DIR__ . '/../../officials/backend/report_common.php';
require_once __DIR__ . '/complaint_analytics_data.php';

$mode = report_mode();
$p = ra_params($_GET);
$a = complaint_analytics_compute($pdo, $p);
$t = $a['totals']; $T = max(1, $t['total']);
$withAi = ($_GET['ai'] ?? '0') === '1';
$ai = $withAi ? ai_cache_get('complaint_analytics', complaint_analytics_snapshot($a)) : null;
$showCharts = $ai !== null;

$brgy = report_barangay_profile($pdo);
$bAddr = trim((string)($brgy['address'] ?? '')) ?: implode(', ', array_filter([$brgy['barangay_name'] ?? '', $brgy['municipality_name'] ?? '', $brgy['province_name'] ?? ''], fn($x) => trim((string)$x) !== ''));
$captain = report_current_captain($pdo);
$generatedBy = report_generated_by($pdo);
$generatedRole = ($_SESSION['role'] ?? '') === 'admin' ? 'Administrator' : 'Barangay Staff';
if ($mode !== '') { try { require_once __DIR__ . '/../../activity_log_helper.php'; log_activity('Complaints', 'Complaint Analytics Report', ($mode === 'pdf' ? 'Saved PDF' : 'Printed') . ' complaint analytics report · ' . $a['range']['label'] . ($ai ? ' · with AI findings' : '')); } catch (Throwable $e) {} }
$n = fn($v) => number_format((float)$v);

$title = 'Complaint Analytics Report';
report_head($title, $mode);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<?php report_toolbar($mode, 'complaint_analytics_' . ($p['start'] ?: 'all') . '_to_' . ($p['end'] ?: 'all'), 'landscape'); ?>
<?php aui_report_css(); ?>
<div class="report-page" id="reportRoot">
    <?php report_letterhead($brgy, 'Office of the Punong Barangay · Complaints'); ?>
    <?php if ($bAddr): ?><p class="brgy-addr"><?php echo rh($bAddr); ?></p><?php endif; ?>
    <?php report_title_block($title, 'Resident complaints, status, categories and resolution · ' . $a['range']['label'], 'Complaints'); ?>

    <?php aui_report_info($a['range']['label'], ['Basis' => 'Complaints by date filed', 'Complaints covered' => $n($t['total'])], $generatedBy, $captain); ?>

    <?php report_section_open('Complaint Summary'); ?>
    <?php report_stat_cards([
        ['value' => $n($t['total']), 'label' => 'Total Complaints', 'variant' => 'a'],
        ['value' => $n($t['pending'] + $t['ongoing']), 'label' => 'Pending / Ongoing', 'variant' => 'b'],
        ['value' => $n($t['resolved']), 'label' => 'Resolved', 'variant' => 'c'],
        ['value' => $t['resolution_rate'] !== null ? $t['resolution_rate'] . '%' : '—', 'label' => 'Resolution Rate', 'variant' => 'd'],
    ]); ?>
    <div style="margin-top:12px"></div>
    <?php aui_table(['Indicator', 'Value'], [
        ['Pending / ongoing / resolved', $n($t['pending']) . ' / ' . $n($t['ongoing']) . ' / ' . $n($t['resolved'])],
        ['High (Urgent) priority', $n($t['high']) . ' (' . ra_pct($t['high'], $T) . '%)'],
        ['With admin reply', $n($t['replied']) . ' (' . ($t['reply_rate'] ?? 0) . '%)'],
        ['Anonymous complaints', $n($t['anonymous']) . ' (' . ra_pct($t['anonymous'], $T) . '%)'],
        ['From registered residents', $n($t['from_app'])],
        ['With attachment', $n($t['with_attachment'])],
        ['Complaints per week', $t['per_week']],
        ['Busiest day / hour', ($a['busiest_day'] ?: '—') . ' / ' . ($a['busiest_hour'] ?: '—')],
    ], '', [1]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Status, Categories & Priority'); ?>
    <div class="grid2">
        <div><p class="sub">Status</p><?php aui_table(['Status', 'Complaints', 'Share'], aui_dist($a['by_status'], $T), 'No complaints.', [1, 2]); ?></div>
        <div><p class="sub">Priority level</p><?php aui_table(['Priority', 'Complaints', 'Share'], aui_dist($a['by_priority'], $T), 'No complaints.', [1, 2]); ?></div>
    </div>
    <p class="sub">Categories</p>
    <?php $rows = array_map(fn($c) => [$c['category'], $n($c['n']), ra_pct($c['n'], $T) . '%', $n($c['pending']), $n($c['ongoing']), $n($c['resolved']), $n($c['high'])], $a['by_category']);
    if ($rows) $rows[] = ['Total', $n($t['total']), '100%', $n($t['pending']), $n($t['ongoing']), $n($t['resolved']), $n($t['high'])];
    aui_table(['Category', 'Complaints', 'Share', 'Pending', 'Ongoing', 'Resolved', 'High (Urgent)'], $rows, 'No complaints.', [1, 2, 3, 4, 5, 6]); ?>
    <?php if ($showCharts && $a['by_category']): ?><p class="chart-cap">Figure 1. Complaints by category and status</p><div class="chart-wrap"><canvas id="rc-cat"></canvas></div><?php endif; ?>
    <p class="sub">Puroks</p>
    <?php aui_table(['Purok', 'Complaints', 'Share'], aui_dist($a['by_purok'], $T), 'No complaints.', [1, 2]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Trends & Comparison'); ?>
    <?php $rows = [];
    foreach ($a['trend']['labels'] as $i => $lbl) if ($a['trend']['filed'][$i] || $a['trend']['granularity'] === 'month') $rows[] = [$lbl, $n($a['trend']['filed'][$i]), $n($a['trend']['resolved'][$i]), $n($a['trend']['high'][$i])];
    aui_table([$a['trend']['granularity'] === 'day' ? 'Day' : 'Month', 'Filed', 'Resolved', 'High (Urgent)'], $rows, 'No complaints in this range.', [1, 2, 3]); ?>
    <?php if ($showCharts && count($a['trend']['labels']) > 1): ?><p class="chart-cap">Figure 2. Complaints over time</p><div class="chart-wrap"><canvas id="rc-trend"></canvas></div><?php endif; ?>
    <p class="sub">Complaints by day of the week</p>
    <?php aui_table(['Day', 'Complaints', 'Share'], aui_dist($a['weekday'], $T), 'No complaints.', [1, 2]); ?>
    <?php if ($a['comparison']): ?>
    <p class="sub">Selected period vs previous period (<?php echo rh($a['comparison']['previous_label']); ?>)</p>
    <?php aui_table(['Indicator', 'Selected period', 'Previous period', 'Change'], array_map(function ($r) use ($n) { $x = $r['current'] - $r['previous']; return [$r['metric'], $n($r['current']), $n($r['previous']), ($x > 0 ? '+' : '') . $n($x)]; }, $a['comparison']['rows']), '', [1, 2, 3]); ?>
    <?php else: ?><p class="note">Set both a Start Date and an End Date to compare with the previous period of the same length.</p><?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Complaint Records'); ?>
    <?php aui_table(['Complaint ID', 'Title', 'Category', 'Priority', 'Complainant', 'Purok', 'Filed', 'Replied', 'Status'],
        array_map(fn($r) => [$r['id'], $r['title'], $r['category'], $r['priority'], $r['complainant'], $r['purok'], $r['filed'], $r['replied'] ? 'Yes' : 'No', $r['status']], $a['records']),
        'No complaints were filed in this range.'); ?>
    <?php report_section_close(); ?>

    <?php aui_report_tail($a['interpretation'], $ai, $withAi, ['Trends', 'Category & Priority Patterns', 'Complainant Observations', 'Recommended Actions'], 'complaint data of ' . $a['range']['label']); ?>

    <?php report_certify_and_signatures($brgy['brgy_name'] ?? 'Barangay', $generatedBy, $generatedRole, $captain); ?>
    <?php report_footer_strip($brgy['brgy_name'] ?? 'Barangay'); ?>
</div>
<script>
(function () {
    if (!window.Chart) return;
    Chart.defaults.animation = false; Chart.defaults.font.family = 'Arial, Helvetica, sans-serif'; Chart.defaults.font.size = 10; Chart.defaults.color = '#475569';
    const grid = { color: '#e2e8f0' }, legend = { position: 'top', align: 'end', labels: { boxWidth: 10 } };
    const a = <?php echo json_encode(['cat' => $a['by_category'], 'trend' => $a['trend']], JSON_UNESCAPED_UNICODE); ?>;
    const el = id => document.getElementById(id);
    const bar = (label, data, color) => ({ label, data, backgroundColor: color, borderRadius: 3, maxBarThickness: 22 });
    if (el('rc-cat')) new Chart(el('rc-cat'), { type: 'bar', data: { labels: a.cat.map(c => c.category), datasets: [bar('Pending', a.cat.map(c => c.pending), '#f97316'), bar('Ongoing', a.cat.map(c => c.ongoing), '#2a78d6'), bar('Resolved', a.cat.map(c => c.resolved), '#1baf7a')] },
        options: { maintainAspectRatio: false, plugins: { legend }, scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, beginAtZero: true, ticks: { precision: 0 }, grid } } } });
    const t = a.trend, line = (label, data, color) => ({ label, data, borderColor: color, backgroundColor: color, borderWidth: 2, pointRadius: t.labels.length > 40 ? 0 : 2, tension: 0 });
    if (el('rc-trend')) new Chart(el('rc-trend'), { type: 'line', data: { labels: t.labels, datasets: [line('Filed', t.filed, '#2a78d6'), line('Resolved', t.resolved, '#1baf7a'), line('High (Urgent)', t.high, '#e11d48')] },
        options: { maintainAspectRatio: false, plugins: { legend }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
})();
</script>
<?php report_foot(); ?>
