<?php
/**
 * Complaint Masterlist — opened from Complaint Reports (hero Save PDF / Print) with
 * ?mode=pdf|print&status=all|Pending|Ongoing|Resolved&start&end. Same shared CAPS report layout
 * (officials report_common.php) as the Resident / Household / Blotter masterlists.
 * Anonymous complaints never show the complainant's name.
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_permission($pdo, 'complaints', 'read');
require_once __DIR__ . '/../../officials/backend/report_common.php';
require_once __DIR__ . '/complaint_analytics_data.php';

$mode = report_mode();
$status = in_array($_GET['status'] ?? '', ['Pending', 'Ongoing', 'Resolved'], true) ? $_GET['status'] : 'all';
$p = ra_params($_GET);
$where = ['1=1']; $args = [];
if ($status !== 'all') { $where[] = 'c.status = ?'; $args[] = $status; }
if ($p['start'] !== '') { $where[] = 'c.created_at >= ?'; $args[] = $p['start'] . ' 00:00:00'; }
if ($p['end'] !== '') { $where[] = 'c.created_at <= ?'; $args[] = $p['end'] . ' 23:59:59'; }
$s = $pdo->prepare("SELECT c.*, CASE WHEN c.is_anonymous = 1 THEN NULL ELSE COALESCE(NULLIF(TRIM(CONCAT(r.FirstName, ' ', r.LastName)), ''), c.complainant_name) END AS ComplainantName
                    FROM complaints c LEFT JOIN residents r ON r.ResidentID = c.resident_id WHERE " . implode(' AND ', $where) . " ORDER BY c.created_at DESC");
$s->execute($args);
$rows = $s->fetchAll(PDO::FETCH_ASSOC);
$total = count($rows);
$cnt = fn($st) => count(array_filter($rows, fn($r) => $r['status'] === $st));
$byCat = [];
foreach ($rows as $r) { $c = complaint_category_label($r); $byCat[$c] = ($byCat[$c] ?? 0) + 1; }
arsort($byCat);

$brgy = report_barangay_profile($pdo);
$bAddr = trim((string)($brgy['address'] ?? '')) ?: implode(', ', array_filter([$brgy['barangay_name'] ?? '', $brgy['municipality_name'] ?? '', $brgy['province_name'] ?? ''], fn($x) => trim((string)$x) !== ''));
$captain = report_current_captain($pdo);
$generatedBy = report_generated_by($pdo);
$generatedRole = ($_SESSION['role'] ?? '') === 'admin' ? 'Administrator' : 'Barangay Staff';
$statusLabel = $status === 'all' ? 'All Complaints' : $status . ' Complaints';
if ($mode !== '') { try { require_once __DIR__ . '/../../activity_log_helper.php'; log_activity('Complaints', 'Complaint Masterlist', ($mode === 'pdf' ? 'Saved PDF' : 'Printed') . ' complaint masterlist (' . $statusLabel . ', ' . $total . ')'); } catch (Throwable $e) {} }

$title = 'Complaint Masterlist';
report_head($title, $mode);
report_toolbar($mode, 'complaint_masterlist_' . strtolower($status) . '_' . date('Ymd'), 'landscape');
aui_report_css();
?>
<div class="report-page" id="reportRoot">
    <?php report_letterhead($brgy, 'Office of the Punong Barangay · Complaints'); ?>
    <?php if ($bAddr): ?><p class="brgy-addr"><?php echo rh($bAddr); ?></p><?php endif; ?>
    <?php report_title_block($title, $statusLabel . ' · ' . $p['label'], 'Complaints'); ?>
    <?php aui_report_info($p['label'], ['Status' => $statusLabel, 'Complaints listed' => number_format($total)], $generatedBy, $captain); ?>

    <?php report_section_open('Summary'); ?>
    <?php report_stat_cards([
        ['value' => number_format($total), 'label' => 'Complaints Listed', 'variant' => 'a'],
        ['value' => number_format($cnt('Pending')), 'label' => 'Pending', 'variant' => 'b'],
        ['value' => number_format($cnt('Ongoing')), 'label' => 'Ongoing', 'variant' => 'c'],
        ['value' => number_format($cnt('Resolved')), 'label' => 'Resolved', 'variant' => 'd'],
    ]); ?>
    <?php if ($byCat): ?><p class="sub" style="margin-top:12px">By category</p><?php aui_table(['Category', 'Complaints', 'Share'], aui_dist($byCat, $total), '', [1, 2]); endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Complaint Masterlist'); ?>
    <?php aui_table(['#', 'Complaint ID', 'Title', 'Category', 'Priority', 'Complainant', 'Purok', 'Filed', 'Status'],
        array_map(fn($r, $i) => [$i + 1, $r['complaint_id'], $r['title'], complaint_category_label($r), $r['priority_level'],
            (int)$r['is_anonymous'] === 1 ? 'Anonymous' : ($r['ComplainantName'] ?: '—'), trim((string)$r['purok']) ?: '—', date('M j, Y', strtotime($r['created_at'])), $r['status']], $rows, array_keys($rows)),
        'No complaints match the selected filters.'); ?>
    <?php report_section_close(); ?>

    <?php report_certify_and_signatures($brgy['brgy_name'] ?? 'Barangay', $generatedBy, $generatedRole, $captain); ?>
    <?php report_footer_strip($brgy['brgy_name'] ?? 'Barangay'); ?>
</div>
<?php report_foot(); ?>
