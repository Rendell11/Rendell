<?php
/**
 * complaint_analytics.php — Complaint Analytics (View Analytics from Complaint Reports).
 * Same structure / behavior as Resident, Household, Legal Document, Disaster, Announcement and
 * Blotter Analytics: Start / End Date (empty = all records), AI Analytics on top (manual only),
 * Data Interpretation, cards / charts / tables, Complaint Records, Save PDF / Print
 * (../backend/complaint_analytics_report.php) asking whether to include the AI findings.
 */
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_permission($pdo, 'complaints', 'read');
require_once __DIR__ . '/../../theme_loader.php';
require_once __DIR__ . '/../backend/complaint_analytics_data.php';

$p = ra_params($_GET);
$a = null;
try { $a = complaint_analytics_compute($pdo, $p); } catch (Throwable $e) { error_log('[Complaint analytics] ' . $e->getMessage()); }
if (($_GET['action'] ?? '') === 'data') aui_json($a ? ['success' => true] + $a : ['success' => false, 'error' => 'Could not load the complaint analytics.']);
$current_page = 'Complaint';
$_theme_head_loaded = true;
?>
<!DOCTYPE html>
<html <?php echo $theme_attrs['html']; ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Analytics — CAPS</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
    <?php include __DIR__ . '/../../theme_head.php'; ?>
    <script>tailwind.config = { theme: { extend: { colors: { primary: { DEFAULT: 'var(--accent-600)', light: 'var(--accent-500)', dark: 'var(--accent-700)' } }, fontFamily: { sans: ['"Plus Jakarta Sans"', 'sans-serif'] } } } };</script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--page-bg, #eef2fb); -webkit-font-smoothing: antialiased; }
        .main-wrapper { margin-left: 288px; width: calc(100% - 288px); }
        @media (max-width: 1024px) { .main-wrapper { margin-left: 0; width: 100%; } }
    </style>
    <?php aui_styles(); ?>
</head>
<body <?php echo $theme_attrs['body']; ?>>
<div class="flex min-h-screen">
    <?php include __DIR__ . '/../../sidebar.php'; ?>
    <div class="flex-1 flex flex-col min-w-0 main-wrapper">
        <?php include __DIR__ . '/../../header.php'; ?>
        <main class="p-4 md:p-6 lg:p-8 space-y-7">
            <?php aui_hero('Complaint Reports', 'rate_review', 'Complaint Analytics', 'Complaints filed by residents — status, categories, priority, puroks and resolution — from the actual records.', 'complaint_rep.php', 'Back to Complaints'); ?>
            <?php aui_date_form($p); ?>
            <?php aui_ai_section(); ?>
            <section class="aui-panel overflow-hidden">
                <div class="px-6 pt-6 pb-4 flex flex-wrap items-end justify-between gap-3">
                    <div class="flex items-center gap-3"><span class="material-symbols-outlined text-white p-2 rounded-xl" style="background:var(--accent-600)">folder_open</span>
                        <div><h2 class="text-lg font-black text-slate-800">Complaint Records</h2><p class="text-[10px] text-slate-400 font-bold">Every complaint filed in the selected range. Anonymous complaints never show the name.</p></div></div>
                    <input type="text" id="recordSearch" placeholder="Search ID, title, category, purok…" oninput="renderRecords()" class="aui-field w-full sm:w-64">
                </div>
                <div class="overflow-x-auto max-h-[560px] overflow-y-auto"><table class="dt"><thead><tr><th>Complaint ID</th><th>Title</th><th>Category</th><th>Priority</th><th>Complainant</th><th>Purok</th><th>Filed</th><th>Replied</th><th>Status</th></tr></thead><tbody id="recordsBody"></tbody></table></div>
                <p class="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase border-t border-slate-100" id="recordsCount">—</p>
            </section>
        </main>
    </div>
</div>
<?php aui_report_modal('Complaint Analytics Report', 'Summary, statistics, tables, complaint records and data interpretation.'); ?>
<?php aui_script(['dataUrl' => 'complaint_analytics.php', 'aiUrl' => '../backend/complaint_ai_summary.php', 'reportUrl' => '../backend/complaint_analytics_report.php',
    'aiLabels' => ['Trends', 'Category & Priority Patterns', 'Complainant Observations', 'Recommended Actions'], 'basis' => 'complaint figures (no names)',
    'openBasis' => 'All complaints on file', 'rangeBasis' => 'Complaints filed within the range'], $a ? ['success' => true] + $a : null); ?>
<script>
    const ST_C = { Pending: '#f97316', Ongoing: '#2a78d6', Resolved: '#1baf7a' };
    const PR_C = { Low: '#1baf7a', Medium: '#eab308', 'High (Urgent)': '#e11d48' };
    function renderRecords() {
        const tb = document.getElementById('recordsBody');
        if (!DATA) { tb.innerHTML = ''; return; }
        const q = (document.getElementById('recordSearch').value || '').toLowerCase().trim();
        const list = DATA.records.filter(r => !q || [r.id, r.title, r.category, r.purok, r.status, r.complainant].some(v => String(v || '').toLowerCase().includes(q)));
        document.getElementById('recordsCount').textContent = `Showing ${list.length} of ${DATA.records.length} complaint(s)`;
        tb.innerHTML = list.length ? list.map(r => `<tr><td class="font-mono">${esc(r.id)}</td><td>${esc(r.title)}</td><td>${esc(r.category)}</td><td>${esc(r.priority)}</td><td>${esc(r.complainant)}</td><td>${esc(r.purok)}</td><td class="whitespace-nowrap">${esc(r.filed)}</td><td>${r.replied ? 'Yes' : 'No'}</td><td>${esc(r.status)}</td></tr>`).join('')
            : '<tr><td colspan="9" class="empty">No complaints found.</td></tr>';
    }
    AUI.start(function (d) {
        const t = d.totals, T = t.total;
        let html = section('rate_review', 'Complaint Summary', 'Complaints by date filed · ' + d.range.label,
            `<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
                ${kpi('Total Complaints', num(T), d.comparison ? (T - d.comparison.rows[0].previous >= 0 ? '+' : '') + (T - d.comparison.rows[0].previous) + ' vs previous period' : t.per_week + ' per week')}
                ${kpi('Pending', num(t.pending), pct(t.pending, T) + ' of complaints')}
                ${kpi('Ongoing', num(t.ongoing), pct(t.ongoing, T) + ' of complaints')}
                ${kpi('Resolved', num(t.resolved), rate(t.resolution_rate) + ' resolution rate')}
                ${kpi('High (Urgent)', num(t.high), pct(t.high, T) + ' of complaints')}
                ${kpi('With Admin Reply', num(t.replied), rate(t.reply_rate) + ' reply rate')}
                ${kpi('Anonymous', num(t.anonymous), pct(t.anonymous, T) + ' of complaints')}
                ${kpi('From Residents', num(t.from_app), 'registered residents')}
                ${kpi('With Attachment', num(t.with_attachment), 'photo / file attached')}
                ${kpi('Busiest Day', d.busiest_day || '—', d.busiest_hour ? 'around ' + d.busiest_hour : '')}
            </div>`);
        const catRows = d.by_category.map(c => [c.category, num(c.n), pct(c.n, T), num(c.pending), num(c.ongoing), num(c.resolved), num(c.high)]);
        if (catRows.length) catRows.push(['Total', num(T), T ? '100%' : '0%', num(t.pending), num(t.ongoing), num(t.resolved), num(t.high)]);
        html += section('donut_large', 'Status, Categories & Priority', 'Where the complaints stand and what they are about',
            `<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                ${card('c-status', 'Complaint Status', 'Pending, ongoing and resolved', { empty: T ? '' : 'No complaints in this range.', table: table(['Status', 'Complaints', 'Share'], distRows(d.by_status, T), [1, 2]) })}
                ${card('c-cat', 'Complaints by Category', 'Status per category', { span: 'lg:col-span-2', empty: T ? '' : 'No complaints in this range.' })}
                ${card('c-prio', 'Priority Level', 'Low, medium and high (urgent)', { empty: T ? '' : 'No complaints.', table: table(['Priority', 'Complaints', 'Share'], distRows(d.by_priority, T), [1, 2]) })}
                ${card('c-purok', 'Complaints by Purok', 'Top puroks', { span: 'lg:col-span-2', empty: T ? '' : 'No complaints.', table: table(['Purok', 'Complaints', 'Share'], distRows(d.by_purok, T), [1, 2]) })}
            </div>
            <div class="mt-6 chart-card"><h3>Category Summary</h3><p class="c-sub">Per category</p>
                <div class="mt-3 overflow-x-auto">${table(['Category', 'Complaints', 'Share', 'Pending', 'Ongoing', 'Resolved', 'High (Urgent)'], catRows, [1, 2, 3, 4, 5, 6])}</div></div>`);
        const hr = Object.fromEntries(Object.entries(d.hours).filter(x => x[1] > 0));
        html += section('insights', 'Trends & Comparison', 'Complaints over time and when they are filed',
            `<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                ${card('c-trend', 'Complaints over Time', 'Per ' + d.trend.granularity + ': filed, resolved and high priority', { span: 'lg:col-span-2', empty: d.trend.labels.length > 1 && T ? '' : 'Not enough data for a trend.' })}
                ${card('c-weekday', 'Complaints by Day of Week', 'Day the complaint was filed', { empty: T ? '' : 'No complaints.', table: table(['Day', 'Complaints', 'Share'], distRows(d.weekday, T), [1, 2]) })}
                ${card('c-hours', 'Complaints by Hour', 'Time the complaint was filed', { empty: T ? '' : 'No complaints.', table: table(['Hour', 'Complaints', 'Share'], distRows(hr, T), [1, 2]) })}
                ${compareSection(d)}
            </div>`);
        document.getElementById('raBody').innerHTML = html;
        renderRecords();
        if (T) donut('c-status', d.by_status, k => ST_C[k], T);
        if (T) mk('c-cat', { type: 'bar', data: { labels: d.by_category.map(c => c.category), datasets: [
            { label: 'Pending', data: d.by_category.map(c => c.pending), backgroundColor: ST_C.Pending, borderRadius: 3, maxBarThickness: 26 },
            { label: 'Ongoing', data: d.by_category.map(c => c.ongoing), backgroundColor: ST_C.Ongoing, borderRadius: 3, maxBarThickness: 26 },
            { label: 'Resolved', data: d.by_category.map(c => c.resolved), backgroundColor: ST_C.Resolved, borderRadius: 3, maxBarThickness: 26 }] },
            options: { plugins: { legend: legendTop }, scales: { x: Object.assign({ stacked: true }, noGrid), y: Object.assign({ stacked: true }, axisCount) } } });
        if (T) donut('c-prio', d.by_priority, k => PR_C[k], T);
        if (T) mk('c-purok', barCfg(Object.keys(d.by_purok), Object.values(d.by_purok), '#0ea5e9', true));
        const n = d.trend.labels.length;
        if (n > 1 && T) mk('c-trend', { type: 'line', data: { labels: d.trend.labels, datasets: [lineDs('Filed', d.trend.filed, COLORS.s1, n), lineDs('Resolved', d.trend.resolved, COLORS.s3, n), lineDs('High (Urgent)', d.trend.high, COLORS.red, n)] },
            options: { interaction: { mode: 'index', intersect: false }, plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
        if (T) mk('c-weekday', barCfg(Object.keys(d.weekday), Object.values(d.weekday), COLORS.s1));
        if (T) mk('c-hours', barCfg(Object.keys(d.hours), Object.values(d.hours), COLORS.s2));
        drawCompare(d);
    });
</script>
</body>
</html>
