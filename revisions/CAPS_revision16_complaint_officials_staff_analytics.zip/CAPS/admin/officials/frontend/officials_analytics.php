<?php
/**
 * officials_analytics.php — Officials Analytics (View Analytics from Barangay Officials).
 * Same structure / behavior as the other CAPS analytics pages: Start / End Date (empty = all records),
 * AI Analytics on top (manual only), Data Interpretation, cards / charts / tables, Save PDF / Print
 * (../backend/officials_analytics_report.php) asking whether to include the AI findings.
 */
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_once __DIR__ . '/../../theme_loader.php';
try { require_permission($pdo, 'officials', 'read'); } catch (Throwable $e) { http_response_code(403); exit('Access denied.'); }
require_once __DIR__ . '/../../staffbpso/backend/staffbpso_common.php';
staffbpso_migrate_schema($pdo);
require_once __DIR__ . '/../backend/officials_analytics_data.php';

$p = ra_params($_GET);
$a = null;
try { $a = officials_analytics_compute($pdo, $p); } catch (Throwable $e) { error_log('[Officials analytics] ' . $e->getMessage()); }
if (($_GET['action'] ?? '') === 'data') aui_json($a ? ['success' => true] + $a : ['success' => false, 'error' => 'Could not load the officials analytics.']);
$current_page = 'Officials';
$_theme_head_loaded = true;
?>
<!DOCTYPE html>
<html <?php echo $theme_attrs['html']; ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officials Analytics — CAPS</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
    <?php include __DIR__ . '/../../theme_head.php'; ?>
    <script>tailwind.config = { theme: { extend: { colors: { primary: { DEFAULT: 'var(--accent-600)', light: 'var(--accent-500)', dark: 'var(--accent-700)' } }, fontFamily: { sans: ['"Plus Jakarta Sans"', 'sans-serif'] } } } };</script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--page-bg, #eef2fb); -webkit-font-smoothing: antialiased; }
        .main-wrapper { margin-left: 288px; width: calc(100% - 288px); }
        @media (max-width: 1024px) { .main-wrapper { margin-left: 0; width: 100%; } }
    </style>
    <?php aui_styles(); ?>
</head>
<body <?php echo $theme_attrs['body']; ?>>
<div class="flex min-h-screen">
    <?php include __DIR__ . '/../../sidebar.php'; ?>
    <div class="flex-1 flex flex-col min-w-0 main-wrapper">
        <?php include __DIR__ . '/../../header.php'; ?>
        <main class="p-4 md:p-6 lg:p-8 space-y-7">
            <?php aui_hero('Barangay Officials', 'shield_person', 'Officials Analytics', 'Elected officials and appointed personnel — positions, terms, turnover and profile — from the actual records.', 'officials.php', 'Back to Officials'); ?>
            <?php aui_date_form($p); ?>
            <?php aui_ai_section(); ?>
        </main>
    </div>
</div>
<?php aui_report_modal('Officials Analytics Report', 'Summary, positions, terms, profile, personnel, tables and data interpretation.'); ?>
<?php aui_script(['dataUrl' => 'officials_analytics.php', 'aiUrl' => '../backend/officials_ai_summary.php', 'reportUrl' => '../backend/officials_analytics_report.php',
    'aiLabels' => ['Changes over Time', 'Turnover & Term Patterns', 'Officials & Personnel Profile', 'Recommended Actions'], 'basis' => 'officials figures (no names)',
    'openBasis' => 'All terms and assignments on file', 'rangeBasis' => 'Assignments active within the range'], $a ? ['success' => true] + $a : null); ?>
<script>
    const TS_C = { Current: '#1baf7a', 'Completed Term': '#2a78d6', 'Ended Early': '#e11d48' };
    AUI.start(function (d) {
        const t = d.totals, O = t.officials;
        let html = section('shield_person', 'Officials Summary', 'Assignments active within the range · ' + d.range.label,
            `<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
                ${kpi('Officials Serving', num(O), num(t.current) + ' current')}
                ${kpi('Positions Filled', num(9 - t.vacant) + ' / 9', t.vacant ? t.vacant + ' vacant' : 'all filled')}
                ${kpi('Completed Terms', num(t.completed), 'ended on schedule')}
                ${kpi('Ended Early', num(t.ended_early), pct(t.ended_early, O) + ' of terms')}
                ${kpi('Ending Soon', num(t.ending_soon), 'within 90 days')}
                ${kpi('Terms Started', num(t.started_in_range), 'within the range')}
                ${kpi('Terms Ended', num(t.ended_in_range), 'within the range')}
                ${kpi('Avg Term Length', t.avg_term_years === null ? '—' : t.avg_term_years + ' yrs', 'served so far')}
                ${kpi('Average Age', t.avg_age === null ? '—' : t.avg_age, 'of the officials')}
                ${kpi('Personnel', num(t.staff), num(t.staff_active) + ' active · ' + num(t.staff_started) + ' hired')}
            </div>`);
        html += section('badge', 'Positions & Terms', 'Who holds each elected position and how terms ended',
            `<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                ${card('c-status', 'Term Status', 'Current, completed or ended early', { empty: O ? '' : 'No officials in this range.', table: table(['Status', 'Officials', 'Share'], distRows(d.by_status, O), [1, 2]) })}
                ${card('c-reason', 'Reasons Terms Ended', 'From the End Term records', { empty: sum(d.end_reasons) ? '' : 'No term ended with a reason.', table: table(['Reason', 'Terms', 'Share'], distRows(d.end_reasons, sum(d.end_reasons)), [1, 2]) })}
                ${card('c-assign', 'Assignments per Position', 'How often each position changed hands', { empty: O ? '' : 'No officials.' })}
            </div>
            <div class="mt-6 chart-card"><h3>Elected Positions</h3><p class="c-sub">Current holder of each position</p>
                <div class="mt-3 overflow-x-auto">${table(['Position', 'Current holder', 'Term ends', 'Assignments in range'], d.positions.map(x => [x.position, x.holder, x.term_end, num(x.assignments)]), [3])}</div></div>`);
        html += section('groups', 'Officials Profile', 'Sex, age, civil status and education of the officials (from their resident records)',
            `<div class="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">
                ${card('c-sex', 'Sex', 'Officials by sex', { empty: O ? '' : 'No officials.', table: table(['Sex', 'Officials', 'Share'], distRows(d.sex, O), [1, 2]) })}
                ${card('c-age', 'Age Group', 'As of the end of the range', { empty: O ? '' : 'No officials.', table: table(['Age group', 'Officials', 'Share'], distRows(d.age_groups, O), [1, 2]) })}
                ${card('c-civil', 'Civil Status', 'Officials by civil status', { empty: O ? '' : 'No officials.', table: table(['Civil status', 'Officials', 'Share'], distRows(d.civil_status, O), [1, 2]) })}
                ${card('c-educ', 'Education', 'Highest education level', { empty: O ? '' : 'No officials.', table: table(['Education', 'Officials', 'Share'], distRows(d.education, O), [1, 2]) })}
            </div>`);
        html += section('badge', 'Appointed Personnel', 'Secretary, treasurer, staff, BHW, tanod and other personnel active within the range',
            `<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                ${card('c-staffpos', 'Personnel by Position', num(t.staff) + ' personnel', { span: 'lg:col-span-1', empty: t.staff ? '' : 'No personnel in this range.', table: table(['Position', 'Personnel', 'Share'], distRows(d.staff_positions, t.staff), [1, 2]) })}
                <div class="chart-card lg:col-span-2"><h3>Personnel List</h3><p class="c-sub">Active within the range</p>
                    <div class="mt-3 overflow-x-auto max-h-[320px] overflow-y-auto">${table(['Name', 'Position', 'Start', 'End', 'End reason'], d.staff_records.map(x => [x.name, x.position, x.start, x.end, x.reason || '—']))}</div></div>
            </div>`);
        const n = d.trend.labels.length, moves = sum(d.trend.started) + sum(d.trend.ended) + sum(d.trend.staff_started) + sum(d.trend.staff_ended);
        html += section('insights', 'Turnover & Comparison', 'Terms and personnel started / ended over time',
            `<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                ${card('c-trend', 'Turnover over Time', 'Per ' + d.trend.granularity, { span: 'lg:col-span-2', empty: n > 1 && moves ? '' : 'No term or personnel change in this range.' })}
                ${compareSection(d)}
            </div>
            <div class="mt-6 chart-card"><h3>Official Terms</h3><p class="c-sub">Every elected-official assignment active within the range</p>
                <div class="mt-3 overflow-x-auto max-h-[420px] overflow-y-auto">${table(['Official', 'Position', 'Term start', 'Term end', 'Status', 'End reason'], d.records.map(r => [r.name, r.position, r.term_start, r.term_end, r.status, r.reason || '—']))}</div></div>`);
        document.getElementById('raBody').innerHTML = html;
        if (O) donut('c-status', d.by_status, k => TS_C[k], O);
        if (sum(d.end_reasons)) donut('c-reason', d.end_reasons, null, sum(d.end_reasons));
        if (O) mk('c-assign', barCfg(d.positions.map(x => x.position.replace('Kagawad - ', 'Kag. ')), d.positions.map(x => x.assignments), COLORS.violet, true));
        if (O) donut('c-sex', d.sex, k => ({ Male: '#2a78d6', Female: '#ec4899' })[k] || COLORS.muted, O);
        if (O) mk('c-age', barCfg(Object.keys(d.age_groups), Object.values(d.age_groups), COLORS.s1));
        if (O) donut('c-civil', d.civil_status, null, O);
        if (O) mk('c-educ', barCfg(Object.keys(d.education), Object.values(d.education), COLORS.s3, true));
        if (t.staff) mk('c-staffpos', barCfg(Object.keys(d.staff_positions), Object.values(d.staff_positions), '#0ea5e9', true));
        if (n > 1 && moves) mk('c-trend', { type: 'line', data: { labels: d.trend.labels, datasets: [lineDs('Terms started', d.trend.started, COLORS.s3, n), lineDs('Terms ended', d.trend.ended, COLORS.red, n),
            lineDs('Personnel hired', d.trend.staff_started, COLORS.s1, n), lineDs('Personnel ended', d.trend.staff_ended, COLORS.s2, n)] },
            options: { interaction: { mode: 'index', intersect: false }, plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
        drawCompare(d);
    });
</script>
</body>
</html>
