<?php
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_once __DIR__ . '/../../theme_loader.php';
require_once __DIR__ . '/../../activity_log_helper.php';
require_once __DIR__ . '/../backend/officials_common.php';
officials_migrate_schema($pdo);
// Add Official's resident eligibility list also excludes current
// Staff/BPSO (below) — make sure the `staff` table's EffectiveEnd column
// exists even on a fresh install where the Staff/BPSO page hasn't run
// its own migration yet.
require_once __DIR__ . '/../../staffbpso/backend/staffbpso_common.php';
staffbpso_migrate_schema($pdo);
$current_page = 'Officials';
$_theme_head_loaded = true;

if (!isset($_SESSION)) session_start();
if (empty($_SESSION['officials_csrf'])) $_SESSION['officials_csrf'] = bin2hex(random_bytes(32));

try { require_permission($pdo, 'officials', 'read'); }
catch (Throwable $e) { http_response_code(403); exit('Access denied.'); }

$positions = [
    'Barangay Captain',
    'Kagawad - Health & Sanitation', 'Kagawad - Education', 'Kagawad - Social Services',
    'Kagawad - Peace & Order', 'Kagawad - Infrastructure', 'Kagawad - Agriculture',
    'Kagawad - Environment', 'SK Chairperson'
];

function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function official_name(array $o) {
    return trim(implode(' ', array_filter([$o['FirstName'] ?? '', $o['MiddleName'] ?? '', $o['LastName'] ?? '', $o['Suffix'] ?? ''])));
}
function official_initials(array $o) {
    $a = strtoupper(substr(trim($o['FirstName'] ?? ''), 0, 1));
    $b = strtoupper(substr(trim($o['LastName'] ?? ''), 0, 1));
    return $a . $b;
}
function official_photo_url($photo) {
    if (!$photo) return null;
    $abs = __DIR__ . '/../uploads/officials/' . basename($photo);
    if (!is_file($abs)) return null;
    return '../uploads/officials/' . rawurlencode(basename($photo));
}

$officials = [];
$residents = [];
$available_positions = $positions;
$support = ['tanod'=>[], 'health_worker'=>[], 'staff'=>[]];

try {
    $stmt = $pdo->query("SELECT o.*, r.FirstName, r.MiddleName, r.LastName, r.Suffix, r.ResidentCode,
        r.HouseNumber, r.BuildingName, r.StreetName, r.Purok, r.AreaName, r.AreaType, r.BarangayName,
        r.CityMunicipalityName, r.ProvinceName, r.RegionName, r.ZipCode, r.ContactNumber, r.Email,
        r.Sex, r.BirthDate, r.CivilStatus, r.BirthPlace, r.Religion, r.Nationality,
        r.EmploymentStatus, r.Occupation, r.SourceOfIncome, r.TotalHouseholdIncome,
        r.EducationLevel, r.IsPWD, r.IsSenior, r.IsSoloParent, r.IsVoter, r.IsDeceased
        FROM officials o
        LEFT JOIN residents r ON r.ResidentID = o.ResidentID
        WHERE o.ActualEndDate IS NULL AND (o.TermEnd IS NULL OR o.TermEnd >= CURDATE())
        ORDER BY FIELD(o.Position,
          'Barangay Captain',
          'Kagawad - Health & Sanitation','Kagawad - Education','Kagawad - Social Services',
          'Kagawad - Peace & Order','Kagawad - Infrastructure','Kagawad - Agriculture',
          'Kagawad - Environment','SK Chairperson'), o.TermStart DESC, o.OfficialID ASC");
    $officials = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $occupied = array_column($officials, 'Position');
    $available_positions = array_values(array_diff($positions, $occupied));

    // Resident picker is a live search (../backend/search_residents.php) — no preloaded list.

    // Every term on record (regardless of current/ended status) — used purely
    // client-side to catch an overlapping Position/Resident + date combination
    // the moment the admin picks it, instead of only after Save Official fails.
    $allTermsStmt = $pdo->query("SELECT o.OfficialID, o.ResidentID, o.Position, o.TermStart, o.TermEnd,
        TRIM(CONCAT_WS(' ', r.FirstName, r.MiddleName, r.LastName, r.Suffix)) AS ResidentName
        FROM officials o LEFT JOIN residents r ON r.ResidentID = o.ResidentID");
    $allTerms = $allTermsStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('[CAPS Officials] ' . $e->getMessage());
    $occupied = [];
    $allTerms = [];
}

try {
    $st = $pdo->query("SELECT s.EmployeeID, s.ResidentID, s.Name, s.Position, s.WorkEmail, s.WorkLoad,
        s.EffectiveStart, s.EffectiveEnd, s.RecordedBy, s.EndReason, s.EndedBy, s.CreatedAt,
        r.FirstName, r.MiddleName, r.LastName, r.Suffix, r.ContactNumber, r.Email,
        r.HouseNumber, r.StreetName, r.Purok, r.AreaName, r.BarangayName
        FROM staff s LEFT JOIN residents r ON r.ResidentID = s.ResidentID
        WHERE s.EffectiveEnd IS NULL
        ORDER BY s.Name");
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $p) {
        $hay = strtolower(($p['Position'] ?? '') . ' ' . ($p['WorkLoad'] ?? ''));
        if (preg_match('/tanod|bpso|barangay public safety|lupon|tagapamayapa/', $hay)) $support['tanod'][] = $p;
        elseif (preg_match('/health worker|healthcare|bhw|barangay health/', $hay)) $support['health_worker'][] = $p;
        else $support['staff'][] = $p;
    }
} catch (Throwable $e) { error_log('[CAPS Officials staff] ' . $e->getMessage()); }

$captain = null; $kagawads = [];
foreach ($officials as $o) {
    $pos = (string)($o['Position'] ?? '');
    if ($pos === 'Barangay Captain') $captain = $o;
    elseif (str_starts_with($pos, 'Kagawad') || $pos === 'SK Chairperson') $kagawads[] = $o;
}

$csrf = $_SESSION['officials_csrf'];
$flashError = ($_GET['status'] ?? '') === 'error' ? trim((string)($_GET['msg'] ?? '')) : '';
?>
<!DOCTYPE html>
<html <?php echo $theme_attrs['html']; ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Officials — Barangay Biñang 2nd</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
    <?php include __DIR__ . '/../../theme_head.php'; ?>
    <script>
        tailwind.config = {
            theme: { extend: {
                colors: {
                    primary: { DEFAULT: 'var(--accent-600)', light: 'var(--accent-500)', dark: 'var(--accent-700)' },
                    accent: { DEFAULT: 'var(--accent-500)', light: 'var(--accent-400)' }
                },
                fontFamily: { sans: ['"Plus Jakarta Sans"','sans-serif'], mono: ['"DM Mono"','monospace'] }
            }}
        };
    </script>
    <style>
        :root { --sidebar-w: 288px; --nav-h: 64px; }
        body { font-family:'Plus Jakarta Sans',sans-serif; background:var(--page-bg,#eef2fb); -webkit-font-smoothing:antialiased; }
        .main-wrapper { margin-left:var(--sidebar-w); width:calc(100% - var(--sidebar-w)); }
        @media(max-width:1024px){.main-wrapper{margin-left:0;width:100%;}}
        .hero-band{background:linear-gradient(135deg,var(--accent-700) 0%,var(--accent-600) 50%,var(--accent-700) 100%);}
        .hero-band:before{content:"";position:absolute;right:-48px;top:-48px;width:260px;height:260px;border-radius:9999px;background:var(--accent-400);opacity:.10;filter:blur(48px);pointer-events:none}
        .hero-band:after{content:"";position:absolute;left:33%;bottom:-48px;width:190px;height:190px;border-radius:9999px;background:var(--accent-300);opacity:.10;filter:blur(36px);pointer-events:none}
        .tree-card{box-shadow:0 10px 30px -18px rgba(15,23,42,.28);}
        .tree-stem{width:2px;background:#cbd5e1;margin:auto;}
        .tree-branch{height:2px;background:#cbd5e1;position:absolute;left:7%;right:7%;top:0;}
        .photo-ring{box-shadow:0 8px 25px -12px rgba(15,23,42,.35);}
        html.dark body{background:#0f172a;color:#e2e8f0}
        html.dark .bg-white{background:#1e293b!important}
        html.dark .bg-slate-50{background:#0f172a!important}
        html.dark .bg-slate-100{background:#1e293b!important}
        html.dark .text-slate-900{color:#f1f5f9!important}
        html.dark .text-slate-800{color:#e2e8f0!important}
        html.dark .text-slate-700{color:#cbd5e1!important}
        html.dark .text-slate-600{color:#94a3b8!important}
        html.dark .text-slate-500{color:#64748b!important}
        html.dark .text-slate-400{color:#64748b!important}
        html.dark .border-slate-100,html.dark .border-slate-200{border-color:#334155!important}
        html.dark input,html.dark select{background:#0f172a!important;border-color:#334155!important;color:#e2e8f0!important}
        @media print{.no-print{display:none!important}.main-wrapper{margin-left:0;width:100%}.print-card{box-shadow:none!important}}
        #cropWrap .img-container{width:100%;height:260px;background:#0f172a0d;border-radius:16px;overflow:hidden}
        #cropWrap .img-container img{display:block;max-width:100%}
        #cropWrap input[type=range]{accent-color:var(--accent-500,#6366f1)}
        #addModal .ts-control{border-radius:1rem;border-color:#e2e8f0;padding:.75rem 1rem;font-size:.875rem;font-weight:600;margin-top:.375rem}
        #addModal .ts-dropdown{border-radius:1rem;overflow:hidden;font-size:.875rem}
        #addModal .ts-dropdown .option{padding:.6rem 1rem}
        html.dark #addModal .ts-control,html.dark #addModal .ts-dropdown{background:#0f172a!important;border-color:#334155!important;color:#e2e8f0!important}
    </style>
</head>
<body <?php echo $theme_attrs['body']; ?>>
<div class="flex min-h-screen">
    <?php include __DIR__ . '/../../sidebar.php'; ?>
    <div class="flex-1 flex flex-col min-w-0 main-wrapper">
        <?php include __DIR__ . '/../../header.php'; ?>
        <main class="p-4 md:p-6 lg:p-8 space-y-8">
            <?php if ($flashError): ?>
            <div id="flashErrorBanner" class="flex items-start gap-3 bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4 md:p-5">
                <span class="material-symbols-outlined text-xl flex-shrink-0">error</span>
                <div class="flex-1"><p class="font-bold text-sm">Could not save this official</p><p class="text-sm mt-0.5"><?php echo h($flashError); ?></p></div>
                <button onclick="document.getElementById('flashErrorBanner').remove()" class="text-red-400 hover:text-red-600 flex-shrink-0"><span class="material-symbols-outlined">close</span></button>
            </div>
            <?php endif; ?>
            <div class="hero-band rounded-2xl p-6 md:p-8 text-white relative overflow-hidden">
                <div class="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                        <h1 class="text-2xl md:text-3xl font-black tracking-tight leading-none">Barangay Officials</h1>
                        <p class="text-white/60 text-sm mt-2 font-medium">Official hierarchy, current personnel, and yearly barangay leadership history.</p>
                    </div>
                    <div class="flex flex-wrap gap-3 no-print">
                        <a href="officials_analytics.php" class="flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all"><span class="material-symbols-outlined text-lg">analytics</span>View Analytics</a>
                        <a href="history.php" class="flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all"><span class="material-symbols-outlined text-lg">history</span>Yearly History</a>
                        <button onclick="openModal('reportModal')" class="flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all"><span class="material-symbols-outlined text-lg">print</span>Reports</button>
                        <?php if (staff_can($pdo,'officials','create')): ?>
                        <button onclick="openAddModal()" class="flex items-center gap-2 bg-accent hover:bg-accent-light text-white px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all shadow-lg"><span class="material-symbols-outlined text-lg">person_add</span>Add Official</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <section class="bg-white rounded-[32px] border border-slate-100 shadow-sm p-5 md:p-8 overflow-x-auto print-card">
                <div class="min-w-[900px]">
                    <div class="text-center">
                        <div class="inline-flex flex-col items-center">
                            <div class="w-3 h-3 rounded-full bg-slate-300"></div>
                            <div class="tree-stem h-7"></div>
                        </div>
                    </div>

                    <?php if ($captain): $photo = official_photo_url($captain['Photo'] ?? null); ?>
                    <div class="flex justify-center">
                        <div class="w-[270px] bg-white border-2 border-indigo-100 rounded-[28px] p-5 tree-card text-center relative">
                            <div class="text-[10px] font-bold uppercase tracking-widest text-accent">Punong Barangay</div>
                            <div class="w-24 h-24 rounded-2xl overflow-hidden mx-auto mt-3 bg-slate-100 photo-ring border-4 border-white">
                                <?php if ($photo): ?><img src="<?php echo h($photo); ?>" class="w-full h-full object-cover" alt="Official photo">
                                <?php else: ?><div class="w-full h-full flex items-center justify-center text-slate-300"><span class="text-lg font-black"><?php echo h(official_initials($captain)); ?></span></div><?php endif; ?>
                            </div>
                            <div class="text-lg font-black text-slate-800 mt-3 leading-tight">Hon. <?php echo h(official_name($captain)); ?></div>
                            <div class="text-[10px] text-slate-400 font-bold mt-1"><?php echo h($captain['TermStart'].' — '.$captain['TermEnd']); ?></div>
                            <button onclick='viewOfficial(<?php echo json_encode($captain, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>)' class="mt-3 px-4 py-2 rounded-xl bg-slate-50 hover:bg-accent-50 text-[10px] font-bold text-slate-600 hover:text-accent transition-all no-print">Details</button>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="flex justify-center"><div class="w-[270px] border-2 border-dashed border-slate-200 rounded-[28px] p-8 text-center text-sm font-bold text-slate-400">Punong Barangay not assigned.</div></div>
                    <?php endif; ?>
                    <div class="tree-stem h-7"></div>

                    <div class="relative pt-7">
                        <div class="tree-branch"></div>
                        <div class="grid grid-cols-4 gap-4">
                            <?php foreach ($kagawads as $k): $photo = official_photo_url($k['Photo'] ?? null); ?>
                            <div class="bg-white border border-slate-100 rounded-2xl p-5 text-center tree-card">
                                <div class="w-16 h-16 rounded-2xl overflow-hidden mx-auto bg-slate-100 border-4 border-white photo-ring">
                                    <?php if ($photo): ?><img src="<?php echo h($photo); ?>" class="w-full h-full object-cover" alt="Official photo">
                                    <?php else: ?><div class="w-full h-full flex items-center justify-center text-slate-400 font-black text-xs"><?php echo h(official_initials($k)); ?></div><?php endif; ?>
                                </div>
                                <div class="font-bold text-sm text-slate-700 mt-3 leading-tight">Hon. <?php echo h(official_name($k)); ?></div>
                                <div class="text-[9px] font-bold uppercase tracking-widest text-accent mt-1"><?php echo h(str_replace('Kagawad - ','',$k['Position'])); ?></div>
                                <button onclick='viewOfficial(<?php echo json_encode($k, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>)' class="mt-3 text-[10px] font-bold text-slate-400 hover:text-accent no-print">VIEW DETAILS</button>
                            </div>
                            <?php endforeach; ?>
                            <?php if (!$kagawads): ?><div class="col-span-4 text-center py-10 text-sm text-slate-400">No current Kagawad records.</div><?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>

            <section>
                <div class="flex items-center gap-3 mb-4"><p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Personnel from Staff / BPSO</p><div class="flex-1 h-px bg-slate-200"></div></div>
                <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
                    <?php $labels=['tanod'=>['Barangay Tanod','shield'],'health_worker'=>['Health Workers (BHW)','medical_services'],'staff'=>['Staff','badge']]; foreach($labels as $key=>$meta): ?>
                    <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
                        <div class="flex items-center gap-2"><span class="material-symbols-outlined text-slate-400"><?php echo $meta[1]; ?></span><p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest"><?php echo h($meta[0]); ?></p></div>
                        <div class="mt-4 space-y-2 max-h-80 overflow-y-auto pr-1">
                            <?php foreach ($support[$key] as $p): $p['Status'] = 'Current'; $p['EffectiveStart'] = $p['EffectiveStart'] ?: substr((string)$p['CreatedAt'], 0, 10); ?>
                            <button type="button" onclick='viewStaff(<?php echo json_encode($p, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>)' class="w-full text-left rounded-xl bg-slate-50 hover:bg-slate-100 p-3 transition-colors">
                                <div class="flex items-start justify-between gap-2">
                                    <div class="min-w-0"><div class="font-bold text-sm text-slate-700 truncate"><?php echo h($p['Name'] ?: trim(($p['FirstName']??'').' '.($p['LastName']??''))); ?></div><div class="text-[10px] text-slate-400 mt-0.5"><?php echo h($p['Position'] ?: 'Personnel'); ?></div></div>
                                    <span class="shrink-0 px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-emerald-50 text-emerald-700">Current</span>
                                </div>
                                <div class="text-[10px] text-slate-400 mt-1.5"><?php echo h(($p['EffectiveStart'] ?: '—').' — Present'); ?></div>
                            </button>
                            <?php endforeach; ?>
                            <?php if (!$support[$key]): ?><div class="text-xs text-slate-400">No personnel found.</div><?php endif; ?>
                        </div>
                        <div class="text-[10px] font-bold text-accent mt-4"><?php echo count($support[$key]); ?> MEMBER(S)</div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

        </main>
    </div>
</div>

<!-- Add Official (create only — there is no Edit Official function; use End Term to close out a current term) -->
<div id="addModal" class="fixed inset-0 hidden z-50 bg-slate-950/60 backdrop-blur-sm p-4 items-center justify-center">
  <div class="bg-white rounded-[32px] w-full max-w-xl p-6 md:p-8 max-h-[92vh] overflow-y-auto">
    <div class="flex items-start justify-between"><div><p class="text-[10px] font-bold uppercase tracking-widest text-accent">Personnel Management</p><h2 class="text-2xl font-black text-slate-800 mt-1">Add Official</h2></div><button onclick="closeModal('addModal')" class="text-slate-400 hover:text-slate-700"><span class="material-symbols-outlined">close</span></button></div>
    <form id="officialForm" action="../backend/official_actions.php" method="post" enctype="multipart/form-data" class="space-y-5 mt-6">
      <input type="hidden" name="csrf" value="<?php echo h($csrf); ?>"><input type="hidden" name="action" value="create">
      <label class="block"><span class="text-[10px] font-bold uppercase tracking-widest text-slate-400">Resident</span><select name="resident_id" id="resident_id" required placeholder="Type resident name, Resident ID or address..." autocomplete="off"></select><span class="block text-[10px] text-slate-400 mt-1">Type to search. Current officials and staff are not listed.</span></label>
      <label class="block"><span class="text-[10px] font-bold uppercase tracking-widest text-slate-400">Position</span><select name="position" id="position" required class="w-full mt-1.5 rounded-2xl border-slate-200 py-3 text-sm font-semibold"><option value="">Select available position...</option><?php foreach($available_positions as $p): ?><option value="<?php echo h($p); ?>"><?php echo h($p); ?></option><?php endforeach; ?></select><p class="text-[10px] text-slate-400 mt-1">Occupied active positions are automatically removed from this list.</p></label>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4"><label><span class="text-[10px] font-bold uppercase tracking-widest text-slate-400">Term Start</span><input type="date" name="term_start" id="term_start" required class="w-full mt-1.5 rounded-2xl border-slate-200 py-3 text-sm"></label><label><span class="text-[10px] font-bold uppercase tracking-widest text-slate-400">Term End</span><input type="date" name="term_end" id="term_end" required class="w-full mt-1.5 rounded-2xl border-slate-200 py-3 text-sm"></label></div>
      <div id="overlapError" class="hidden flex items-start gap-2 bg-red-50 border border-red-200 text-red-700 rounded-xl p-3 text-xs font-semibold"><span class="material-symbols-outlined text-base flex-shrink-0">error</span><span id="overlapErrorText"></span></div>
      <label class="block"><span class="text-[10px] font-bold uppercase tracking-widest text-slate-400">Official Photo</span><input type="file" id="photoInput" name="photo" accept="image/jpeg,image/png,image/webp" class="w-full mt-1.5 rounded-2xl border border-slate-200 p-2.5 text-xs"><p class="text-[10px] text-slate-400 mt-1">After choosing a photo, drag to reposition and use the slider to zoom before saving.</p></label>
      <div id="cropWrap" class="hidden">
        <div class="img-container"><img id="cropImg" alt="Photo to crop"></div>
        <div class="flex items-center gap-3 mt-3">
          <span class="material-symbols-outlined text-slate-400 text-lg">zoom_out</span>
          <input type="range" id="zoomRange" min="0" max="1" step="0.01" value="0" class="w-full">
          <span class="material-symbols-outlined text-slate-400 text-lg">zoom_in</span>
        </div>
      </div>
      <div class="flex justify-end gap-3 pt-2"><button type="button" onclick="closeModal('addModal')" class="px-4 py-3 text-xs font-bold text-slate-500">Cancel</button><button id="saveOfficialBtn" class="px-5 py-3 rounded-xl bg-accent text-white text-[10px] font-bold uppercase tracking-wider disabled:opacity-40 disabled:cursor-not-allowed">Save Official</button></div>
    </form>
  </div>
</div>

<!-- End Term: step 1 (confirm) -->
<div id="endTermConfirmModal" class="fixed inset-0 hidden z-[60] bg-slate-950/60 backdrop-blur-sm p-4 items-center justify-center">
  <div class="bg-white rounded-[28px] w-full max-w-md p-6 md:p-8">
    <div class="flex items-start gap-3"><span class="material-symbols-outlined text-3xl text-amber-500">warning</span><div><h2 class="text-xl font-black text-slate-800">End Official Term?</h2><p class="text-sm text-slate-500 mt-2">This official's term has not yet ended. Are you sure you want to end the term now?</p></div></div>
    <div class="flex justify-end gap-3 mt-6"><button type="button" onclick="closeModal('endTermConfirmModal')" class="px-4 py-3 text-xs font-bold text-slate-500">Cancel</button><button type="button" onclick="closeModal('endTermConfirmModal');openModal('endTermReasonModal')" class="px-5 py-3 rounded-xl bg-red-600 text-white text-[10px] font-bold uppercase tracking-wider">Yes, End Term</button></div>
  </div>
</div>

<!-- End Term: step 2 (reason) -->
<div id="endTermReasonModal" class="fixed inset-0 hidden z-[60] bg-slate-950/60 backdrop-blur-sm p-4 items-center justify-center">
  <div class="bg-white rounded-[28px] w-full max-w-md p-6 md:p-8">
    <h2 class="text-xl font-black text-slate-800">End Official Term</h2>
    <p id="endTermWho" class="text-sm text-slate-500 mt-1"></p>
    <form id="endTermReasonForm" onsubmit="return proceedToFinalConfirm(event)" class="mt-5 space-y-4">
      <label class="block"><span class="text-[10px] font-bold uppercase tracking-widest text-slate-400">Reason for Ending Term</span>
        <select id="endTermReasonSelect" onchange="document.getElementById('endTermReasonOther').classList.toggle('hidden', this.value!=='Other')" class="w-full mt-1.5 rounded-2xl border-slate-200 py-3 text-sm font-semibold">
          <option value="">Select reason...</option>
          <option value="Resigned">Resigned</option>
          <option value="Removed / Recalled">Removed / Recalled</option>
          <option value="Suspended">Suspended</option>
          <option value="Deceased">Deceased</option>
          <option value="Transferred / Relocated">Transferred / Relocated</option>
          <option value="Health Reasons">Health Reasons</option>
          <option value="Other">Other (please specify)</option>
        </select>
      </label>
      <label id="endTermReasonOther" class="block hidden"><span class="text-[10px] font-bold uppercase tracking-widest text-slate-400">Please specify</span><input type="text" id="endTermReasonText" maxlength="255" class="w-full mt-1.5 rounded-2xl border-slate-200 py-3 text-sm"></label>
      <div class="flex justify-end gap-3 pt-2"><button type="button" onclick="closeModal('endTermReasonModal')" class="px-4 py-3 text-xs font-bold text-slate-500">Cancel</button><button type="submit" class="px-5 py-3 rounded-xl bg-red-600 text-white text-[10px] font-bold uppercase tracking-wider">Continue</button></div>
    </form>
  </div>
</div>

<!-- End Term: step 3 (final confirmation before the term is actually ended) -->
<div id="endTermFinalModal" class="fixed inset-0 hidden z-[60] bg-slate-950/60 backdrop-blur-sm p-4 items-center justify-center">
  <div class="bg-white rounded-[28px] w-full max-w-md p-6 md:p-8">
    <div class="flex items-start gap-3"><span class="material-symbols-outlined text-3xl text-red-600">event_busy</span><div><h2 class="text-xl font-black text-slate-800">Confirm: End Term</h2><p class="text-sm text-slate-500 mt-2">This will end the term for:</p></div></div>
    <div class="mt-4 rounded-2xl bg-slate-50 p-4 space-y-1.5">
      <p id="endTermFinalWho" class="font-bold text-sm text-slate-800"></p>
      <p class="text-xs text-slate-500">Reason: <span id="endTermFinalReason" class="font-semibold text-slate-700"></span></p>
    </div>
    <p class="text-xs text-slate-400 mt-3">This action cannot be undone. The official's actual end date, reason, and who ended the term will all be recorded automatically. This will not delete the resident's profile or their previous Official History.</p>
    <form id="endTermForm" action="../backend/official_actions.php" method="post" class="mt-5">
      <input type="hidden" name="csrf" value="<?php echo h($csrf); ?>"><input type="hidden" name="action" value="end_term"><input type="hidden" name="official_id" id="endTermOfficialId"><input type="hidden" name="reason" id="endTermReasonFinal">
      <div class="flex justify-end gap-3"><button type="button" onclick="closeModal('endTermFinalModal');openModal('endTermReasonModal')" class="px-4 py-3 text-xs font-bold text-slate-500">Cancel</button><button type="submit" class="px-5 py-3 rounded-xl bg-red-600 text-white text-[10px] font-bold uppercase tracking-wider">Yes, End Term</button></div>
    </form>
  </div>
</div>

<!-- Details -->
<!-- Staff/BPSO details (same as Yearly History): term info + link to the full service history -->
<div id="staffViewModal" class="fixed inset-0 hidden z-50 bg-slate-950/60 backdrop-blur-sm p-4 items-center justify-center">
  <div class="bg-white rounded-[32px] w-full max-w-lg p-6 md:p-8 max-h-[92vh] overflow-y-auto">
    <div class="flex items-start justify-between">
      <div class="flex items-center gap-4">
        <div class="w-14 h-14 rounded-2xl overflow-hidden bg-slate-100 flex-shrink-0 flex items-center justify-center text-slate-400 font-black text-sm" id="sv_initials"></div>
        <div><p id="sv_position" class="text-[10px] font-bold uppercase tracking-widest text-accent"></p><h2 id="sv_name" class="text-xl md:text-2xl font-black text-slate-800 mt-0.5"></h2></div>
      </div>
      <button onclick="closeModal('staffViewModal')" class="text-slate-400"><span class="material-symbols-outlined">close</span></button>
    </div>
    <div class="grid grid-cols-2 gap-x-5 gap-y-4 mt-6">
      <div><p class="text-[9px] font-bold uppercase text-slate-400">Employee ID</p><p id="sv_id" class="font-bold text-sm mt-1"></p></div>
      <div><p class="text-[9px] font-bold uppercase text-slate-400">Status</p><p id="sv_status" class="font-bold text-sm mt-1"></p></div>
      <div><p class="text-[9px] font-bold uppercase text-slate-400">Start Date</p><p id="sv_start" class="font-bold text-sm mt-1"></p></div>
      <div><p class="text-[9px] font-bold uppercase text-slate-400">End Date</p><p id="sv_end" class="font-bold text-sm mt-1"></p></div>
      <div><p class="text-[9px] font-bold uppercase text-slate-400">Contact</p><p id="sv_phone" class="font-bold text-sm mt-1"></p></div>
      <div><p class="text-[9px] font-bold uppercase text-slate-400">Work Email</p><p id="sv_email" class="font-bold text-sm mt-1 break-all"></p></div>
      <div><p class="text-[9px] font-bold uppercase text-slate-400">Recorded By</p><p id="sv_recorded" class="font-bold text-sm mt-1"></p></div>
      <div><p class="text-[9px] font-bold uppercase text-slate-400">Ended By</p><p id="sv_endedby" class="font-bold text-sm mt-1"></p></div>
    </div>
    <div id="sv_reason_wrap" class="mt-4 rounded-2xl bg-rose-50 p-4 hidden">
      <p class="text-[9px] font-bold uppercase tracking-widest text-rose-400">Reason for Ending Term</p>
      <p id="sv_reason" class="text-sm text-rose-700 font-semibold mt-1"></p>
    </div>
    <div class="flex flex-wrap justify-end gap-2 mt-6"><a id="sv_residentLink" href="#" class="px-5 py-3 rounded-xl bg-accent text-white text-[10px] font-bold uppercase tracking-wider"><span class="material-symbols-outlined align-middle text-base">history</span> Profile &amp; Service History</a></div>
  </div>
</div>

<div id="viewModal" class="fixed inset-0 hidden z-50 bg-slate-950/60 backdrop-blur-sm p-4 items-center justify-center">
  <div class="bg-white rounded-[32px] w-full max-w-2xl p-6 md:p-8 max-h-[92vh] overflow-y-auto">
    <div class="flex items-start justify-between"><div><p id="v_position" class="text-[10px] font-bold uppercase tracking-widest text-accent"></p><h2 id="v_name" class="text-2xl md:text-3xl font-black text-slate-800 mt-1"></h2></div><button onclick="closeModal('viewModal')" class="text-slate-400"><span class="material-symbols-outlined">close</span></button></div>
    <div class="flex flex-col sm:flex-row gap-5 mt-6"><div id="v_photo" class="w-28 h-28 rounded-2xl overflow-hidden bg-slate-100 flex-shrink-0"></div><div class="grid grid-cols-2 gap-x-5 gap-y-4 flex-1"><div><p class="text-[9px] font-bold uppercase text-slate-400">Resident ID</p><p id="v_id" class="font-bold text-sm mt-1"></p></div><div><p class="text-[9px] font-bold uppercase text-slate-400">Term</p><p id="v_term" class="font-bold text-sm mt-1"></p></div><div><p class="text-[9px] font-bold uppercase text-slate-400">Contact</p><p id="v_phone" class="font-bold text-sm mt-1"></p></div><div><p class="text-[9px] font-bold uppercase text-slate-400">Email</p><p id="v_email" class="font-bold text-sm mt-1 break-all"></p></div></div></div>
    <div class="mt-6 rounded-2xl bg-slate-50 p-4">
      <p class="text-[9px] font-bold uppercase tracking-widest text-slate-400">Complete Address</p>
      <p class="text-[10px] text-slate-400 mt-0.5">Sourced directly from this official's Resident Profile.</p>
      <div id="v_address_grid" class="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-3 mt-3"></div>
      <p id="v_address_empty" class="text-sm text-slate-400 hidden">No address on file.</p>
    </div>
    <div class="flex flex-wrap justify-end gap-2 mt-6"><a id="residentLink" href="#" class="px-5 py-3 rounded-xl bg-accent text-white text-[10px] font-bold uppercase tracking-wider"><span class="material-symbols-outlined align-middle text-base">person_search</span> View Resident Profile</a><button id="v_endterm" class="hidden px-5 py-3 rounded-xl bg-red-50 text-red-600 text-[10px] font-bold uppercase tracking-wider"><span class="material-symbols-outlined align-middle text-base">event_busy</span> End Term</button></div>
  </div>
</div>

<!-- Report -->
<div id="reportModal" class="fixed inset-0 hidden z-50 bg-slate-950/60 backdrop-blur-sm p-4 items-center justify-center">
  <div class="bg-white rounded-[32px] w-full max-w-lg p-6 md:p-8"><div class="flex justify-between"><div><p class="text-[10px] font-bold uppercase tracking-widest text-accent">Officials & Personnel</p><h2 class="text-2xl font-black text-slate-800 mt-1">Reports</h2></div><button onclick="closeModal('reportModal')" class="text-slate-400"><span class="material-symbols-outlined">close</span></button></div>
    <p class="text-sm text-slate-500 mt-2">Choose what to include, then pick an action.</p>
    <form id="reportForm" action="../backend/official_report.php" method="get" target="_blank" class="mt-6 space-y-2.5">
      <?php foreach([['official','Officials','Barangay Captain, Kagawads, SK Chairperson'],['staff','Staff','All Staff / BPSO positions: Secretary, Treasurer, BHW, Mother Leader, Tanod, etc.'],['all','All','Officials and Staff']] as $opt): ?><label class="flex items-center gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-100 cursor-pointer"><input type="radio" name="scope" value="<?php echo $opt[0]; ?>" <?php echo $opt[0]==='all'?'checked':''; ?> class="text-accent focus:ring-accent"><span><span class="block text-sm font-bold text-slate-700"><?php echo h($opt[1]); ?></span><span class="block text-[11px] text-slate-400"><?php echo h($opt[2]); ?></span></span></label><?php endforeach; ?>
      <input type="hidden" name="mode" id="reportMode" value="pdf">
      <div class="flex justify-end gap-3 pt-3">
        <button type="button" onclick="closeModal('reportModal')" class="px-4 py-3 text-xs font-bold text-slate-500">Cancel</button>
        <button type="submit" onclick="document.getElementById('reportMode').value='pdf'" class="px-5 py-3 rounded-xl bg-slate-900 text-white text-[10px] font-bold uppercase tracking-wider"><span class="material-symbols-outlined align-middle text-base">save</span> Save as PDF</button>
        <button type="submit" onclick="document.getElementById('reportMode').value='print'" class="px-5 py-3 rounded-xl bg-white border-2 border-slate-900 text-slate-900 text-[10px] font-bold uppercase tracking-wider"><span class="material-symbols-outlined align-middle text-base">print</span> Print</button>
      </div>
    </form>
  </div>
</div>

<script>
const positions = <?php echo json_encode($positions); ?>;
const occupied = <?php echo json_encode(array_values($occupied)); ?>;
const allTerms = <?php echo json_encode($allTerms, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>;
let residentTS=null;
if (window.TomSelect) {
  residentTS = new TomSelect('#resident_id', {
    valueField:'id', labelField:'name', searchField:['name','code','address'],
    maxOptions:20, loadThrottle:250, openOnFocus:true, preload:false, maxItems:1, create:false,
    shouldLoad:q=>q.trim().length>=1, score:()=>()=>1,
    load:function(q,cb){ this.clearOptions();
      fetch('../backend/search_residents.php?q='+encodeURIComponent(q),{credentials:'same-origin'}).then(r=>r.json())
        .then(d=>cb(d.residents||[])).catch(()=>cb()); },
    render:{
      option:r=>'<div><div class="font-bold text-slate-800">'+escHtml(r.name)+' <span class="font-mono text-[11px] text-indigo-600">'+escHtml(r.code)+'</span></div><div class="text-[11px] text-slate-400">'+escHtml(r.address||'')+'</div></div>',
      item:r=>'<div><span class="font-bold">'+escHtml(r.name)+'</span> <span class="font-mono text-[11px] text-indigo-600">'+escHtml(r.code)+'</span></div>',
      no_results:()=>'<div class="no-results px-3 py-2 text-sm text-slate-400">No eligible resident found.</div>',
      loading:()=>'<div class="px-3 py-2 text-sm text-slate-400">Searching…</div>'
    },
    onChange:()=>checkOverlap()
  });
}
function escHtml(s){const d=document.createElement('div');d.textContent=String(s==null?'':s);return d.innerHTML}
function openModal(id){const e=document.getElementById(id);e.classList.remove('hidden');e.classList.add('flex')}
function closeModal(id){const e=document.getElementById(id);e.classList.add('hidden');e.classList.remove('flex')}

// Checks the currently-selected Resident / Position / Term Start / Term End
// against every term on record and shows an English error message the
// moment an overlapping combination is picked — instead of only finding out
// after clicking Save Official.
function checkOverlap(){
  const errBox=document.getElementById('overlapError');
  const errText=document.getElementById('overlapErrorText');
  const saveBtn=document.getElementById('saveOfficialBtn');
  const rid=parseInt(document.getElementById('resident_id').value||'0',10);
  const pos=document.getElementById('position').value;
  const start=document.getElementById('term_start').value;
  const end=document.getElementById('term_end').value;

  function showError(msg){ errText.textContent=msg; errBox.classList.remove('hidden'); saveBtn.disabled=true; }
  function clearError(){ errBox.classList.add('hidden'); saveBtn.disabled=false; }

  if (!start || !end) { clearError(); return; }
  if (end < start) { showError('Term End cannot be earlier than Term Start.'); return; }

  const overlaps = t => t.TermStart <= end && t.TermEnd >= start;

  if (pos) {
    const posConflict = allTerms.find(t => t.Position === pos && overlaps(t));
    if (posConflict) {
      const who = posConflict.ResidentName || ('Resident #'+posConflict.ResidentID);
      showError('That position is already assigned for an overlapping term ('+posConflict.TermStart+' to '+posConflict.TermEnd+', '+who+'). Please choose a different position or non-overlapping dates.');
      return;
    }
  }
  if (rid) {
    const residentConflict = allTerms.find(t => Number(t.ResidentID) === rid && overlaps(t));
    if (residentConflict) {
      showError('This resident already has an overlapping official term ('+residentConflict.Position+', '+residentConflict.TermStart+' to '+residentConflict.TermEnd+'). Please choose non-overlapping dates.');
      return;
    }
  }
  clearError();
}
['position','term_start','term_end'].forEach(id => document.getElementById(id).addEventListener('change', checkOverlap));

function openAddModal(){
  if(residentTS){residentTS.clear(true);residentTS.clearOptions();} else document.getElementById('resident_id').value='';
  document.getElementById('position').innerHTML='<option value="">Select available position...</option>';
  positions.filter(p=>!occupied.includes(p)).forEach(p=>document.getElementById('position').add(new Option(p,p)));
  document.getElementById('term_start').value='';document.getElementById('term_end').value='';
  document.getElementById('overlapError').classList.add('hidden');
  document.getElementById('saveOfficialBtn').disabled=false;
  resetPhotoCrop();
  openModal('addModal');
}
let currentViewRecord=null;
function viewStaff(d){
  const set=(id,v)=>{document.getElementById(id).textContent=v;};
  set('sv_initials',((d.Name||'').trim().split(/\s+/).filter((_,i,a)=>i===0||i===a.length-1).map(w=>w[0]||'').join('')||'—').toUpperCase());
  set('sv_position',d.Position||'Personnel');
  set('sv_name',d.Name||'Personnel');
  set('sv_id',d.EmployeeID||'—');
  const ended=(d.Status||'Current')==='Ended';
  const st=document.getElementById('sv_status'); st.textContent=d.Status||'Current'; st.className='font-bold text-sm mt-1 '+(ended?'text-rose-600':'text-emerald-600');
  set('sv_start',d.EffectiveStart||'—');
  set('sv_end',d.EffectiveEnd||'Present');
  set('sv_phone',d.ContactNumber||'—');
  set('sv_email',d.WorkEmail||d.Email||'—');
  set('sv_recorded',d.RecordedBy||'—');
  set('sv_endedby',ended?(d.EndedBy||'—'):'—');
  const rw=document.getElementById('sv_reason_wrap');
  if(ended&&d.EndReason){set('sv_reason',d.EndReason);rw.classList.remove('hidden');}else{rw.classList.add('hidden');}
  document.getElementById('sv_residentLink').href='resident_profile.php?resident_id='+encodeURIComponent(d.ResidentID||'');
  openModal('staffViewModal');
}
function viewOfficial(d){
  currentViewRecord=d;
  document.getElementById('v_position').textContent=d.Position||'';
  document.getElementById('v_name').textContent='Hon. '+[d.FirstName,d.MiddleName,d.LastName,d.Suffix].filter(Boolean).join(' ');
  document.getElementById('v_id').textContent=d.ResidentCode||('ID #'+(d.ResidentID||''));
  document.getElementById('v_term').textContent=(d.TermStart||'—')+' — '+(d.TermEnd||'—');
  document.getElementById('v_phone').textContent=d.ContactNumber||'No contact number';
  document.getElementById('v_email').textContent=d.Email||'No email';
  const addrFields=[
    ['House Number', d.HouseNumber],
    ['Building Name', d.BuildingName],
    ['Street', d.StreetName],
    ['Subdivision/Village/Sitio/Purok', d.AreaName || d.Purok],
    ['Barangay', d.BarangayName],
    ['City/Municipality', d.CityMunicipalityName],
    ['Province', d.ProvinceName],
    ['Region', d.RegionName],
    ['ZIP Code', d.ZipCode],
  ];
  const grid=document.getElementById('v_address_grid');
  const populated=addrFields.filter(f=>f[1]);
  grid.innerHTML=populated.map(f=>'<div><p class="text-[9px] font-bold uppercase text-slate-400">'+escHtml(f[0])+'</p><p class="font-semibold text-sm text-slate-700 mt-0.5">'+escHtml(f[1])+'</p></div>').join('');
  grid.classList.toggle('hidden', populated.length===0);
  document.getElementById('v_address_empty').classList.toggle('hidden', populated.length>0);
  const p=document.getElementById('v_photo');
  if(d.Photo){p.innerHTML='<img src="../uploads/officials/'+encodeURIComponent(d.Photo)+'" class="w-full h-full object-cover" alt="Official photo">';}
  else{const ini=((d.FirstName||'')[0]||'')+((d.LastName||'')[0]||'');p.innerHTML='<div class="w-full h-full flex items-center justify-center text-slate-400 font-black">'+ini.toUpperCase()+'</div>';}
  document.getElementById('residentLink').href='../frontend/resident_profile.php?resident_id='+encodeURIComponent(d.ResidentID);
  // End Term is only offered while the term is currently running (not already
  // ended, and today hasn't already passed the scheduled TermEnd). There is
  // no Edit Official function — the only action available here is End Term.
  const today=new Date().toISOString().slice(0,10);
  const isCurrent = !d.ActualEndDate && d.TermEnd && d.TermEnd>=today;
  const endBtn=document.getElementById('v_endterm');
  endBtn.classList.toggle('hidden', !isCurrent);
  endBtn.onclick=()=>{closeModal('viewModal');startEndTerm()};
  openModal('viewModal');
}

function startEndTerm(){
  if (!currentViewRecord) return;
  document.getElementById('endTermOfficialId').value=currentViewRecord.OfficialID;
  document.getElementById('endTermWho').textContent='Hon. '+[currentViewRecord.FirstName,currentViewRecord.MiddleName,currentViewRecord.LastName,currentViewRecord.Suffix].filter(Boolean).join(' ')+' — '+(currentViewRecord.Position||'');
  document.getElementById('endTermReasonSelect').value='';
  document.getElementById('endTermReasonOther').classList.add('hidden');
  document.getElementById('endTermReasonText').value='';
  openModal('endTermConfirmModal');
}

// Step 2 -> Step 3: validate the reason, then show the final confirmation
// before anything is actually submitted/saved.
function proceedToFinalConfirm(e){
  e.preventDefault();
  if (!currentViewRecord) return false;
  const sel=document.getElementById('endTermReasonSelect').value;
  const other=document.getElementById('endTermReasonText').value.trim();
  const reason = sel==='Other' ? other : sel;
  if (!reason){ alert('Please select or enter a reason for ending this term.'); return false; }
  document.getElementById('endTermReasonFinal').value=reason;
  document.getElementById('endTermFinalWho').textContent='Hon. '+[currentViewRecord.FirstName,currentViewRecord.MiddleName,currentViewRecord.LastName,currentViewRecord.Suffix].filter(Boolean).join(' ')+' — '+(currentViewRecord.Position||'');
  document.getElementById('endTermFinalReason').textContent=reason;
  closeModal('endTermReasonModal');
  openModal('endTermFinalModal');
  return false;
}

// ---- Official Photo adjust (zoom / position / crop) before save, Facebook-profile-photo style ----
let officialCropper = null;
const photoInput = document.getElementById('photoInput');
const cropWrap = document.getElementById('cropWrap');
const cropImg = document.getElementById('cropImg');
const zoomRange = document.getElementById('zoomRange');

function resetPhotoCrop(){
  if (officialCropper) { officialCropper.destroy(); officialCropper = null; }
  cropWrap.classList.add('hidden');
  cropImg.removeAttribute('src');
  photoInput.value = '';
}

photoInput.addEventListener('change', function(e){
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(ev){
    cropImg.src = ev.target.result;
    cropWrap.classList.remove('hidden');
    if (officialCropper) officialCropper.destroy();
    officialCropper = new Cropper(cropImg, {
      aspectRatio: 1,
      viewMode: 1,
      dragMode: 'move',
      autoCropArea: 1,
      background: false,
      guides: false,
      center: false,
      highlight: false,
      cropBoxMovable: false,
      cropBoxResizable: false,
      toggleDragModeOnDblclick: false,
      zoomOnWheel: true,
      ready: function(){ zoomRange.value = 0; }
    });
  };
  reader.readAsDataURL(file);
});

zoomRange.addEventListener('input', function(){
  if (officialCropper) officialCropper.zoomTo(parseFloat(this.value));
});

document.getElementById('officialForm').addEventListener('submit', function(e){
  if (!officialCropper) return; // no new photo chosen — submit as-is, keeps existing photo on edit
  e.preventDefault();
  const form = e.target;
  officialCropper.getCroppedCanvas({ width: 600, height: 600, imageSmoothingQuality: 'high' }).toBlob(function(blob){
    const croppedFile = new File([blob], 'official_photo.jpg', { type: 'image/jpeg' });
    const dt = new DataTransfer();
    dt.items.add(croppedFile);
    photoInput.files = dt.files;
    officialCropper.destroy();
    officialCropper = null;
    form.submit(); // native submit — does not re-trigger this listener
  }, 'image/jpeg', 0.92);
});
</script>
</body></html>
