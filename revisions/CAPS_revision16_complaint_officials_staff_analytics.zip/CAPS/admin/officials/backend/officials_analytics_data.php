<?php
/**
 * officials_analytics_data.php — every figure of Officials Analytics, its AI Analytics and its
 * Save PDF / Print report, computed from the actual `officials` (elected officials, effective-dated
 * TermStart / TermEnd / ActualEndDate) and `staff` (appointed personnel, EffectiveStart / EffectiveEnd) rows.
 * Start / End Date optional (empty = all records). An assignment is "in the range" when it was active
 * at any time within it; terms started / ended are counted by their own dates.
 */
require_once __DIR__ . '/../../analytics_common.php';
require_once __DIR__ . '/officials_common.php';

const OFA_POSITIONS = ['Barangay Captain', 'Kagawad - Health & Sanitation', 'Kagawad - Education', 'Kagawad - Social Services',
    'Kagawad - Peace & Order', 'Kagawad - Infrastructure', 'Kagawad - Agriculture', 'Kagawad - Environment', 'SK Chairperson'];

function ofa_age(?string $birth, string $asOf): ?int {
    if (!$birth || $birth === '0000-00-00') return null;
    return (int)date_diff(date_create($birth), date_create($asOf))->y;
}
function ofa_age_group(?int $age): string {
    if ($age === null) return 'Not specified';
    return $age < 30 ? '18–29' : ($age < 40 ? '30–39' : ($age < 50 ? '40–49' : ($age < 60 ? '50–59' : '60 and above')));
}

function officials_analytics_compute(PDO $pdo, array $p): array {
    officials_migrate_schema($pdo);
    $min = $pdo->query("SELECT MIN(d) FROM (SELECT MIN(TermStart) d FROM officials UNION ALL SELECT MIN(COALESCE(EffectiveStart, DATE(CreatedAt))) FROM staff) x")->fetchColumn();
    [$from, $to] = aui_resolve_range($p, $min ?: null);
    $open = $p['start'] === '' || $p['end'] === '';
    $today = date('Y-m-d');
    $asOf = min($to, $today);

    // Elected officials active at any time within the range.
    $s = $pdo->prepare("SELECT o.*, r.FirstName, r.MiddleName, r.LastName, r.Suffix, r.Sex, r.BirthDate, r.CivilStatus, r.EducationLevel
        FROM officials o LEFT JOIN residents r ON r.ResidentID = o.ResidentID
        WHERE o.TermStart <= ? AND COALESCE(o.ActualEndDate, o.TermEnd, '9999-12-31') >= ?
        ORDER BY FIELD(o.Position,'" . implode("','", OFA_POSITIONS) . "'), o.TermStart");
    $s->execute([$to, $from]);
    $off = $s->fetchAll(PDO::FETCH_ASSOC);
    // Appointed personnel active within the range.
    $s = $pdo->prepare("SELECT s.*, r.Sex, r.BirthDate FROM staff s LEFT JOIN residents r ON r.ResidentID = s.ResidentID
        WHERE COALESCE(s.EffectiveStart, DATE(s.CreatedAt)) <= ? AND COALESCE(s.EffectiveEnd, '9999-12-31') >= ?");
    $s->execute([$to, $from]);
    $staff = $s->fetchAll(PDO::FETCH_ASSOC);

    $b = aui_buckets($from, $to);
    $trend = ['started' => array_fill_keys($b['keys'], 0), 'ended' => array_fill_keys($b['keys'], 0), 'staff_started' => array_fill_keys($b['keys'], 0), 'staff_ended' => array_fill_keys($b['keys'], 0)];
    $t = ['officials' => count($off), 'current' => 0, 'completed' => 0, 'ended_early' => 0, 'started_in_range' => 0, 'ended_in_range' => 0,
          'ending_soon' => 0, 'staff' => count($staff), 'staff_active' => 0, 'staff_started' => 0, 'staff_ended' => 0, 'term_days_sum' => 0, 'term_n' => 0];
    $sex = []; $ageGroups = []; $civil = []; $educ = []; $byStatus = ['Current' => 0, 'Completed Term' => 0, 'Ended Early' => 0];
    $endReasons = []; $records = []; $filled = [];
    $ages = [];
    foreach ($off as $o) {
        $st = official_term_status($o);
        $byStatus[$st]++;
        if ($st === 'Current') { $t['current']++; $filled[$o['Position']] = true; }
        elseif ($st === 'Ended Early') $t['ended_early']++; else $t['completed']++;
        $end = $o['ActualEndDate'] ?: $o['TermEnd'];
        if ($o['TermStart'] >= $from && $o['TermStart'] <= $to) { $t['started_in_range']++; $k = aui_bucket_key($o['TermStart'], $b['granularity']); if (isset($trend['started'][$k])) $trend['started'][$k]++; }
        if ($end && $end >= $from && $end <= $to && $end <= $today) { $t['ended_in_range']++; $k = aui_bucket_key($end, $b['granularity']); if (isset($trend['ended'][$k])) $trend['ended'][$k]++; }
        if ($st === 'Current' && $o['TermEnd'] && $o['TermEnd'] <= date('Y-m-d', strtotime('+90 days'))) $t['ending_soon']++;
        if ($end) { $t['term_days_sum'] += max(0, (strtotime(min($end, $today)) - strtotime($o['TermStart'])) / 86400); $t['term_n']++; }
        if ($o['EndReason']) { $r = trim($o['EndReason']); $endReasons[$r] = ($endReasons[$r] ?? 0) + 1; }
        $sx = trim((string)$o['Sex']) ?: 'Not specified'; $sex[$sx] = ($sex[$sx] ?? 0) + 1;
        $age = ofa_age($o['BirthDate'], $asOf); if ($age !== null) $ages[] = $age;
        $g = ofa_age_group($age); $ageGroups[$g] = ($ageGroups[$g] ?? 0) + 1;
        $cs = trim((string)$o['CivilStatus']) ?: 'Not specified'; $civil[$cs] = ($civil[$cs] ?? 0) + 1;
        $ed = trim((string)$o['EducationLevel']) ?: 'Not specified'; $educ[$ed] = ($educ[$ed] ?? 0) + 1;
        $name = trim(implode(' ', array_filter([$o['FirstName'], $o['MiddleName'] ? mb_substr($o['MiddleName'], 0, 1) . '.' : '', $o['LastName'], $o['Suffix']]))) ?: '—';
        $records[] = ['name' => $name, 'position' => $o['Position'], 'term_start' => date('M j, Y', strtotime($o['TermStart'])),
            'term_end' => $end ? date('M j, Y', strtotime($end)) : '—', 'status' => $st, 'reason' => $o['EndReason'] ?: '', 'age' => $age];
    }
    $staffPos = []; $staffRecords = [];
    foreach ($staff as $x) {
        $pos = trim((string)$x['Position']) ?: 'Not specified';
        $staffPos[$pos] = ($staffPos[$pos] ?? 0) + 1;
        $start = $x['EffectiveStart'] ?: substr((string)$x['CreatedAt'], 0, 10);
        if (!$x['EffectiveEnd']) $t['staff_active']++;
        if ($start >= $from && $start <= $to) { $t['staff_started']++; $k = aui_bucket_key($start, $b['granularity']); if (isset($trend['staff_started'][$k])) $trend['staff_started'][$k]++; }
        if ($x['EffectiveEnd'] && $x['EffectiveEnd'] >= $from && $x['EffectiveEnd'] <= $to) { $t['staff_ended']++; $k = aui_bucket_key($x['EffectiveEnd'], $b['granularity']); if (isset($trend['staff_ended'][$k])) $trend['staff_ended'][$k]++; }
        $staffRecords[] = ['name' => $x['Name'] ?: '—', 'position' => $pos, 'start' => $start ? date('M j, Y', strtotime($start)) : '—',
            'end' => $x['EffectiveEnd'] ? date('M j, Y', strtotime($x['EffectiveEnd'])) : 'Active', 'reason' => $x['EndReason'] ?: ''];
    }
    arsort($staffPos); arsort($endReasons); ksort($ageGroups);
    $t['vacant'] = count(array_filter(OFA_POSITIONS, fn($pp) => empty($filled[$pp])));
    $t['avg_term_years'] = $t['term_n'] ? round($t['term_days_sum'] / $t['term_n'] / 365.25, 1) : null;
    $t['avg_age'] = $ages ? round(array_sum($ages) / count($ages), 1) : null;
    unset($t['term_days_sum'], $t['term_n']);
    $positions = [];
    foreach (OFA_POSITIONS as $pp) {
        $cur = array_values(array_filter($records, fn($r) => $r['position'] === $pp && $r['status'] === 'Current'));
        $positions[] = ['position' => $pp, 'holder' => $cur[0]['name'] ?? 'Vacant', 'term_end' => $cur[0]['term_end'] ?? '—',
            'assignments' => count(array_filter($records, fn($r) => $r['position'] === $pp))];
    }

    $a = [
        'period' => $p, 'range' => ['label' => $p['label'], 'open' => $open, 'from' => $from, 'to' => $to],
        'totals' => $t, 'by_status' => $byStatus, 'sex' => $sex, 'age_groups' => $ageGroups, 'civil_status' => $civil, 'education' => $educ,
        'end_reasons' => $endReasons, 'staff_positions' => $staffPos, 'positions' => $positions,
        'trend' => ['granularity' => $b['granularity'], 'labels' => $b['labels'], 'started' => array_values($trend['started']), 'ended' => array_values($trend['ended']),
                    'staff_started' => array_values($trend['staff_started']), 'staff_ended' => array_values($trend['staff_ended'])],
        'records' => $records, 'staff_records' => $staffRecords, 'comparison' => null,
    ];
    if (!$open) {
        [$ps, $pe] = aui_prev_range($from, $to);
        $one = function (string $sql, array $args) use ($pdo) { $q = $pdo->prepare($sql); $q->execute($args); return (int)$q->fetchColumn(); };
        $a['comparison'] = ['previous_label' => ra_range_label($ps, $pe), 'rows' => [
            ['metric' => 'Officials serving', 'current' => $t['officials'], 'previous' => $one("SELECT COUNT(*) FROM officials WHERE TermStart <= ? AND COALESCE(ActualEndDate, TermEnd, '9999-12-31') >= ?", [$pe, $ps])],
            ['metric' => 'Terms started', 'current' => $t['started_in_range'], 'previous' => $one("SELECT COUNT(*) FROM officials WHERE TermStart BETWEEN ? AND ?", [$ps, $pe])],
            ['metric' => 'Terms ended', 'current' => $t['ended_in_range'], 'previous' => $one("SELECT COUNT(*) FROM officials WHERE COALESCE(ActualEndDate, TermEnd) BETWEEN ? AND ?", [$ps, $pe])],
            ['metric' => 'Personnel serving', 'current' => $t['staff'], 'previous' => $one("SELECT COUNT(*) FROM staff WHERE COALESCE(EffectiveStart, DATE(CreatedAt)) <= ? AND COALESCE(EffectiveEnd, '9999-12-31') >= ?", [$pe, $ps])],
            ['metric' => 'Personnel hired', 'current' => $t['staff_started'], 'previous' => $one("SELECT COUNT(*) FROM staff WHERE COALESCE(EffectiveStart, DATE(CreatedAt)) BETWEEN ? AND ?", [$ps, $pe])],
        ]];
    }
    $a['interpretation'] = officials_analytics_interpretation($a);
    return $a;
}

function officials_analytics_interpretation(array $a): array {
    $t = $a['totals']; $L = $a['range']['label'];
    if (!$t['officials'] && !$t['staff']) return ['No officials or personnel served during ' . $L . '.'];
    $o = [];
    $o[] = $t['officials'] . ' elected official assignment(s) were active during ' . $L . ': ' . $t['current'] . ' still serving, ' . $t['completed'] . ' completed the term and ' . $t['ended_early'] . ' ended early.';
    $o[] = ($t['vacant'] ? $t['vacant'] . ' of ' . count(OFA_POSITIONS) . ' elected positions are vacant right now' : 'All ' . count(OFA_POSITIONS) . ' elected positions are filled') . ($t['ending_soon'] ? '; ' . $t['ending_soon'] . ' term(s) end within the next 90 days.' : '.');
    if ($t['started_in_range'] || $t['ended_in_range']) $o[] = $t['started_in_range'] . ' term(s) started and ' . $t['ended_in_range'] . ' term(s) ended within the range.';
    if ($t['avg_term_years'] !== null) $o[] = 'Officials served ' . $t['avg_term_years'] . ' year(s) on average' . ($t['avg_age'] !== null ? ', and their average age is ' . $t['avg_age'] . '.' : '.');
    if ($a['sex']) { $parts = []; foreach ($a['sex'] as $k => $v) $parts[] = $v . ' ' . strtolower($k); $o[] = 'By sex: ' . implode(', ', $parts) . '.'; }
    if ($a['end_reasons']) $o[] = 'The most common reason a term ended is "' . array_key_first($a['end_reasons']) . '" (' . reset($a['end_reasons']) . ').';
    $o[] = $t['staff'] . ' appointed personnel served during the range (' . $t['staff_active'] . ' still active; ' . $t['staff_started'] . ' started and ' . $t['staff_ended'] . ' ended within the range)'
        . ($a['staff_positions'] ? '; the largest group is ' . array_key_first($a['staff_positions']) . ' (' . reset($a['staff_positions']) . ').' : '.');
    if ($a['comparison']) {
        $c = $a['comparison']['rows'][3]; $x = $c['current'] - $c['previous'];
        $o[] = 'Compared with the previous period (' . $a['comparison']['previous_label'] . '), personnel serving ' . ($x > 0 ? 'increased by ' . $x : ($x < 0 ? 'decreased by ' . abs($x) : 'stayed the same')) . ' (' . $c['previous'] . ' → ' . $c['current'] . ').';
    }
    return $o;
}

/** Aggregated figures only (no names) — what the AI sees and the key of its saved result. */
function officials_analytics_snapshot(array $a): array {
    return ['date_range' => $a['range']['label'], 'totals' => $a['totals'], 'term_status' => $a['by_status'], 'sex' => $a['sex'], 'age_groups' => $a['age_groups'],
        'civil_status' => $a['civil_status'], 'education' => $a['education'], 'end_reasons' => $a['end_reasons'], 'personnel_positions' => $a['staff_positions'],
        'positions' => array_map(fn($x) => ['position' => $x['position'], 'filled' => $x['holder'] !== 'Vacant', 'assignments' => $x['assignments']], $a['positions']),
        'trend' => $a['trend'], 'comparison' => $a['comparison']];
}
