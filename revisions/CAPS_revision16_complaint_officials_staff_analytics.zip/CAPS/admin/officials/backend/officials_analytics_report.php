<?php
/**
 * Officials Analytics Report — opened from Officials Analytics with ?start&end&mode=print|pdf&ai=1|0.
 * Same shared CAPS report layout (report_common.php) and behavior as the other analytics reports:
 *   ai=0 → "No AI – Data and tables only" (no charts)
 *   ai=1 → supporting charts + the AI Analytics already generated on the page (AI cache — never calls Gemini).
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
try { require_permission($pdo, 'officials', 'read'); } catch (Throwable $e) { http_response_code(403); exit('Access denied.'); }
require_once __DIR__ . '/report_common.php';
require_once __DIR__ . '/officials_analytics_data.php';

$mode = report_mode();
$p = ra_params($_GET);
$a = officials_analytics_compute($pdo, $p);
$t = $a['totals']; $O = max(1, $t['officials']);
$withAi = ($_GET['ai'] ?? '0') === '1';
$ai = $withAi ? ai_cache_get('officials_analytics', officials_analytics_snapshot($a)) : null;
$showCharts = $ai !== null;

$brgy = report_barangay_profile($pdo);
$bAddr = trim((string)($brgy['address'] ?? '')) ?: implode(', ', array_filter([$brgy['barangay_name'] ?? '', $brgy['municipality_name'] ?? '', $brgy['province_name'] ?? ''], fn($x) => trim((string)$x) !== ''));
$captain = report_current_captain($pdo);
$generatedBy = report_generated_by($pdo);
$generatedRole = ($_SESSION['role'] ?? '') === 'admin' ? 'Administrator' : 'Barangay Staff';
if ($mode !== '') { try { require_once __DIR__ . '/../../activity_log_helper.php'; log_activity('Officials', 'Officials Analytics Report', ($mode === 'pdf' ? 'Saved PDF' : 'Printed') . ' officials analytics report · ' . $a['range']['label'] . ($ai ? ' · with AI findings' : '')); } catch (Throwable $e) {} }
$n = fn($v) => number_format((float)$v);

$title = 'Officials Analytics Report';
report_head($title, $mode);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<?php report_toolbar($mode, 'officials_analytics_' . ($p['start'] ?: 'all') . '_to_' . ($p['end'] ?: 'all'), 'landscape'); ?>
<?php aui_report_css(); ?>
<div class="report-page" id="reportRoot">
    <?php report_letterhead($brgy, 'Office of the Punong Barangay'); ?>
    <?php if ($bAddr): ?><p class="brgy-addr"><?php echo rh($bAddr); ?></p><?php endif; ?>
    <?php report_title_block($title, 'Elected officials and appointed personnel · ' . $a['range']['label'], 'Barangay Officials'); ?>

    <?php aui_report_info($a['range']['label'], ['Basis' => 'Assignments active within the range', 'Officials covered' => $n($t['officials']), 'Personnel covered' => $n($t['staff'])], $generatedBy, $captain); ?>

    <?php report_section_open('Officials Summary'); ?>
    <?php report_stat_cards([
        ['value' => $n($t['officials']), 'label' => 'Officials Serving', 'variant' => 'a'],
        ['value' => (9 - $t['vacant']) . ' / 9', 'label' => 'Positions Filled', 'variant' => 'b'],
        ['value' => $n($t['ended_early']), 'label' => 'Ended Early', 'variant' => 'c'],
        ['value' => $n($t['staff']), 'label' => 'Personnel', 'variant' => 'd'],
    ]); ?>
    <div style="margin-top:12px"></div>
    <?php aui_table(['Indicator', 'Value'], [
        ['Current / completed / ended early', $n($t['current']) . ' / ' . $n($t['completed']) . ' / ' . $n($t['ended_early'])],
        ['Terms started / ended within the range', $n($t['started_in_range']) . ' / ' . $n($t['ended_in_range'])],
        ['Terms ending within 90 days', $n($t['ending_soon'])],
        ['Average term served', $t['avg_term_years'] !== null ? $t['avg_term_years'] . ' year(s)' : '—'],
        ['Average age of officials', $t['avg_age'] ?? '—'],
        ['Personnel active / hired / ended', $n($t['staff_active']) . ' / ' . $n($t['staff_started']) . ' / ' . $n($t['staff_ended'])],
    ], '', [1]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Positions & Terms'); ?>
    <p class="sub">Elected positions</p>
    <?php aui_table(['Position', 'Current holder', 'Term ends', 'Assignments in range'], array_map(fn($x) => [$x['position'], $x['holder'], $x['term_end'], $n($x['assignments'])], $a['positions']), '', [3]); ?>
    <div class="grid2">
        <div><p class="sub">Term status</p><?php aui_table(['Status', 'Officials', 'Share'], aui_dist($a['by_status'], $O), 'No officials.', [1, 2]); ?></div>
        <div><p class="sub">Reasons terms ended</p><?php aui_table(['Reason', 'Terms', 'Share'], aui_dist($a['end_reasons']), 'No term ended with a reason.', [1, 2]); ?></div>
    </div>
    <?php if ($showCharts && $t['officials']): ?><p class="chart-cap">Figure 1. Term status</p><div class="chart-wrap"><canvas id="rc-status"></canvas></div><?php endif; ?>
    <p class="sub">Official terms</p>
    <?php aui_table(['Official', 'Position', 'Term start', 'Term end', 'Status', 'End reason'], array_map(fn($r) => [$r['name'], $r['position'], $r['term_start'], $r['term_end'], $r['status'], $r['reason'] ?: '—'], $a['records']), 'No officials in this range.'); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Officials Profile'); ?>
    <div class="grid2">
        <div><p class="sub">Sex</p><?php aui_table(['Sex', 'Officials', 'Share'], aui_dist($a['sex'], $O), 'No officials.', [1, 2]); ?></div>
        <div><p class="sub">Age group</p><?php aui_table(['Age group', 'Officials', 'Share'], aui_dist($a['age_groups'], $O), 'No officials.', [1, 2]); ?></div>
        <div><p class="sub">Civil status</p><?php aui_table(['Civil status', 'Officials', 'Share'], aui_dist($a['civil_status'], $O), 'No officials.', [1, 2]); ?></div>
        <div><p class="sub">Education</p><?php aui_table(['Education', 'Officials', 'Share'], aui_dist($a['education'], $O), 'No officials.', [1, 2]); ?></div>
    </div>
    <?php report_section_close(); ?>

    <?php report_section_open('Appointed Personnel'); ?>
    <?php aui_table(['Position', 'Personnel', 'Share'], aui_dist($a['staff_positions'], max(1, $t['staff'])), 'No personnel in this range.', [1, 2]); ?>
    <p class="sub">Personnel list</p>
    <?php aui_table(['Name', 'Position', 'Start', 'End', 'End reason'], array_map(fn($x) => [$x['name'], $x['position'], $x['start'], $x['end'], $x['reason'] ?: '—'], $a['staff_records']), 'No personnel in this range.'); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Turnover & Comparison'); ?>
    <?php $rows = []; $tr = $a['trend'];
    foreach ($tr['labels'] as $i => $lbl) if ($tr['started'][$i] + $tr['ended'][$i] + $tr['staff_started'][$i] + $tr['staff_ended'][$i]) $rows[] = [$lbl, $n($tr['started'][$i]), $n($tr['ended'][$i]), $n($tr['staff_started'][$i]), $n($tr['staff_ended'][$i])];
    aui_table([$tr['granularity'] === 'day' ? 'Day' : 'Month', 'Terms started', 'Terms ended', 'Personnel hired', 'Personnel ended'], $rows, 'No term or personnel change in this range.', [1, 2, 3, 4]); ?>
    <?php if ($showCharts && $rows && count($tr['labels']) > 1): ?><p class="chart-cap">Figure 2. Turnover over time</p><div class="chart-wrap"><canvas id="rc-trend"></canvas></div><?php endif; ?>
    <?php if ($a['comparison']): ?>
    <p class="sub">Selected period vs previous period (<?php echo rh($a['comparison']['previous_label']); ?>)</p>
    <?php aui_table(['Indicator', 'Selected period', 'Previous period', 'Change'], array_map(function ($r) use ($n) { $x = $r['current'] - $r['previous']; return [$r['metric'], $n($r['current']), $n($r['previous']), ($x > 0 ? '+' : '') . $n($x)]; }, $a['comparison']['rows']), '', [1, 2, 3]); ?>
    <?php else: ?><p class="note">Set both a Start Date and an End Date to compare with the previous period of the same length.</p><?php endif; ?>
    <?php report_section_close(); ?>

    <?php aui_report_tail($a['interpretation'], $ai, $withAi, ['Changes over Time', 'Turnover & Term Patterns', 'Officials & Personnel Profile', 'Recommended Actions'], 'officials data of ' . $a['range']['label']); ?>

    <?php report_certify_and_signatures($brgy['brgy_name'] ?? 'Barangay', $generatedBy, $generatedRole, $captain); ?>
    <?php report_footer_strip($brgy['brgy_name'] ?? 'Barangay'); ?>
</div>
<script>
(function () {
    if (!window.Chart) return;
    Chart.defaults.animation = false; Chart.defaults.font.family = 'Arial, Helvetica, sans-serif'; Chart.defaults.font.size = 10; Chart.defaults.color = '#475569';
    const grid = { color: '#e2e8f0' }, legend = { position: 'top', align: 'end', labels: { boxWidth: 10 } };
    const a = <?php echo json_encode(['status' => $a['by_status'], 'trend' => $a['trend']], JSON_UNESCAPED_UNICODE); ?>;
    const el = id => document.getElementById(id);
    if (el('rc-status')) new Chart(el('rc-status'), { type: 'bar', data: { labels: Object.keys(a.status), datasets: [{ data: Object.values(a.status), backgroundColor: ['#1baf7a', '#2a78d6', '#e11d48'], borderRadius: 3, maxBarThickness: 40 }] },
        options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
    const t = a.trend, line = (label, data, color) => ({ label, data, borderColor: color, backgroundColor: color, borderWidth: 2, pointRadius: t.labels.length > 40 ? 0 : 2, tension: 0 });
    if (el('rc-trend')) new Chart(el('rc-trend'), { type: 'line', data: { labels: t.labels, datasets: [line('Terms started', t.started, '#1baf7a'), line('Terms ended', t.ended, '#e11d48'), line('Personnel hired', t.staff_started, '#2a78d6'), line('Personnel ended', t.staff_ended, '#eb6834')] },
        options: { maintainAspectRatio: false, plugins: { legend }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
})();
</script>
<?php report_foot(); ?>
