<?php
/**
 * officials_ai_summary.php — AI Analytics for Officials Analytics (JSON, POST).
 * Same behavior as the other CAPS analytics: only when "Generate AI Analytics" is clicked;
 * cached_only=1 returns a result generated before for the same data (no Gemini call).
 * Only aggregated figures are sent (no names).
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
try { require_permission($pdo, 'officials', 'read'); } catch (Throwable $e) { http_response_code(403); exit; }
require_once __DIR__ . '/officials_analytics_data.php';

try {
    $p = ra_params($_POST);
    $a = officials_analytics_compute($pdo, $p);
} catch (Throwable $e) {
    error_log('[Officials AI] ' . $e->getMessage());
    aui_json(['success' => false, 'error' => 'Could not read the officials records.'], 500);
}
aui_ai_endpoint('officials_analytics', officials_analytics_snapshot($a), officials_analytics_snapshot($a), $p, ($a['totals']['officials'] + $a['totals']['staff']) > 0,
    'No officials or personnel served during ' . $a['range']['label'] . ', so there is nothing to analyse.', 'office of the Punong Barangay',
    "Focus on the barangay officials and personnel: elected positions filled / vacant, terms current / completed / ended early and their reasons, terms ending soon, turnover (terms started / ended), average term length, "
    . "the officials' profile (sex, age groups, civil status, education) and appointed personnel per position. "
    . "key_findings = the most important facts; demographic_trends = changes over time (terms and hiring, comparison with the previous period); patterns = turnover and early-end patterns, vacant or frequently changed positions; "
    . "population_observations = profile of the officials and personnel; recommendations = practical governance / staffing actions, each tied to a finding.",
    function () use ($a) {
        require_once __DIR__ . '/../../activity_log_helper.php';
        log_activity('Officials', 'Generate AI Analytics', 'Generated officials AI analytics for ' . $a['range']['label']);
    });
