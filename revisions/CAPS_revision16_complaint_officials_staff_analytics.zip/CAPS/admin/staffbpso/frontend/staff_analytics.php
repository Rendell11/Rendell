<?php
/**
 * staff_analytics.php — Staff / BPSO Analytics.
 * Same structure / behavior as the other CAPS analytics pages: Start / End Date (empty = all records)
 * + Personnel (Staff / BPSO / All), AI Analytics on top (manual only), Data Interpretation,
 * cards / charts / tables, Save PDF / Print (../backend/staff_analytics_report.php) asking whether
 * to include the AI findings. Computed only from recorded attendance / duty rows.
 */
require_once __DIR__.'/../../db.php';
require_once __DIR__.'/../../auth_check.php';
require_once __DIR__.'/../../theme_loader.php';
require_once __DIR__.'/../backend/staff_analytics_data.php';
staffbpso_migrate_schema($pdo);
staffbpso_duty_migrate_schema($pdo);

$p = ra_params($_GET);
$scope = staff_analytics_scope($_GET['scope'] ?? 'all');
$a = null;
try { $a = staff_analytics_uniform($pdo, $p, $scope); } catch (Throwable $e) { error_log('[Staff analytics] '.$e->getMessage()); }
if (($_GET['action'] ?? '') === 'data') aui_json($a ? ['success' => true] + $a : ['success' => false, 'error' => 'Could not load the staff analytics.']);
$current_page = 'Staff and BPSO';
$_theme_head_loaded = true;
$scopeSel = '<div><label for="scope" class="aui-label">Personnel</label><select id="scope" data-aui-param="scope" class="aui-field">';
foreach (['all' => 'All Personnel', 'staff' => 'Barangay Staff', 'tanod' => 'BPSO / Tanod'] as $k => $l) $scopeSel .= '<option value="'.$k.'"'.($scope === $k ? ' selected' : '').'>'.$l.'</option>';
$scopeSel .= '</select></div>';
?>
<!DOCTYPE html>
<html <?php echo $theme_attrs['html'] ?? ''; ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Analytics — CAPS</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
    <?php require_once __DIR__.'/../../theme_head.php'; ?>
    <script>tailwind.config = { theme: { extend: { colors: { primary: { DEFAULT: 'var(--accent-600)', light: 'var(--accent-500)', dark: 'var(--accent-700)' } }, fontFamily: { sans: ['"Plus Jakarta Sans"', 'sans-serif'] } } } };</script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--page-bg, #eef2fb); -webkit-font-smoothing: antialiased; }
        .main-wrapper { margin-left: 288px; width: calc(100% - 288px); }
        @media (max-width: 1024px) { .main-wrapper { margin-left: 0; width: 100%; } }
    </style>
    <?php aui_styles(); ?>
</head>
<body <?php echo $theme_attrs['body'] ?? ''; ?>>
<div class="flex min-h-screen">
    <?php include __DIR__.'/../../sidebar.php'; ?>
    <div class="flex-1 flex flex-col min-w-0 main-wrapper">
        <?php include __DIR__.'/../../header.php'; ?>
        <main class="p-4 md:p-6 lg:p-8 space-y-7">
            <?php aui_hero('Staff and BPSO', 'badge', 'Staff Analytics', 'Attendance, punctuality, absences, overtime and tanod duty — from the recorded attendance and duty logs.', 'staff.php', 'Back to Staff'); ?>
            <?php aui_date_form($p, $scopeSel); ?>
            <?php aui_ai_section(); ?>
        </main>
    </div>
</div>
<?php aui_report_modal('Staff Analytics Report', 'Summary, attendance, reasons, hours, per-person table and data interpretation.'); ?>
<?php aui_script(['dataUrl' => 'staff_analytics.php', 'aiUrl' => '../backend/staff_ai_analytics.php', 'reportUrl' => '../backend/staff_analytics_report.php',
    'aiLabels' => ['Attendance Trends', 'Lateness, Absence & Overtime Patterns', 'Personnel Observations', 'Recommended Actions'], 'basis' => 'attendance and duty figures',
    'openBasis' => 'All attendance and duty records', 'rangeBasis' => 'Attendance and duty within the range'], $a ? ['success' => true] + $a : null); ?>
<script>
    AUI.start(function (d) {
        const t = d.totals, R = t.records;
        const fmtMin = m => m >= 60 ? Math.floor(m / 60) + 'h ' + (m % 60) + 'm' : m + 'm';
        let html = section('badge', 'Attendance Summary', d.range.extra_label + ' · ' + d.range.label,
            `<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
                ${kpi('Records', num(R), num(t.people) + ' person(s)')}
                ${kpi('Present', num(t.present), rate(t.attendance_rate) + ' attendance rate')}
                ${kpi('Absent', num(t.absent), num(t.no_record) + ' with no Time In')}
                ${kpi('Late', num(t.late), rate(t.punctuality) + ' punctuality')}
                ${kpi('Avg Lateness', fmtMin(t.avg_late_minutes), 'per late Time In')}
                ${kpi('Early Outs', num(t.early_out), fmtMin(t.early_minutes) + ' short')}
                ${kpi('Overtime', t.overtime_hours + ' h', num(t.overtime) + ' day(s)')}
                ${kpi('Avg Worked', t.avg_worked_hours + ' h', 'per duty day')}
                ${kpi('Peak Duty Hour', d.peak_hour === null ? '—' : d.hour_labels[d.peak_hour], d.peak_time_in_hour === null ? '' : 'most Time Ins ' + d.hour_labels[d.peak_time_in_hour])}
                ${kpi('Deployments', num(t.deployments), 'tanod deployments')}
            </div>`);
        const status = { 'On time': t.present - t.late, 'Late': t.late, 'Absent': t.absent, 'No Time In': t.no_record };
        const ar = d.absent_reason_groups, er = d.early_out_reason_groups;
        const toObj = g => Object.fromEntries((g.labels || []).map((l, i) => [l, g.data[i]]));
        html += section('donut_large', 'Attendance Status & Reasons', 'How personnel attended and why they were absent or left early',
            `<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                ${card('c-status', 'Attendance Status', 'On time, late, absent, no Time In', { empty: R ? '' : 'No records.', table: table(['Status', 'Records', 'Share'], distRows(status, R), [1, 2]) })}
                ${card('c-absent', 'Absence Reasons', num(t.absent) + ' absence(s)', { empty: t.absent ? '' : 'No absences.', table: table(['Reason', 'Absences', 'Share'], distRows(d.absent_reasons, t.absent), [1, 2]) })}
                ${card('c-early', 'Early Out Reasons', num(t.early_out) + ' early out(s)', { empty: t.early_out ? '' : 'No early outs.', table: table(['Reason', 'Early outs', 'Share'], distRows(d.early_out_reasons, t.early_out), [1, 2]) })}
            </div>`);
        const cov = Object.fromEntries(d.hour_labels.map((h, i) => [h, d.coverage_hours[i]]).filter(x => x[1] > 0));
        const n = d.trend.labels.length;
        html += section('insights', 'Trends & Hours', 'Attendance over time, by weekday and by hour',
            `<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                ${card('c-trend', 'Attendance over Time', 'Per ' + d.trend.granularity + ': present, late, absent', { span: 'lg:col-span-2', empty: n > 1 && R ? '' : 'Not enough data for a trend.' })}
                ${card('c-weekday', 'Attendance by Weekday', 'Present, late and absent', { empty: R ? '' : 'No records.', table: table(['Day', 'Present', 'Late', 'Absent'], Object.entries(d.weekday_named).map(([k, v]) => [k, num(v.present), num(v.late), num(v.absent)]), [1, 2, 3]) })}
                ${card('c-hours', 'Staff-Hours on Duty by Hour', 'Peak working hours', { empty: sum(d.coverage_hours) ? '' : 'No Time Out recorded.', table: table(['Hour', 'Staff-hours'], Object.entries(cov).map(([k, v]) => [k, v]), [1]) })}
                ${card('c-ot', 'Overtime Hours over Time', 'Per ' + d.trend.granularity, { span: 'lg:col-span-2', empty: t.overtime_hours ? '' : 'No overtime recorded.' })}
                ${compareSection(d)}
            </div>`);
        const ppl = d.people.map(p => [p.name, p.type, p.position, num(p.records), num(p.present), num(p.absent), num(p.late), rate(p.attendance_rate), rate(p.punctuality), p.avg_time_in || '—', p.worked_hours + ' h', p.overtime_hours + ' h', num(p.deployments)]);
        html += section('groups', 'Per-Person Attendance', 'Every person with records in the range',
            `<div class="overflow-x-auto max-h-[520px] overflow-y-auto">${table(['Name', 'Type', 'Position', 'Records', 'Present', 'Absent', 'Late', 'Attendance', 'Punctuality', 'Avg Time In', 'Worked', 'Overtime', 'Deploy.'], ppl, [3, 4, 5, 6, 7, 8, 10, 11, 12])}</div>` +
            (sum(d.deploy_locations) ? `<div class="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">${card('c-deploy', 'Deployment Locations', num(t.deployments) + ' deployment(s)', { table: table(['Location', 'Deployments', 'Share'], distRows(d.deploy_locations, t.deployments), [1, 2]) })}</div>` : ''));
        document.getElementById('raBody').innerHTML = html;
        if (R) donut('c-status', status, k => ({ 'On time': COLORS.s3, Late: '#eab308', Absent: COLORS.red, 'No Time In': COLORS.muted })[k], R);
        if (t.absent) donut('c-absent', toObj(ar), null, t.absent);
        if (t.early_out) donut('c-early', toObj(er), null, t.early_out);
        if (n > 1 && R) mk('c-trend', { type: 'line', data: { labels: d.trend.labels, datasets: [lineDs('Present', d.trend.present, COLORS.s3, n), lineDs('Late', d.trend.late, '#eab308', n), lineDs('Absent', d.trend.absent, COLORS.red, n)] },
            options: { interaction: { mode: 'index', intersect: false }, plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
        const wd = Object.entries(d.weekday_named);
        if (R) mk('c-weekday', { type: 'bar', data: { labels: wd.map(x => x[0]), datasets: [
            { label: 'Present', data: wd.map(x => x[1].present), backgroundColor: COLORS.s3, borderRadius: 3, maxBarThickness: 22 },
            { label: 'Late', data: wd.map(x => x[1].late), backgroundColor: '#eab308', borderRadius: 3, maxBarThickness: 22 },
            { label: 'Absent', data: wd.map(x => x[1].absent), backgroundColor: COLORS.red, borderRadius: 3, maxBarThickness: 22 }] },
            options: { plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
        if (sum(d.coverage_hours)) mk('c-hours', barCfg(d.hour_labels, d.coverage_hours, COLORS.s1));
        if (t.overtime_hours) mk('c-ot', barCfg(d.trend.labels, d.trend.overtime_hours, COLORS.violet));
        if (sum(d.deploy_locations)) mk('c-deploy', barCfg(Object.keys(d.deploy_locations), Object.values(d.deploy_locations), '#0ea5e9', true));
        drawCompare(d);
    });
</script>
</body>
</html>
