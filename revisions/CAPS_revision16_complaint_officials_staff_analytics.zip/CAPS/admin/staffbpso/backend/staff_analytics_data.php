<?php
/**
 * Staff Analytics data — computed only from recorded attendance/duty rows
 * (staff_attendance + tanod_schedules/tanod_deployments). Shared by the
 * Staff Analytics page and the AI Analytics endpoint so both see the same numbers.
 */
require_once __DIR__.'/staffbpso_common.php';

/** Normalizes ?from/?to/?scope. Default: last 30 days, regular staff only. */
function staff_analytics_params(array $q): array {
    $today = date('Y-m-d');
    $range = $q['range'] ?? '30';
    if (preg_match('/^\d{4}-\d{2}$/', $q['month'] ?? '')) {
        // One calendar month (per-chart month picker).
        $range = 'month';
        $from = $q['month'].'-01';
        $to = date('Y-m-t', strtotime($from));
    } elseif ($range === 'custom') {
        $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', $q['from'] ?? '') ? $q['from'] : date('Y-m-d', strtotime('-29 days'));
        $to = preg_match('/^\d{4}-\d{2}-\d{2}$/', $q['to'] ?? '') ? $q['to'] : $today;
    } else {
        $days = in_array($range, ['7', '30', '90', '365'], true) ? (int)$range : 30;
        $range = (string)$days;
        $from = date('Y-m-d', strtotime('-'.($days - 1).' days'));
        $to = $today;
    }
    if ($to > $today) $to = $today;
    if ($from > $to) [$from, $to] = [$to, $from];
    $scope = in_array($q['scope'] ?? '', ['staff', 'tanod', 'all'], true) ? $q['scope'] : 'staff';
    return ['from' => $from, 'to' => $to, 'range' => $range, 'scope' => $scope];
}

/** All recorded duty rows in range, decorated with late/early/overtime/worked minutes. */
function staff_analytics_records(PDO $pdo, string $from, string $to, string $scope): array {
    $rows = [];
    if ($scope !== 'tanod') {
        $st = $pdo->prepare("SELECT sa.*, sa.attendance_date AS schedule_date, s.Name, s.Position
            FROM staff_attendance sa JOIN staff s ON s.EmployeeID = sa.EmployeeID
            WHERE sa.attendance_date BETWEEN ? AND ?");
        $st->execute([$from, $to]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { $r['_type'] = 'Staff'; $rows[] = duty_decorate_log($r); }
    }
    if ($scope !== 'staff') {
        $st = $pdo->prepare("SELECT ts.*, MIN(s.Name) AS Name, MIN(s.Position) AS Position, MIN(s.EmployeeID) AS EmployeeID
            FROM tanod_schedules ts JOIN staff s ON s.ResidentID = ts.ResidentID
            WHERE ts.schedule_date BETWEEN ? AND ? GROUP BY ts.id");
        $st->execute([$from, $to]);
        $tanod = $st->fetchAll(PDO::FETCH_ASSOC);
        $deps = [];
        if ($tanod) {
            $ids = array_column($tanod, 'id');
            $dst = $pdo->prepare('SELECT * FROM tanod_deployments WHERE schedule_id IN ('.implode(',', array_fill(0, count($ids), '?')).') ORDER BY deployed_at');
            $dst->execute($ids);
            foreach ($dst->fetchAll(PDO::FETCH_ASSOC) as $d) $deps[$d['schedule_id']][] = $d;
        }
        foreach ($tanod as $r) {
            // Future-dated, untouched schedules are plans, not attendance data.
            if ($r['status'] === 'Scheduled' && $r['schedule_date'] >= date('Y-m-d')) continue;
            $r['_type'] = 'BPSO';
            $r['_deployments'] = $deps[$r['id']] ?? [];
            $rows[] = duty_decorate_log($r);
        }
    }
    return $rows;
}

function staff_analytics_compute(PDO $pdo, array $p): array {
    $records = staff_analytics_records($pdo, $p['from'], $p['to'], $p['scope']);

    $t = ['records' => count($records), 'present' => 0, 'absent' => 0, 'no_record' => 0, 'late' => 0, 'on_time' => 0,
          'early_out' => 0, 'overtime' => 0, 'late_minutes' => 0, 'early_minutes' => 0, 'overtime_minutes' => 0,
          'worked_minutes' => 0, 'worked_days' => 0, 'deployments' => 0, 'people' => 0];
    $daily = []; $weekday = []; $inHour = array_fill(0, 24, 0); $outHour = array_fill(0, 24, 0); $coverage = array_fill(0, 24, 0);
    $people = []; $absentReasons = []; $earlyReasons = []; $deployLocations = [];

    for ($d = strtotime($p['from']); $d <= strtotime($p['to']); $d += 86400) {
        $daily[date('Y-m-d', $d)] = ['present' => 0, 'late' => 0, 'absent' => 0, 'early_out' => 0, 'early_minutes' => 0, 'overtime_minutes' => 0, 'worked_minutes' => 0];
    }
    for ($i = 1; $i <= 7; $i++) $weekday[$i] = ['present' => 0, 'late' => 0, 'absent' => 0];

    foreach ($records as $r) {
        $date = $r['schedule_date']; $wd = (int)date('N', strtotime($date));
        $key = $r['_type'].'|'.$r['EmployeeID'];
        if (!isset($people[$key])) {
            $people[$key] = ['name' => $r['Name'], 'employee_id' => $r['EmployeeID'], 'type' => $r['_type'], 'position' => $r['Position'] ?: $r['_type'],
                             'records' => 0, 'present' => 0, 'absent' => 0, 'late' => 0, 'early_out' => 0, 'overtime' => 0,
                             'late_minutes' => 0, 'overtime_minutes' => 0, 'worked_minutes' => 0, 'time_in_sum' => 0, 'deployments' => 0];
        }
        $pp = &$people[$key];
        $pp['records']++;

        if ($r['status'] === 'Absent') {
            $t['absent']++; $pp['absent']++; $weekday[$wd]['absent']++;
            if (isset($daily[$date])) $daily[$date]['absent']++;
            $reason = trim((string)$r['absent_reason']) ?: 'Unspecified';
            $absentReasons[$reason] = ($absentReasons[$reason] ?? 0) + 1;
        } elseif (!empty($r['time_in'])) {
            $t['present']++; $pp['present']++; $weekday[$wd]['present']++;
            if (isset($daily[$date])) $daily[$date]['present']++;
            $inTs = strtotime($r['time_in']);
            $inHour[(int)date('G', $inTs)]++;
            $pp['time_in_sum'] += (int)date('G', $inTs) * 60 + (int)date('i', $inTs);
            if ($r['_is_late']) {
                $t['late']++; $pp['late']++; $weekday[$wd]['late']++;
                $t['late_minutes'] += $r['_late_minutes']; $pp['late_minutes'] += $r['_late_minutes'];
                if (isset($daily[$date])) $daily[$date]['late']++;
            } else {
                $t['on_time']++;
            }
            if (!empty($r['time_out'])) {
                $outTs = strtotime($r['time_out']);
                $outHour[(int)date('G', $outTs)]++;
                $t['worked_minutes'] += $r['_worked_minutes']; $t['worked_days']++; $pp['worked_minutes'] += $r['_worked_minutes'];
                if (isset($daily[$date])) $daily[$date]['worked_minutes'] += $r['_worked_minutes'];
                // Staff-hours on duty per hour of day (peak working hours).
                for ($h = $inTs - ($inTs % 3600); $h < $outTs; $h += 3600) {
                    $overlap = min($outTs, $h + 3600) - max($inTs, $h);
                    if ($overlap > 0) $coverage[(int)date('G', $h)] += $overlap / 3600;
                }
            }
            if ($r['status'] === 'Early Out') {
                $t['early_out']++; $pp['early_out']++; $t['early_minutes'] += $r['_early_minutes'];
                if (isset($daily[$date])) { $daily[$date]['early_out']++; $daily[$date]['early_minutes'] += $r['_early_minutes']; }
                $reason = trim((string)$r['early_out_reason']) ?: 'Unspecified';
                $earlyReasons[$reason] = ($earlyReasons[$reason] ?? 0) + 1;
            }
            if ($r['_overtime_minutes'] > 0) {
                $t['overtime']++; $pp['overtime']++;
                $t['overtime_minutes'] += $r['_overtime_minutes']; $pp['overtime_minutes'] += $r['_overtime_minutes'];
                if (isset($daily[$date])) $daily[$date]['overtime_minutes'] += $r['_overtime_minutes'];
            }
        } else {
            $t['no_record']++; // past schedule with no Time In and not marked absent
        }
        foreach ($r['_deployments'] as $d) {
            $t['deployments']++; $pp['deployments']++;
            $loc = trim((string)$d['location']) ?: 'Unspecified';
            $deployLocations[$loc] = ($deployLocations[$loc] ?? 0) + 1;
        }
        unset($pp);
    }

    foreach ($people as &$pp) {
        $pp['attendance_rate'] = ($pp['present'] + $pp['absent']) ? round($pp['present'] / ($pp['present'] + $pp['absent']) * 100, 1) : null;
        $pp['punctuality'] = $pp['present'] ? round(($pp['present'] - $pp['late']) / $pp['present'] * 100, 1) : null;
        $pp['avg_time_in'] = $pp['present'] ? sprintf('%02d:%02d', intdiv((int)round($pp['time_in_sum'] / $pp['present']), 60), (int)round($pp['time_in_sum'] / $pp['present']) % 60) : null;
        $pp['avg_late_minutes'] = $pp['late'] ? (int)round($pp['late_minutes'] / $pp['late']) : 0;
        $pp['worked_hours'] = round($pp['worked_minutes'] / 60, 1);
        $pp['overtime_hours'] = round($pp['overtime_minutes'] / 60, 1);
        unset($pp['time_in_sum']);
    }
    unset($pp);
    $people = array_values($people);
    usort($people, function($a, $b) { return [$b['present'], $a['late']] <=> [$a['present'], $b['late']]; });
    $t['people'] = count($people);

    arsort($absentReasons); arsort($earlyReasons); arsort($deployLocations);
    $t['attendance_rate'] = ($t['present'] + $t['absent']) ? round($t['present'] / ($t['present'] + $t['absent']) * 100, 1) : null;
    $t['punctuality'] = $t['present'] ? round($t['on_time'] / $t['present'] * 100, 1) : null;
    $t['avg_late_minutes'] = $t['late'] ? (int)round($t['late_minutes'] / $t['late']) : 0;
    $t['avg_worked_hours'] = $t['worked_days'] ? round($t['worked_minutes'] / $t['worked_days'] / 60, 1) : 0;
    $t['overtime_hours'] = round($t['overtime_minutes'] / 60, 1);

    $peakHour = array_sum($coverage) > 0 ? array_search(max($coverage), $coverage) : null;
    $peakIn = array_sum($inHour) > 0 ? array_search(max($inHour), $inHour) : null;
    $dayNames = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'];

    return [
        'params' => $p, 'totals' => $t, 'daily' => $daily, 'weekday' => $weekday, 'day_names' => $dayNames,
        'time_in_hours' => $inHour, 'time_out_hours' => $outHour, 'coverage_hours' => array_map(function($v) { return round($v, 1); }, $coverage),
        'peak_hour' => $peakHour, 'peak_time_in_hour' => $peakIn,
        'people' => $people,
        'absent_reasons' => array_slice($absentReasons, 0, 8, true),
        'absent_reason_groups' => staff_analytics_reason_groups($absentReasons, 'absent'),
        'early_out_reason_groups' => staff_analytics_reason_groups($earlyReasons, 'early_out'),
        'early_out_reasons' => array_slice($earlyReasons, 0, 8, true),
        'deploy_locations' => array_slice($deployLocations, 0, 8, true),
    ];
}

/**
 * Groups reasons for the pie charts: preset dropdown reasons keep their own
 * slice; anything typed under "Other" goes into one "Others" slice, with the
 * typed reasons kept in 'others' for the hover tooltip.
 */
function staff_analytics_reason_groups(array $reasons, string $kind): array {
    $preset = duty_reason_options($kind);
    $groups = array_fill_keys($preset, 0); $others = [];
    foreach ($reasons as $reason => $n) {
        if (in_array($reason, $preset, true)) $groups[$reason] += $n;
        else $others[$reason] = ($others[$reason] ?? 0) + $n;
    }
    $groups = array_filter($groups);
    if ($others) { arsort($others); $groups['Others'] = array_sum($others); }
    return ['labels' => array_keys($groups), 'data' => array_values($groups), 'others' => $others];
}

/** Compact snapshot sent to Gemini: aggregates only, no contact details. */
function staff_analytics_ai_snapshot(array $a, array $p): array {
    return [
        'period' => ['from' => $p['from'], 'to' => $p['to'], 'scope' => $p['scope']],
        'totals' => $a['totals'],
        'weekday' => array_combine(array_values($a['day_names']), array_values($a['weekday'])),
        'staff_hours_on_duty_by_hour' => array_filter($a['coverage_hours']),
        'time_in_count_by_hour' => array_filter($a['time_in_hours']),
        'time_out_count_by_hour' => array_filter($a['time_out_hours']),
        'daily' => array_filter($a['daily'], function($d) { return array_sum($d) > 0; }),
        'per_person' => array_map(function($pp) {
            return array_intersect_key($pp, array_flip(['name', 'type', 'position', 'records', 'present', 'absent', 'late', 'avg_late_minutes', 'early_out',
                'overtime', 'overtime_hours', 'worked_hours', 'avg_time_in', 'attendance_rate', 'punctuality', 'deployments']));
        }, array_slice($a['people'], 0, 40)),
        'absent_reasons' => $a['absent_reasons'],
        'early_out_reasons' => $a['early_out_reasons'],
        'deployment_locations' => $a['deploy_locations'],
    ];
}

/** Where the Gemini result for one data snapshot is cached (shared with the report). */
function staff_analytics_ai_cache_file(array $snapshot): string {
    return __DIR__.'/../../cache/staff_ai_v2_'.md5(json_encode($snapshot)).'.json';
}

/**
 * Rule-based trends: compares the first half of the period with the second
 * half (present, late, absent, overtime). Used when Gemini is unavailable.
 */
function staff_analytics_rule_trends(array $a): array {
    $days = array_values($a['daily']);
    if (count($days) < 2 || !$a['totals']['records']) return [];
    $half = intdiv(count($days), 2);
    $sum = function(array $rows, string $k) { return array_sum(array_column($rows, $k)); };
    $first = array_slice($days, 0, $half); $second = array_slice($days, $half);
    $out = [];
    foreach (['present' => 'Attendance', 'late' => 'Late arrivals', 'absent' => 'Absences', 'overtime_minutes' => 'Overtime'] as $k => $label) {
        $x = $sum($first, $k); $y = $sum($second, $k);
        if (!$x && !$y) continue;
        $fmt = function($v) use ($k) { return $k === 'overtime_minutes' ? round($v / 60, 1).' h' : $v; };
        $dir = $y > $x ? 'up' : ($y < $x ? 'down' : 'stable');
        $out[] = ['title' => $label.' '.['up' => 'increasing', 'down' => 'decreasing', 'stable' => 'steady'][$dir],
                  'detail' => $fmt($x).' in the first half of the period vs '.$fmt($y).' in the second half.', 'direction' => $dir];
    }
    return array_slice($out, 0, 3);
}

/** Rule-based recommended actions from the same numbers. */
function staff_analytics_rule_actions(array $a): array {
    $t = $a['totals']; $out = [];
    $top = function(string $k) use ($a) {
        $list = array_filter($a['people'], function($p) use ($k) { return $p[$k] > 0; });
        usort($list, function($x, $y) use ($k) { return $y[$k] <=> $x[$k]; });
        return implode(', ', array_map(function($p) { return $p['name']; }, array_slice($list, 0, 3)));
    };
    if ($t['absent']) $out[] = ['action' => 'Follow up on absences', 'reason' => $t['absent'].' absence(s) recorded'.($top('absent') ? ' — '.$top('absent') : '').'.', 'priority' => $t['attendance_rate'] < 85 ? 'high' : 'medium'];
    if ($t['late']) $out[] = ['action' => 'Address late Time Ins', 'reason' => 'Punctuality is '.$t['punctuality'].'%'.($top('late') ? '; most late: '.$top('late') : '').'. Review shift start times or remind personnel.', 'priority' => $t['punctuality'] < 80 ? 'high' : 'medium'];
    if ($t['early_out']) $out[] = ['action' => 'Review early out reasons', 'reason' => $t['early_out'].' early out(s), '.duty_fmt_minutes($t['early_minutes']).' of duty not covered.', 'priority' => 'medium'];
    if ($t['overtime']) $out[] = ['action' => 'Balance workload to reduce overtime', 'reason' => $t['overtime_hours'].' overtime hours'.($top('overtime_minutes') ? ', mostly '.$top('overtime_minutes') : '').'.', 'priority' => $t['overtime_hours'] > 20 ? 'high' : 'low'];
    if (!$out) $out[] = ['action' => 'Keep current schedules', 'reason' => 'No absences, late arrivals, early outs or overtime in this period.', 'priority' => 'low'];
    return array_slice($out, 0, 4);
}

/** Last $n months for the per-chart month picker: ['2026-09' => 'September 2026', ...]. */
function staff_analytics_month_options(int $n = 12): array {
    $out = [];
    $d = new DateTime('first day of this month');
    for ($i = 0; $i < $n; $i++) { $out[$d->format('Y-m')] = $d->format('F Y'); $d->modify('-1 month'); }
    return $out;
}

/** Chart.js-ready series for one computed period (page + per-chart month endpoint). */
function staff_analytics_chart_data(array $a): array {
    $t = $a['totals'];
    return [
        'dailyLabels' => array_map(function($d) { return date('M j', strtotime($d)); }, array_keys($a['daily'])),
        'present' => array_column($a['daily'], 'present'),
        'late' => array_column($a['daily'], 'late'),
        'absent' => array_column($a['daily'], 'absent'),
        'earlyOut' => array_column($a['daily'], 'early_out'),
        'overtimeHours' => array_map(function($d) { return round($d['overtime_minutes'] / 60, 1); }, array_values($a['daily'])),
        'earlyHours' => array_map(function($d) { return round($d['early_minutes'] / 60, 1); }, array_values($a['daily'])),
        'absentReasons' => $a['absent_reason_groups'],
        'earlyReasons' => $a['early_out_reason_groups'],
        'weekdayLabels' => array_map(function($n) { return substr($n, 0, 3); }, array_values($a['day_names'])),
        'weekdayPresent' => array_column($a['weekday'], 'present'),
        'weekdayLate' => array_column($a['weekday'], 'late'),
        'weekdayAbsent' => array_column($a['weekday'], 'absent'),
        'hourLabels' => array_map('staff_analytics_hour', range(0, 23)),
        'coverage' => $a['coverage_hours'],
        'timeIn' => $a['time_in_hours'],
        'status' => [$t['present'] - $t['late'], $t['late'], $t['absent'], $t['no_record']],
        'peakHour' => staff_analytics_hour($a['peak_hour']),
        'records' => $t['records'],
    ];
}

/** Hour label, e.g. 13 -> "1 PM". */
function staff_analytics_hour(?int $h): string {
    if ($h === null) return '—';
    return date('g A', mktime($h, 0, 0));
}

/**
 * Rule-based observations from the same numbers — shown when the Gemini
 * API is unavailable so the AI Overview never comes back empty.
 */
function staff_analytics_rule_insights(array $a): array {
    $t = $a['totals']; $out = [];
    if (!$t['records']) return [['title' => 'No recorded data yet', 'detail' => 'There are no attendance or duty records in the selected period.', 'severity' => 'info']];
    if ($t['attendance_rate'] !== null) {
        $out[] = ['title' => 'Attendance rate: '.$t['attendance_rate'].'%', 'detail' => $t['present'].' present vs '.$t['absent'].' absent in the selected period.', 'severity' => $t['attendance_rate'] >= 90 ? 'good' : 'warning'];
    }
    if ($t['late']) {
        $out[] = ['title' => $t['late'].' late Time In'.($t['late'] > 1 ? 's' : ''), 'detail' => 'Average lateness is '.duty_fmt_minutes($t['avg_late_minutes']).'. Punctuality rate is '.$t['punctuality'].'%.', 'severity' => $t['punctuality'] >= 85 ? 'info' : 'warning'];
    }
    if ($t['early_out']) {
        $top = array_key_first($a['early_out_reasons']);
        $out[] = ['title' => $t['early_out'].' early out'.($t['early_out'] > 1 ? 's' : ''), 'detail' => 'Total '.duty_fmt_minutes($t['early_minutes']).' short of schedule.'.($top ? ' Most common reason: '.$top.'.' : ''), 'severity' => 'warning'];
    }
    if ($t['overtime']) {
        $out[] = ['title' => $t['overtime_hours'].' overtime hours', 'detail' => 'Recorded across '.$t['overtime'].' duty day'.($t['overtime'] > 1 ? 's' : '').'.', 'severity' => 'info'];
    }
    if ($a['peak_hour'] !== null) {
        $out[] = ['title' => 'Peak working hour: '.staff_analytics_hour($a['peak_hour']), 'detail' => 'Most staff are on duty around '.staff_analytics_hour($a['peak_hour']).'. Most Time Ins happen around '.staff_analytics_hour($a['peak_time_in_hour']).'.', 'severity' => 'info'];
    }
    return $out;
}

/* ─────────────────────────────────────────────────────────────────────────────
 * Uniform Staff / BPSO Analytics (same behavior as the other CAPS analytics pages):
 * Start / End Date optional — empty = all records; scope = staff | tanod | all.
 *   $p = ra_params($_GET);  $a = staff_analytics_uniform($pdo, $p, $scope);
 * ───────────────────────────────────────────────────────────────────────────── */
require_once __DIR__.'/../../analytics_common.php';

function staff_analytics_scope($v): string { return in_array($v, ['staff', 'tanod', 'all'], true) ? $v : 'all'; }
function staff_analytics_scope_label(string $s): string { return ['staff' => 'Barangay Staff', 'tanod' => 'BPSO / Tanod', 'all' => 'All Personnel'][$s] ?? 'All Personnel'; }

function staff_analytics_uniform(PDO $pdo, array $p, string $scope): array {
    $min = null;
    try { $min = $pdo->query("SELECT MIN(d) FROM (SELECT MIN(attendance_date) d FROM staff_attendance UNION ALL SELECT MIN(schedule_date) FROM tanod_schedules) x")->fetchColumn() ?: null; } catch (Throwable $e) {}
    [$from, $to] = aui_resolve_range($p, $min);
    if ($to > date('Y-m-d')) $to = max($from, date('Y-m-d'));
    $open = $p['start'] === '' || $p['end'] === '';
    $a = staff_analytics_compute($pdo, ['from' => $from, 'to' => $to, 'range' => 'custom', 'scope' => $scope]);
    $a['period'] = $p;
    $a['extra_params'] = ['scope' => $scope];
    $a['scope'] = $scope;
    $a['range'] = ['label' => $p['label'], 'open' => $open, 'from' => $from, 'to' => $to, 'extra_label' => staff_analytics_scope_label($scope)];

    // Attendance over time (per day up to 92 days, else per month).
    $b = aui_buckets($from, $to);
    $tr = ['present' => array_fill_keys($b['keys'], 0), 'late' => array_fill_keys($b['keys'], 0), 'absent' => array_fill_keys($b['keys'], 0), 'overtime_hours' => array_fill_keys($b['keys'], 0)];
    foreach ($a['daily'] as $day => $d) {
        $k = aui_bucket_key($day, $b['granularity']);
        if (!isset($tr['present'][$k])) continue;
        $tr['present'][$k] += $d['present']; $tr['late'][$k] += $d['late']; $tr['absent'][$k] += $d['absent'];
        $tr['overtime_hours'][$k] = round($tr['overtime_hours'][$k] + $d['overtime_minutes'] / 60, 1);
    }
    $a['trend'] = ['granularity' => $b['granularity'], 'labels' => $b['labels']] + array_map('array_values', $tr);
    $a['weekday_named'] = [];
    foreach ($a['weekday'] as $i => $w) $a['weekday_named'][substr($a['day_names'][$i], 0, 3)] = $w;
    $a['hour_labels'] = array_map('staff_analytics_hour', range(0, 23));
    unset($a['daily']);

    $a['comparison'] = null;
    if (!$open) {
        [$ps, $pe] = aui_prev_range($from, $to);
        $pv = staff_analytics_compute($pdo, ['from' => $ps, 'to' => $pe, 'range' => 'custom', 'scope' => $scope])['totals'];
        $t = $a['totals'];
        $a['comparison'] = ['previous_label' => ra_range_label($ps, $pe), 'rows' => [
            ['metric' => 'Present', 'current' => $t['present'], 'previous' => $pv['present']],
            ['metric' => 'Late', 'current' => $t['late'], 'previous' => $pv['late']],
            ['metric' => 'Absent', 'current' => $t['absent'], 'previous' => $pv['absent']],
            ['metric' => 'Early outs', 'current' => $t['early_out'], 'previous' => $pv['early_out']],
            ['metric' => 'Overtime hours', 'current' => $t['overtime_hours'], 'previous' => $pv['overtime_hours']],
        ]];
    }
    $a['interpretation'] = staff_analytics_interpretation($a);
    return $a;
}

function staff_analytics_interpretation(array $a): array {
    $t = $a['totals']; $L = $a['range']['label'] . ' (' . $a['range']['extra_label'] . ')';
    if (!$t['records']) return ['There are no attendance or duty records for ' . $L . '.'];
    $o = [];
    $o[] = $t['records'] . ' attendance / duty record(s) of ' . $t['people'] . ' person(s) were recorded for ' . $L . ': ' . $t['present'] . ' present, ' . $t['absent'] . ' absent'
        . ($t['no_record'] ? ' and ' . $t['no_record'] . ' with no Time In recorded.' : '.');
    if ($t['attendance_rate'] !== null) $o[] = 'The attendance rate is ' . $t['attendance_rate'] . '% and punctuality is ' . ($t['punctuality'] ?? 0) . '% (' . $t['late'] . ' late Time In(s), ' . duty_fmt_minutes($t['avg_late_minutes']) . ' late on average).';
    if ($t['worked_days']) $o[] = 'Personnel worked ' . $t['avg_worked_hours'] . ' hour(s) per duty day on average; ' . $t['overtime_hours'] . ' overtime hour(s) were recorded on ' . $t['overtime'] . ' day(s).';
    if ($t['early_out']) $o[] = $t['early_out'] . ' early out(s) left ' . duty_fmt_minutes($t['early_minutes']) . ' of duty uncovered' . ($a['early_out_reasons'] ? '; the most common reason is "' . array_key_first($a['early_out_reasons']) . '".' : '.');
    if ($a['absent_reasons']) $o[] = 'The most common absence reason is "' . array_key_first($a['absent_reasons']) . '" (' . reset($a['absent_reasons']) . ').';
    if ($a['peak_hour'] !== null) $o[] = 'Most personnel are on duty around ' . staff_analytics_hour($a['peak_hour']) . '; most Time Ins happen around ' . staff_analytics_hour($a['peak_time_in_hour']) . '.';
    if ($t['deployments']) $o[] = $t['deployments'] . ' tanod deployment(s) were logged' . ($a['deploy_locations'] ? ', mostly at ' . array_key_first($a['deploy_locations']) . '.' : '.');
    if ($a['comparison']) {
        $c = $a['comparison']['rows'][0]; $x = $c['current'] - $c['previous'];
        $o[] = 'Compared with the previous period (' . $a['comparison']['previous_label'] . '), attendance (present) ' . ($x > 0 ? 'increased by ' . $x : ($x < 0 ? 'decreased by ' . abs($x) : 'stayed the same')) . ' (' . $c['previous'] . ' → ' . $c['current'] . ').';
    }
    return $o;
}

/** Key / data of the saved AI result (aggregates + per-person figures, no contact details). */
function staff_analytics_uniform_snapshot(array $a): array {
    return ['date_range' => $a['range']['label'], 'scope' => $a['range']['extra_label'], 'totals' => $a['totals'], 'weekday' => $a['weekday_named'],
        'staff_hours_on_duty_by_hour' => array_filter($a['coverage_hours']), 'trend' => $a['trend'],
        'per_person' => array_map(fn($pp) => array_intersect_key($pp, array_flip(['name', 'type', 'position', 'records', 'present', 'absent', 'late', 'avg_late_minutes', 'early_out',
            'overtime_hours', 'worked_hours', 'avg_time_in', 'attendance_rate', 'punctuality', 'deployments'])), array_slice($a['people'], 0, 40)),
        'absent_reasons' => $a['absent_reasons'], 'early_out_reasons' => $a['early_out_reasons'], 'deployment_locations' => $a['deploy_locations'], 'comparison' => $a['comparison']];
}
