<?php
/**
 * staff_ai_analytics.php — AI Analytics for Staff / BPSO Analytics (JSON, POST).
 * Same behavior as the other CAPS analytics: only when "Generate AI Analytics" is clicked;
 * cached_only=1 returns a result generated before for the same data (no Gemini call).
 * POST start, end (optional — empty = all records), scope (staff | tanod | all), csrf_token.
 * The Gemini key stays server side (GEMINI_API_KEY in the CAPS .env); no contact details are sent.
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__.'/../../db.php';
require_once __DIR__.'/../../auth_check.php';
require_once __DIR__.'/staff_analytics_data.php';
staffbpso_migrate_schema($pdo);
staffbpso_duty_migrate_schema($pdo);

try {
    $p = ra_params($_POST);
    $a = staff_analytics_uniform($pdo, $p, staff_analytics_scope($_POST['scope'] ?? 'all'));
} catch (Throwable $e) {
    error_log('[Staff AI] '.$e->getMessage());
    aui_json(['success' => false, 'error' => 'Could not read the attendance records.'], 500);
}
$snap = staff_analytics_uniform_snapshot($a);
aui_ai_endpoint('staff_analytics', $snap, $snap, $p, $a['totals']['records'] > 0,
    'There are no attendance or duty records for '.$a['range']['label'].' ('.$a['range']['extra_label'].'), so there is nothing to analyse.', 'personnel / BPSO attendance',
    "Scope: ".$a['range']['extra_label'].". Focus on attendance and duty of barangay staff and BPSO / tanod: attendance rate, punctuality and late Time Ins, absences and their reasons, early outs, overtime, worked hours, "
    ."peak duty hours, tanod deployments and locations, per-person patterns (you may name personnel from per_person when relevant). "
    ."key_findings = the most important facts; demographic_trends = attendance trends over time / by weekday, comparison with the previous period; patterns = recurring lateness, absence or overtime patterns; "
    ."population_observations = per-person and per-group observations (staff vs BPSO); recommendations = practical scheduling / HR actions, each tied to a finding.",
    function () use ($a) {
        require_once __DIR__.'/../../activity_log_helper.php';
        log_activity('Staff and BPSO', 'Generate AI Analytics', 'Generated staff analytics AI ('.$a['range']['extra_label'].') for '.$a['range']['label']);
    });
