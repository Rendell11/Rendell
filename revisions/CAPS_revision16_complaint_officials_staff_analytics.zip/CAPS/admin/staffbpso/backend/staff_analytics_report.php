<?php
/**
 * Staff Analytics Report — opened from Staff Analytics with ?start&end&scope&mode=print|pdf&ai=1|0.
 * Same shared CAPS report layout (officials report_common.php) and behavior as the other analytics reports:
 *   ai=0 → "No AI – Data and tables only" (no charts)
 *   ai=1 → supporting charts + the AI Analytics already generated on the page (AI cache — never calls Gemini).
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__.'/../../db.php';
require_once __DIR__.'/../../auth_check.php';
require_once __DIR__.'/staff_analytics_data.php';
require_once __DIR__.'/../../officials/backend/report_common.php';
staffbpso_migrate_schema($pdo);
staffbpso_duty_migrate_schema($pdo);

$mode = report_mode();
$p = ra_params($_GET);
$a = staff_analytics_uniform($pdo, $p, staff_analytics_scope($_GET['scope'] ?? 'all'));
$t = $a['totals']; $R = max(1, $t['records']);
$withAi = ($_GET['ai'] ?? '0') === '1';
$ai = $withAi ? ai_cache_get('staff_analytics', staff_analytics_uniform_snapshot($a)) : null;
$showCharts = $ai !== null;

$brgy = report_barangay_profile($pdo);
$bAddr = trim((string)($brgy['address'] ?? '')) ?: implode(', ', array_filter([$brgy['barangay_name'] ?? '', $brgy['municipality_name'] ?? '', $brgy['province_name'] ?? ''], fn($x) => trim((string)$x) !== ''));
$captain = report_current_captain($pdo);
$generatedBy = report_generated_by($pdo);
$generatedRole = ($_SESSION['role'] ?? '') === 'admin' ? 'Administrator' : 'Barangay Staff';
if ($mode !== '') { try { require_once __DIR__.'/../../activity_log_helper.php'; log_activity('Staff and BPSO', 'Staff Analytics Report', ($mode === 'pdf' ? 'Saved PDF' : 'Printed').' staff analytics report ('.$a['range']['extra_label'].') · '.$a['range']['label'].($ai ? ' · with AI findings' : '')); } catch (Throwable $e) {} }
$n = fn($v) => number_format((float)$v);
$rt = fn($v) => $v === null ? '—' : $v.'%';

$title = 'Staff Analytics Report';
report_head($title, $mode);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<?php report_toolbar($mode, 'staff_analytics_'.$a['scope'].'_'.($p['start'] ?: 'all').'_to_'.($p['end'] ?: 'all'), 'landscape'); ?>
<?php aui_report_css(); ?>
<div class="report-page" id="reportRoot">
    <?php report_letterhead($brgy, 'Office of the Punong Barangay · Staff and BPSO'); ?>
    <?php if ($bAddr): ?><p class="brgy-addr"><?php echo rh($bAddr); ?></p><?php endif; ?>
    <?php report_title_block($title, $a['range']['extra_label'].' · attendance and duty · '.$a['range']['label'], 'Attendance Analytics'); ?>

    <?php aui_report_info($a['range']['label'], ['Personnel' => $a['range']['extra_label'], 'Basis' => 'Recorded attendance and duty logs', 'Records covered' => $n($t['records']).' of '.$n($t['people']).' person(s)'], $generatedBy, $captain); ?>

    <?php report_section_open('Attendance Summary'); ?>
    <?php report_stat_cards([
        ['value' => $rt($t['attendance_rate']), 'label' => 'Attendance Rate', 'variant' => 'a'],
        ['value' => $rt($t['punctuality']), 'label' => 'Punctuality', 'variant' => 'b'],
        ['value' => $n($t['absent']), 'label' => 'Absences', 'variant' => 'c'],
        ['value' => $t['overtime_hours'].' h', 'label' => 'Overtime', 'variant' => 'd'],
    ]); ?>
    <div style="margin-top:12px"></div>
    <?php aui_table(['Indicator', 'Value'], [
        ['Records / persons', $n($t['records']).' / '.$n($t['people'])],
        ['Present / absent / no Time In', $n($t['present']).' / '.$n($t['absent']).' / '.$n($t['no_record'])],
        ['Late Time Ins (average lateness)', $n($t['late']).' ('.duty_fmt_minutes($t['avg_late_minutes']).')'],
        ['Early outs (duty not covered)', $n($t['early_out']).' ('.duty_fmt_minutes($t['early_minutes']).')'],
        ['Overtime', $t['overtime_hours'].' h on '.$n($t['overtime']).' day(s)'],
        ['Average worked hours per duty day', $t['avg_worked_hours'].' h'],
        ['Peak duty hour / most Time Ins', staff_analytics_hour($a['peak_hour']).' / '.staff_analytics_hour($a['peak_time_in_hour'])],
        ['Tanod deployments', $n($t['deployments'])],
    ], '', [1]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Attendance Status & Reasons'); ?>
    <div class="grid2">
        <div><p class="sub">Attendance status</p><?php aui_table(['Status', 'Records', 'Share'], aui_dist(['On time' => $t['present'] - $t['late'], 'Late' => $t['late'], 'Absent' => $t['absent'], 'No Time In' => $t['no_record']], $R), 'No records.', [1, 2]); ?></div>
        <div><p class="sub">Absence reasons</p><?php aui_table(['Reason', 'Absences', 'Share'], aui_dist($a['absent_reasons']), 'No absences.', [1, 2]); ?>
            <p class="sub">Early out reasons</p><?php aui_table(['Reason', 'Early outs', 'Share'], aui_dist($a['early_out_reasons']), 'No early outs.', [1, 2]); ?></div>
    </div>
    <?php if ($showCharts && $t['records']): ?><p class="chart-cap">Figure 1. Attendance status</p><div class="chart-wrap"><canvas id="rc-status"></canvas></div><?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Trends & Hours'); ?>
    <?php $rows = []; $tr = $a['trend'];
    foreach ($tr['labels'] as $i => $lbl) if ($tr['present'][$i] + $tr['late'][$i] + $tr['absent'][$i] || $tr['granularity'] === 'month') $rows[] = [$lbl, $n($tr['present'][$i]), $n($tr['late'][$i]), $n($tr['absent'][$i]), $tr['overtime_hours'][$i].' h'];
    aui_table([$tr['granularity'] === 'day' ? 'Day' : 'Month', 'Present', 'Late', 'Absent', 'Overtime'], $rows, 'No records in this range.', [1, 2, 3, 4]); ?>
    <?php if ($showCharts && count($tr['labels']) > 1): ?><p class="chart-cap">Figure 2. Attendance over time</p><div class="chart-wrap"><canvas id="rc-trend"></canvas></div><?php endif; ?>
    <div class="grid2">
        <div><p class="sub">By weekday</p><?php aui_table(['Day', 'Present', 'Late', 'Absent'], array_map(fn($k, $v) => [$k, $n($v['present']), $n($v['late']), $n($v['absent'])], array_keys($a['weekday_named']), $a['weekday_named']), '', [1, 2, 3]); ?></div>
        <div><p class="sub">Staff-hours on duty by hour</p><?php $cov = []; foreach ($a['coverage_hours'] as $h => $v) if ($v > 0) $cov[] = [staff_analytics_hour($h), $v]; aui_table(['Hour', 'Staff-hours'], $cov, 'No Time Out recorded.', [1]); ?></div>
    </div>
    <?php if ($a['comparison']): ?>
    <p class="sub">Selected period vs previous period (<?php echo rh($a['comparison']['previous_label']); ?>)</p>
    <?php aui_table(['Indicator', 'Selected period', 'Previous period', 'Change'], array_map(function ($r) use ($n) { $x = round($r['current'] - $r['previous'], 1); return [$r['metric'], $n($r['current']), $n($r['previous']), ($x > 0 ? '+' : '').$x]; }, $a['comparison']['rows']), '', [1, 2, 3]); ?>
    <?php else: ?><p class="note">Set both a Start Date and an End Date to compare with the previous period of the same length.</p><?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Per-Person Attendance'); ?>
    <?php aui_table(['Name', 'Type', 'Position', 'Records', 'Present', 'Absent', 'Late', 'Attendance', 'Punctuality', 'Avg Time In', 'Worked', 'Overtime', 'Deploy.'],
        array_map(fn($pp) => [$pp['name'], $pp['type'], $pp['position'], $n($pp['records']), $n($pp['present']), $n($pp['absent']), $n($pp['late']), $rt($pp['attendance_rate']), $rt($pp['punctuality']),
            $pp['avg_time_in'] ?: '—', $pp['worked_hours'].' h', $pp['overtime_hours'].' h', $n($pp['deployments'])], $a['people']),
        'No personnel records in this range.', [3, 4, 5, 6, 7, 8, 10, 11, 12]); ?>
    <?php if ($a['deploy_locations']): ?><p class="sub">Deployment locations</p><?php aui_table(['Location', 'Deployments', 'Share'], aui_dist($a['deploy_locations']), '', [1, 2]); endif; ?>
    <?php report_section_close(); ?>

    <?php aui_report_tail($a['interpretation'], $ai, $withAi, ['Attendance Trends', 'Lateness, Absence & Overtime Patterns', 'Personnel Observations', 'Recommended Actions'], 'attendance data of '.$a['range']['label']); ?>

    <?php report_certify_and_signatures($brgy['brgy_name'] ?? 'Barangay', $generatedBy, $generatedRole, $captain); ?>
    <?php report_footer_strip($brgy['brgy_name'] ?? 'Barangay'); ?>
</div>
<script>
(function () {
    if (!window.Chart) return;
    Chart.defaults.animation = false; Chart.defaults.font.family = 'Arial, Helvetica, sans-serif'; Chart.defaults.font.size = 10; Chart.defaults.color = '#475569';
    const grid = { color: '#e2e8f0' }, legend = { position: 'top', align: 'end', labels: { boxWidth: 10 } };
    const a = <?php echo json_encode(['t' => $t, 'trend' => $a['trend']], JSON_UNESCAPED_UNICODE); ?>;
    const el = id => document.getElementById(id);
    if (el('rc-status')) new Chart(el('rc-status'), { type: 'bar', data: { labels: ['On time', 'Late', 'Absent', 'No Time In'], datasets: [{ data: [a.t.present - a.t.late, a.t.late, a.t.absent, a.t.no_record], backgroundColor: ['#1baf7a', '#eab308', '#e11d48', '#94a3b8'], borderRadius: 3, maxBarThickness: 40 }] },
        options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
    const t = a.trend, line = (label, data, color) => ({ label, data, borderColor: color, backgroundColor: color, borderWidth: 2, pointRadius: t.labels.length > 40 ? 0 : 2, tension: 0 });
    if (el('rc-trend')) new Chart(el('rc-trend'), { type: 'line', data: { labels: t.labels, datasets: [line('Present', t.present, '#1baf7a'), line('Late', t.late, '#eab308'), line('Absent', t.absent, '#e11d48')] },
        options: { maintainAspectRatio: false, plugins: { legend }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
})();
</script>
<?php report_foot(); ?>
