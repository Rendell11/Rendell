<?php
/**
 * analytics_common.php — shared pieces of the uniform CAPS analytics pages
 * (same structure / behavior as Resident, Household, Legal Document, Disaster,
 * Announcement and Blotter Analytics). Used by Complaint, Officials and Staff / BPSO.
 *
 *   Page:    aui_styles(), aui_date_form(), aui_ai_section(), aui_report_modal(), aui_script()
 *            → Start / End Date (empty = all records), AI Analytics on top (manual only),
 *              Data Interpretation below, cards / charts ("View table") / tables,
 *              Save PDF / Print asking whether to include the AI findings.
 *   AI:      aui_ai_endpoint() — POST start, end, csrf_token, cached_only; result cached by data
 *            snapshot so the report can include it without calling Gemini again.
 *   Report:  aui_report_css(), aui_table(), aui_report_ai() with officials/backend/report_common.php.
 */
require_once __DIR__ . '/residents/backend/resident_analytics_data.php'; // ra_params, ra_range_label, ra_pct
require_once __DIR__ . '/ai_helper.php';

if (!function_exists('aui_csrf_token')) {

function aui_csrf_token(): string {
    if (session_status() === PHP_SESSION_NONE) @session_start();
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return (string)$_SESSION['csrf_token'];
}
function aui_csrf_ok(): bool {
    if (session_status() === PHP_SESSION_NONE) @session_start();
    $sent = (string)($_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    return $sent !== '' && !empty($_SESSION['csrf_token']) && hash_equals((string)$_SESSION['csrf_token'], $sent);
}
function aui_json(array $d, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($d, JSON_UNESCAPED_UNICODE);
    exit;
}
function aui_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

/** Open date range → [from, to] of the actual data (first record … today). */
function aui_resolve_range(array $p, ?string $minDate): array {
    $from = $p['start'] !== '' ? $p['start'] : ($minDate ? substr($minDate, 0, 10) : date('Y-m-d'));
    $to = $p['end'] !== '' ? $p['end'] : max(date('Y-m-d'), $from);
    if ($from > $to) $from = $to;
    return [$from, $to];
}
/** Previous period of the same length, ending the day before $from. */
function aui_prev_range(string $from, string $to): array {
    $days = (int)((strtotime($to) - strtotime($from)) / 86400) + 1;
    $pe = date('Y-m-d', strtotime($from . ' -1 day'));
    return [date('Y-m-d', strtotime($pe . ' -' . ($days - 1) . ' days')), $pe];
}
/** Day buckets up to 92 days, else months: ['granularity','keys','labels']. */
function aui_buckets(string $from, string $to): array {
    $days = (int)((strtotime($to) - strtotime($from)) / 86400) + 1;
    $monthly = $days > 92;
    $keys = []; $labels = [];
    $cur = strtotime($monthly ? date('Y-m-01', strtotime($from)) : $from); $end = strtotime($to);
    while ($cur <= $end) {
        $keys[] = date($monthly ? 'Y-m' : 'Y-m-d', $cur);
        $labels[] = date($monthly ? 'M Y' : 'M j', $cur);
        $cur = strtotime($monthly ? '+1 month' : '+1 day', $cur);
    }
    return ['granularity' => $monthly ? 'month' : 'day', 'keys' => $keys, 'labels' => $labels, 'days' => $days];
}
function aui_bucket_key(string $datetime, string $granularity): string {
    return date($granularity === 'month' ? 'Y-m' : 'Y-m-d', strtotime($datetime));
}

/**
 * AI Analytics endpoint (JSON, POST). $focus is the module-specific instruction; the section
 * names follow the uniform shape: summary, key_findings, demographic_trends, patterns,
 * population_observations, recommendations.
 */
function aui_ai_endpoint(string $ns, array $snapshot, array $data, array $p, bool $hasData, string $emptyMsg, string $role, string $focus, ?callable $log = null): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') aui_json(['success' => false, 'error' => 'Method not allowed.'], 405);
    if (!aui_csrf_ok()) aui_json(['success' => false, 'error' => 'Your session has expired. Please refresh the page and try again.'], 403);
    if (!empty($_POST['cached_only'])) {
        $c = ai_cache_get($ns, $snapshot);
        aui_json($c ? $c + ['cached' => true] : ['success' => true, 'none' => true]);
    }
    if (!$hasData) aui_json(['success' => false, 'error' => $emptyMsg]);
    if (ai_api_key() === '') aui_json(['success' => false, 'error' => 'AI is not configured. Set GEMINI_API_KEY in the CAPS .env file.']);

    $prompt = "You are a data analyst for a Philippine barangay office ($role). Analyze ONLY the aggregated data below for the date range: " . $p['label'] . ". "
        . $focus . " Do not invent numbers or names; cite the actual figures and percentages. Keep each detail to one or two short sentences. If the data is thin, say so briefly.\n"
        . "Return JSON: {\"summary\": string (1-2 sentences), "
        . "\"key_findings\": [{\"title\": string, \"detail\": string}] (3-4 items), "
        . "\"demographic_trends\": [{\"title\": string, \"detail\": string}] (2-3 items), "
        . "\"patterns\": [{\"title\": string, \"detail\": string}] (2-3 items), "
        . "\"population_observations\": [{\"title\": string, \"detail\": string}] (2-3 items), "
        . "\"recommendations\": [{\"action\": string, \"reason\": string, \"priority\": \"high\"|\"medium\"|\"low\"}] (3-4 items)}.\n\n"
        . "DATA:\n" . json_encode($data, JSON_UNESCAPED_UNICODE);
    $r = ai_call([['text' => $prompt]], '', ['temperature' => 0.3]);
    $parsed = $r['ok'] ? ai_parse_json($r['text']) : null;
    if (!is_array($parsed) || empty($parsed['key_findings'])) aui_json(['success' => false, 'error' => ($r['error'] ?? '') ?: 'The AI service returned an unreadable answer. Please try again.']);

    $clean = fn($v) => mb_substr(trim((string)$v), 0, 600);
    $items = function ($list) use ($clean): array {
        $res = [];
        foreach (is_array($list) ? $list : [] as $x) {
            if (!is_array($x) || trim((string)($x['title'] ?? '')) === '') continue;
            $res[] = ['title' => $clean($x['title']), 'detail' => $clean($x['detail'] ?? '')];
        }
        return array_slice($res, 0, 5);
    };
    $recs = [];
    foreach (is_array($parsed['recommendations'] ?? null) ? $parsed['recommendations'] : [] as $x) {
        if (!is_array($x) || trim((string)($x['action'] ?? '')) === '') continue;
        $recs[] = ['action' => $clean($x['action']), 'reason' => $clean($x['reason'] ?? ''),
                   'priority' => in_array($x['priority'] ?? '', ['high', 'medium', 'low'], true) ? $x['priority'] : 'medium'];
    }
    $result = [
        'success' => true, 'ai' => true, 'model' => $r['model'] ?? '', 'generated_at' => date('F j, Y g:i A'), 'period' => $p,
        'summary' => $clean($parsed['summary'] ?? ''),
        'key_findings' => $items($parsed['key_findings']),
        'demographic_trends' => $items($parsed['demographic_trends'] ?? []),
        'patterns' => $items($parsed['patterns'] ?? []),
        'population_observations' => $items($parsed['population_observations'] ?? []),
        'recommendations' => array_slice($recs, 0, 5),
    ];
    ai_cache_put($ns, $snapshot, $result);
    if ($log) { try { $log(); } catch (Throwable $e) { /* optional */ } }
    aui_json($result);
}

/* ───────────────────────────── Report helpers ───────────────────────────── */

function aui_report_css(): void { ?>
<style>
    .brgy-addr{text-align:center;font-size:11px;color:#64748b;margin:-12px 0 14px}
    .report-page{max-width:1100px}
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 24px}
    table.kv th{width:42%;background:transparent;font-size:10.5px;color:#64748b}
    table.kv td{font-weight:700}
    td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
    tr.total td{font-weight:800;border-top:1.5px solid #94a3b8;background:#f8fafc}
    th,td{font-size:10.5px}
    .note{margin:10px 0 0;font-size:11.5px;line-height:1.55;color:#334155}
    .sub{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#0d9488;margin:14px 0 4px}
    .sub:first-child{margin-top:0}
    .grid2{display:grid;grid-template-columns:1fr 1fr;gap:0 20px}
    .chart-wrap{position:relative;height:200px;margin:6px 0 4px}
    .chart-cap{font-size:10px;color:#64748b;margin:0 0 4px}
    ol.interp{margin:0;padding-left:18px;font-size:12px;line-height:1.6}
    .ai-item{padding:6px 0;border-bottom:1px solid #e2e8f0;font-size:12px}
    .ai-item:last-child{border-bottom:0}
    .ai-pri{display:inline-block;padding:1px 6px;border-radius:99px;font-size:9px;font-weight:800;text-transform:uppercase;margin-left:6px}
    .pri-high{background:#fee2e2;color:#b91c1c}.pri-medium{background:#fef3c7;color:#b45309}.pri-low{background:#f1f5f9;color:#475569}
    .section-wrap{page-break-inside:auto;break-inside:auto}
    tr,.chart-wrap,.stat-grid,.signature-block,.certify-line{page-break-inside:avoid;break-inside:avoid}
    h2.section{page-break-after:avoid;break-after:avoid}
</style>
<?php }

/** Table with optional right-aligned (numeric) columns; a first cell "Total" makes a total row. */
function aui_table(array $head, array $rows, string $empty = 'No data for the selected range.', array $right = []): void {
    if (!$rows) { echo '<p class="empty-note">' . aui_h($empty) . '</p>'; return; }
    echo '<table><thead><tr>';
    foreach ($head as $i => $h) echo '<th' . (in_array($i, $right, true) ? ' class="num"' : '') . '>' . aui_h($h) . '</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr' . (($row[0] ?? '') === 'Total' ? ' class="total"' : '') . '>';
        foreach (array_values($row) as $i => $c) echo '<td' . (in_array($i, $right, true) ? ' class="num"' : '') . '>' . aui_h($c) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
}
/** [label => count] → rows with share and a Total row. */
function aui_dist(array $counts, ?int $base = null): array {
    $sum = array_sum($counts); $base = $base ?: max(1, $sum); $rows = [];
    foreach ($counts as $k => $v) $rows[] = [(string)$k, number_format((float)$v), ra_pct($v, $base) . '%'];
    if ($rows) $rows[] = ['Total', number_format((float)$sum), ra_pct($sum, $base) . '%'];
    return $rows;
}
/** Report information block (date range, basis, generated by, date, captain). */
function aui_report_info(string $rangeLabel, array $left, string $generatedBy, ?array $captain): void {
    report_section_open('Report Information'); ?>
    <div class="info-grid">
        <table class="kv"><tbody>
            <tr><th>Date range</th><td><?php echo aui_h($rangeLabel); ?></td></tr>
            <?php foreach ($left as $k => $v): ?><tr><th><?php echo aui_h($k); ?></th><td><?php echo aui_h($v); ?></td></tr><?php endforeach; ?>
        </tbody></table>
        <table class="kv"><tbody>
            <tr><th>Generated by</th><td><?php echo aui_h($generatedBy); ?></td></tr>
            <tr><th>Date generated</th><td><?php echo aui_h(date('F j, Y g:i A')); ?></td></tr>
            <tr><th>Barangay Captain</th><td><?php echo aui_h($captain ? 'Hon. ' . $captain['full_name'] : 'Not assigned'); ?></td></tr>
        </tbody></table>
    </div>
    <?php report_section_close();
}
/** Data Interpretation + AI Findings sections of a report. */
function aui_report_tail(array $notes, ?array $ai, bool $withAi, array $labels, string $basis): void {
    report_section_open('Data Interpretation'); ?>
    <ol class="interp"><?php foreach ($notes as $x): ?><li><?php echo aui_h($x); ?></li><?php endforeach; ?></ol>
    <?php report_section_close();
    if ($ai) {
        report_section_open('AI Findings');
        if (!empty($ai['summary'])) echo '<p class="note">' . aui_h($ai['summary']) . '</p>';
        foreach ([['key_findings', 'Key Findings'], ['demographic_trends', $labels[0] ?? 'Trends'], ['patterns', $labels[1] ?? 'Significant Changes / Patterns'], ['population_observations', $labels[2] ?? 'Observations']] as [$key, $lbl]) {
            if (empty($ai[$key])) continue;
            echo '<p class="sub">' . aui_h($lbl) . '</p>';
            foreach ($ai[$key] as $f) echo '<div class="ai-item"><strong>' . aui_h($f['title']) . '</strong> — ' . aui_h($f['detail']) . '</div>';
        }
        if (!empty($ai['recommendations'])) {
            echo '<p class="sub">' . aui_h($labels[3] ?? 'Recommended Actions') . '</p>';
            foreach ($ai['recommendations'] as $i => $f) echo '<div class="ai-item">' . ($i + 1) . '. <strong>' . aui_h($f['action']) . '</strong><span class="ai-pri pri-' . aui_h($f['priority']) . '">' . aui_h($f['priority']) . '</span><br><span style="color:#64748b">' . aui_h($f['reason']) . '</span></div>';
        }
        echo '<p style="margin:8px 0 0;font-size:10px;color:#64748b">AI-generated (Gemini) · ' . aui_h($ai['generated_at'] ?? '') . ' · based on the aggregated ' . aui_h($basis) . '. Verify against the tables above.</p>';
        report_section_close();
    } elseif ($withAi) {
        report_section_open('AI Findings');
        echo '<p class="note">No AI Analytics has been generated for this data yet.</p>';
        report_section_close();
    }
}

/* ───────────────────────────── Page helpers ───────────────────────────── */

function aui_styles(): void { ?>
<style>
    .kpi2 { border: 1px solid #eef2f7; border-radius: 20px; padding: 16px 18px; background: #fff }
    .kpi2 .k-label { font-size: 9px; font-weight: 900; text-transform: uppercase; letter-spacing: .08em; color: #64748b }
    .kpi2 .k-value { font-size: 26px; font-weight: 900; color: #0f172a; line-height: 1.1; margin-top: 4px; font-variant-numeric: tabular-nums }
    .kpi2 .k-sub { font-size: 10px; font-weight: 700; color: #94a3b8; margin-top: 2px }
    .aui-panel { background: #fff; border: 1px solid #eef2f7; border-radius: 1.5rem; box-shadow: 0 1px 2px rgba(15,23,42,.04) }
    .chart-card { border: 1px solid #eef2f7; border-radius: 24px; padding: 20px; background: #fff; display: flex; flex-direction: column; min-width: 0 }
    .chart-card h3 { font-size: 14px; font-weight: 900; color: #1e293b }
    .chart-card .c-sub { font-size: 10px; font-weight: 700; color: #94a3b8; margin-top: 2px }
    .chart-box2 { position: relative; height: 250px; margin-top: 14px }
    details.tv { margin-top: 10px }
    details.tv summary { cursor: pointer; font-size: 10px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: .06em }
    table.dt { width: 100%; border-collapse: collapse; font-size: 12px }
    table.dt th { text-align: left; font-size: 9px; text-transform: uppercase; letter-spacing: .06em; color: #94a3b8; font-weight: 900; padding: 8px 10px; border-bottom: 1px solid #eef2f7; background: #f8fafc }
    table.dt td { padding: 8px 10px; border-bottom: 1px solid #f1f5f9; color: #334155; font-weight: 600 }
    table.dt td.num, table.dt th.num { text-align: right; font-variant-numeric: tabular-nums }
    table.dt tr.total td { font-weight: 900; border-top: 1.5px solid #cbd5e1; background: #f8fafc }
    .empty { font-size: 12px; color: #94a3b8; font-style: italic; text-align: center; padding: 40px 10px }
    .aui-field { border: 1px solid #e2e8f0; border-radius: .9rem; padding: .6rem .8rem; font-size: .85rem; font-weight: 600; color: #1e293b; background: #fff }
    .aui-label { display: block; font-size: .62rem; font-weight: 800; letter-spacing: .12em; text-transform: uppercase; color: #94a3b8; margin-bottom: .35rem }
    .aui-btn { display: inline-flex; align-items: center; gap: .45rem; padding: .65rem 1.1rem; border-radius: .9rem; font-size: .72rem; font-weight: 800; text-transform: uppercase; letter-spacing: .05em }
    .aui-btn .material-symbols-outlined { font-size: 16px }
    .aui-dark { background: #0f172a; color: #fff } .aui-dark:hover { background: #1e293b } .aui-dark:disabled { opacity: .6 }
    .aui-light { background: #fff; color: #475569; border: 1px solid #e2e8f0 } .aui-light:hover { background: #f8fafc }
    .aui-hero-btn { display: inline-flex; align-items: center; gap: .5rem; padding: .625rem 1.25rem; border-radius: .75rem; font-weight: 700; font-size: .75rem; text-transform: uppercase; letter-spacing: .05em; color: #fff; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.2) }
    .aui-hero-btn:hover { background: rgba(255,255,255,.2) } .aui-hero-btn.white { background: #fff; color: #0f172a } .aui-hero-btn.white:hover { background: #f1f5f9 }
    .aui-hero { background: linear-gradient(135deg, var(--accent-700) 0%, var(--accent-600) 50%, var(--accent-700) 100%) }
    #aiScopeModal.hidden, #reportModal.hidden { display: none }
    html.dark .kpi2, html.dark .chart-card, html.dark .aui-panel { background: #1e293b; border-color: #334155 }
    html.dark .kpi2 .k-value, html.dark .chart-card h3 { color: #e2e8f0 }
    html.dark table.dt th { background: #0f172a; border-color: #334155 } html.dark table.dt td { color: #cbd5e1; border-color: #334155 }
</style>
<?php }

/** Hero band with Save PDF / Print / Back. */
function aui_hero(string $eyebrow, string $icon, string $title, string $subtitle, string $backUrl, string $backLabel): void { ?>
    <section class="aui-hero rounded-2xl p-6 md:p-8 text-white relative overflow-hidden">
        <div class="absolute -right-12 -top-12 w-64 h-64 opacity-10 rounded-full blur-3xl pointer-events-none" style="background: var(--accent-400);"></div>
        <div class="relative z-10 flex flex-col xl:flex-row xl:items-center xl:justify-between gap-5">
            <div>
                <div class="flex items-center gap-2 text-white/60 text-[10px] font-black uppercase tracking-[0.18em] mb-2"><span class="material-symbols-outlined text-base"><?php echo aui_h($icon); ?></span><?php echo aui_h($eyebrow); ?></div>
                <h1 class="text-2xl md:text-3xl font-black tracking-tight leading-none"><?php echo aui_h($title); ?></h1>
                <p class="text-white/65 text-sm mt-2 font-medium max-w-2xl"><?php echo aui_h($subtitle); ?></p>
            </div>
            <div class="flex flex-wrap items-center gap-3">
                <button type="button" onclick="AUI.openReport('pdf')" class="aui-hero-btn white"><span class="material-symbols-outlined" style="font-size:18px">picture_as_pdf</span>Save PDF</button>
                <button type="button" onclick="AUI.openReport('print')" class="aui-hero-btn"><span class="material-symbols-outlined" style="font-size:18px">print</span>Print</button>
                <a href="<?php echo aui_h($backUrl); ?>" class="aui-hero-btn"><span class="material-symbols-outlined" style="font-size:18px">arrow_back</span><?php echo aui_h($backLabel); ?></a>
            </div>
        </div>
    </section>
<?php }

/** Start / End Date (+ optional extra filters HTML with [data-aui-param] inputs). */
function aui_date_form(array $p, string $extra = ''): void { ?>
    <section class="aui-panel p-5 md:p-6">
        <form id="rangeForm" class="flex flex-wrap items-end gap-4" onsubmit="AUI.apply(event)">
            <div><label for="startDate" class="aui-label">Start Date</label><input type="date" id="startDate" max="9999-12-31" class="aui-field" value="<?php echo aui_h($p['start']); ?>"></div>
            <div><label for="endDate" class="aui-label">End Date</label><input type="date" id="endDate" max="9999-12-31" class="aui-field" value="<?php echo aui_h($p['end']); ?>"></div>
            <?php echo $extra; ?>
            <button type="submit" class="aui-btn aui-dark"><span class="material-symbols-outlined">filter_alt</span>Apply</button>
            <button type="button" onclick="AUI.clear()" class="aui-btn aui-light">Clear</button>
            <div class="ml-auto text-right">
                <p class="aui-label">Showing</p>
                <p id="rangeLabel" class="text-sm font-black text-slate-800"></p>
                <p id="rangeBasis" class="text-[10px] font-bold text-slate-400"></p>
            </div>
        </form>
    </section>
<?php }

function aui_ai_section(): void { ?>
    <section class="aui-panel p-6 md:p-8">
        <div class="flex flex-wrap items-center justify-between gap-4">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined text-white bg-indigo-600 p-2 rounded-xl">auto_awesome</span>
                <div><h2 class="text-lg font-black text-slate-800">AI Analytics</h2>
                    <p id="aiStatus" class="text-[10px] text-slate-400 font-bold">Not generated. AI runs only when you click the button.</p></div>
            </div>
            <button type="button" id="aiBtn" onclick="AUI.generateAi()" class="aui-btn aui-dark"><span class="material-symbols-outlined">auto_awesome</span><span id="aiBtnText">Generate AI Analytics</span></button>
        </div>
        <div id="aiBody" class="mt-6"></div>
    </section>
    <!-- Data Interpretation (directly below AI Analytics) -->
    <div id="raInterp"></div>
    <div id="raBody" class="space-y-7"></div>
<?php }

function aui_report_modal(string $subtitle, string $noAiHint): void { ?>
    <div id="reportModal" class="fixed inset-0 z-[999] hidden bg-slate-900/70 items-center justify-center p-4" style="background:rgba(15,23,42,.7)" onclick="if (event.target === this) AUI.closeReport()">
        <div class="bg-white rounded-[2rem] shadow-2xl w-full max-w-md p-8" style="max-width:28rem" role="dialog" aria-modal="true" aria-labelledby="rmTitle">
            <div class="flex items-start justify-between gap-4">
                <div>
                    <h3 id="rmTitle" class="text-2xl font-black text-slate-900 tracking-tight">Save as PDF</h3>
                    <p class="text-[11px] font-black text-indigo-600 uppercase tracking-widest mt-1"><?php echo aui_h($subtitle); ?></p>
                    <p id="rmRange" class="text-xs font-bold text-slate-400 mt-1"></p>
                </div>
                <button type="button" onclick="AUI.closeReport()" class="p-1 text-slate-400 hover:text-slate-700" aria-label="Close"><span class="material-symbols-outlined">close</span></button>
            </div>
            <p class="text-sm font-bold text-slate-700 mt-6 mb-3">Include AI findings in the report?</p>
            <div class="space-y-3">
                <label class="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 cursor-pointer hover:border-indigo-300">
                    <input type="radio" name="rmAi" value="0" class="mt-1" checked>
                    <span><span class="block text-sm font-black text-slate-800">No AI – Data and tables only</span>
                        <span class="block text-[11px] font-semibold text-slate-400"><?php echo aui_h($noAiHint); ?></span></span>
                </label>
                <label class="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 cursor-pointer hover:border-indigo-300">
                    <input type="radio" name="rmAi" value="1" class="mt-1">
                    <span><span class="block text-sm font-black text-slate-800">Include AI – Data, charts, and AI explanation</span>
                        <span class="block text-[11px] font-semibold text-slate-400">Uses the AI Analytics already generated on this page.</span></span>
                </label>
            </div>
            <p id="rmError" class="hidden mt-4 text-xs font-bold text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-3 py-2">Please generate AI Analytics first.</p>
            <div class="flex justify-end gap-3 mt-8">
                <button type="button" onclick="AUI.closeReport()" class="aui-btn aui-light">Cancel</button>
                <button type="button" onclick="AUI.continueReport()" class="aui-btn aui-dark">Continue</button>
            </div>
        </div>
    </div>
<?php }

/**
 * Shared page script: helpers (kpi, card, table, section, mk, donut, barCfg …) and the AUI controller.
 * $cfg: dataUrl, aiUrl, reportUrl, aiLabels [trends, patterns, observations, actions], basis.
 */
function aui_script(array $cfg, $initialData): void { ?>
<script>
    const AUI_CSRF = <?php echo json_encode(aui_csrf_token()); ?>;
    const COLORS = { s1: '#2a78d6', s2: '#eb6834', s3: '#1baf7a', red: '#e11d48', violet: '#6366f1', muted: '#94a3b8', grid: '#eef2f7' };
    const PAL = ['#2a78d6', '#1baf7a', '#eb6834', '#6366f1', '#e11d48', '#eab308', '#14b8a6', '#8b5cf6', '#94a3b8', '#ec4899'];
    const charts = {};
    let DATA = <?php echo json_encode($initialData, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?>;
    const esc = v => { const x = document.createElement('div'); x.textContent = v == null ? '' : String(v); return x.innerHTML; };
    const num = v => Number(v || 0).toLocaleString('en-US');
    const pct = (v, d) => d ? (Math.round(Number(v || 0) / d * 1000) / 10) + '%' : '0%';
    const sum = o => (Array.isArray(o) ? o : Object.values(o || {})).reduce((s, v) => s + Number(v || 0), 0);
    const rate = v => v === null || v === undefined ? '—' : v + '%';
    if (window.Chart) {
        Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";
        Chart.defaults.font.size = 11;
        Chart.defaults.color = document.documentElement.classList.contains('dark') ? '#94a3b8' : '#64748b';
        Chart.defaults.plugins.tooltip.backgroundColor = '#0f172a';
        Chart.defaults.plugins.tooltip.padding = 10;
    }
    function kpi(label, value, sub) { return `<div class="kpi2"><p class="k-label">${esc(label)}</p><p class="k-value">${esc(value)}</p>${sub ? `<p class="k-sub">${esc(sub)}</p>` : ''}</div>`; }
    function card(id, title, sub, opts = {}) {
        return `<div class="chart-card ${opts.span || ''}"><h3>${esc(title)}</h3><p class="c-sub">${esc(sub)}</p>
            ${opts.empty ? `<p class="empty">${esc(opts.empty)}</p>` : `<div class="chart-box2"><canvas id="${id}" role="img" aria-label="${esc(title)}"></canvas></div>`}
            ${opts.table ? `<details class="tv"><summary>View table</summary><div class="mt-2 overflow-x-auto">${opts.table}</div></details>` : ''}</div>`;
    }
    function table(head, rows, numCols = []) {
        if (!rows.length) return '<p class="empty">No data for the selected range.</p>';
        return `<table class="dt"><thead><tr>${head.map((h, i) => `<th class="${numCols.includes(i) ? 'num' : ''}">${esc(h)}</th>`).join('')}</tr></thead><tbody>` +
            rows.map(r => `<tr class="${r[0] === 'Total' ? 'total' : ''}">${r.map((c, i) => `<td class="${numCols.includes(i) ? 'num' : ''}">${esc(c)}</td>`).join('')}</tr>`).join('') + '</tbody></table>';
    }
    function distRows(obj, base) {
        const rows = Object.entries(obj || {}).map(([k, v]) => [k, num(v), pct(v, base)]);
        if (rows.length) rows.push(['Total', num(sum(obj)), pct(sum(obj), base)]);
        return rows;
    }
    function section(icon, title, sub, inner) {
        return `<section class="aui-panel p-6 md:p-8"><div class="flex items-center gap-3 mb-6"><span class="material-symbols-outlined text-white bg-primary p-2 rounded-xl" style="background:var(--accent-600)">${icon}</span>
            <div><h2 class="text-lg font-black text-slate-800">${esc(title)}</h2><p class="text-[10px] text-slate-400 font-bold">${esc(sub)}</p></div></div>${inner}</section>`;
    }
    const axisCount = { beginAtZero: true, ticks: { precision: 0 }, grid: { color: COLORS.grid }, border: { display: false } };
    const noGrid = { grid: { display: false }, border: { display: false } };
    const legendTop = { position: 'top', align: 'end', labels: { boxWidth: 10, boxHeight: 10 } };
    function mk(id, cfg) { const el = document.getElementById(id); if (!el || !window.Chart) return; cfg.options = Object.assign({ maintainAspectRatio: false }, cfg.options || {}); charts[id] = new Chart(el, cfg); }
    function donut(id, obj, colorOf, base) {
        const e = Object.entries(obj || {}).filter(([, v]) => v > 0);
        mk(id, { type: 'doughnut', data: { labels: e.map(x => x[0]), datasets: [{ data: e.map(x => x[1]), backgroundColor: e.map((x, i) => colorOf ? colorOf(x[0], i) : PAL[i % PAL.length]), borderColor: '#fff', borderWidth: 2 }] },
            options: { cutout: '62%', plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, boxHeight: 10 } }, tooltip: { callbacks: { label: c => ` ${c.label}: ${num(c.raw)} (${pct(c.raw, base)})` } } } } });
    }
    const barCfg = (labels, data, color, horizontal) => ({ type: 'bar', data: { labels, datasets: [{ data, backgroundColor: color, borderRadius: 4, maxBarThickness: 32 }] },
        options: { indexAxis: horizontal ? 'y' : 'x', plugins: { legend: { display: false } }, scales: horizontal ? { x: axisCount, y: noGrid } : { x: noGrid, y: axisCount } } });
    const lineDs = (label, data, color, n) => ({ label, data, borderColor: color, backgroundColor: color, borderWidth: 2, pointRadius: n > 40 ? 0 : 3, tension: 0 });
    function compareSection(d) {
        if (!d.comparison) return '';
        return `<div class="chart-card lg:col-span-2"><h3>Selected Period vs Previous Period</h3><p class="c-sub">Previous period: ${esc(d.comparison.previous_label)}</p>
            <div class="chart-box2"><canvas id="c-compare"></canvas></div>
            <div class="mt-3 overflow-x-auto">${table(['Indicator', 'Selected', 'Previous', 'Change'], d.comparison.rows.map(r => [r.metric, num(r.current), num(r.previous), (r.current - r.previous > 0 ? '+' : '') + num(Math.round((r.current - r.previous) * 10) / 10)]), [1, 2, 3])}</div></div>`;
    }
    function drawCompare(d) {
        if (!d.comparison) return;
        mk('c-compare', { type: 'bar', data: { labels: d.comparison.rows.map(r => r.metric), datasets: [
            { label: 'Selected period', data: d.comparison.rows.map(r => r.current), backgroundColor: COLORS.s1, borderRadius: 4, maxBarThickness: 40 },
            { label: 'Previous period', data: d.comparison.rows.map(r => r.previous), backgroundColor: COLORS.muted, borderRadius: 4, maxBarThickness: 40 }] },
            options: { plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
    }

    /* ───────── Controller: date range, AI (manual only), Save PDF / Print ───────── */
    const AUI = (function () {
        const CFG = <?php echo json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?>;
        let AI = null, _mode = 'pdf', renderFn = null;
        const $ = id => document.getElementById(id);
        function params() {
            const p = { start: $('startDate').value, end: $('endDate').value };
            document.querySelectorAll('[data-aui-param]').forEach(i => { p[i.dataset.auiParam] = i.value; });
            return p;
        }
        function dataParams() {
            const p = { start: DATA?.period?.start || '', end: DATA?.period?.end || '' };
            Object.assign(p, DATA?.extra_params || {});
            return p;
        }
        function draw() {
            Object.values(charts).forEach(c => c.destroy());
            for (const k in charts) delete charts[k];
            $('raInterp').innerHTML = '';
            if (!DATA) { $('raBody').innerHTML = '<section class="aui-panel p-8"><p class="empty">Unable to load the analytics.</p></section>'; return; }
            $('rangeLabel').textContent = DATA.range.label + (DATA.range.extra_label ? ' · ' + DATA.range.extra_label : '');
            $('rangeBasis').textContent = DATA.range.open ? CFG.openBasis : CFG.rangeBasis;
            $('raInterp').innerHTML = section('fact_check', 'Data Interpretation', 'Automatic summary of the figures (no AI) · ' + DATA.range.label,
                `<ol class="list-decimal pl-5 space-y-2 text-sm text-slate-600 font-medium">${(DATA.interpretation || []).map(x => `<li>${esc(x)}</li>`).join('')}</ol>`);
            renderFn(DATA);
        }
        async function apply(e) {
            if (e) e.preventDefault();
            const p = params();
            if (p.start && p.end && p.start > p.end) { alert('The Start Date must be on or before the End Date.'); return; }
            const q = new URLSearchParams(p);
            history.replaceState({}, '', location.pathname + '?' + q.toString());
            $('raBody').style.opacity = '.5';
            try {
                const r = await fetch(CFG.dataUrl + (CFG.dataUrl.includes('?') ? '&' : '?') + 'action=data&' + q.toString(), { credentials: 'same-origin' });
                const j = await r.json();
                if (!j.success) throw new Error(j.error || 'Unable to load the analytics.');
                DATA = j;
            } catch (err) { alert(err.message); }
            $('raBody').style.opacity = '';
            draw(); resetAi(); loadCachedAi();
        }
        function clear() { $('startDate').value = ''; $('endDate').value = ''; apply(); }
        function resetAi() {
            AI = null; $('aiBody').innerHTML = '';
            $('aiStatus').textContent = 'Not generated for this date range. AI runs only when you click the button.';
            $('aiBtnText').textContent = 'Generate AI Analytics';
        }
        function renderAi(x) {
            AI = x;
            $('aiStatus').textContent = 'Generated ' + (x.generated_at || '') + ' · ' + (x.period?.label || '') + (x.cached ? ' · saved result' : '');
            $('aiBtnText').textContent = 'Regenerate AI Analytics';
            const L = CFG.aiLabels;
            const group = (title, icon, list) => list && list.length ? `<div class="rounded-2xl border border-indigo-100 bg-indigo-50/40 p-5" style="border:1px solid #e0e7ff"><div class="flex items-center gap-2 mb-3"><span class="material-symbols-outlined text-indigo-600">${icon}</span><h5 class="text-[10px] font-black uppercase tracking-widest text-indigo-700">${esc(title)}</h5></div>
                <ul class="space-y-2">${list.map(f => `<li class="text-xs leading-relaxed text-slate-600"><strong class="text-slate-800">${esc(f.title)}</strong> — ${esc(f.detail)}</li>`).join('')}</ul></div>` : '';
            const recs = (x.recommendations || []).map((f, i) => `<li class="text-xs leading-relaxed text-slate-600"><strong class="text-slate-800">${i + 1}. ${esc(f.action)}</strong>
                <span class="ml-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${f.priority === 'high' ? 'bg-rose-100 text-rose-700' : f.priority === 'low' ? 'bg-slate-100 text-slate-600' : 'bg-amber-100 text-amber-700'}">${esc(f.priority)}</span><br>${esc(f.reason)}</li>`).join('');
            $('aiBody').innerHTML = (x.summary ? `<p class="text-sm font-semibold text-slate-700 mb-5">${esc(x.summary)}</p>` : '') +
                `<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">${group('Key Findings', 'insights', x.key_findings)}${group(L[0], 'trending_up', x.demographic_trends)}
                 ${group(L[1], 'timeline', x.patterns)}${group(L[2], 'groups', x.population_observations)}</div>` +
                (recs ? `<div class="rounded-2xl border border-indigo-100 bg-white p-5 mt-4" style="border:1px solid #e0e7ff"><div class="flex items-center gap-2 mb-3"><span class="material-symbols-outlined text-indigo-600">task_alt</span><h5 class="text-[10px] font-black uppercase tracking-widest text-indigo-700">${esc(L[3])}</h5></div><ul class="space-y-3">${recs}</ul></div>` : '') +
                `<p class="text-[10px] text-slate-400 font-bold mt-4">AI-generated from aggregated ${esc(CFG.basis)} only. Verify against the tables below.</p>`;
        }
        async function aiRequest(cachedOnly) {
            const fd = new FormData();
            fd.append('csrf_token', AUI_CSRF);
            Object.entries(dataParams()).forEach(([k, v]) => fd.append(k, v));
            if (cachedOnly) fd.append('cached_only', '1');
            const r = await fetch(CFG.aiUrl, { method: 'POST', body: fd, credentials: 'same-origin' });
            let j = null; try { j = await r.json(); } catch (e) { throw new Error('The AI service returned an invalid response.'); }
            if (!j || !j.success) throw new Error(j?.error || 'AI Analytics is unavailable right now.');
            return j;
        }
        async function generateAi() {
            if (!DATA) return;
            $('aiBtn').disabled = true;
            $('aiBtnText').textContent = 'Generating…';
            $('aiStatus').textContent = 'Generating AI Analytics for ' + DATA.range.label + '…';
            try { renderAi(await aiRequest(false)); }
            catch (e) { $('aiStatus').textContent = e.message; $('aiBtnText').textContent = AI ? 'Regenerate AI Analytics' : 'Generate AI Analytics'; }
            $('aiBtn').disabled = false;
        }
        async function loadCachedAi() { if (!DATA) return; try { const j = await aiRequest(true); if (j.ai) renderAi(j); } catch (e) { } }
        function openReport(mode) {
            _mode = mode;
            $('rmTitle').textContent = mode === 'pdf' ? 'Save as PDF' : 'Print';
            $('rmRange').textContent = DATA ? DATA.range.label + (DATA.range.extra_label ? ' · ' + DATA.range.extra_label : '') : '';
            document.querySelector('input[name="rmAi"][value="0"]').checked = true;
            $('rmError').classList.add('hidden');
            const m = $('reportModal'); m.classList.remove('hidden'); m.style.display = 'flex';
        }
        function closeReport() { const m = $('reportModal'); m.classList.add('hidden'); m.style.display = 'none'; }
        function continueReport() {
            const withAi = document.querySelector('input[name="rmAi"]:checked')?.value === '1';
            // Never generates AI here — only uses the analysis already generated on this page.
            if (withAi && !AI) { $('rmError').classList.remove('hidden'); return; }
            const q = new URLSearchParams(Object.assign({ mode: _mode }, dataParams(), { ai: withAi ? '1' : '0' }));
            closeReport();
            window.open(CFG.reportUrl + '?' + q.toString(), '_blank');
        }
        document.addEventListener('keydown', e => { if (e.key === 'Escape') closeReport(); });
        document.addEventListener('change', e => { if (e.target.name === 'rmAi') $('rmError').classList.add('hidden'); });
        function start(fn) { renderFn = fn; draw(); loadCachedAi(); }
        return { start, apply, clear, generateAi, openReport, closeReport, continueReport, redraw: draw };
    })();
</script>
<?php }

}
