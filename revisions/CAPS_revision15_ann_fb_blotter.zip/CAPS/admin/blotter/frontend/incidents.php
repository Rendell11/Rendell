<?php
/**
 * Blotter / Case Management — main page (sidebar: Blotter).
 * Cards, tabs, filters and the case list; File New Case, Notice Templates, View Analytics and
 * Settings (configurable time-based / hearing-based rule + transfer destination).
 * Data: ../backend/blotter_cases.php, ../backend/settings.php.
 */
require_once __DIR__ . '/../../db.php';
$required_module = 'blotter';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../backend/blotter_common.php';

$current_page = 'Blotter';
$pageTitle = 'Blotter';
$db_error = '';
$types = []; $statuses = blt_statuses(); $set = null; $configured = true;
try {
    blt_migrate($pdo);
    $types = array_column(blt_incident_types($pdo, false), 'name');
    $statuses = blt_workflow_statuses($pdo);
    $set = blt_settings($pdo);
    $configured = blt_settings_configured($pdo);
} catch (Throwable $e) { $db_error = 'Database setup failed. Import sql/blotter.sql and check the PHP error log.'; error_log('[Blotter] ' . $e->getMessage()); }
$canCreate = blt_can($pdo, 'create');
$isAdmin = blt_is_admin();
$tab = in_array($_GET['tab'] ?? '', ['all', 'active', 'hearing', 'resolved', 'transfer', 'cancelled'], true) ? $_GET['tab'] : 'all';
?>
<!doctype html>
<html <?php require_once __DIR__ . '/../../theme_loader.php'; echo $theme_attrs['html'] ?? ''; ?>>
<head>
    <?php require __DIR__ . '/partials/blotter_head.php'; ?>
    <style>
        .wk-head-btns { display:flex; align-items:center; gap:.4rem; }
        .wk-nav { width:34px; height:34px; display:inline-flex; align-items:center; justify-content:center; border-radius:.75rem; border:1px solid #e2e8f0; background:#fff; color:#475569; }
        .wk-nav:hover, .wk-today:hover { background:#f8fafc; color:var(--accent-700, #4338ca); }
        .wk-nav .material-symbols-outlined { font-size:20px; }
        .wk-today { height:34px; padding:0 .9rem; border-radius:.75rem; border:1px solid #e2e8f0; background:#fff; font-size:10px; font-weight:900; text-transform:uppercase; letter-spacing:.08em; color:#475569; }
        .wk-legend { display:flex; gap:.9rem; font-size:10px; font-weight:800; color:#94a3b8; text-transform:uppercase; letter-spacing:.06em; }
        .wk-legend i { display:inline-block; width:8px; height:8px; border-radius:99px; margin-right:.3rem; vertical-align:middle; }
        .wk-grid { display:grid; grid-template-columns:repeat(7, minmax(0,1fr)); gap:.6rem; padding:1rem 1.25rem 1.25rem; }
        @media (max-width:1100px) { .wk-grid { grid-template-columns:repeat(2, minmax(0,1fr)); } }
        @media (max-width:640px) { .wk-grid { grid-template-columns:1fr; } }
        .wk-day { background:#f8fafc; border:1px solid #f1f5f9; border-radius:1rem; padding:.6rem; min-height:110px; display:flex; flex-direction:column; gap:.45rem; min-width:0; }
        .wk-day.today { background:#eef2ff; border-color:#c7d2fe; }
        .wk-dh { display:flex; align-items:center; justify-content:space-between; padding:0 .15rem .15rem; }
        .wk-dh .wd { font-size:10px; font-weight:900; text-transform:uppercase; letter-spacing:.1em; color:#94a3b8; }
        .wk-dh .dn { font-size:18px; font-weight:900; color:#334155; line-height:1; }
        .wk-day.today .wd, .wk-day.today .dn { color:var(--accent-700, #4338ca); }
        .wk-dh .cnt { font-size:9px; font-weight:900; padding:.15rem .45rem; border-radius:99px; background:#fff; color:#64748b; border:1px solid #e2e8f0; }
        .wk-ev { background:#fff; border:1px solid #e2e8f0; border-left:4px solid #6366f1; border-radius:.7rem; padding:.4rem .5rem; cursor:pointer; transition:transform .1s, box-shadow .1s; min-width:0; }
        .wk-ev:hover { transform:translateY(-1px); box-shadow:0 6px 16px rgba(15,23,42,.08); }
        .wk-ev .t { font-size:11px; font-weight:900; color:#0f172a; display:flex; align-items:center; justify-content:space-between; gap:.3rem; }
        .wk-ev .t small { font-size:9px; font-weight:800; color:#94a3b8; font-family:"DM Mono",monospace; }
        .wk-ev .n { font-size:10.5px; font-weight:600; color:#475569; line-height:1.3; margin-top:.1rem; overflow:hidden; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; }
        .wk-ev.done { border-left-color:#cbd5e1; background:#fbfcfd; }
        .wk-ev.done .t, .wk-ev.done .n { color:#94a3b8; }
        .wk-ev.res { border-left-color:#10b981; }
        .wk-more { font-size:10px; font-weight:900; color:var(--accent-700, #4338ca); text-align:left; padding:.25rem .3rem; border:0; background:none; cursor:pointer; }
        .wk-none { font-size:11px; color:#cbd5e1; font-weight:600; margin:auto 0; text-align:center; }
        .wk-tip { position:fixed; z-index:80; display:none; max-width:320px; background:#0f172a; color:#fff; border-radius:.9rem; padding:.7rem .85rem; font-size:11px; line-height:1.45; box-shadow:0 12px 32px rgba(15,23,42,.35); pointer-events:none; }
        .wk-tip b { color:#c7d2fe; }
    </style>
    <style>.pager button { display:inline-flex; align-items:center; gap:.25rem; padding:.375rem .75rem; border-radius:.75rem; font-size:10px; font-weight:900; text-transform:uppercase; letter-spacing:.05em; }</style>
</head>
<body <?php echo $theme_attrs['body'] ?? ''; ?>>
<div class="flex min-h-screen">
    <?php require __DIR__ . '/../../sidebar.php'; ?>
    <div class="flex-1 flex flex-col min-w-0 main-wrapper">
        <?php require __DIR__ . '/../../header.php'; ?>
        <main class="p-4 md:p-6 lg:p-8 space-y-8">

            <div class="hero-band rounded-2xl p-6 md:p-8 text-white relative overflow-hidden">
                <div class="absolute -right-12 -top-12 w-64 h-64 opacity-10 rounded-full blur-3xl pointer-events-none" style="background:var(--accent-400);"></div>
                <div class="absolute left-1/3 bottom-0 w-48 h-48 opacity-10 rounded-full blur-2xl pointer-events-none" style="background:var(--accent-300);"></div>
                <div class="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                        <h1 class="text-2xl md:text-3xl font-black tracking-tight leading-none">Blotter / Case Management</h1>
                        <p class="text-white/60 text-sm mt-2 font-medium">File cases, schedule hearings, issue summons and track every case until it is settled or transferred.</p>
                        <?php if ($set): ?><p class="text-white/70 text-[11px] mt-2 font-bold uppercase tracking-wider"><span class="material-symbols-outlined text-sm align-middle">rule</span> <?php echo h(blt_rule_label($set['rule_type'], $set['max_days'], $set['max_hearings'])); ?> · then transfer to <?php echo h(blt_settings_destination($set)); ?></p><?php endif; ?>
                    </div>
                    <div class="flex flex-wrap gap-3 flex-shrink-0">
                        <button type="button" onclick="openMasterlist('pdf')" class="hero-btn"><span class="material-symbols-outlined">picture_as_pdf</span>Save PDF</button>
                        <button type="button" onclick="openMasterlist('print')" class="hero-btn"><span class="material-symbols-outlined">print</span>Print</button>
                        <a href="blotter_analytics.php" class="hero-btn"><span class="material-symbols-outlined">analytics</span>View Analytics</a>
                        <a href="notice_templates.php" class="hero-btn"><span class="material-symbols-outlined">design_services</span>Notice Templates</a>
                        <button type="button" onclick="Settings.open()" class="hero-btn"><span class="material-symbols-outlined">settings</span>Settings</button>
                        <?php if ($canCreate && $configured): ?>
                        <a href="file_case.php" class="hero-btn hero-btn-primary"><span class="material-symbols-outlined">note_add</span>File New Case</a>
                        <?php elseif ($canCreate): ?>
                        <button type="button" disabled title="Configure the Blotter Settings first" class="hero-btn hero-btn-primary" style="opacity:.5;cursor:not-allowed"><span class="material-symbols-outlined">note_add</span>File New Case</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if ($db_error): ?>
                <div class="rounded-2xl border border-rose-200 bg-rose-50 text-rose-700 px-5 py-4 text-sm font-bold"><?php echo h($db_error); ?></div>
            <?php endif; ?>

            <?php if (!$db_error && !$configured): ?>
                <!-- First use: the Settings must be configured before the first case can be filed -->
                <div id="setupNote" class="rounded-2xl border border-amber-200 bg-amber-50 px-5 py-4 flex flex-col sm:flex-row sm:items-center gap-4" style="border:1px solid #fde68a;background:#fffbeb">
                    <span class="material-symbols-outlined text-amber-600" style="font-size:32px;color:#d97706">settings_alert</span>
                    <div class="flex-1">
                        <p class="text-sm font-black text-amber-900" style="color:#78350f">Configure the Blotter Settings first</p>
                        <p class="text-xs font-semibold text-amber-800 mt-1" style="color:#92400e">Before filing a new case, set the case limit rule (time-based or hearing-based), the transfer destination, the incident types and the locations. <strong>File New Case</strong> stays disabled until the Settings are saved.</p>
                    </div>
                    <?php if ($isAdmin): ?>
                    <button type="button" onclick="Settings.open()" class="btn btn-dark shrink-0"><span class="material-symbols-outlined">settings</span>Configure Settings</button>
                    <?php else: ?>
                    <p class="text-[11px] font-bold text-amber-800 shrink-0" style="color:#92400e">Ask an administrator to configure them.</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-12 gap-4">
                <div class="col-span-12 lg:col-span-4 relative">
                    <span class="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-xl">search</span>
                    <input id="q" type="search" placeholder="Search Blotter ID, name, plate number, type or location…" class="search-pill">
                </div>
                <div class="col-span-6 md:col-span-3 lg:col-span-2">
                    <select id="typeFilter" class="select-pill"><option value="">All Case Types</option><?php foreach ($types as $t): ?><option value="<?php echo h($t); ?>"><?php echo h($t); ?></option><?php endforeach; ?></select>
                </div>
                <div class="col-span-6 md:col-span-3 lg:col-span-2">
                    <select id="statusFilter" class="select-pill"><option value="">All Statuses</option><?php foreach ($statuses as $s): ?><option value="<?php echo h($s); ?>"><?php echo h($s); ?></option><?php endforeach; ?></select>
                </div>
                <div class="col-span-6 md:col-span-3 lg:col-span-2"><input type="date" id="fromFilter" class="select-pill" title="Filed from" max="<?php echo date('Y-m-d'); ?>"></div>
                <div class="col-span-6 md:col-span-3 lg:col-span-2"><input type="date" id="toFilter" class="select-pill" title="Filed to" max="<?php echo date('Y-m-d'); ?>"></div>
            </div>

            <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-6">
                <?php foreach ([
                    ['all', 'Total Cases', 'total', 'folder_open', 'bg-indigo-50 text-indigo-600'],
                    ['active', 'Active', 'active', 'pending_actions', 'bg-amber-50 text-amber-600'],
                    ['hearing', 'Hearing Scheduled', 'hearing', 'event', 'bg-sky-50 text-sky-600'],
                    ['resolved', 'Resolved / Closed', 'resolved', 'handshake', 'bg-emerald-50 text-emerald-600'],
                    ['transfer', 'For Transfer / Transferred', 'transfer', 'local_police', 'bg-rose-50 text-rose-600'],
                ] as [$tabKey, $label, $count, $icon, $tile]): ?>
                <button type="button" onclick="setTab('<?php echo $tabKey; ?>')" class="stat stat-card relative text-left">
                    <div class="stat-icon <?php echo $tile; ?>"><span class="material-symbols-outlined"><?php echo $icon; ?></span></div>
                    <p class="stat-label"><?php echo h($label); ?></p>
                    <h3 class="stat-value" data-count="<?php echo $count; ?>">0</h3>
                </button>
                <?php endforeach; ?>
            </div>

            <!-- Weekly hearing calendar: who, what time; hover for the details, click to open the case -->
            <div class="table-card" id="weekCal">
                <div class="px-8 pt-6 pb-4 flex flex-wrap items-center justify-between gap-3 border-b border-slate-50">
                    <div class="flex items-center gap-3">
                        <span class="material-symbols-outlined text-white bg-primary p-2 rounded-xl shadow-md">calendar_month</span>
                        <div><h2 class="text-base font-black text-slate-800 leading-tight">Hearing Schedule</h2>
                            <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5" id="wkRange">This week</p></div>
                    </div>
                    <div class="flex flex-wrap items-center gap-4">
                        <div class="wk-legend"><span><i style="background:#6366f1"></i>Scheduled</span><span><i style="background:#10b981"></i>Resolved</span><span><i style="background:#cbd5e1"></i>Done</span></div>
                        <div class="wk-head-btns">
                            <button type="button" class="wk-nav" title="Previous week" onclick="Week.move(-7)"><span class="material-symbols-outlined">chevron_left</span></button>
                            <button type="button" class="wk-today" onclick="Week.move(0)">This week</button>
                            <button type="button" class="wk-nav" title="Next week" onclick="Week.move(7)"><span class="material-symbols-outlined">chevron_right</span></button>
                        </div>
                    </div>
                </div>
                <div class="wk-grid" id="wkGrid"><p class="text-sm text-slate-400">Loading…</p></div>
            </div>
            <div id="wkTip" class="wk-tip"></div>

            <div class="table-card">
                <div class="px-8 pt-6 pb-4 flex flex-wrap items-center justify-between gap-3 border-b border-slate-50">
                    <div class="flex items-center gap-3">
                        <span class="material-symbols-outlined text-white bg-primary p-2 rounded-xl shadow-md">gavel</span>
                        <div><h2 class="text-base font-black text-slate-800 leading-tight">Blotter Cases</h2>
                            <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5"><span data-count="today">0</span> filed today · <span data-count="for_transfer">0</span> waiting for transfer</p></div>
                    </div>
                    <div class="flex gap-2 overflow-x-auto pb-1" id="tabs">
                        <?php foreach (['all' => ['All', 'total'], 'active' => ['Active', 'active'], 'hearing' => ['Hearings', 'hearing'], 'resolved' => ['Resolved', 'resolved'],
                                        'transfer' => ['Transfer', 'transfer'], 'cancelled' => ['Cancelled', 'cancelled']] as $k => [$lbl, $cnt]): ?>
                        <button type="button" class="tab<?php echo $tab === $k ? ' active' : ''; ?>" data-tab="<?php echo $k; ?>" onclick="setTab('<?php echo $k; ?>')"><?php echo h($lbl); ?><span class="cnt" data-count="<?php echo $cnt; ?>">0</span></button>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead><tr><th>Blotter ID</th><th>Complainant / Respondent</th><th>Case Type</th><th>Incident</th><th>Filed</th><th>Status</th><th class="text-right">Action</th></tr></thead>
                        <tbody id="rows" class="divide-y divide-slate-50"><tr><td colspan="7" class="text-center py-16 text-slate-400">Loading…</td></tr></tbody>
                    </table>
                </div>
                <div id="pager" class="pager hidden flex flex-col sm:flex-row items-center justify-between gap-3 px-8 py-4 border-t border-slate-50"></div>
            </div>
        </main>
    </div>
</div>

<!-- Masterlist Save PDF / Print: which cases? -->
<div id="mlModal" class="modal-back">
  <div class="modal-box" style="max-width:480px">
    <div class="modal-body">
      <div class="flex items-start justify-between"><div><h3 id="mlTitle" class="modal-title">Save as PDF</h3><p class="modal-sub">Blotter Case Masterlist</p></div>
        <button type="button" onclick="BLT.close('mlModal')" class="modal-close" aria-label="Close"><span class="material-symbols-outlined">close</span></button></div>
      <p class="text-sm font-bold text-slate-700 mt-5 mb-2">Which cases to include?</p>
      <div class="grid grid-cols-2 gap-2">
        <?php foreach (['all' => 'All Cases', 'active' => 'Active', 'hearing' => 'Hearing Scheduled', 'resolved' => 'Resolved / Closed', 'transfer' => 'For Transfer / Transferred', 'cancelled' => 'Cancelled / Withdrawn'] as $k => $l): ?>
        <label class="choice"><input type="radio" name="mlTab" value="<?php echo $k; ?>"><span><?php echo h($l); ?></span></label>
        <?php endforeach; ?>
      </div>
      <label class="flex items-start gap-2 mt-4 text-xs font-semibold text-slate-600"><input type="checkbox" id="mlFilters" checked class="mt-0.5">
        <span>Apply the current search, case type, status and filed dates <span id="mlFilterText" class="block text-[11px] text-slate-400"></span></span></label>
    </div>
    <div class="modal-foot"><button type="button" onclick="BLT.close('mlModal')" class="btn btn-ghost">Cancel</button><button type="button" onclick="continueMasterlist()" class="btn btn-dark">Continue</button></div>
  </div>
</div>

<!-- Settings -->
<div id="settingsModal" class="modal-back">
  <div class="modal-box" style="max-width:820px">
    <div class="modal-head">
      <div><h3 class="modal-title">Blotter Settings</h3><p class="modal-sub">Barangay procedure</p><p class="text-[11px] text-slate-400 mt-1" id="setUpdated"></p></div>
      <button type="button" class="modal-close" onclick="BLT.close('settingsModal')"><span class="material-symbols-outlined">close</span></button>
    </div>
    <div class="modal-body space-y-6">
      <?php if (!$isAdmin): ?><div class="note note-info"><span class="material-symbols-outlined">lock</span><span>Only the administrator can change these settings.</span></div><?php endif; ?>
      <div class="sec-box space-y-4">
        <div class="sec-head !mb-1"><span class="material-symbols-outlined">rule</span><h4>Case limit rule</h4></div>
        <div class="grid sm:grid-cols-2 gap-3">
          <label class="choice"><input type="radio" name="rule_type" value="time"><span><span class="block">Time-based</span><span class="block text-[11px] font-semibold text-slate-500">A number of days to settle the case, then transfer (the days can be extended in Case Details).</span></span></label>
          <label class="choice"><input type="radio" name="rule_type" value="hearing"><span><span class="block">Hearing-based</span><span class="block text-[11px] font-semibold text-slate-500">Allow up to a number of hearings.</span></span></label>
        </div>
        <div class="grid sm:grid-cols-2 gap-4">
          <div><label class="field-label" for="sDays">Maximum days to settle the case (before transfer)</label><input id="sDays" type="number" min="1" max="365" class="input"></div>
          <div><label class="field-label" for="sHear">Maximum hearings</label><input id="sHear" type="number" min="1" max="20" class="input"></div>
        </div>
        <label class="flex items-center gap-2 text-sm font-semibold text-slate-600"><input type="checkbox" id="sNoShow"> A no-show hearing counts toward the maximum hearings</label>
        <p class="text-[11px] text-slate-400">When the limit is reached the case becomes <strong>For Transfer</strong>. The rule is saved on each case when it is filed, so changes apply to new cases only.</p>
        <div class="note note-warn hidden" id="sRuleNote"><span class="material-symbols-outlined">info</span><span></span></div>
      </div>
      <div class="sec-box space-y-4">
        <div class="sec-head !mb-1"><span class="material-symbols-outlined">local_police</span><h4>Transfer destination</h4></div>
        <p class="text-[11px] text-slate-400 -mt-2">One destination for both rules (hearing-based and time-based).</p>
        <div class="grid sm:grid-cols-3 gap-3" id="sDest"></div>
        <div id="sDestOtherWrap" class="hidden"><label class="field-label" for="sDestOther">Other authority *</label><input id="sDestOther" class="input" maxlength="150" placeholder="e.g. Municipal Social Welfare Office"></div>
        <div><label class="field-label" for="sTplT">Letter for the transfer (notice template)</label><select id="sTplT" class="input"></select>
          <p class="text-[11px] text-slate-400 mt-1">The letter that goes with the case to the receiving office (PNP / BPSO / other). Made in Case Details after the letters to the complainant and respondent are marked issued.</p></div>
        <div><label class="field-label" for="sMin">Minutes per hearing</label><input id="sMin" type="number" min="5" max="480" step="5" class="input">
          <p class="text-[11px] text-slate-400 mt-1">How long one hearing takes. No two hearings may be scheduled within this time of each other (e.g. 60 = a 2:00 PM hearing blocks 1:01 PM–2:59 PM).</p></div>
        <div><label class="field-label" for="sHall">Default hearing location</label><input id="sHall" class="input" maxlength="255"></div>
      </div>
      <div class="grid md:grid-cols-2 gap-4">
        <div class="sec-box space-y-3">
          <div class="sec-head !mb-1"><span class="material-symbols-outlined">category</span><h4>Incident types</h4></div>
          <ul id="sTypes" class="space-y-2 max-h-72 overflow-auto"></ul>
          <div class="flex gap-2"><input id="sTypeNew" class="input" maxlength="100" placeholder="Add a type"><button type="button" class="btn btn-ghost" onclick="Settings.add('types')"><span class="material-symbols-outlined">add</span></button></div>
        </div>
        <div class="sec-box space-y-3">
          <div class="sec-head !mb-1"><span class="material-symbols-outlined">location_on</span><h4>Extra incident locations</h4></div>
          <p class="text-[11px] text-slate-400">Streets and areas from Residents › Manage Area are listed automatically. "Other" is always available.</p>
          <ul id="sLocs" class="space-y-2 max-h-60 overflow-auto"></ul>
          <div class="flex gap-2"><input id="sLocNew" class="input" maxlength="150" placeholder="Add a place, e.g. Covered Court"><button type="button" class="btn btn-ghost" onclick="Settings.add('locs')"><span class="material-symbols-outlined">add</span></button></div>
        </div>
      </div>
    </div>
    <div class="modal-foot">
      <p id="sMsg" class="text-[11px] font-semibold text-rose-600 mr-auto"></p>
      <button type="button" class="btn btn-ghost" onclick="BLT.close('settingsModal')">Close</button>
      <?php if ($isAdmin): ?><button type="button" class="btn btn-dark" id="sSave" onclick="Settings.save()"><span class="material-symbols-outlined">save</span>Save Settings</button><?php endif; ?>
    </div>
  </div>
</div>

<script>
const API = '../backend/blotter_cases.php';
const esc = BLT.esc;
let TAB = <?php echo json_encode($tab); ?>, ROWS = [], PAGE = 1;
const PER = 10;

function setTab(t){
    TAB = t; PAGE = 1;
    document.querySelectorAll('#tabs .tab').forEach(b => b.classList.toggle('active', b.dataset.tab === t));
    history.replaceState(null, '', '?tab=' + t);
    load();
}
function counts(c){ document.querySelectorAll('[data-count]').forEach(el => { el.textContent = c[el.dataset.count] ?? 0; }); }
let timer = null;
async function load(){
    const p = new URLSearchParams({ action:'list', tab:TAB, q:document.getElementById('q').value.trim(), type:document.getElementById('typeFilter').value,
        status:document.getElementById('statusFilter').value, from:document.getElementById('fromFilter').value, to:document.getElementById('toFilter').value });
    try {
        const d = await BLT.getJSON(API + '?' + p);
        if (!d.success) throw new Error(d.message);
        ROWS = d.rows; counts(d.counts); draw();
    } catch (e) { document.getElementById('rows').innerHTML = '<tr><td colspan="7" class="text-center py-16 text-rose-600 font-semibold">' + esc(e.message) + '</td></tr>'; }
}
function draw(){
    const body = document.getElementById('rows'), pager = document.getElementById('pager');
    if (!ROWS.length) { body.innerHTML = '<tr><td colspan="7" class="text-center py-16"><span class="material-symbols-outlined text-4xl block mb-2 text-slate-200">manage_search</span><p class="text-sm text-slate-400">No cases found.</p></td></tr>'; pager.classList.add('hidden'); return; }
    const pages = Math.ceil(ROWS.length / PER); PAGE = Math.min(PAGE, pages);
    body.innerHTML = ROWS.slice((PAGE - 1) * PER, PAGE * PER).map(r =>
        '<tr class="cursor-pointer" onclick="location.href=\'case_details.php?id=' + r.id + '\'">' +
        '<td><span class="font-mono font-black text-indigo-600 text-sm">' + esc(r.case_number) + '</span>' + (r.hearing ? '<div class="text-[10px] text-sky-600 font-bold mt-1"><span class="material-symbols-outlined text-[12px] align-middle">event</span> ' + esc(r.hearing) + '</div>' : '') + '</td>' +
        '<td><div class="text-sm font-bold text-slate-800 truncate max-w-[260px]" title="' + esc(r.complainant) + '">' + esc(r.complainant) + '</div><div class="text-[11px] text-slate-400 truncate max-w-[260px]" title="' + esc(r.respondent) + '">vs. ' + esc(r.respondent) + '</div></td>' +
        '<td class="text-sm font-semibold text-slate-600">' + esc(r.type) + '</td>' +
        '<td><div class="text-xs font-bold text-slate-700">' + esc(r.incident) + '</div><div class="text-[11px] text-slate-400 truncate max-w-[200px]">' + esc(r.location) + '</div></td>' +
        '<td><div class="text-xs font-bold text-slate-700">' + esc(r.filed) + '</div><div class="text-[11px] text-slate-400">' + esc(r.filed_time) + '</div></td>' +
        '<td><span class="pill ' + esc(r.status_class) + '"><span class="material-symbols-outlined">' + esc(r.status_icon) + '</span>' + esc(r.status) + '</span></td>' +
        '<td class="text-right"><a class="btn btn-ghost btn-sm" href="case_details.php?id=' + r.id + '" onclick="event.stopPropagation()"><span class="material-symbols-outlined">folder_open</span>Open</a></td></tr>').join('');
    pager.classList.toggle('hidden', pages <= 1);
    pager.innerHTML = '<p class="text-[10px] font-bold uppercase tracking-widest text-slate-400">' + ((PAGE - 1) * PER + 1) + '–' + Math.min(PAGE * PER, ROWS.length) + ' of ' + ROWS.length + '</p>' +
        '<div class="flex gap-2"><button type="button" class="btn-ghost border border-slate-200" ' + (PAGE <= 1 ? 'disabled' : '') + ' onclick="PAGE--;draw()"><span class="material-symbols-outlined text-sm">chevron_left</span>Prev</button>' +
        '<button type="button" class="btn-ghost border border-slate-200" ' + (PAGE >= pages ? 'disabled' : '') + ' onclick="PAGE++;draw()">Next<span class="material-symbols-outlined text-sm">chevron_right</span></button></div>';
}
document.getElementById('q').addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => { PAGE = 1; load(); }, 300); });
['typeFilter', 'statusFilter', 'fromFilter', 'toFilter'].forEach(id => document.getElementById(id).addEventListener('change', () => { PAGE = 1; load(); }));

/* ───────── Weekly hearing calendar ───────── */
const Week = (function(){
    const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const monday = d => { const x = new Date(d); x.setHours(0, 0, 0, 0); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x; };
    let start = monday(new Date()), items = [];
    const tip = document.getElementById('wkTip');
    async function load(){
        const grid = document.getElementById('wkGrid');
        try {
            const d = await BLT.getJSON(API + '?action=week&days=7&start=' + iso(start));
            if (!d.success) throw new Error(d.message);
            items = d.hearings || [];
            const end = new Date(start); end.setDate(end.getDate() + 6);
            const f = x => x.toLocaleDateString([], { month: 'short', day: 'numeric' });
            document.getElementById('wkRange').textContent = f(start) + ' – ' + f(end) + ', ' + end.getFullYear() + ' · ' + items.filter(i => i.status === 'Scheduled').length + ' scheduled';
            const todayIso = iso(new Date());
            const MAX = 4;   // per day; the rest behind "+ N more"
            const ev = h => '<div class="wk-ev ' + (h.status === 'Scheduled' ? '' : (h.outcome === 'Resolved' ? 'res' : 'done')) + '" data-h="' + h.id + '">' +
                '<div class="t"><span>' + esc(h.time_label) + '</span><small>#' + h.no + '</small></div>' +
                '<div class="n">' + esc(h.complainant || '?') + ' <span style="color:#94a3b8">vs.</span> ' + esc(h.respondent || '?') + '</div></div>';
            grid.innerHTML = Array.from({ length: 7 }, (_, i) => { const day = new Date(start); day.setDate(day.getDate() + i); const k = iso(day);
                const list = items.filter(h => h.date === k);
                return '<div class="wk-day' + (k === todayIso ? ' today' : '') + '" data-day="' + k + '"><div class="wk-dh"><div><div class="wd">' + day.toLocaleDateString([], { weekday: 'short' }) + (k === todayIso ? ' · Today' : '') + '</div><div class="dn">' + day.getDate() + '</div></div>' +
                    (list.length ? '<span class="cnt">' + list.length + '</span>' : '') + '</div>' +
                    (list.length ? list.slice(0, MAX).map(ev).join('') + (list.length > MAX ? '<button type="button" class="wk-more" data-more="' + k + '">+ ' + (list.length - MAX) + ' more</button>' : '')
                                : '<p class="wk-none">No hearing</p>') + '</div>'; }).join('');
            grid.querySelectorAll('[data-more]').forEach(b => b.addEventListener('click', e => { e.stopPropagation();
                const k = b.dataset.more; b.insertAdjacentHTML('beforebegin', items.filter(h => h.date === k).slice(MAX).map(ev).join('')); b.remove(); }));
        } catch (e) { grid.innerHTML = '<p class="text-sm text-rose-600 p-6">' + esc(e.message) + '</p>'; }
    }
    document.getElementById('wkGrid').addEventListener('mouseover', e => {
        const li = e.target.closest('[data-h]'); if (!li) { tip.style.display = 'none'; return; }
        const h = items.find(x => x.id === Number(li.dataset.h)); if (!h) return;
        tip.innerHTML = '<b>' + esc(h.case_number) + '</b> · Hearing #' + h.no + '<br>' + esc(h.time_label) + ' · ' + esc(h.location) +
            '<br><b>Complainant:</b> ' + esc(h.complainant || '—') + '<br><b>Respondent:</b> ' + esc(h.respondent || '—') + '<br><b>Case:</b> ' + esc(h.type || '—') +
            (h.agenda ? '<br><b>Agenda:</b> ' + esc(h.agenda) : '') + '<br><b>Status:</b> ' + esc(h.outcome || h.status) + ' · case ' + esc(h.case_status) + '<br><span style="color:#94a3b8">Click to open the case</span>';
        tip.style.display = 'block';
    });
    document.getElementById('wkGrid').addEventListener('mousemove', e => {
        if (tip.style.display !== 'block') return;
        const w = tip.offsetWidth, x = e.clientX + 16 + w > innerWidth ? e.clientX - w - 12 : e.clientX + 16;
        tip.style.left = x + 'px'; tip.style.top = Math.min(e.clientY + 14, innerHeight - tip.offsetHeight - 8) + 'px';
    });
    document.getElementById('wkGrid').addEventListener('mouseleave', () => { tip.style.display = 'none'; });
    document.getElementById('wkGrid').addEventListener('click', e => { const li = e.target.closest('[data-h]'); if (!li) return; const h = items.find(x => x.id === Number(li.dataset.h)); if (h) location.href = 'case_details.php?id=' + h.case_id; });
    function move(days){ if (!days) start = monday(new Date()); else start.setDate(start.getDate() + days); load(); }
    load();
    return { move, load };
})();

/* ───────── Settings ───────── */
const Settings = (function(){
    let s = null, canEdit = false;
    async function open(){
        document.getElementById('sMsg').textContent = '';
        const d = await BLT.getJSON('../backend/settings.php?action=get');
        if (!d.success) { BLT.toast(d.message, 'error'); return; }
        s = d.settings; canEdit = d.can_edit; draw(); BLT.open('settingsModal');
    }
    function draw(){
        document.querySelectorAll('input[name="rule_type"]').forEach(r => r.checked = r.value === s.rule_type);
        document.getElementById('sDays').value = s.max_days;
        document.getElementById('sHear').value = s.max_hearings;
        document.getElementById('sNoShow').checked = !!s.noshow_counts;
        document.getElementById('sHall').value = s.default_hearing_location || '';
        document.getElementById('sMin').value = s.hearing_minutes || 60;
        document.getElementById('sTplT').innerHTML = '<option value="">— Choose a template —</option>' + (s.templates || []).map(t => '<option value="' + t.id + '"' + (t.id === s.transfer_template_id ? ' selected' : '') + '>' + esc(t.label) + '</option>').join('');
        document.getElementById('sDestOther').value = s.transfer_destination_other || '';
        document.getElementById('sDest').innerHTML = Object.keys(s.destinations).map(k => '<label class="choice"><input type="radio" name="dest" value="' + esc(k) + '"' + (s.transfer_destination === k ? ' checked' : '') + '>' + esc(s.destinations[k]) + '</label>').join('');
        document.querySelectorAll('input[name="dest"]').forEach(r => r.addEventListener('change', dest));
        document.querySelectorAll('input[name="rule_type"]').forEach(r => r.addEventListener('change', rule));
        document.getElementById('setUpdated').textContent = s.updated ? 'Last changed ' + s.updated : '';
        list('types'); list('locs'); dest(); rule();
        document.querySelectorAll('#settingsModal input, #settingsModal select, #settingsModal button.icon-btn').forEach(i => { if (!canEdit) i.disabled = true; });
    }
    function rule(){
        const t = (document.querySelector('input[name="rule_type"]:checked') || {}).value;
        document.getElementById('sDays').closest('div').classList.toggle('opacity-40', t !== 'time');
        document.getElementById('sHear').closest('div').classList.toggle('opacity-40', t !== 'hearing');
        // Changing the rule while cases are open: those cases keep the rule they were filed with.
        const oc = s.open_cases || {}, other = t === 'time' ? (oc.hearing || 0) : (oc.time || 0);
        const note = document.getElementById('sRuleNote'), changed = !!t && t !== s.rule_type && (oc.total || 0) > 0;
        note.classList.toggle('hidden', !changed); note.style.display = changed ? '' : 'none';
        if (changed) note.querySelector('span:last-child').innerHTML = '<strong>' + (oc.total || 0) + ' open case(s)</strong> already exist' + (other ? ' (' + other + ' filed with the ' + (t === 'time' ? 'hearing-based' : 'time-based') + ' rule)' : '') +
            '. They keep the rule they were filed with. Only <strong>new cases</strong> (filed from now on) will use the ' + (t === 'time' ? 'time-based' : 'hearing-based') + ' rule.';
    }
    function dest(){ document.getElementById('sDestOtherWrap').classList.toggle('hidden', (document.querySelector('input[name="dest"]:checked') || {}).value !== 'Other'); }
    function key(which){ return which === 'types' ? 'incident_types' : 'locations'; }
    function list(which){
        const arr = s[key(which)];
        document.getElementById(which === 'types' ? 'sTypes' : 'sLocs').innerHTML = arr.length ? arr.map((x, i) =>
            '<li class="flex items-center gap-2"><input class="input !py-2" value="' + esc(x.name) + '" maxlength="' + (which === 'types' ? 100 : 150) + '" oninput="Settings.set(\'' + which + '\',' + i + ',\'name\',this.value)">' +
            '<label class="text-[10px] font-bold uppercase text-slate-500 flex items-center gap-1 shrink-0"><input type="checkbox"' + (x.is_active ? ' checked' : '') + ' onchange="Settings.set(\'' + which + '\',' + i + ',\'is_active\',this.checked?1:0)">Active</label>' +
            '<button type="button" class="icon-btn danger" title="' + (x.used ? 'Used by ' + x.used + ' case(s): it will be disabled, not deleted' : 'Remove') + '" onclick="Settings.del(\'' + which + '\',' + i + ')"><span class="material-symbols-outlined text-lg">delete</span></button></li>').join('')
            : '<li class="text-sm text-slate-400">None yet.</li>';
    }
    function set(which, i, k, v){ s[key(which)][i][k] = v; }
    function del(which, i){ s[key(which)].splice(i, 1); list(which); }
    function add(which){
        const inp = document.getElementById(which === 'types' ? 'sTypeNew' : 'sLocNew'), v = inp.value.trim();
        if (!v) return;
        if (s[key(which)].some(x => x.name.toLowerCase() === v.toLowerCase())) { inp.value = ''; return; }
        s[key(which)].push({ id:0, name:v, is_active:1 }); inp.value = ''; list(which);
    }
    async function save(){
        const rule = document.querySelector('input[name="rule_type"]:checked'), dst = document.querySelector('input[name="dest"]:checked');
        const oc = s.open_cases || {};
        if (rule && rule.value !== s.rule_type && (oc.total || 0) > 0 && !(await BLT.confirm({ title: 'Change the case limit rule?', icon: 'rule', ok: 'Save',
                message: (oc.total || 0) + ' open case(s) keep the rule they were filed with. Only new cases (filed from now on) will use the ' + (rule.value === 'time' ? 'time-based' : 'hearing-based') + ' rule.' }))) return;
        const btn = document.getElementById('sSave'); btn.disabled = true;
        try {
            const d = await BLT.post('../backend/settings.php', { action:'save', rule_type: rule ? rule.value : '', max_days:document.getElementById('sDays').value, max_hearings:document.getElementById('sHear').value,
                noshow_counts: document.getElementById('sNoShow').checked ? 1 : 0, transfer_destination: dst ? dst.value : '', transfer_destination_other:document.getElementById('sDestOther').value,
                default_hearing_location:document.getElementById('sHall').value, hearing_minutes: document.getElementById('sMin').value, transfer_template_id: document.getElementById('sTplT').value, incident_types:s.incident_types, locations:s.locations });
            if (!d.success) { document.getElementById('sMsg').textContent = d.message; return; }
            BLT.toast(d.message, 'success'); BLT.close('settingsModal'); setTimeout(() => location.reload(), 600);
        } catch (e) { document.getElementById('sMsg').textContent = e.message; }
        finally { btn.disabled = false; }
    }
    ['sTypeNew', 'sLocNew'].forEach(id => document.getElementById(id).addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); add(id === 'sTypeNew' ? 'types' : 'locs'); } }));
    return { open, save, set, del, add };
})();

/* ───────── Masterlist Save PDF / Print (same report layout as the other modules) ───────── */
let _mlMode = 'pdf';
function mlFilterValues(){
    return { q: document.getElementById('q').value.trim(), type: document.getElementById('typeFilter').value, status: document.getElementById('statusFilter').value,
             from: document.getElementById('fromFilter').value, to: document.getElementById('toFilter').value };
}
function openMasterlist(mode){
    _mlMode = mode;
    document.getElementById('mlTitle').textContent = mode === 'pdf' ? 'Save as PDF' : 'Print';
    const r = document.querySelector('input[name="mlTab"][value="' + TAB + '"]') || document.querySelector('input[name="mlTab"][value="all"]'); r.checked = true;
    const f = mlFilterValues(), parts = [];
    if (f.q) parts.push('search "' + f.q + '"'); if (f.type) parts.push(f.type); if (f.status) parts.push(f.status);
    if (f.from || f.to) parts.push('filed ' + (f.from || '…') + ' to ' + (f.to || '…'));
    document.getElementById('mlFilterText').textContent = parts.length ? parts.join(' · ') : 'No filter is set (all cases).';
    BLT.open('mlModal');
}
function continueMasterlist(){
    const tab = (document.querySelector('input[name="mlTab"]:checked') || {}).value || 'all';
    const q = new URLSearchParams(Object.assign({ mode: _mlMode, tab }, document.getElementById('mlFilters').checked ? mlFilterValues() : {}));
    BLT.close('mlModal');
    window.open('../backend/masterlist_report.php?' + q.toString(), '_blank');
}

load();
<?php if (!$db_error && !$configured && $isAdmin && isset($_GET['setup'])): ?>Settings.open();<?php endif; ?>
</script>
</body>
</html>
