<?php
/**
 * Notice Templates — Template Builder for blotter notices (same concept / design as the
 * Certificate Template Builder). The notice type is free: pick one from the drop-down or
 * "Add new notice type" (Summons, Notice of Hearing, Subpoena, … — as many as the barangay uses).
 *   Option A — Upload Template: PDF, Word (DOCX), PNG or JPG. Word is converted to PDF in the browser; EVERY page
 *              of the PDF is kept as a layout page (template_convert.js, max 10). Saved in upload/blotter/templates/ (opacity preview),
 *              then the layout editor: check a field to place it / uncheck to remove it, Add Text boxes,
 *              font, size, bold, italic, underline, alignment, line / letter spacing, zoom in / out.
 *              AI Auto Detect runs by itself on a new form: it checks and places the fields, the admin drags any that are
 *              not aligned. Nothing is saved until "Save Template".
 *   Save Template → preview with sample values + confirmation (with "Use as default") → back to the list.
 *   Disabled templates are listed separately, below the active ones.
 *   Extra information: the admin adds his own fields (e.g. Lupon member assigned, Pangkat chairperson) in the editor; they are typed
 *   in on Case Details → Generate Notice before the notice is made, then printed like any other field.
 *   Option B — Text-based notice, edited like in Word (assets/doc_editor.js): the letter is typed right on the page — move parts up / down,
 *              bold / italic / underline, sizes, tables (add / remove rows, columns), add / remove text, signature and logo size.
 *              (Older text templates — letterhead, date, recipient, subject, case block, body, hearing details —
 *              instructions, signature and signatory — become an editable page when opened.) {{FIELD}} values, font, spacing, preview.
 * Data: ../backend/templates.php, ../backend/template_ai_detect.php.
 */
require_once __DIR__ . '/../../db.php';
$required_module = 'blotter';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../backend/blotter_common.php';

$current_page = 'Blotter';
$pageTitle = 'Notice Templates';
$db_error = '';
try { blt_migrate($pdo); } catch (Throwable $e) { $db_error = 'Database setup failed. Import sql/blotter.sql.'; error_log('[Blotter] ' . $e->getMessage()); }
$canEdit = blt_can($pdo, 'update');
?>
<!doctype html>
<html <?php require_once __DIR__ . '/../../theme_loader.php'; echo $theme_attrs['html'] ?? ''; ?>>
<head>
    <?php require __DIR__ . '/partials/blotter_head.php'; ?>
    <link rel="stylesheet" href="assets/notice_editor.css?v=<?php echo @filemtime(__DIR__ . '/assets/notice_editor.css'); ?>">
    <style>
        .type-card { background:#fff; border-radius:32px; border:1px solid #f1f5f9; box-shadow:0 1px 2px rgba(15,23,42,.05); padding:1rem; display:flex; flex-direction:column; gap:.9rem; transition:transform .2s, box-shadow .2s; }
        .type-card:hover { transform:translateY(-2px); box-shadow:0 16px 36px -14px rgba(15,23,42,.18); }
        .thumb { height:240px; background:#f8fafc; border-radius:1.5rem; overflow:hidden; display:flex; align-items:center; justify-content:center; border:1px solid #f1f5f9; width:100%; }
        .thumb img { width:100%; height:100%; object-fit:cover; object-position:top; }
        .op-preview { background:#fff; border:1px solid #e2e8f0; border-radius:1rem; overflow:hidden; display:flex; align-items:center; justify-content:center; aspect-ratio:210/297; }
        .op-preview img { width:100%; height:100%; object-fit:fill; transition:opacity .1s; }
        .overlay { position:fixed; inset:0; z-index:70; background:#0f172a; display:none; flex-direction:column; }
        .overlay.open { display:flex; }
        #editorHost { flex:1; min-height:0; }
        .drop { border:2px dashed #cbd5e1; border-radius:1.5rem; padding:1.25rem; text-align:center; cursor:pointer; background:#f8fafc; transition:all .15s; display:block; }
        .drop:hover { border-color:var(--accent-400,#818cf8); background:#eef2ff; }
        .tx-wrap { flex:1; min-height:0; display:grid; grid-template-columns:minmax(340px,440px) 1fr; background:#f1f5f9; }
        @media (max-width:1024px) { .tx-wrap { grid-template-columns:1fr; overflow:auto; } }
        .tx-form { background:#fff; overflow:auto; padding:1.25rem; }
        .tx-preview { overflow:auto; padding:1rem 1.5rem 1.5rem; display:flex; flex-direction:column; gap:.6rem; min-height:0; }
        .tx-preview .notice-host { flex:1; min-height:0; }
        .tx-preview { padding:0 !important; } .tx-preview #txZoom { padding:.5rem 1rem 0; }
        #txPreview .de-root { height:100%; }
        .chip { display:inline-flex; padding:.2rem .5rem; border-radius:.5rem; background:#eef2ff; color:var(--accent-700); font-size:10px; font-weight:800; font-family:"DM Mono",monospace; cursor:pointer; border:1px solid #e0e7ff; }
        .chip:hover { background:var(--accent-600); color:#fff; }
        .dis-sec > summary { list-style:none; cursor:pointer; }
        .dis-sec > summary::-webkit-details-marker { display:none; }
        .dis-sec[open] .dis-arrow { transform:rotate(180deg); }
        .dis-sec .type-card { opacity:.85; }
        .tog { display:flex; align-items:center; gap:.4rem; font-size:.75rem; font-weight:700; color:#475569; }
    </style>
</head>
<body <?php echo $theme_attrs['body'] ?? ''; ?>>
<div class="flex min-h-screen">
    <?php require __DIR__ . '/../../sidebar.php'; ?>
    <div class="flex-1 flex flex-col min-w-0 main-wrapper">
        <?php require __DIR__ . '/../../header.php'; ?>
        <main class="p-4 md:p-6 lg:p-8 space-y-8">
            <div class="hero-band rounded-2xl p-6 md:p-8 text-white relative overflow-hidden">
                <div class="absolute -right-12 -top-12 w-64 h-64 opacity-10 rounded-full blur-3xl pointer-events-none" style="background:var(--accent-400);"></div>
                <div class="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                        <h1 class="text-2xl md:text-3xl font-black tracking-tight leading-none">Notice Templates</h1>
                        <p class="text-white/60 text-sm mt-2 font-medium">Summons, Notice of Hearing or any notice your barangay uses — upload the barangay's form or build a text-based notice.</p>
                    </div>
                    <div class="flex flex-wrap gap-3">
                        <a href="incidents.php" class="hero-btn"><span class="material-symbols-outlined">arrow_back</span>Back to Blotter</a>
                        <?php if ($canEdit): ?><button type="button" class="hero-btn hero-btn-primary" onclick="Details.open(0)"><span class="material-symbols-outlined">note_add</span>New Template</button><?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if ($db_error): ?><div class="rounded-2xl border border-rose-200 bg-rose-50 text-rose-700 px-5 py-4 text-sm font-bold"><?php echo h($db_error); ?></div><?php endif; ?>
            <div class="note note-info"><span class="material-symbols-outlined">info</span><span>Generate Notice uses the <strong>Default</strong> template of each notice type. Issued notices keep their own copy, so editing a template never changes a notice already generated.</span></div>
            <div id="grid" class="space-y-8"><p class="text-sm text-slate-400">Loading…</p></div>
        </main>
    </div>
</div>

<!-- Details (new template / replace image / rename) -->
<div id="detailsModal" class="modal-back">
  <div class="modal-box" style="max-width:760px">
    <div class="modal-head"><div><h3 class="modal-title" id="dTitle">New Template</h3><p class="modal-sub">Notice template</p></div>
      <button type="button" class="modal-close" onclick="BLT.close('detailsModal')"><span class="material-symbols-outlined">close</span></button></div>
    <div class="modal-body space-y-4">
      <div class="grid sm:grid-cols-2 gap-4">
        <div><label class="field-label" for="dTypeSel">Notice type *</label>
          <select id="dTypeSel" class="input"></select>
          <input id="dTypeNew" class="input mt-2 hidden" maxlength="100" placeholder="New notice type, e.g. Subpoena"></div>
        <div><label class="field-label" for="dName">Template name *</label><input id="dName" class="input" maxlength="150" placeholder="e.g. KP Form 9"></div>
      </div>
      <div><label class="field-label">Layout *</label><div class="grid sm:grid-cols-2 gap-2">
        <label class="choice"><input type="radio" name="dMode" value="image"><span><span class="block">Upload Template</span><span class="block text-[11px] font-semibold text-slate-500">PDF, Word, PNG or JPG of the barangay's form; AI places the fields on it.</span></span></label>
        <label class="choice"><input type="radio" name="dMode" value="text" checked><span><span class="block">Text-based notice</span><span class="block text-[11px] font-semibold text-slate-500">No image layout — build the letter here.</span></span></label></div></div>
      <div><label class="field-label" for="dPaper">Paper size</label><select id="dPaper" class="input"><?php foreach (blt_paper_sizes() as $k => $ps): ?><option value="<?php echo h($k); ?>"><?php echo h($ps['label']); ?></option><?php endforeach; ?></select></div>
      <div id="dImageWrap" class="grid sm:grid-cols-[1fr_170px] gap-4 items-start">
        <div class="space-y-3">
          <label class="drop" for="dImage"><span class="material-symbols-outlined text-3xl text-slate-400">upload_file</span>
            <p class="text-sm font-bold text-slate-700 mt-1" id="dImageLbl">Choose template file</p><p class="text-[11px] text-slate-400">PDF or Word (DOCX) max 10 MB · PNG / JPG max 5 MB · same proportion as the paper</p>
            <p class="text-[11px] text-slate-400">Word files are converted to PDF first so the AI can read them.</p>
            <p id="dImageName" class="text-[11px] font-bold text-indigo-600 mt-1"></p><input id="dImage" type="file" accept=".pdf,.docx,.png,.jpg,.jpeg,application/pdf,image/png,image/jpeg,application/vnd.openxmlformats-officedocument.wordprocessingml.document" class="hidden"></label>
          <div><label class="field-label" for="dOpacity">Image opacity · <span id="dOpVal">100%</span></label><input id="dOpacity" type="range" min="0.1" max="1" step="0.05" value="1" class="w-full"></div>
        </div>
        <div><p class="field-label">Preview</p><div class="op-preview" id="dThumb"><span class="material-symbols-outlined text-slate-300 text-4xl">image</span></div></div>
      </div>
    </div>
    <div class="modal-foot"><p id="dMsg" class="text-[11px] font-semibold text-rose-600 mr-auto"></p>
      <button type="button" class="btn btn-ghost" onclick="BLT.close('detailsModal')">Cancel</button>
      <button type="button" class="btn btn-dark" id="dSave" onclick="Details.save()">Continue<span class="material-symbols-outlined">arrow_forward</span></button></div>
  </div>
</div>

<!-- Save Template: preview + confirmation -->
<div id="saveModal" class="modal-back" style="z-index:80">
  <div class="modal-box" style="max-width:900px">
    <div class="modal-head"><div><h3 class="modal-title">Save template?</h3><p class="modal-sub" id="svSub">Preview with sample values</p></div>
      <button type="button" class="modal-close" onclick="SaveConfirm.answer(false)"><span class="material-symbols-outlined">close</span></button></div>
    <div class="modal-body space-y-4">
      <div id="svPreview" class="notice-host" style="height:58vh"></div>
      <div class="rounded-2xl border border-slate-100 bg-slate-50 px-4 py-3">
        <label class="tog"><input type="checkbox" id="svDefault"> <span id="svDefaultLbl">Use as the default template for this notice type</span></label>
        <p class="text-[11px] text-slate-500 mt-1 ml-6" id="svDefaultNote">You can change the default anytime with the ★ button on the template card.</p>
      </div>
    </div>
    <div class="modal-foot">
      <button type="button" class="btn btn-ghost" onclick="SaveConfirm.answer(false)"><span class="material-symbols-outlined">arrow_back</span>Back to editing</button>
      <button type="button" class="btn btn-dark" onclick="SaveConfirm.answer(true)"><span class="material-symbols-outlined">check</span>Confirm &amp; Save</button></div>
  </div>
</div>

<!-- Image layout editor -->
<div id="imgOverlay" class="overlay">
  <div class="flex items-center justify-between gap-3 px-5 py-3 hero-band text-white">
    <div class="min-w-0"><p class="text-[10px] font-black uppercase tracking-[0.18em] text-white/60">Template layout · saved only with Save Template</p><p class="font-black truncate" id="edTitle"></p></div>
    <div class="flex items-center gap-2">
      <button type="button" class="hero-btn" onclick="ImgEditor.replace()"><span class="material-symbols-outlined">swap_horiz</span>Replace image / opacity</button>
      <button type="button" class="hero-btn hero-btn-white" onclick="ImgEditor.close()"><span class="material-symbols-outlined">close</span>Close</button>
    </div>
  </div>
  <div id="editorHost"></div>
</div>

<!-- Text-based editor -->
<div id="txtOverlay" class="overlay">
  <div class="flex items-center justify-between gap-3 px-5 py-3 hero-band text-white">
    <div class="min-w-0"><p class="text-[10px] font-black uppercase tracking-[0.18em] text-white/60">Text-based notice</p><p class="font-black truncate" id="txTitle"></p></div>
    <div class="flex items-center gap-2">
      <span id="txStatus" class="text-[11px] text-white/70"></span>
      <span class="flex items-center gap-1 rounded-xl bg-white/10 px-2 py-1 text-xs font-black text-white" title="Pages of the letter"><button type="button" class="hero-btn !px-2" onclick="TxtEditor.pages(-1)" title="Remove the last page"><span class="material-symbols-outlined">remove</span></button><span id="txPages">1 page</span><button type="button" class="hero-btn !px-2" onclick="TxtEditor.pages(1)" title="Add a new page"><span class="material-symbols-outlined">add</span>Page</button></span>
      <button type="button" class="hero-btn" id="txAi" onclick="TxtEditor.aiSample(true)" title="Let the AI write a sample letter for this notice type"><span class="material-symbols-outlined">auto_awesome</span>AI Sample</button>
      <button type="button" class="hero-btn" onclick="TxtEditor.clear()" title="Start from an empty page"><span class="material-symbols-outlined">layers_clear</span>Clear</button>
      <button type="button" class="hero-btn" id="txPrev" onclick="TxtEditor.togglePreview()"><span class="material-symbols-outlined">visibility</span>Preview</button>
      <button type="button" class="hero-btn hero-btn-primary" id="txSave" onclick="TxtEditor.save()"><span class="material-symbols-outlined">save</span>Save Template</button>
      <button type="button" class="hero-btn hero-btn-white" onclick="TxtEditor.close()"><span class="material-symbols-outlined">close</span>Close</button>
    </div>
  </div>
  <div class="tx-wrap">
    <div class="tx-form space-y-4" id="txForm"></div>
    <div class="tx-preview"><div class="flex justify-end" id="txZoom"></div><div id="txPreview" class="notice-host"></div></div>
  </div>
</div>

<script src="assets/notice_render.js?v=<?php echo @filemtime(__DIR__ . '/assets/notice_render.js'); ?>"></script>
<script src="assets/notice_editor.js?v=<?php echo @filemtime(__DIR__ . '/assets/notice_editor.js'); ?>"></script>
<script src="assets/doc_editor.js?v=<?php echo @filemtime(__DIR__ . '/assets/doc_editor.js'); ?>"></script>
<script src="assets/template_convert.js?v=<?php echo @filemtime(__DIR__ . '/assets/template_convert.js'); ?>"></script>
<script>
const API = '../backend/templates.php';
const CAN_EDIT = <?php echo $canEdit ? 'true' : 'false'; ?>;
const esc = BLT.esc;
let LIST = [], TYPES = [], CAT = null;

async function catalog(){ if (!CAT) CAT = await BLT.getJSON(API + '?action=catalog'); return CAT; }
function sampleValues(extras){
    const v = {};
    CAT.groups.forEach(g => g.items.forEach(i => v[i.key] = i.sample));
    (extras || []).forEach(x => v[x.key] = '[' + x.label + ']');   // Extra information: typed in before printing
    v.BARANGAY_LOGO = CAT.barangay.logo_url || '';
    return v;
}

/* ───────── List (grouped by notice type) ───────── */
async function load(){
    const grid = document.getElementById('grid');
    try {
        const d = await BLT.getJSON(API + '?action=list');
        LIST = d.templates || []; TYPES = d.types || [];
        if (!TYPES.length) { grid.innerHTML = '<div class="text-center py-16 bg-white rounded-[32px] border border-slate-100"><span class="material-symbols-outlined text-4xl block mb-2 text-slate-200">draft</span><p class="text-sm text-slate-400">No notice template yet.' + (CAN_EDIT ? ' Click <strong>New Template</strong> and add your first notice type (e.g. Summons).' : '') + '</p></div>'; return; }
        const active = LIST.filter(t => t.is_active), disabled = LIST.filter(t => !t.is_active);
        let html = TYPES.filter(type => active.some(t => t.notice_type === type)).map(type => {
            const items = active.filter(t => t.notice_type === type);
            return '<div><div class="flex items-center gap-3 mb-4"><span class="material-symbols-outlined text-white bg-primary p-2 rounded-xl shadow-md">' + (/summon/i.test(type) ? 'gavel' : 'event_note') + '</span><div><h2 class="text-base font-black text-slate-800 leading-tight">' + esc(type) + '</h2>' +
                '<p class="text-[10px] text-slate-400 font-bold mt-0.5">' + (items.some(t => t.is_default) ? 'Default: ' + esc(items.find(t => t.is_default).name) : 'No default yet — Generate Notice uses the newest usable template') + '</p></div></div>' +
                '<div class="grid sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6">' + items.map(card).join('') + '</div></div>';
        }).join('');
        if (!active.length) html += '<div class="text-center py-10 bg-white rounded-[32px] border border-slate-100"><p class="text-sm text-slate-400">No active template. Enable one below or create a new template.</p></div>';
        if (disabled.length) {
            html += '<details class="dis-sec rounded-[32px] border border-slate-200 bg-slate-50/60 p-5"' + (active.length ? '' : ' open') + '><summary class="flex items-center gap-3">' +
                '<span class="material-symbols-outlined text-slate-500 bg-white border border-slate-200 p-2 rounded-xl">toggle_off</span>' +
                '<div class="flex-1"><h2 class="text-base font-black text-slate-700 leading-tight">Disabled templates <span class="pill bg-slate-100 text-slate-500 border-slate-200 ml-1">' + disabled.length + '</span></h2>' +
                '<p class="text-[10px] text-slate-400 font-bold mt-0.5">Not used by Generate Notice. Enable one to use it again.</p></div>' +
                '<span class="material-symbols-outlined text-slate-400 dis-arrow transition-transform">expand_more</span></summary>' +
                '<div class="grid sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6 mt-5">' + disabled.map(card).join('') + '</div></details>';
        }
        grid.innerHTML = html;
    } catch (e) { grid.innerHTML = '<p class="text-sm text-rose-600 font-semibold">' + esc(e.message) + '</p>'; }
}
function card(t){
    const badges = (t.is_default ? '<span class="pill bg-indigo-50 text-indigo-700 border-indigo-200"><span class="material-symbols-outlined">star</span>Default</span>' : '') +
        (t.is_active ? '<span class="pill bg-emerald-50 text-emerald-700 border-emerald-200">Active</span>' : '<span class="pill bg-slate-100 text-slate-500 border-slate-200">Disabled</span>') +
        (t.mode === 'image' && !t.field_count ? '<span class="pill bg-amber-50 text-amber-700 border-amber-200">No fields yet</span>' : '') +
        (t.extra_count ? '<span class="pill bg-violet-50 text-violet-700 border-violet-200">' + t.extra_count + ' extra info</span>' : '');
    return '<div class="type-card"><button type="button" class="thumb" onclick="openEditor(' + t.id + ')">' +
        (t.bg_image ? '<img src="' + esc(t.bg_image) + '" alt="">' : '<span class="material-symbols-outlined text-5xl text-slate-200">article</span>') + '</button>' +
        '<div class="px-1">' + (!t.is_active ? '<p class="text-[10px] font-black uppercase tracking-wider text-slate-400">' + esc(t.notice_type) + '</p>' : '') + '<p class="text-sm font-bold text-slate-700 truncate">' + esc(t.name) + '</p><p class="text-[10px] text-slate-400 font-bold uppercase tracking-tighter mt-0.5">' + (t.mode === 'image' ? 'Uploaded template' + (t.page_count > 1 ? ' · ' + t.page_count + ' pages' : '') + ' · ' + t.field_count + ' items' : 'Text-based') + ' | ' + esc(t.paper_label) + '</p>' +
        '<div class="flex flex-wrap gap-1 mt-2">' + badges + '<span class="pill bg-slate-50 text-slate-500 border-slate-200">' + t.used + ' generated</span></div></div>' +
        (CAN_EDIT ? '<div class="flex items-center gap-1 mt-auto pt-2 border-t border-slate-50">' +
            '<button class="btn btn-dark btn-sm flex-1" onclick="openEditor(' + t.id + ')"><span class="material-symbols-outlined">dashboard_customize</span>' + (t.mode === 'image' ? 'Layout' : 'Edit') + '</button>' +
            '<button class="icon-btn" title="Details" onclick="Details.open(' + t.id + ')"><span class="material-symbols-outlined text-xl">edit_square</span></button>' +
            (!t.is_default ? '<button class="icon-btn" title="Use as default" onclick="act(\'set_default\',' + t.id + ')"><span class="material-symbols-outlined text-xl">star</span></button>' : '') +
            '<button class="icon-btn" title="' + (t.is_active ? 'Disable' : 'Enable') + '" onclick="act(\'toggle_active\',' + t.id + ',' + (t.is_active ? 0 : 1) + ')"><span class="material-symbols-outlined text-xl">' + (t.is_active ? 'toggle_on' : 'toggle_off') + '</span></button>' +
            '<button class="icon-btn danger" title="Delete" onclick="del(' + t.id + ')"><span class="material-symbols-outlined text-xl">delete</span></button></div>' : '') + '</div>';
}
async function act(action, id, active){
    const d = await BLT.post(API, { action: action, id: id, active: active });
    BLT.toast(d.message, d.success ? 'success' : 'error'); load();
}
async function del(id){
    const t = LIST.find(x => x.id === id);
    const ok = await BLT.confirm({ title: 'Delete "' + t.name + '"?', message: t.used ? 'Notices were already generated with it, so it will be disabled instead.' : 'The template and its image are removed.', ok: 'Delete', danger: true, icon: 'delete' });
    if (ok) act('delete', id);
}
async function openEditor(id){
    if (!CAN_EDIT) return;
    const d = await BLT.getJSON(API + '?action=get&id=' + id);
    if (!d.success) { BLT.toast(d.message, 'error'); return; }
    if (d.template.mode === 'image') ImgEditor.open(d.template, { autoAi: !d.template.positions.length }); else TxtEditor.open(d.template);
}

/* ───────── Save Template: preview + confirmation (+ Use as default) ───────── */
const SaveConfirm = (function(){
    let done = null;
    /** ask(template, render model) → Promise<null (cancelled) | { makeDefault: bool }> */
    function ask(t, model){
        const otherDefault = LIST.some(x => x.notice_type === t.notice_type && x.is_default && x.is_active && x.id !== t.id);
        const box = document.getElementById('svDefault'), lbl = document.getElementById('svDefaultLbl'), note = document.getElementById('svDefaultNote');
        document.getElementById('svSub').textContent = t.notice_type + ' · ' + t.name + ' · sample values';
        if (t.is_default || !otherDefault) {
            box.checked = true; box.disabled = true;
            lbl.textContent = t.is_default ? 'This is the default template for ' + t.notice_type : 'First template of ' + t.notice_type + ' — it becomes the default';
        } else {
            box.checked = false; box.disabled = false;
            lbl.textContent = 'Use as the default template for ' + t.notice_type;
        }
        note.textContent = 'You can change the default anytime with the ★ button on the template card.';
        BLT.open('saveModal');
        const host = document.getElementById('svPreview');
        requestAnimationFrame(() => NoticeRender.into(host, model, { width: Math.min(760, host.clientWidth - 28), noResize: true }));
        return new Promise(res => { done = res; });
    }
    function answer(ok){
        BLT.close('saveModal');
        if (done) { const d = done; done = null; d(ok ? { makeDefault: document.getElementById('svDefault').checked } : null); }
    }
    return { ask, answer };
})();

/* ───────── Details modal (new / edit / replace image) ───────── */
const Details = (function(){
    let cur = null, file = null, pdfFile = null, pageFiles = [], previewUrl = null;
    const NEW = '__new__';
    function mode(){ return (document.querySelector('input[name=dMode]:checked') || {}).value; }
    function type(){ const s = document.getElementById('dTypeSel').value; return s === NEW ? document.getElementById('dTypeNew').value.trim() : s; }
    function sync(){ document.getElementById('dImageWrap').classList.toggle('hidden', mode() !== 'image'); }
    function opacity(){
        const v = document.getElementById('dOpacity').value;
        document.getElementById('dOpVal').textContent = Math.round(v * 100) + '%';
        const img = document.querySelector('#dThumb img'); if (img) img.style.opacity = v;
    }
    function thumb(src){
        document.getElementById('dThumb').innerHTML = src ? '<img src="' + esc(src) + '" alt="">' : '<span class="material-symbols-outlined text-slate-300 text-4xl">image</span>';
        opacity();
    }
    function fillTypes(selected){
        const sel = document.getElementById('dTypeSel');
        const list = TYPES.slice();
        if (selected && !list.includes(selected)) list.push(selected);
        sel.innerHTML = '<option value="">Select notice type</option>' + list.map(t => '<option' + (t === selected ? ' selected' : '') + '>' + esc(t) + '</option>').join('') +
            '<option value="' + NEW + '">+ Add new notice type…</option>';
        if (!list.length) sel.value = NEW;
        typeSync();
    }
    function typeSync(){
        const isNew = document.getElementById('dTypeSel').value === NEW;
        document.getElementById('dTypeNew').classList.toggle('hidden', !isNew);
        if (isNew) document.getElementById('dTypeNew').focus();
    }
    async function open(id){
        await catalog();
        cur = id ? (await BLT.getJSON(API + '?action=get&id=' + id)).template : null; file = null; pdfFile = null; pageFiles = [];
        document.getElementById('dTitle').textContent = cur ? cur.name : 'New Template';
        fillTypes(cur ? cur.notice_type : '');
        document.getElementById('dTypeNew').value = '';
        document.querySelectorAll('input[name=dMode]').forEach(r => { r.checked = r.value === (cur ? cur.mode : 'text'); r.disabled = !!(cur && cur.used); });
        document.getElementById('dName').value = cur ? cur.name : '';
        document.getElementById('dPaper').value = cur ? cur.paper_size : 'a4';
        document.getElementById('dOpacity').value = cur ? cur.bg_opacity : 1;
        document.getElementById('dImage').value = ''; document.getElementById('dImageName').textContent = '';
        document.getElementById('dImageLbl').textContent = cur && cur.bg_image ? 'Replace template file' : 'Choose template file';
        thumb(cur && cur.bg_image ? cur.bg_image : null);
        document.getElementById('dMsg').textContent = '';
        sync(); BLT.open('detailsModal');
    }
    async function save(){
        const t = type();
        if (!t) { document.getElementById('dMsg').textContent = 'Choose the notice type, or add a new one.'; return; }
        if (t.length < 2) { document.getElementById('dMsg').textContent = 'The notice type must be at least 2 characters.'; return; }
        const fd = new FormData();
        fd.append('action', 'save'); fd.append('id', cur ? cur.id : 0);
        fd.append('notice_type', t);
        fd.append('name', document.getElementById('dName').value.trim());
        fd.append('mode', mode());
        fd.append('paper_size', document.getElementById('dPaper').value);
        fd.append('bg_opacity', document.getElementById('dOpacity').value);
        if (mode() === 'text' && cur && cur.text_config) fd.append('text_config', JSON.stringify(cur.text_config)); // new text templates get the default letter
        if (file) fd.append('template_image', file);
        if (file && pdfFile) fd.append('template_pdf', pdfFile);
        if (file) pageFiles.slice(1).forEach(f => fd.append('template_pages[]', f, f.name));   // pages 2… of the form
        if (mode() === 'image' && !file && !(cur && cur.bg_image)) { document.getElementById('dMsg').textContent = 'Upload the template file (PDF, Word, PNG or JPG).'; return; }
        const btn = document.getElementById('dSave'); btn.disabled = true;
        try {
            const d = await BLT.post(API, fd);
            if (!d.success) { document.getElementById('dMsg').textContent = d.message; return; }
            const newForm = !!file, isNew = !cur;
            BLT.close('detailsModal'); await load();
            // A newly uploaded form: AI checks and places the fields right away (the admin adjusts, then saves).
            if (ImgEditor.isOpen()) ImgEditor.reloadImage(d.template, newForm);
            else if (d.template.mode === 'image') ImgEditor.open(d.template, { autoAi: newForm || !d.template.positions.length }); else TxtEditor.open(d.template, { ai: isNew && d.template.mode === 'text' });   // new text template: the AI writes a sample
        } catch (e) { document.getElementById('dMsg').textContent = e.message; }
        finally { btn.disabled = false; }
    }
    document.querySelectorAll('input[name=dMode]').forEach(r => r.addEventListener('change', sync));
    document.getElementById('dTypeSel').addEventListener('change', typeSync);
    document.getElementById('dOpacity').addEventListener('input', opacity);
    document.getElementById('dImage').addEventListener('change', async function(){
        const f = this.files[0]; if (!f) return;
        const msg = document.getElementById('dMsg'), name = document.getElementById('dImageName'), btn = document.getElementById('dSave');
        msg.textContent = ''; file = null; pdfFile = null; pageFiles = [];
        name.textContent = 'Converting ' + f.name + '…'; btn.disabled = true;
        try {
            const r = await TemplateConvert.convert(f);
            file = r.image; pdfFile = r.pdf; pageFiles = r.images || [r.image];
            name.textContent = f.name + (r.note ? ' — ' + r.note : '');
            if (previewUrl) URL.revokeObjectURL(previewUrl);
            previewUrl = URL.createObjectURL(file); thumb(previewUrl);
        } catch (e) { msg.textContent = e.message || 'The file could not be converted.'; name.textContent = ''; this.value = ''; }
        finally { btn.disabled = false; }
    });
    return { open, save };
})();

/* ───────── Image layout editor ───────── */
const ImgEditor = (function(){
    let ed = null, cur = null;
    function mount(t, positions, extras){
        const values = {};
        t.groups.forEach(g => g.items.forEach(i => values[i.key] = i.sample));
        if (ed) ed.destroy();
        ed = NoticeEditor.mount(document.getElementById('editorHost'), {
            paper: t.paper, bg_image: t.bg_image, bg_opacity: t.bg_opacity, pages: t.pages, positions: positions, groups: t.groups, values: values,
            extras: extras || t.extra_fields || [],
            saveLabel: 'Save Template',
            note: 'Sample values are shown. Generated notices use the real case, party, hearing and barangay data. Text boxes may use {{FIELD}} values.',
            onSave: async function(pos, xs){
                const vals = Object.assign({}, values, sampleValues(xs));
                const model = { mode: 'image', paper: cur.paper, bg_image: cur.bg_image, bg_opacity: cur.bg_opacity, pages: cur.pages,
                    fields: pos.map(p => Object.assign({}, p, { value: /^TEXT_\d+$/.test(p.field_key) ? NoticeRender.fillPlain(p.custom_text || '', vals) : (vals[p.field_key] || '') })) };
                const ans = await SaveConfirm.ask(cur, model);
                if (!ans) return false;
                const r = await BLT.post(API, { action: 'save_layout', id: cur.id, positions: pos, extra_fields: xs || [] });
                if (!r.success) throw new Error(r.message);
                if (ans.makeDefault && !r.template.is_default) {
                    const d = await BLT.post(API, { action: 'set_default', id: cur.id });
                    if (!d.success) BLT.toast(d.message, 'error');
                }
                BLT.toast(r.message, 'success');
                setTimeout(() => close(true), 0);   // back to the Notice Templates list
                return true;
            },
            onAiDetect: async function(keys, xs){
                const r = await BLT.post('../backend/template_ai_detect.php', { id: cur.id, keys: keys, extra_fields: xs || [] });
                if (!r.success) throw new Error(r.message);
                return { positions: r.positions };
            },
        });
    }
    function open(t, opts){
        cur = t;
        document.getElementById('edTitle').textContent = t.notice_type + ' · ' + t.name + ' · ' + t.paper.label;
        document.getElementById('imgOverlay').classList.add('open'); document.body.style.overflow = 'hidden';
        mount(t, t.positions);
        if (opts && opts.autoAi && t.bg_image) ed.runAi();
    }
    async function close(force){
        if (force !== true && ed && ed.isDirty()) {
            const ok = await BLT.confirm({ title: 'Leave without saving?', message: 'Your layout changes (including AI suggestions) are not saved yet.', ok: 'Leave', danger: true, icon: 'warning' });
            if (!ok) return;
        }
        if (ed) { ed.destroy(); ed = null; }
        document.getElementById('imgOverlay').classList.remove('open'); document.body.style.overflow = '';
        load();
    }
    function replace(){ Details.open(cur.id); }
    function reloadImage(t, autoAi){
        const keep = ed ? ed.positions() : t.positions, xs = ed ? ed.extras() : t.extra_fields;
        const n = (t.pages || []).length || 1;
        keep.forEach(p => { if ((p.page_no || 1) > n) p.page_no = n; });   // shorter replacement form
        cur = Object.assign({}, t); mount(cur, keep, xs); if (autoAi) ed.runAi();
    }
    return { open, close, replace, reloadImage, isOpen: () => document.getElementById('imgOverlay').classList.contains('open') };
})();

/* ───────── Text-based notice editor (Word-like: edit the letter right on the page) ───────── */
const TxtEditor = (function(){
    // An emptied Word-like letter stays an (empty) letter: '' would mean the older form-based letter,
    // whose default title / body would come back in the preview and on save.
    const EMPTY_DOC = '<p><br></p>';
    const LEGACY_TEXT = ['header_text', 'title', 'recipient', 'subject', 'body', 'instructions', 'signatory_name', 'signatory_title', 'footer'];
    let cur = null, cfg = null, sigFile = null, removeSig = false, dirty = false, zoom = 1, extras = [], doc = null, previewing = false;
    const zbar = NoticeRender.zoomBar(z => { zoom = z; if (previewing) preview(); }, 1);
    document.getElementById('txZoom').appendChild(zbar);
    const sigUrl = () => sigFile ? URL.createObjectURL(sigFile) : (removeSig ? null : cur.signature_url);
    const images = () => ({ SIGNATURE: sigUrl(), BARANGAY_LOGO: CAT.barangay.logo_url || '' });
    function open(t, opt){
        cur = t; cfg = Object.assign({}, t.text_config); sigFile = null; removeSig = false; dirty = false; previewing = false;
        extras = (t.extra_fields || []).map(x => Object.assign({}, x));
        // Older templates (form-based letter) are turned into an editable document once.
        if (!cfg.html) cfg.html = NoticeRender.docFromConfig(cfg, !!t.signature_url);
        document.getElementById('txTitle').textContent = t.notice_type + ' · ' + t.name;
        document.getElementById('txStatus').textContent = '';
        const f = document.getElementById('txForm');
        const sel = (k, opts) => '<select class="input" data-c="' + k + '">' + opts.map(o => '<option value="' + esc(o[0]) + '"' + (String(cfg[k]) === String(o[0]) ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select>';
        f.innerHTML = '<div class="note note-info"><span class="material-symbols-outlined">edit_document</span><span>Edit the letter right on the page, like in Word: type, <strong>Bold / Italic / Underline</strong>, size, alignment, <strong>Table</strong> (add / remove rows, columns). Every part can be placed <strong>anywhere</strong>: hover it and drag the <strong>✥</strong> handle (parts may overlap — use Front / Back), drag <strong>◢</strong> to change its width. <strong>Double-click</strong> an empty spot to type there. <strong>AI Sample</strong> writes a letter for this notice type; <strong>Clear</strong> starts from an empty page.</span></div>' +
            '<div><p class="section-title mb-2">Default text style</p><div class="grid grid-cols-2 gap-3">' +
              '<div><label class="field-label">Font</label>' + sel('font_family', (CAT.fonts || []).map(x => [x, x])) + '</div>' +
              '<div><label class="field-label">Font size</label><input type="number" min="10" max="20" class="input" data-c="font_size" value="' + (cfg.font_size || 14) + '"></div>' +
              '<div><label class="field-label">Line spacing</label><input type="number" min="1" max="3" step="0.05" class="input" data-c="line_height" value="' + (cfg.line_height || 1.55) + '"></div>' +
              '<div><label class="field-label">Paper</label><div class="input bg-slate-100 text-slate-500">' + esc(t.paper.label) + '</div></div>' +
            '</div></div>' +
            '<div><p class="section-title mb-2">Dynamic fields · click to insert at the cursor</p><div class="flex flex-wrap gap-1">' + t.groups.filter(g => !g.extra).map(g => g.items.filter(i => !i.image).map(i => '<span class="chip" title="' + esc(i.label) + '" data-k="' + esc(i.key) + '">{{' + esc(i.key) + '}}</span>').join('')).join('') + '</div></div>' +
            '<div><p class="section-title mb-1">Extra information · typed in before printing</p><p class="text-[11px] text-slate-400 mb-2">Add your own fields (e.g. Lupon member assigned). Click one to insert it in the letter.</p>' +
              '<div class="flex gap-2"><input class="input" id="txExtraLabel" maxlength="100" placeholder="e.g. Lupon member assigned"><button type="button" class="btn btn-ghost btn-sm" id="txExtraAdd"><span class="material-symbols-outlined">add</span>Add</button></div>' +
              '<div class="flex flex-wrap gap-1 mt-2" id="txExtras"></div></div>' +
            '<div><label class="field-label">Signature image (optional, PNG/JPG)</label><div class="flex items-center gap-2"><input type="file" id="sigFile" accept="image/png,image/jpeg" class="text-xs flex-1">' +
            '<button type="button" class="btn btn-ghost btn-sm" id="sigRemove"><span class="material-symbols-outlined">delete</span>Remove</button></div><p class="text-[11px] text-slate-400 mt-1">Put it on the letter with <strong>Sign.</strong> in the toolbar, then drag the size slider.</p></div>' +
            '<div><button type="button" class="btn btn-ghost btn-sm" id="txReset"><span class="material-symbols-outlined">restart_alt</span>Start over from the default letter</button></div>';
        f.querySelectorAll('[data-c]').forEach(i => i.addEventListener(i.tagName === 'SELECT' ? 'change' : 'input', () => {
            cfg[i.dataset.c] = ['font_size', 'line_height'].includes(i.dataset.c) ? Number(i.value) : i.value;
            if (doc) doc.setFont({ family: cfg.font_family, size: cfg.font_size, line_height: cfg.line_height }); changed();
        }));
        const drawExtras = () => {
            const box = f.querySelector('#txExtras');
            box.innerHTML = extras.map(x => '<span class="chip" data-x="' + esc(x.key) + '" title="{{' + esc(x.key) + '}}">' + esc(x.label) + ' <span data-xdel="' + esc(x.key) + '" title="Delete">✕</span></span>').join('') || '<span class="text-[11px] text-slate-400">None yet.</span>';
            box.querySelectorAll('[data-x]').forEach(c => c.addEventListener('mousedown', e => {
                e.preventDefault();
                if (e.target.dataset.xdel) { extras = extras.filter(x => x.key !== e.target.dataset.xdel); drawExtras(); changed(); return; }
                if (doc) doc.insertToken(c.dataset.x);
            }));
        };
        const addExtra = () => {
            const inp = f.querySelector('#txExtraLabel'), label = inp.value.trim().replace(/\s+/g, ' ');
            if (!label) { inp.focus(); return; }
            if (extras.some(x => x.label.toLowerCase() === label.toLowerCase())) { BLT.toast('"' + label + '" is already in the list.', 'error'); return; }
            let n = 1; while (extras.some(x => x.key === 'EXTRA_' + n)) n++;
            extras.push({ key: 'EXTRA_' + n, label: label }); inp.value = '';
            drawExtras(); if (doc) doc.insertToken('EXTRA_' + n); changed();
        };
        f.querySelector('#txExtraAdd').addEventListener('click', addExtra);
        f.querySelector('#txExtraLabel').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addExtra(); } });
        drawExtras();
        f.querySelectorAll('.chip[data-k]').forEach(c => c.addEventListener('mousedown', e => { e.preventDefault(); if (doc) doc.insertToken(c.dataset.k); }));
        f.querySelector('#sigFile').addEventListener('change', function(){ const x = this.files[0]; if (x && (x.size > 5 * 1048576 || !/^image\/(png|jpeg)$/.test(x.type))) { BLT.toast('Use a PNG or JPG up to 5 MB.', 'error'); this.value = ''; return; } sigFile = x || null; removeSig = false; if (doc) doc.setImages(images()); changed(); });
        f.querySelector('#sigRemove').addEventListener('click', () => { sigFile = null; removeSig = true; f.querySelector('#sigFile').value = ''; if (doc) doc.setImages(images()); changed(); });
        f.querySelector('#txReset').addEventListener('click', async () => {
            if (!(await BLT.confirm({ title: 'Start over?', message: 'The letter goes back to the default text of a ' + cur.notice_type + '. Your edits on the page are removed.', ok: 'Start over', danger: true, icon: 'restart_alt' }))) return;
            const d = await BLT.getJSON(API + '?action=default_text&notice_type=' + encodeURIComponent(cur.notice_type)).catch(() => null);
            cfg.html = NoticeRender.docFromConfig(Object.assign({}, cfg, (d && d.text_config) || {}), !!sigUrl()); mountDoc(); changed();
        });
        document.getElementById('txtOverlay').classList.add('open'); document.body.style.overflow = 'hidden';
        mountDoc();
        if (opt && opt.ai) aiSample(false);
    }
    /** The AI writes a sample letter for this notice type (e.g. "For Transfer" → endorsement to the receiving office). Nothing is saved. */
    /** English or Tagalog letter? → 'en' | 'tl' | null (cancelled). The last choice is remembered. */
    function pickLang(replace){
        return new Promise(resolve => {
            let last = 'en'; try { last = localStorage.getItem('blt_ai_lang') || 'en'; } catch (e) {}
            const back = document.createElement('div');
            back.className = 'modal-back open'; back.style.zIndex = 96;
            back.innerHTML = '<div class="bg-white rounded-[2rem] shadow-2xl w-full p-7 space-y-4" style="max-width:30rem">' +
                '<div class="flex items-start gap-3"><div class="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 bg-indigo-50 text-indigo-500"><span class="material-symbols-outlined">auto_awesome</span></div>' +
                '<div><h3 class="text-base font-black text-slate-800">AI Sample · ' + esc(cur.notice_type) + '</h3><p class="text-xs text-slate-500 mt-1">' + (replace ? 'The letter on the page is replaced by the AI sample. ' : '') + 'You can still edit everything before saving.</p></div></div>' +
                '<p class="field-label">Language of the letter</p><div class="grid grid-cols-2 gap-2">' +
                [['en', 'English'], ['tl', 'Tagalog']].map(o => '<label class="choice"><input type="radio" name="aiLang" value="' + o[0] + '"' + (o[0] === last ? ' checked' : '') + '><span>' + o[1] + '</span></label>').join('') + '</div>' +
                '<div class="flex gap-3 pt-1"><button type="button" class="flex-1 py-3 text-xs font-black uppercase text-slate-400 border border-slate-200 rounded-2xl" data-r="0">' + (replace ? 'Cancel' : 'Skip') + '</button>' +
                '<button type="button" class="flex-[2] py-3 text-white text-xs font-black uppercase rounded-2xl bg-primary" data-r="1">Write sample</button></div></div>';
            document.body.appendChild(back);
            back.addEventListener('click', e => { const b = e.target.closest('[data-r]'); if (!b) return;
                const v = b.dataset.r === '1' ? (back.querySelector('input[name=aiLang]:checked') || {}).value || 'en' : null;
                if (v) { try { localStorage.setItem('blt_ai_lang', v); } catch (x) {} }
                back.remove(); resolve(v); });
        });
    }
    async function aiSample(ask){
        if (!cur) return;
        const lang = await pickLang(ask);
        if (!lang) return;
        if (previewing) mountDoc();
        const btn = document.getElementById('txAi'), st = document.getElementById('txStatus');
        btn.disabled = true; st.textContent = 'AI is writing a sample ' + cur.notice_type + ' letter in ' + (lang === 'tl' ? 'Tagalog' : 'English') + '…';
        try {
            const d = await BLT.post('../backend/template_ai_generate.php', { notice_type: cur.notice_type, name: cur.name, extra_fields: extras, lang: lang, pages: cfg.pages || 1 });
            if (!d.success) { BLT.toast(d.message, 'error'); st.textContent = ''; return; }
            await doc.setHtml(d.html);
            // Parts cut by the end of a page go to the next page; pages are added when the AI letter is longer.
            const before = cfg.pages || 1; cfg.pages = doc.paginate(); cfg.html = doc.html(); showPages(); changed();
            if (cfg.pages > before) BLT.toast('The AI letter needed ' + cfg.pages + ' pages — a page was added.', 'success');
            setTimeout(() => { st.textContent = 'AI sample ready — move, edit or clear anything, then Save.'; }, 500);
        } catch (e) { BLT.toast(e.message, 'error'); st.textContent = ''; }
        finally { btn.disabled = false; }
    }
    /** Fresh canvas: an empty page (double-click anywhere or use Text / Table to add parts). */
    async function clear(){
        if (!cur || !(await BLT.confirm({ title: 'Clear the page?', message: 'Everything on the letter is removed so you can start from an empty page. (Not saved until you click Save Template.)', ok: 'Clear', danger: true, icon: 'layers_clear' }))) return;
        if (previewing) mountDoc();
        doc.clear(); cfg.html = EMPTY_DOC;
        // Nothing of the old letter may come back in the preview or on save.
        LEGACY_TEXT.forEach(k => { cfg[k] = ''; });
        Object.keys(cfg).forEach(k => { if (k.startsWith('show_')) cfg[k] = 0; });
        changed();
        setTimeout(() => { document.getElementById('txStatus').textContent = 'Empty page — double-click anywhere to type, or use Text / Table / Sign.'; }, 500);
    }
    function mountDoc(){
        const host = document.getElementById('txPreview');
        if (doc) doc.destroy();
        previewing = false; document.getElementById('txPrev').innerHTML = '<span class="material-symbols-outlined">visibility</span>Preview';
        document.getElementById('txZoom').style.visibility = 'hidden';
        doc = DocEditor.mount(host, { html: cfg.html, paper: cur.paper, pages: cfg.pages || 1, font: { family: cfg.font_family, size: cfg.font_size, line_height: cfg.line_height }, images: images(),
            onChange: h => { cfg.html = h || EMPTY_DOC; cfg.pages = doc ? doc.pages() : cfg.pages; showPages(); changed(); } });
        showPages();
    }
    function showPages(){ const n = cfg.pages || 1; document.getElementById('txPages').textContent = n + ' page' + (n > 1 ? 's' : ''); }
    /** Add a new page (+1) or remove the last one (−1) — up to 5 pages. */
    function pages(d){
        if (!cur) return;
        if (previewing) mountDoc();
        const n = (cfg.pages || 1) + d;
        if (n < 1 || n > 5) { BLT.toast(n < 1 ? 'The letter has at least one page.' : 'At most 5 pages.', 'error'); return; }
        if (!doc.setPages(n)) { BLT.toast('Move or remove the parts on page ' + (cfg.pages || 1) + ' first, then remove the page.', 'error'); return; }
        cfg.pages = n; showPages(); changed();
    }
    function changed(){ dirty = true; document.getElementById('txStatus').textContent = 'Not saved'; }
    function model(){ if (doc && !previewing) cfg.html = doc.html() || EMPTY_DOC; return { mode: 'text', paper: cur.paper, config: cfg, values: sampleValues(extras), signature_url: sigUrl() }; }
    function preview(){
        const host = document.getElementById('txPreview');
        NoticeRender.into(host, model(), { width: Math.min(820, host.clientWidth - 28), zoom: zoom, noResize: true });
    }
    /** Preview with sample values ⇄ back to editing. */
    function togglePreview(){
        if (!cur) return;
        if (!previewing) { const m = model(); if (doc) { doc.destroy(); doc = null; } previewing = true; document.getElementById('txZoom').style.visibility = '';
            document.getElementById('txPrev').innerHTML = '<span class="material-symbols-outlined">edit</span>Back to editing'; preview(); }
        else mountDoc();
    }
    async function save(){
        const m = model();
        const ans = await SaveConfirm.ask(cur, m);
        if (!ans) return;
        const fd = new FormData();
        fd.append('action', 'save'); fd.append('id', cur.id); fd.append('notice_type', cur.notice_type); fd.append('name', cur.name); fd.append('mode', 'text');
        fd.append('paper_size', cur.paper_size); fd.append('text_config', JSON.stringify(cfg)); fd.append('extra_fields', JSON.stringify(extras));
        if (cur.is_default || ans.makeDefault) fd.append('is_default', '1');
        if (sigFile) fd.append('signature_image', sigFile);
        if (removeSig) fd.append('remove_signature', '1');
        const btn = document.getElementById('txSave'); btn.disabled = true;
        try {
            const d = await BLT.post(API, fd);
            if (!d.success) { BLT.toast(d.message, 'error'); return; }
            dirty = false; BLT.toast(d.message, 'success');
            close();   // back to the Notice Templates list
        } catch (e) { BLT.toast(e.message, 'error'); }
        finally { btn.disabled = false; }
    }
    async function close(){
        if (dirty && !(await BLT.confirm({ title: 'Leave without saving?', message: 'Your changes are not saved yet.', ok: 'Leave', danger: true, icon: 'warning' }))) return;
        if (doc) { doc.destroy(); doc = null; }
        document.getElementById('txtOverlay').classList.remove('open'); document.body.style.overflow = '';
        load();
    }
    window.addEventListener('resize', () => { if (previewing && document.getElementById('txtOverlay').classList.contains('open')) preview(); });
    return { open, save, close, togglePreview, aiSample, clear, pages };
})();

catalog().then(load);
</script>
</body>
</html>
