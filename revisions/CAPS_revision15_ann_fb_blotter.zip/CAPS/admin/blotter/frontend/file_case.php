<?php
/**
 * File New Case — 3 steps:
 *   1 Complainant & Respondent (existing resident / non-resident; a resident picked on one side is not listed on the other)
 *   2 Incident (date + time — never in the future, type with "Other" (typed), location with "Other", description with name
 *     type-ahead (complainant / respondent / location — Tab), evidence files (optional)
 *   3 Review → File Case (saves everything, generates the Blotter ID, opens Case Details)
 */
require_once __DIR__ . '/../../db.php';
$required_module = 'blotter';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../backend/blotter_common.php';

$current_page = 'Blotter';
$pageTitle = 'File New Case';
$db_error = '';
try { blt_migrate($pdo); } catch (Throwable $e) { $db_error = 'Database setup failed. Import sql/blotter.sql.'; error_log('[Blotter] ' . $e->getMessage()); }
if (!blt_can($pdo, 'create')) { header('Location: incidents.php'); exit; }
// No case can be filed until the Blotter Settings have been configured.
if (!$db_error && !blt_settings_configured($pdo)) { header('Location: incidents.php?setup=1'); exit; }
?>
<!doctype html>
<html <?php require_once __DIR__ . '/../../theme_loader.php'; echo $theme_attrs['html'] ?? ''; ?>>
<head>
    <?php require __DIR__ . '/partials/blotter_head.php'; ?>
    <link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
    <style>
        .ev-row { display:grid; grid-template-columns:1fr 1fr auto; gap:.75rem; align-items:center; padding:.75rem; border:1px solid #f1f5f9; border-radius:1rem; background:#f8fafc; }
        @media (max-width:640px) { .ev-row { grid-template-columns:1fr; } }
        .ev-row input[type=file] { font-size:.8rem; }
        .rv-table td:first-child { width:170px; color:#94a3b8; font-size:10px; font-weight:800; text-transform:uppercase; letter-spacing:.06em; }
        /* Incident description type-ahead */
        .da-box.hidden { display:none !important; }
        .da-box { position:fixed; z-index:95; background:#fff; border:1px solid #e2e8f0; border-radius:.9rem; box-shadow:0 16px 36px -12px rgba(15,23,42,.25); padding:.35rem; }
        .da-item { display:flex; width:100%; align-items:center; justify-content:space-between; gap:.75rem; padding:.45rem .65rem; border-radius:.6rem; font-size:.8rem; font-weight:700; color:#1e293b; text-align:left; }
        .da-item.on, .da-item:hover { background:#eef2ff; color:#3730a3; }
        .da-role { font-size:.6rem; font-weight:800; text-transform:uppercase; letter-spacing:.08em; color:#94a3b8; }
        .da-hint { font-size:.62rem; color:#94a3b8; padding:.3rem .65rem 0; }
    </style>
</head>
<body <?php echo $theme_attrs['body'] ?? ''; ?>>
<div class="flex min-h-screen">
    <?php require __DIR__ . '/../../sidebar.php'; ?>
    <div class="flex-1 flex flex-col min-w-0 main-wrapper">
        <?php require __DIR__ . '/../../header.php'; ?>
        <main class="p-4 md:p-6 lg:p-8 space-y-6">
            <div class="hero-band rounded-2xl p-6 md:p-8 text-white relative overflow-hidden">
                <div class="absolute -right-12 -top-12 w-64 h-64 opacity-10 rounded-full blur-3xl pointer-events-none" style="background:var(--accent-400);"></div>
                <div class="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                        <h1 class="text-2xl md:text-3xl font-black tracking-tight leading-none">File New Case</h1>
                        <p class="text-white/60 text-sm mt-2 font-medium">The Blotter ID (BLO-<?php echo date('Y'); ?>-####) is generated when the case is filed.</p>
                    </div>
                    <a href="incidents.php" class="hero-btn"><span class="material-symbols-outlined">arrow_back</span>Back to Blotter</a>
                </div>
            </div>
            <?php if ($db_error): ?><div class="rounded-2xl border border-rose-200 bg-rose-50 text-rose-700 px-5 py-4 text-sm font-bold"><?php echo h($db_error); ?></div><?php endif; ?>

            <div class="card p-5 md:p-7">
                <div class="steps" id="steps"></div>
            </div>

            <!-- Step 1 -->
            <section data-step="1" class="space-y-6">
                <div class="card p-5 md:p-7 space-y-4">
                    <div class="flex items-center justify-between gap-3"><div class="sec-head !mb-0"><span class="material-symbols-outlined">person</span><h4>Complainant</h4></div>
                        <button type="button" class="btn btn-ghost btn-sm" onclick="Parties.add('Complainant')"><span class="material-symbols-outlined">add</span>Add another complainant</button></div>
                    <div id="compList" class="space-y-4"></div>
                </div>
                <div class="card p-5 md:p-7 space-y-4">
                    <div class="flex items-center justify-between gap-3"><div class="sec-head !mb-0"><span class="material-symbols-outlined">person_alert</span><h4>Respondent</h4></div>
                        <button type="button" class="btn btn-ghost btn-sm" onclick="Parties.add('Respondent')"><span class="material-symbols-outlined">add</span>Add another respondent</button></div>
                    <div id="respList" class="space-y-4"></div>
                </div>
            </section>

            <!-- Step 2 -->
            <section data-step="2" class="space-y-6 hidden">
                <div class="card p-5 md:p-7 space-y-4">
                    <div class="sec-head"><span class="material-symbols-outlined">report</span><h4>Incident</h4></div>
                    <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div><label class="field-label" for="iDate">Incident date *</label><input type="date" id="iDate" class="input" max="<?php echo date('Y-m-d'); ?>"></div>
                        <div><label class="field-label" for="iTime">Incident time *</label><input type="time" id="iTime" class="input"></div>
                        <div class="lg:col-span-2"><label class="field-label" for="iType">Incident type / category *</label><select id="iType" class="input"><option value="">Select type</option></select>
                            <div id="iTypeOtherWrap" class="hidden mt-2"><label class="field-label" for="iTypeOther">Specify the incident type / category *</label><input id="iTypeOther" class="input" maxlength="150" placeholder="e.g. Vandalism, Illegal parking"></div></div>
                    </div>
                    <p id="dtErr" class="field-error hidden"></p>
                    <div class="grid sm:grid-cols-2 gap-4">
                        <div><label class="field-label" for="iLoc">Incident location *</label><select id="iLoc" class="input"><option value="">Select location</option></select></div>
                        <div id="iLocOtherWrap" class="hidden"><label class="field-label" for="iLocOther">Other location *</label><input id="iLocOther" class="input" maxlength="255" placeholder="Type the exact place"></div>
                    </div>
                    <div><label class="field-label" for="iDesc">Incident description *</label><textarea id="iDesc" class="input" rows="6" maxlength="10000" placeholder="What happened, who was involved, injuries / damage, witnesses…"></textarea>
                        <p class="text-[11px] text-slate-400 mt-1 ml-1"><span id="iDescN">0</span> characters (at least 10) · type the first letters of a complainant / respondent name or the location, then press <kbd class="font-mono font-bold">Tab</kbd> to complete it</p></div>
                </div>
                <div class="card p-5 md:p-7 space-y-4">
                    <div class="sec-head"><span class="material-symbols-outlined">attach_file</span><h4>Evidence <span class="text-[11px] font-semibold text-slate-400 normal-case tracking-normal">(optional — can also be added later in Case Details)</span></h4></div>
                    <p class="text-[11px] text-slate-400">Photos, documents, videos or audio · up to <span id="maxMb">10</span> MB each · at least one file.</p>
                    <div id="evList" class="space-y-2"></div>
                    <div class="flex flex-wrap gap-2">
                        <button type="button" class="btn btn-ghost" id="evAddFirst" onclick="Evidence.add()"><span class="material-symbols-outlined">attach_file</span>Add Attachment</button>
                        <button type="button" class="btn btn-ghost hidden" id="evAddMore" onclick="Evidence.add()"><span class="material-symbols-outlined">add</span>Add Another</button>
                    </div>
                </div>
            </section>

            <!-- Step 3 -->
            <section data-step="3" class="space-y-6 hidden">
                <div class="note note-info"><span class="material-symbols-outlined">fact_check</span><span>Check everything below. Use <strong>Edit</strong> to go back to a step. Nothing is saved until you click <strong>File Case</strong>.</span></div>
                <div id="review" class="space-y-6"></div>
            </section>

            <div class="card p-5 flex flex-wrap items-center gap-3">
                <p id="msg" class="text-xs font-semibold text-rose-600 mr-auto whitespace-pre-line"></p>
                <button type="button" class="btn btn-ghost" id="bBack" onclick="Wizard.back()"><span class="material-symbols-outlined">arrow_back</span>Back</button>
                <button type="button" class="btn btn-dark" id="bNext" onclick="Wizard.next()">Next<span class="material-symbols-outlined">arrow_forward</span></button>
                <button type="button" class="btn btn-green hidden" id="bFile" onclick="Wizard.file()"><span class="material-symbols-outlined">gavel</span>File Case</button>
            </div>
        </main>
    </div>
</div>

<script src="assets/blotter_party.js?v=<?php echo @filemtime(__DIR__ . '/assets/blotter_party.js'); ?>"></script>
<script>
const API = '../backend/blotter_cases.php';
const esc = BLT.esc;
let OPT = null;

/* ───────── Parties (step 1) ───────── */
const Parties = (function(){
    const list = { Complainant: [], Respondent: [] };
    function add(role){
        if (list[role].length >= 10) return;
        const wrap = document.createElement('div');
        wrap.className = 'party-card';
        const n = list[role].length + 1;
        wrap.innerHTML = '<div class="flex items-center justify-between mb-3"><p class="text-xs font-black uppercase tracking-widest text-slate-500">' + role + ' ' + (n > 1 ? n : '') + '</p>' +
            (n > 1 ? '<button type="button" class="icon-btn danger" title="Remove"><span class="material-symbols-outlined">close</span></button>' : '') + '</div><div></div>';
        document.getElementById(role === 'Complainant' ? 'compList' : 'respList').appendChild(wrap);
        const item = { wrap: wrap, form: null };
        // Residents already picked in the other forms (either side) are not offered again.
        const exclude = () => ['Complainant', 'Respondent'].flatMap(r => list[r]).filter(it => it !== item && it.form).map(it => it.form.residentId()).filter(Boolean);
        const form = BLTParty.mount(wrap.lastElementChild, { role: role, api: API, defaults: OPT ? OPT.barangay : {}, exclude: exclude });
        item.form = form;
        list[role].push(item);
        const x = wrap.querySelector('.icon-btn');
        if (x) x.addEventListener('click', () => { form.destroy(); wrap.remove(); list[role].splice(list[role].indexOf(item), 1); relabel(role); });
    }
    function relabel(role){ list[role].forEach((it, i) => it.wrap.querySelector('p').textContent = role + (list[role].length > 1 ? ' ' + (i + 1) : '')); }
    function validate(){
        const e = [];
        ['Complainant', 'Respondent'].forEach(role => list[role].forEach((it, i) => it.form.validate().forEach(m => e.push(role + (list[role].length > 1 ? ' ' + (i + 1) : '') + ': ' + m))));
        const ids = [];
        ['Complainant', 'Respondent'].forEach(role => list[role].forEach(it => { const o = it.form.get(); if (o.party_type === 'Resident' && o.resident_id) ids.push(o.resident_id); }));
        if (new Set(ids).size !== ids.length) e.push('The same resident is listed more than once.');
        return e;
    }
    function get(role){ return list[role].map(it => it.form.get()); }
    function summary(role){ return list[role].map(it => it.form.summary()); }
    /** [{text, role}] — every complainant / respondent name (for the description type-ahead). */
    function names(){ const out = []; ['Complainant', 'Respondent'].forEach(role => list[role].forEach(it => it.form.names().forEach(n => out.push({ text: n, role: role })))); return out; }
    return { add, validate, get, summary, names };
})();

/* ───────── Evidence (step 2) ───────── */
const Evidence = (function(){
    const rows = [];
    const extOk = ['jpg','jpeg','png','gif','webp','pdf','doc','docx','xls','xlsx','txt','mp4','webm','mov','mp3','m4a','wav'];
    function add(){
        if (rows.length >= 20) return;
        const div = document.createElement('div');
        div.className = 'ev-row';
        div.innerHTML = '<input type="file" accept="<?php echo h(blt_evidence_accept()); ?>">' +
            '<input class="input !py-2" maxlength="255" placeholder="Short description (optional)">' +
            '<button type="button" class="icon-btn danger" title="Remove"><span class="material-symbols-outlined">delete</span></button>' +
            '<p class="field-error hidden sm:col-span-3"></p>';
        const row = { div: div, file: null };
        div.querySelector('input[type=file]').addEventListener('change', function(){
            const f = this.files[0], err = div.querySelector('.field-error');
            row.file = null; err.classList.add('hidden');
            if (!f) return;
            const ext = (f.name.split('.').pop() || '').toLowerCase();
            const maxB = (OPT ? OPT.max_upload_mb : 10) * 1048576;
            let m = '';
            if (!extOk.includes(ext) && !(OPT && OPT.evidence_types.includes(f.type))) m = 'This file type is not allowed.';
            else if (f.size > maxB) m = 'The file is larger than ' + (OPT ? OPT.max_upload_mb : 10) + ' MB.';
            else if (!f.size) m = 'The file is empty.';
            if (m) { err.textContent = m; err.classList.remove('hidden'); this.value = ''; return; }
            row.file = f;
        });
        div.querySelector('.icon-btn').addEventListener('click', () => { div.remove(); rows.splice(rows.indexOf(row), 1); buttons(); });
        rows.push(row);
        document.getElementById('evList').appendChild(div);
        buttons();
    }
    function buttons(){
        document.getElementById('evAddFirst').classList.toggle('hidden', rows.length > 0);
        document.getElementById('evAddMore').classList.toggle('hidden', rows.length === 0 || rows.length >= 20);
    }
    function files(){ return rows.filter(r => r.file).map(r => ({ file: r.file, desc: r.div.querySelector('input.input').value.trim() })); }
    return { add, files };
})();

/* ───────── Incident (step 2) ───────── */
function nowParts(){ const d = new Date(); const p = n => String(n).padStart(2, '0'); return { date: d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()), time: p(d.getHours()) + ':' + p(d.getMinutes()) }; }
function dtError(){
    const d = document.getElementById('iDate').value, t = document.getElementById('iTime').value, now = nowParts();
    if (!d) return 'Enter the incident date.';
    if (!t) return 'Enter the incident time.';
    if (d > now.date) return 'Incident date cannot be in the future.';
    if (d === now.date && t > now.time) return 'Incident time cannot be later than the current time (' + new Date().toLocaleTimeString([], { hour:'numeric', minute:'2-digit' }) + ').';
    return '';
}
function showDt(){
    const e = (document.getElementById('iDate').value && document.getElementById('iTime').value) ? dtError() : '';
    const el = document.getElementById('dtErr'); el.textContent = e; el.classList.toggle('hidden', !e);
    document.getElementById('iTime').classList.toggle('is-invalid', !!e);
    // Today: the time picker cannot go past the current time.
    document.getElementById('iTime').max = document.getElementById('iDate').value === nowParts().date ? nowParts().time : '';
}
['iDate', 'iTime'].forEach(id => document.getElementById(id).addEventListener('input', showDt));
document.getElementById('iLoc').addEventListener('change', function(){
    const other = this.value === 'Other';
    document.getElementById('iLocOtherWrap').classList.toggle('hidden', !other);
    if (other) document.getElementById('iLocOther').focus();
});
document.getElementById('iType').addEventListener('change', function(){
    const other = this.value === 'Other';
    document.getElementById('iTypeOtherWrap').classList.toggle('hidden', !other);
    if (other) document.getElementById('iTypeOther').focus();
});
document.getElementById('iDesc').addEventListener('input', function(){ document.getElementById('iDescN').textContent = this.value.trim().length; });

/* ───────── Incident description type-ahead: party names + location, Tab to complete ───────── */
const DescAssist = (function(){
    const ta = document.getElementById('iDesc');
    // The list floats over the page (fixed), right under the textarea (or above it near the bottom of the
    // window), so no card / scroll area can hide it.
    const box = document.createElement('div');
    box.className = 'da-box hidden';
    document.body.appendChild(box);
    function place(){
        const r = ta.getBoundingClientRect(), h = box.offsetHeight || 220;
        const below = r.bottom + 6 + h < window.innerHeight;
        box.style.left = Math.max(8, r.left) + 'px';
        box.style.width = Math.min(460, r.width) + 'px';
        box.style.top = (below ? r.bottom + 6 : Math.max(8, r.top - h - 6)) + 'px';
    }
    window.addEventListener('scroll', () => { if (!box.classList.contains('hidden')) place(); }, true);
    window.addEventListener('resize', () => { if (!box.classList.contains('hidden')) place(); });
    let items = [], idx = 0, range = null;
    function candidates(){
        const list = Parties.names();
        const i = incident();
        const loc = i.location_option === 'Other' ? i.location_other : i.location_option;
        if (loc) list.push({ text: loc, role: 'Location' });
        const seen = {};
        return list.filter(c => c.text && !seen[c.text.toLowerCase()] && (seen[c.text.toLowerCase()] = 1));
    }
    /** The words typed just before the cursor that match the start of a name (1–4 words, at least 2 letters). */
    function find(){
        const pos = ta.selectionStart;
        if (pos !== ta.selectionEnd) return null;
        const before = ta.value.slice(0, pos);
        const words = before.match(/(\S+\s*){1,4}$/);
        if (!words) return null;
        const cands = candidates();
        const tail = words[0];
        // Try the longest run of words first ("juan dela c" → "Juan Dela Cruz"), then shorter.
        const parts = tail.split(/(?=\s\S)/);
        for (let k = 0; k < parts.length; k++) {
            const q = parts.slice(k).join('').replace(/^\s+/, '');
            if (q.length < 2 || /\s$/.test(before)) continue;
            const ql = q.toLowerCase();
            const hits = cands.filter(c => {
                const t = c.text.toLowerCase();
                if (t === ql) return false;
                return t.startsWith(ql) || t.split(/\s+/).some(w => w.startsWith(ql) && !ql.includes(' '));
            });
            if (hits.length) return { hits: hits.slice(0, 6), start: pos - q.length, end: pos };
        }
        return null;
    }
    function show(){
        const f = find();
        if (!f) { hide(); return; }
        items = f.hits; range = [f.start, f.end]; idx = Math.min(idx, items.length - 1);
        box.innerHTML = items.map((c, i) => '<button type="button" class="da-item' + (i === idx ? ' on' : '') + '" data-i="' + i + '"><span>' + esc(c.text) + '</span><span class="da-role">' + esc(c.role) + '</span></button>').join('') +
            '<p class="da-hint">Tab to insert · ↑ ↓ to choose · Esc to close</p>';
        box.classList.remove('hidden');
        place();
    }
    function hide(){ box.classList.add('hidden'); items = []; idx = 0; }
    function accept(i){
        const c = items[i]; if (!c) return;
        const v = ta.value, after = v.slice(range[1]);
        const ins = c.text + (/^[\s.,;:!?)]/.test(after) ? '' : ' ');
        ta.value = v.slice(0, range[0]) + ins + after;
        const p = range[0] + ins.length;
        ta.selectionStart = ta.selectionEnd = p;
        hide(); ta.dispatchEvent(new Event('input'));
    }
    ta.addEventListener('keydown', e => {
        if (box.classList.contains('hidden') || !items.length) return;
        if (e.key === 'Tab') { e.preventDefault(); accept(idx); }
        else if (e.key === 'ArrowDown') { e.preventDefault(); idx = (idx + 1) % items.length; show(); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); idx = (idx - 1 + items.length) % items.length; show(); }
        else if (e.key === 'Escape') { e.preventDefault(); hide(); }
    });
    ta.addEventListener('input', () => { idx = 0; show(); });
    ta.addEventListener('click', show);
    ta.addEventListener('blur', () => setTimeout(hide, 150));
    box.addEventListener('mousedown', e => { const b = e.target.closest('[data-i]'); if (b) { e.preventDefault(); accept(Number(b.dataset.i)); } });
    return { hide };
})();
function incident(){
    return { incident_date: document.getElementById('iDate').value, incident_time: document.getElementById('iTime').value, incident_type: document.getElementById('iType').value,
             incident_type_other: document.getElementById('iType').value === 'Other' ? document.getElementById('iTypeOther').value.trim() : '',
             location_option: document.getElementById('iLoc').value, location_other: document.getElementById('iLocOther').value.trim(), description: document.getElementById('iDesc').value.trim() };
}
function incidentErrors(){
    const i = incident(), e = [];
    const dt = dtError(); if (dt) e.push(dt);
    if (!i.incident_type) e.push('Select the incident type.');
    if (i.incident_type === 'Other' && i.incident_type_other.length < 2) e.push('Specify the incident type / category (Other).');
    if (!i.location_option) e.push('Select the incident location.');
    if (i.location_option === 'Other' && !i.location_other) e.push('Enter the other location.');
    if (i.description.length < 10) e.push('Describe the incident (at least 10 characters).');
    return e;
}

/* ───────── Review (step 3) ───────── */
function drawReview(){
    const tbl = rows => '<table class="w-full rv-table text-sm"><tbody>' + rows.map(r => '<tr class="border-t border-slate-50"><td class="py-2 pr-3 align-top">' + esc(r[0]) + '</td><td class="py-2 font-bold text-slate-800 whitespace-pre-line">' + esc(r[1]) + '</td></tr>').join('') + '</tbody></table>';
    const card = (icon, title, step, body) => '<div class="card p-5 md:p-7"><div class="flex items-center justify-between mb-3"><div class="sec-head !mb-0"><span class="material-symbols-outlined">' + icon + '</span><h4>' + title + '</h4></div><button type="button" class="btn btn-ghost btn-sm" onclick="Wizard.go(' + step + ')"><span class="material-symbols-outlined">edit</span>Edit</button></div>' + body + '</div>';
    const i = incident();
    const fmtDate = d => d ? new Date(d + 'T00:00').toLocaleDateString([], { year:'numeric', month:'long', day:'numeric' }) : '—';
    const fmtTime = t => t ? new Date('2000-01-01T' + t).toLocaleTimeString([], { hour:'numeric', minute:'2-digit' }) : '—';
    let h = '';
    ['Complainant', 'Respondent'].forEach(role => {
        const s = Parties.summary(role);
        h += card(role === 'Complainant' ? 'person' : 'person_alert', role + (s.length > 1 ? 's' : ''), 1, s.map((rows, n) => (s.length > 1 ? '<p class="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-3">' + role + ' ' + (n + 1) + '</p>' : '') + tbl(rows)).join(''));
    });
    h += card('report', 'Incident', 2, tbl([['Incident date', fmtDate(i.incident_date)], ['Incident time', fmtTime(i.incident_time)], ['Incident type', i.incident_type === 'Other' ? i.incident_type_other + ' (Other)' : i.incident_type],
        ['Incident location', i.location_option === 'Other' ? i.location_other + ' (Other)' : i.location_option], ['Description', i.description]]));
    const ev = Evidence.files();
    h += card('attach_file', 'Evidence (' + ev.length + ')', 2, !ev.length ? '<p class="text-sm text-slate-400">No evidence attached (optional).</p>' : '<table class="mini-table"><thead><tr><th>Filename</th><th>File type</th><th>Size</th><th>Description</th><th></th></tr></thead><tbody>' +
        ev.map((x, n) => '<tr><td class="font-bold">' + esc(x.file.name) + '</td><td>' + esc(x.file.type || x.file.name.split('.').pop().toUpperCase()) + '</td><td>' + (x.file.size >= 1048576 ? (x.file.size / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(x.file.size / 1024)) + ' KB') + '</td><td>' + esc(x.desc || '—') + '</td>' +
            '<td class="text-right"><button type="button" class="btn btn-ghost btn-sm" onclick="Wizard.view(' + n + ')"><span class="material-symbols-outlined">open_in_new</span>View</button></td></tr>').join('') + '</tbody></table>');
    document.getElementById('review').innerHTML = h;
}

/* ───────── Wizard ───────── */
const Wizard = (function(){
    const LABELS = ['Complainant & Respondent', 'Incident', 'Review'];
    let step = 1;
    function go(n){
        step = n;
        document.querySelectorAll('[data-step]').forEach(s => s.classList.toggle('hidden', Number(s.dataset.step) !== n));
        document.getElementById('steps').innerHTML = LABELS.map((l, i) => (i ? '<span class="step-line"></span>' : '') + '<span class="step-dot ' + (i + 1 === n ? 'active' : (i + 1 < n ? 'done' : '')) + '"><span class="n">' + (i + 1 < n ? '✓' : i + 1) + '</span>' + l + '</span>').join('');
        document.getElementById('bBack').classList.toggle('invisible', n === 1);
        document.getElementById('bNext').classList.toggle('hidden', n === 3);
        document.getElementById('bFile').classList.toggle('hidden', n !== 3);
        document.getElementById('msg').textContent = '';
        if (n === 3) drawReview();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    function errorsFor(n){ return n === 1 ? Parties.validate() : (n === 2 ? incidentErrors() : Parties.validate().concat(incidentErrors())); }
    function next(){
        const e = errorsFor(step);
        if (e.length) { document.getElementById('msg').textContent = e.slice(0, 6).join('\n') + (e.length > 6 ? '\n…and ' + (e.length - 6) + ' more' : ''); return; }
        go(step + 1);
    }
    function back(){ if (step > 1) go(step - 1); }
    function view(n){ const f = Evidence.files()[n]; if (f) window.open(URL.createObjectURL(f.file), '_blank'); }
    async function file(){
        const e = errorsFor(3);
        if (e.length) { document.getElementById('msg').textContent = e.slice(0, 6).join('\n'); return; }
        const ok = await BLT.confirm({ title:'File this case?', message:'The case will be saved with a new Blotter ID' + (Evidence.files().length ? ' and the evidence files will be uploaded.' : '.'), ok:'File Case', icon:'gavel' });
        if (!ok) return;
        const fd = new FormData();
        fd.append('action', 'file');
        fd.append('complainants', JSON.stringify(Parties.get('Complainant')));
        fd.append('respondents', JSON.stringify(Parties.get('Respondent')));
        const i = incident(); Object.keys(i).forEach(k => fd.append(k, i[k]));
        Evidence.files().forEach(x => { fd.append('attachments[]', x.file, x.file.name); fd.append('attachment_desc[]', x.desc); });
        const btn = document.getElementById('bFile'); btn.disabled = true; btn.innerHTML = '<span class="material-symbols-outlined">hourglass_top</span>Filing…';
        try {
            const d = await BLT.post(API, fd);
            if (!d.success) { document.getElementById('msg').textContent = (d.errors || [d.message]).join('\n'); return; }
            BLT.toast(d.message, 'success');
            location.href = 'case_details.php?id=' + d.id + '&filed=1';
        } catch (err) { document.getElementById('msg').textContent = err.message; }
        finally { btn.disabled = false; btn.innerHTML = '<span class="material-symbols-outlined">gavel</span>File Case'; }
    }
    return { go, next, back, file, view };
})();

(async function init(){
    try {
        OPT = await BLT.getJSON(API + '?action=options');
        // "Other" always last; choosing it shows a field for the typed incident type / category.
        const types = OPT.incident_types.filter(t => !/^other$/i.test(t));
        document.getElementById('iType').innerHTML = '<option value="">Select type</option>' + types.map(t => '<option>' + esc(t) + '</option>').join('') + '<option value="Other">Other (specify)</option>';
        document.getElementById('iLoc').innerHTML = '<option value="">Select location</option>' +
            OPT.locations.map(g => '<optgroup label="' + esc(g.label) + '">' + g.items.map(x => '<option>' + esc(x) + '</option>').join('') + '</optgroup>').join('') +
            '<option value="Other">Other (type the place)</option>';
        document.getElementById('maxMb').textContent = OPT.max_upload_mb;
    } catch (e) { BLT.toast('Could not load the form options: ' + e.message, 'error'); }
    Parties.add('Complainant');
    Parties.add('Respondent');
    Wizard.go(1);
})();
</script>
</body>
</html>
