<?php
/**
 * Blotter Analytics — same structure / behavior as Resident, Household, Legal Document, Disaster
 * and Announcement Analytics:
 *   Start / End Date → Apply; empty dates = all records
 *   AI Analytics (manual only), Data Interpretation, summary cards, charts (with "View table") and tables.
 *   Save PDF / Print → ../backend/analytics_report.php (shared CAPS report layout),
 *   asking whether to include the AI findings (never generates AI automatically).
 */
require_once __DIR__ . '/../../db.php';
$required_module = 'blotter';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../backend/analytics_data.php';

$current_page = 'Blotter';
$pageTitle = 'Blotter Analytics';
$p = ra_params($_GET);
$a = null;
try { blt_migrate($pdo); $a = blt_analytics_uniform($pdo, $p); }
catch (Throwable $e) { error_log('[Blotter] analytics: ' . $e->getMessage()); }

// ── AJAX: analytics data for the selected date range ─────────────────────────
if (($_GET['action'] ?? '') === 'data') {
    blt_json($a ? ['success' => true] + $a : ['success' => false, 'error' => 'Could not load the blotter analytics.']);
}
?>
<!doctype html>
<html <?php require_once __DIR__ . '/../../theme_loader.php'; echo $theme_attrs['html'] ?? ''; ?>>
<head>
    <?php require __DIR__ . '/partials/blotter_head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
        .kpi2 { border: 1px solid #eef2f7; border-radius: 20px; padding: 16px 18px; background: #fff }
        .kpi2 .k-label { font-size: 9px; font-weight: 900; text-transform: uppercase; letter-spacing: .08em; color: #64748b }
        .kpi2 .k-value { font-size: 26px; font-weight: 900; color: #0f172a; line-height: 1.1; margin-top: 4px; font-variant-numeric: tabular-nums }
        .kpi2 .k-sub { font-size: 10px; font-weight: 700; color: #94a3b8; margin-top: 2px }
        .chart-card { border: 1px solid #eef2f7; border-radius: 24px; padding: 20px; background: #fff; display: flex; flex-direction: column; min-width: 0 }
        .chart-card h3 { font-size: 14px; font-weight: 900; color: #1e293b }
        .chart-card .c-sub { font-size: 10px; font-weight: 700; color: #94a3b8; margin-top: 2px }
        .chart-box2 { position: relative; height: 250px; margin-top: 14px }
        details.tv { margin-top: 10px }
        details.tv summary { cursor: pointer; font-size: 10px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: .06em }
        table.dt { width: 100%; border-collapse: collapse; font-size: 12px }
        table.dt th { text-align: left; font-size: 9px; text-transform: uppercase; letter-spacing: .06em; color: #94a3b8; font-weight: 900; padding: 8px 10px; border-bottom: 1px solid #eef2f7; background: #f8fafc }
        table.dt td { padding: 8px 10px; border-bottom: 1px solid #f1f5f9; color: #334155; font-weight: 600 }
        table.dt td.num, table.dt th.num { text-align: right; font-variant-numeric: tabular-nums }
        table.dt tr.total td { font-weight: 900; border-top: 1.5px solid #cbd5e1; background: #f8fafc }
        .empty { font-size: 12px; color: #94a3b8; font-style: italic; text-align: center; padding: 40px 10px }
        html.dark .kpi2, html.dark .chart-card { background: #1e293b; border-color: #334155 }
        html.dark .kpi2 .k-value, html.dark .chart-card h3 { color: #e2e8f0 }
        html.dark table.dt th { background: #0f172a; border-color: #334155 } html.dark table.dt td { color: #cbd5e1; border-color: #334155 }
    </style>
</head>
<body <?php echo $theme_attrs['body'] ?? ''; ?>>
<div class="flex min-h-screen">
    <?php require __DIR__ . '/../../sidebar.php'; ?>
    <div class="flex-1 flex flex-col min-w-0 main-wrapper">
        <?php require __DIR__ . '/../../header.php'; ?>
        <main class="p-4 md:p-6 lg:p-8 space-y-7">
            <section class="hero-band rounded-2xl p-6 md:p-8 text-white relative overflow-hidden">
                <div class="absolute -right-12 -top-12 w-64 h-64 opacity-10 rounded-full blur-3xl pointer-events-none" style="background:var(--accent-400);"></div>
                <div class="relative z-10 flex flex-col xl:flex-row xl:items-center xl:justify-between gap-5">
                    <div>
                        <div class="flex items-center gap-2 text-white/60 text-[10px] font-black uppercase tracking-[0.18em] mb-2"><span class="material-symbols-outlined text-base">gavel</span>Blotter / Case Management</div>
                        <h1 class="text-2xl md:text-3xl font-black tracking-tight leading-none">Blotter Analytics</h1>
                        <p class="text-white/65 text-sm mt-2 font-medium max-w-2xl">Cases, hearings, resolutions and transfers from the actual blotter records.</p>
                    </div>
                    <div class="flex flex-wrap items-center gap-3">
                        <button type="button" onclick="openReport('pdf')" class="hero-btn hero-btn-white"><span class="material-symbols-outlined">picture_as_pdf</span>Save PDF</button>
                        <button type="button" onclick="openReport('print')" class="hero-btn"><span class="material-symbols-outlined">print</span>Print</button>
                        <a href="incidents.php" class="hero-btn"><span class="material-symbols-outlined">arrow_back</span>Back to Blotter</a>
                    </div>
                </div>
            </section>

            <!-- Date range -->
            <section class="card p-5 md:p-6">
                <form id="rangeForm" class="flex flex-wrap items-end gap-4" onsubmit="applyRange(event)">
                    <div><label for="startDate" class="field-label">Start Date</label>
                        <input type="date" id="startDate" max="9999-12-31" class="input !w-auto" value="<?php echo h($p['start']); ?>"></div>
                    <div><label for="endDate" class="field-label">End Date</label>
                        <input type="date" id="endDate" max="9999-12-31" class="input !w-auto" value="<?php echo h($p['end']); ?>"></div>
                    <button type="submit" class="btn btn-dark"><span class="material-symbols-outlined">filter_alt</span>Apply</button>
                    <button type="button" onclick="clearRange()" class="btn btn-ghost">Clear</button>
                    <div class="ml-auto text-right">
                        <p class="section-title">Showing</p>
                        <p id="rangeLabel" class="text-sm font-black text-slate-800"></p>
                        <p id="rangeBasis" class="text-[10px] font-bold text-slate-400"></p>
                    </div>
                </form>
            </section>

            <!-- AI Analytics (manual only) -->
            <section class="card p-6 md:p-8">
                <div class="flex flex-wrap items-center justify-between gap-4">
                    <div class="flex items-center gap-3">
                        <span class="material-symbols-outlined text-white bg-indigo-600 p-2 rounded-xl">auto_awesome</span>
                        <div><h2 class="text-lg font-black text-slate-800">AI Analytics</h2>
                            <p id="aiStatus" class="text-[10px] text-slate-400 font-bold">Not generated. AI runs only when you click the button.</p></div>
                    </div>
                    <button type="button" id="aiBtn" onclick="generateAi()" class="btn btn-dark"><span class="material-symbols-outlined">auto_awesome</span><span id="aiBtnText">Generate AI Analytics</span></button>
                </div>
                <div id="aiBody" class="mt-6"></div>
            </section>

            <!-- Data Interpretation (directly below AI Analytics) -->
            <div id="raInterp"></div>
            <div id="raBody" class="space-y-7"></div>

            <!-- Case Records -->
            <section class="card overflow-hidden">
                <div class="px-6 pt-6 pb-4 flex flex-wrap items-end justify-between gap-3">
                    <div class="flex items-center gap-3">
                        <span class="material-symbols-outlined text-white bg-primary p-2 rounded-xl">folder_open</span>
                        <div><h2 class="text-lg font-black text-slate-800">Case Records</h2>
                            <p class="text-[10px] text-slate-400 font-bold">Every case filed in the selected range. Click a Blotter ID to open the case.</p></div>
                    </div>
                    <div class="relative w-full sm:w-64">
                        <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" style="font-size:16px">search</span>
                        <input type="text" id="recordSearch" placeholder="Search Blotter ID, name, type…" oninput="renderRecords()" class="input !pl-9">
                    </div>
                </div>
                <div class="overflow-x-auto max-h-[560px] overflow-y-auto">
                    <table class="dt"><thead><tr><th>Blotter ID</th><th>Complainant</th><th>Respondent</th><th>Case Type</th><th>Incident</th><th>Location</th><th>Filed</th><th class="num">Hearings</th><th>Status</th></tr></thead>
                        <tbody id="recordsBody"></tbody></table>
                </div>
                <p class="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase border-t border-slate-100" id="recordsCount">—</p>
            </section>
        </main>
    </div>
</div>

<!-- Save PDF / Print: include AI findings? -->
<div id="reportModal" class="modal-back">
  <div class="modal-box" style="max-width:460px">
    <div class="modal-body">
      <div class="flex items-start justify-between"><div><h3 id="rmTitle" class="modal-title">Save as PDF</h3><p class="modal-sub">Blotter Analytics Report</p><p id="rmRange" class="text-xs text-slate-400 font-semibold mt-1"></p></div>
        <button type="button" onclick="closeReport()" class="modal-close" aria-label="Close"><span class="material-symbols-outlined">close</span></button></div>
      <p class="text-sm font-bold text-slate-700 mt-5 mb-2">Include AI findings in the report?</p>
      <div class="space-y-2">
        <label class="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-100 cursor-pointer"><input type="radio" name="rmAi" value="0" checked class="mt-0.5">
            <span><span class="block text-sm font-bold text-slate-700">No AI – Data and tables only</span><span class="block text-[11px] text-slate-400">Summary, statistics, tables, case records and data interpretation.</span></span></label>
        <label class="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-100 cursor-pointer"><input type="radio" name="rmAi" value="1" class="mt-0.5">
            <span><span class="block text-sm font-bold text-slate-700">Include AI – Data, charts, and AI explanation</span><span class="block text-[11px] text-slate-400">Uses the AI Analytics already generated on this page.</span></span></label>
      </div>
      <p id="rmError" class="hidden mt-4 text-xs font-bold text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-3 py-2">Please generate AI Analytics first.</p>
    </div>
    <div class="modal-foot"><button type="button" onclick="closeReport()" class="btn btn-ghost">Cancel</button><button type="button" onclick="continueReport()" class="btn btn-dark">Continue</button></div>
  </div>
</div>

<script>
    const COLORS = { s1: '#2a78d6', s2: '#eb6834', s3: '#1baf7a', red: '#e11d48', muted: '#94a3b8', grid: '#eef2f7' };
    const PAL = ['#2a78d6', '#1baf7a', '#eb6834', '#6366f1', '#e11d48', '#eab308', '#14b8a6', '#8b5cf6', '#94a3b8', '#ec4899'];
    const STATUS_COLORS = { Resolved: '#1baf7a', Closed: '#0d9488', 'For Transfer': '#f97316', Transferred: '#e11d48', Cancelled: '#94a3b8', Withdrawn: '#cbd5e1' };
    const charts = {};
    let DATA = <?php echo json_encode($a ? ['success' => true] + $a : null, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?>;
    let BA_AI = null;
    const esc = BLT.esc;
    const num = v => Number(v || 0).toLocaleString('en-US');
    const pct = (v, d) => d ? (Math.round(Number(v || 0) / d * 1000) / 10) + '%' : '0%';
    const sum = o => (Array.isArray(o) ? o : Object.values(o)).reduce((s, v) => s + Number(v || 0), 0);
    const kv = list => Object.fromEntries(list.map(x => [x.label, x.n]));
    const fmtDur = m => m === null || m === undefined ? '—' : m < 60 ? Math.round(m) + ' min' : m < 1440 ? (Math.round(m / 6) / 10) + ' h' : (Math.round(m / 144) / 10) + ' days';
    if (window.Chart) {
        const dark = document.documentElement.classList.contains('dark');
        Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";
        Chart.defaults.font.size = 11;
        Chart.defaults.color = dark ? '#94a3b8' : '#64748b';
        Chart.defaults.plugins.tooltip.backgroundColor = '#0f172a';
        Chart.defaults.plugins.tooltip.padding = 10;
    }

    /* ───────── Rendering helpers (same as the other analytics pages) ───────── */
    function kpi(label, value, sub) { return `<div class="kpi2"><p class="k-label">${esc(label)}</p><p class="k-value">${esc(value)}</p>${sub ? `<p class="k-sub">${esc(sub)}</p>` : ''}</div>`; }
    function card(id, title, sub, opts = {}) {
        return `<div class="chart-card ${opts.span || ''}"><h3>${esc(title)}</h3><p class="c-sub">${esc(sub)}</p>
            ${opts.empty ? `<p class="empty">${esc(opts.empty)}</p>` : `<div class="chart-box2"><canvas id="${id}" role="img" aria-label="${esc(title)}"></canvas></div>`}
            ${opts.table ? `<details class="tv"><summary>View table</summary><div class="mt-2 overflow-x-auto">${opts.table}</div></details>` : ''}</div>`;
    }
    function table(head, rows, numCols = []) {
        if (!rows.length) return '<p class="empty">No data for the selected range.</p>';
        return `<table class="dt"><thead><tr>${head.map((h, i) => `<th class="${numCols.includes(i) ? 'num' : ''}">${esc(h)}</th>`).join('')}</tr></thead><tbody>` +
            rows.map(r => `<tr class="${r[0] === 'Total' ? 'total' : ''}">${r.map((c, i) => `<td class="${numCols.includes(i) ? 'num' : ''}">${esc(c)}</td>`).join('')}</tr>`).join('') + '</tbody></table>';
    }
    function distRows(obj, base) {
        const rows = Object.entries(obj).map(([k, v]) => [k, num(v), pct(v, base)]);
        if (rows.length) rows.push(['Total', num(sum(obj)), pct(sum(obj), base)]);
        return rows;
    }
    function section(icon, title, sub, inner) {
        return `<section class="card p-6 md:p-8"><div class="flex items-center gap-3 mb-6"><span class="material-symbols-outlined text-white bg-primary p-2 rounded-xl">${icon}</span>
            <div><h2 class="text-lg font-black text-slate-800">${esc(title)}</h2><p class="text-[10px] text-slate-400 font-bold">${esc(sub)}</p></div></div>${inner}</section>`;
    }
    const axisCount = { beginAtZero: true, ticks: { precision: 0 }, grid: { color: COLORS.grid }, border: { display: false } };
    const noGrid = { grid: { display: false }, border: { display: false } };
    const legendTop = { position: 'top', align: 'end', labels: { boxWidth: 10, boxHeight: 10 } };
    function mk(id, cfg) { const el = document.getElementById(id); if (!el) return; cfg.options = Object.assign({ maintainAspectRatio: false }, cfg.options || {}); charts[id] = new Chart(el, cfg); }
    function donut(id, obj, colorOf, base) {
        const e = Object.entries(obj).filter(([, v]) => v > 0);
        mk(id, { type: 'doughnut', data: { labels: e.map(x => x[0]), datasets: [{ data: e.map(x => x[1]), backgroundColor: e.map((x, i) => colorOf(x[0], i)), borderColor: '#fff', borderWidth: 2 }] },
            options: { cutout: '62%', plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, boxHeight: 10 } }, tooltip: { callbacks: { label: c => ` ${c.label}: ${num(c.raw)} (${pct(c.raw, base)})` } } } } });
    }
    const barCfg = (labels, data, color, horizontal) => ({ type: 'bar', data: { labels, datasets: [{ data, backgroundColor: color, borderRadius: 4, maxBarThickness: 32 }] },
        options: { indexAxis: horizontal ? 'y' : 'x', plugins: { legend: { display: false } }, scales: horizontal ? { x: axisCount, y: noGrid } : { x: noGrid, y: axisCount } } });

    /* ───────── Page ───────── */
    function render() {
        Object.values(charts).forEach(c => c.destroy());
        for (const k in charts) delete charts[k];
        const body = document.getElementById('raBody');
        document.getElementById('raInterp').innerHTML = '';
        if (!DATA) { body.innerHTML = '<section class="card p-8"><p class="empty">Unable to load the blotter analytics.</p></section>'; renderRecords(); return; }
        const d = DATA, t = d.totals, T = t.total;
        document.getElementById('rangeLabel').textContent = d.range.label;
        document.getElementById('rangeBasis').textContent = d.range.open ? 'All blotter cases on file' : 'Cases filed within the range';

        let html = section('gavel', 'Case Summary', 'Cases by date filed · ' + d.range.label,
            `<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
                ${kpi('Total Cases', num(T), d.comparison ? (T - d.comparison.rows[0].previous >= 0 ? '+' : '') + (T - d.comparison.rows[0].previous) + ' vs previous period' : d.days + ' day(s)')}
                ${kpi('Active', num(t.active), 'still being handled')}
                ${kpi('Resolved / Closed', num(t.resolved), t.resolution_rate !== null ? t.resolution_rate + '% resolution rate' : 'none decided yet')}
                ${kpi('For Transfer', num(t.for_transfer), 'reached the case limit')}
                ${kpi('Transferred', num(t.transferred), 'to BPSO / police / other')}
                ${kpi('Unresolved', num(t.unresolved), 'active + transfer')}
                ${kpi('Cancelled / Withdrawn', num(t.cancelled), pct(t.cancelled, T) + ' of cases')}
                ${kpi('Avg Resolution Time', fmtDur(t.avg_resolution_min), (t.avg_hearings_before_resolution ?? '—') + ' hearing(s) before resolution')}
                ${kpi('Hearings', num(t.hearings), num(t.hearings_completed) + ' completed · ' + num(t.hearings_scheduled) + ' scheduled')}
                ${kpi('No-Shows', num(t.no_shows), 'hearings with a no-show')}
            </div>`);

        const typeRows = d.by_type.map(x => [x.label, num(x.n), pct(x.n, T), num(x.resolved), num(x.transferred)]);
        if (typeRows.length) typeRows.push(['Total', num(T), T ? '100%' : '0%', num(sum(d.by_type.map(x => x.resolved))), num(sum(d.by_type.map(x => x.transferred)))]);
        html += section('category', 'Case Types & Status', 'What kind of cases were filed and where they stand now',
            `<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                ${card('c-type', 'Case Types', 'Cases, resolved and transferred per type', { span: 'lg:col-span-2', empty: T ? '' : 'No cases in this range.' })}
                ${card('c-status', 'Case Status', 'Current status of the cases', { empty: T ? '' : 'No cases.', table: table(['Status', 'Cases', 'Share'], distRows(kv(d.by_status), T), [1, 2]) })}
            </div>
            <div class="mt-6 chart-card"><h3>Case Type Summary</h3><p class="c-sub">Per case type</p>
                <div class="mt-3 overflow-x-auto">${table(['Case type', 'Cases', 'Share', 'Resolved', 'Transferred'], typeRows, [1, 2, 3, 4])}</div></div>`);

        const outcome = { 'Resolved / Closed': t.resolved, 'For transfer / Transferred': t.transferred + t.for_transfer, 'Still active': t.active, 'Cancelled / Withdrawn': t.cancelled };
        const hd = Object.fromEntries(Object.entries(d.hearing_dist).map(([k, v]) => [k + ' hearing' + (k === '1' ? '' : 's'), v]));
        const oc = kv(d.outcomes), rb = d.resolution_buckets;
        html += section('handshake', 'Hearings & Resolution', 'How cases are heard, settled or transferred',
            `<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                ${card('c-outcome', 'Case Outcome', t.resolution_rate !== null ? t.resolution_rate + '% settled at the barangay' : 'Resolved vs transferred', { empty: T ? '' : 'No cases.', table: table(['Outcome', 'Cases', 'Share'], distRows(outcome, T), [1, 2]) })}
                ${card('c-hresult', 'Hearing Results', 'Outcome of each hearing', { empty: sum(oc) ? '' : 'No hearing results.', table: table(['Outcome', 'Hearings', 'Share'], distRows(oc, sum(oc)), [1, 2]) })}
                ${card('c-noshow', 'No-Shows', num(t.no_shows) + ' hearing(s) with a no-show', { empty: t.no_shows ? '' : 'No no-shows recorded.', table: table(['No-show', 'Hearings', 'Share'], distRows(d.no_show, t.no_shows), [1, 2]) })}
                ${card('c-hdist', 'Hearings per Case', num(t.hearings) + ' hearing(s) in total', { empty: T ? '' : 'No cases.', table: table(['Hearings', 'Cases', 'Share'], distRows(hd, T), [1, 2]) })}
                ${card('c-restime', 'Resolution Time', 'Filing → settlement · average ' + fmtDur(t.avg_resolution_min), { span: 'lg:col-span-2', empty: sum(rb) ? '' : 'No resolved case in this range.', table: table(['Time', 'Cases', 'Share'], distRows(rb, sum(rb)), [1, 2]) })}
            </div>`);

        let comparison = '';
        if (d.comparison) comparison = `<div class="chart-card lg:col-span-2"><h3>Selected Period vs Previous Period</h3><p class="c-sub">Previous period: ${esc(d.comparison.previous_label)}</p>
            <div class="chart-box2"><canvas id="c-compare"></canvas></div>
            <div class="mt-3 overflow-x-auto">${table(['Indicator', 'Selected', 'Previous', 'Change'], d.comparison.rows.map(r => [r.metric, num(r.current), num(r.previous), (r.current - r.previous > 0 ? '+' : '') + num(r.current - r.previous)]), [1, 2, 3])}</div></div>`;
        const s = d.series, wd = Object.fromEntries(d.weekday.labels.map((l, i) => [l, d.weekday.data[i]])), hr = Object.fromEntries(d.hours.labels.map((l, i) => [l, d.hours.data[i]]).filter(x => x[1] > 0));
        html += section('insights', 'Trends & Comparison', 'Filings over time, when and where incidents happen',
            `<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                ${card('c-trend', 'Cases over Time', 'Filed, resolved and transferred per ' + (d.monthly ? 'month' : 'day'), { span: 'lg:col-span-2', empty: s.labels.length > 1 && sum(s.filed) ? '' : 'Not enough data for a trend.' })}
                ${card('c-weekday', 'Incidents by Day of Week', d.weekday.busiest ? 'Most on ' + d.weekday.busiest : 'Day of the incident', { empty: sum(d.weekday.data) ? '' : 'No incident dates.', table: table(['Day', 'Incidents', 'Share'], distRows(wd, sum(wd)), [1, 2]) })}
                ${card('c-hours', 'Incidents by Hour', d.hours.busiest ? 'Peak around ' + d.hours.busiest : 'Time of the incident', { empty: sum(d.hours.data) ? '' : 'No incident times.', table: table(['Hour', 'Incidents', 'Share'], distRows(hr, sum(hr)), [1, 2]) })}
                ${card('c-location', 'Top Incident Locations', 'Where incidents happened', { span: 'lg:col-span-2', empty: d.by_location.length ? '' : 'No locations.', table: table(['Location', 'Cases', 'Share'], distRows(kv(d.by_location), T), [1, 2]) })}
                ${comparison}
            </div>`);

        document.getElementById('raInterp').innerHTML = section('fact_check', 'Data Interpretation', 'Automatic summary of the blotter figures (no AI) · ' + d.range.label,
            `<ol class="list-decimal pl-5 space-y-2 text-sm text-slate-600 font-medium">${(d.interpretation || []).map(x => `<li>${esc(x)}</li>`).join('')}</ol>`);
        body.innerHTML = html;
        renderRecords();

        if (!window.Chart) return;
        if (T) mk('c-type', { type: 'bar', data: { labels: d.by_type.map(x => x.label), datasets: [
            { label: 'Cases', data: d.by_type.map(x => x.n), backgroundColor: COLORS.s1, borderRadius: 4, maxBarThickness: 22 },
            { label: 'Resolved', data: d.by_type.map(x => x.resolved), backgroundColor: COLORS.s3, borderRadius: 4, maxBarThickness: 22 },
            { label: 'Transferred', data: d.by_type.map(x => x.transferred), backgroundColor: COLORS.red, borderRadius: 4, maxBarThickness: 22 }] },
            options: { plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
        if (T) donut('c-status', kv(d.by_status), (k, i) => STATUS_COLORS[k] || PAL[i % PAL.length], T);
        if (T) donut('c-outcome', outcome, k => ({ 'Resolved / Closed': COLORS.s3, 'For transfer / Transferred': COLORS.red, 'Still active': COLORS.s2, 'Cancelled / Withdrawn': COLORS.muted })[k], T);
        if (sum(oc)) donut('c-hresult', oc, (k, i) => k === 'Resolved' ? COLORS.s3 : (/No Show/.test(k) ? COLORS.s2 : PAL[i % PAL.length]), sum(oc));
        if (t.no_shows) mk('c-noshow', barCfg(Object.keys(d.no_show), Object.values(d.no_show), COLORS.s2));
        if (T) mk('c-hdist', barCfg(Object.keys(hd), Object.values(hd), '#6366f1'));
        if (sum(rb)) mk('c-restime', barCfg(Object.keys(rb), Object.values(rb), COLORS.s3));
        if (s.labels.length > 1 && sum(s.filed)) mk('c-trend', { type: 'line', data: { labels: s.labels, datasets: [['Filed', s.filed, COLORS.s1], ['Resolved', s.resolved, COLORS.s3], ['Transferred', s.transferred, COLORS.red]]
            .map(([l, v, c]) => ({ label: l, data: v, borderColor: c, backgroundColor: c, borderWidth: 2, pointRadius: s.labels.length > 40 ? 0 : 3, tension: 0 })) },
            options: { interaction: { mode: 'index', intersect: false }, plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
        if (sum(d.weekday.data)) mk('c-weekday', barCfg(d.weekday.labels, d.weekday.data, COLORS.s1));
        if (sum(d.hours.data)) mk('c-hours', barCfg(d.hours.labels, d.hours.data, COLORS.s2));
        if (d.by_location.length) mk('c-location', barCfg(d.by_location.map(x => x.label), d.by_location.map(x => x.n), '#0ea5e9', true));
        if (d.comparison) mk('c-compare', { type: 'bar', data: { labels: d.comparison.rows.map(r => r.metric), datasets: [
            { label: 'Selected period', data: d.comparison.rows.map(r => r.current), backgroundColor: COLORS.s1, borderRadius: 4, maxBarThickness: 40 },
            { label: 'Previous period', data: d.comparison.rows.map(r => r.previous), backgroundColor: COLORS.muted, borderRadius: 4, maxBarThickness: 40 }] },
            options: { plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
    }

    function renderRecords() {
        const tb = document.getElementById('recordsBody');
        if (!DATA) { tb.innerHTML = ''; document.getElementById('recordsCount').textContent = '—'; return; }
        const q = (document.getElementById('recordSearch').value || '').toLowerCase().trim();
        const list = DATA.records.filter(r => !q || [r.case_number, r.complainant, r.respondent, r.type, r.location, r.status].some(v => String(v || '').toLowerCase().includes(q)));
        document.getElementById('recordsCount').textContent = `Showing ${list.length} of ${DATA.records.length} case(s)`;
        tb.innerHTML = list.length ? list.map(r => `<tr><td><a href="case_details.php?id=${r.id}" class="font-mono font-bold text-indigo-600 hover:underline">${esc(r.case_number)}</a></td>
            <td>${esc(r.complainant)}</td><td>${esc(r.respondent)}</td><td>${esc(r.type)}</td><td class="whitespace-nowrap">${esc(r.incident)}</td><td>${esc(r.location)}</td>
            <td class="whitespace-nowrap">${esc(r.filed)}</td><td class="num">${num(r.hearings)}</td><td>${esc(r.status)}</td></tr>`).join('')
            : '<tr><td colspan="9" class="empty">No blotter cases found.</td></tr>';
    }

    /* ───────── Date range ───────── */
    async function applyRange(e) {
        if (e) e.preventDefault();
        const p = { start: document.getElementById('startDate').value, end: document.getElementById('endDate').value };
        if (p.start && p.end && p.start > p.end) { alert('The Start Date must be on or before the End Date.'); return; }
        const q = new URLSearchParams(p);
        history.replaceState({}, '', location.pathname + '?' + q.toString());
        document.getElementById('raBody').style.opacity = '.5';
        try {
            const j = await BLT.getJSON('blotter_analytics.php?action=data&' + q.toString());
            if (!j.success) throw new Error(j.error || 'Unable to load the blotter analytics.');
            DATA = j;
        } catch (err) { alert(err.message); }
        document.getElementById('raBody').style.opacity = '';
        render(); resetAi(); loadCachedAi();
    }
    function clearRange() { document.getElementById('startDate').value = ''; document.getElementById('endDate').value = ''; applyRange(); }

    /* ───────── AI Analytics (only on click) ───────── */
    function resetAi() {
        BA_AI = null;
        document.getElementById('aiBody').innerHTML = '';
        document.getElementById('aiStatus').textContent = 'Not generated for this date range. AI runs only when you click the button.';
        document.getElementById('aiBtnText').textContent = 'Generate AI Analytics';
    }
    function renderAi(x) {
        BA_AI = x;
        document.getElementById('aiStatus').textContent = 'Generated ' + (x.generated_at || '') + ' · ' + (x.period?.label || '') + (x.cached ? ' · saved result' : '');
        document.getElementById('aiBtnText').textContent = 'Regenerate AI Analytics';
        const group = (title, icon, list) => list && list.length ? `<div class="rounded-2xl border border-indigo-100 bg-indigo-50/40 p-5"><div class="flex items-center gap-2 mb-3"><span class="material-symbols-outlined text-indigo-600">${icon}</span><h5 class="text-[10px] font-black uppercase tracking-widest text-indigo-700">${esc(title)}</h5></div>
            <ul class="space-y-2">${list.map(f => `<li class="text-xs leading-relaxed text-slate-600"><strong class="text-slate-800">${esc(f.title)}</strong> — ${esc(f.detail)}</li>`).join('')}</ul></div>` : '';
        const recs = (x.recommendations || []).map((f, i) => `<li class="text-xs leading-relaxed text-slate-600"><strong class="text-slate-800">${i + 1}. ${esc(f.action)}</strong>
            <span class="ml-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${f.priority === 'high' ? 'bg-rose-100 text-rose-700' : f.priority === 'low' ? 'bg-slate-100 text-slate-600' : 'bg-amber-100 text-amber-700'}">${esc(f.priority)}</span><br>${esc(f.reason)}</li>`).join('');
        document.getElementById('aiBody').innerHTML =
            (x.summary ? `<p class="text-sm font-semibold text-slate-700 mb-5">${esc(x.summary)}</p>` : '') +
            `<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">${group('Key Findings', 'insights', x.key_findings)}${group('Trends', 'trending_up', x.demographic_trends)}
             ${group('Resolution Patterns', 'handshake', x.patterns)}${group('Parties & Hearings Observations', 'groups', x.population_observations)}</div>` +
            (recs ? `<div class="rounded-2xl border border-indigo-100 bg-white p-5 mt-4"><div class="flex items-center gap-2 mb-3"><span class="material-symbols-outlined text-indigo-600">task_alt</span><h5 class="text-[10px] font-black uppercase tracking-widest text-indigo-700">Recommended Administrative Actions</h5></div><ul class="space-y-3">${recs}</ul></div>` : '') +
            '<p class="text-[10px] text-slate-400 font-bold mt-4">AI-generated from aggregated blotter figures only (no names). Verify against the tables below.</p>';
    }
    async function aiRequest(cachedOnly) {
        const j = await BLT.post('../backend/analytics_ai.php', Object.assign({ start: DATA?.period?.start || '', end: DATA?.period?.end || '' }, cachedOnly ? { cached_only: 1 } : {}));
        if (!j || !j.success) throw new Error(j?.error || j?.message || 'AI Analytics is unavailable right now.');
        return j;
    }
    async function generateAi() {
        if (!DATA) return;
        const btn = document.getElementById('aiBtn');
        btn.disabled = true;
        document.getElementById('aiBtnText').textContent = 'Generating…';
        document.getElementById('aiStatus').textContent = 'Generating AI Analytics for ' + DATA.range.label + '…';
        try { renderAi(await aiRequest(false)); }
        catch (e) { document.getElementById('aiStatus').textContent = e.message; document.getElementById('aiBtnText').textContent = BA_AI ? 'Regenerate AI Analytics' : 'Generate AI Analytics'; }
        btn.disabled = false;
    }
    async function loadCachedAi() { if (!DATA) return; try { const j = await aiRequest(true); if (j.ai) renderAi(j); } catch (e) { } }

    /* ───────── Save PDF / Print ───────── */
    let _reportMode = 'pdf';
    function openReport(mode) {
        _reportMode = mode;
        document.getElementById('rmTitle').textContent = mode === 'pdf' ? 'Save as PDF' : 'Print';
        document.getElementById('rmRange').textContent = DATA ? DATA.range.label : '';
        document.querySelector('input[name="rmAi"][value="0"]').checked = true;
        document.getElementById('rmError').classList.add('hidden');
        BLT.open('reportModal');
    }
    function closeReport() { BLT.close('reportModal'); }
    function continueReport() {
        const withAi = document.querySelector('input[name="rmAi"]:checked')?.value === '1';
        // Never generates AI here — only uses the analysis already generated on this page.
        if (withAi && !BA_AI) { document.getElementById('rmError').classList.remove('hidden'); return; }
        const q = new URLSearchParams({ mode: _reportMode, start: DATA?.period?.start || '', end: DATA?.period?.end || '', ai: withAi ? '1' : '0' });
        closeReport();
        window.open('../backend/analytics_report.php?' + q.toString(), '_blank');
    }
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeReport(); });
    document.querySelectorAll('input[name="rmAi"]').forEach(r => r.addEventListener('change', () => document.getElementById('rmError').classList.add('hidden')));

    render(); loadCachedAi();
</script>
</body>
</html>
