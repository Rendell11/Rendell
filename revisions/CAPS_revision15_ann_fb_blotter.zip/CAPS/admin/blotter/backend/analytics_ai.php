<?php
/**
 * analytics_ai.php — AI Analytics for Blotter Analytics (JSON, POST).
 * Same behavior as the Resident / Household / Legal Document / Disaster / Announcement analytics:
 *   - called ONLY when "Generate AI Analytics" is clicked (never automatically)
 *   - start, end (optional — empty = all records), csrf_token
 *   - cached_only=1 → return an analysis generated before for the same data (no Gemini call)
 * Only aggregated figures are sent (no names, addresses or contact numbers). The result is cached
 * by data snapshot, so the Save PDF / Print report can include it without calling Gemini again.
 */
require_once __DIR__ . '/../../db.php';
$required_module = 'blotter';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/analytics_data.php';
require_once __DIR__ . '/../../ai_helper.php';
blt_migrate($pdo);

$out = function (array $d, int $code = 200) { http_response_code($code); header('Content-Type: application/json; charset=utf-8'); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; };
if ($_SERVER['REQUEST_METHOD'] !== 'POST') $out(['success' => false, 'error' => 'Method not allowed.'], 405);
blt_csrf_verify();

try {
    $p = ra_params($_POST);
    $a = blt_analytics_uniform($pdo, $p);
} catch (Throwable $e) {
    error_log('[Blotter] analytics AI data: ' . $e->getMessage());
    $out(['success' => false, 'error' => 'Could not read the blotter records.'], 500);
}

$snapshot = blt_analytics_ai_snapshot($a);
$ns = 'blotter_analytics';
if (!empty($_POST['cached_only'])) {
    $c = ai_cache_get($ns, $snapshot);
    $out($c ? $c + ['cached' => true] : ['success' => true, 'none' => true]);
}
if (!$a['totals']['total']) $out(['success' => false, 'error' => 'There are no blotter cases for ' . $a['range']['label'] . ', so there is nothing to analyse.']);
if (ai_api_key() === '') $out(['success' => false, 'error' => 'AI is not configured. Set GEMINI_API_KEY in the CAPS .env file.']);

$prompt = "You are an analyst for a Philippine barangay (Katarungang Pambarangay / blotter desk). Analyze ONLY the aggregated blotter case data below "
    . "for the date range: " . $a['range']['label'] . " (cases filed, hearings, no-shows, resolutions, transfers to BPSO / police / other authority). "
    . "Do not invent numbers or names; cite the actual figures and percentages. Keep each detail to one or two short sentences. If the data is thin, say so briefly.\n"
    . "- key_findings: the most important facts (volume, common case types, resolution rate, pending transfers, no-shows).\n"
    . "- demographic_trends: trends over time (filings per day / month, weekday / hour of incidents, comparison with the previous period).\n"
    . "- patterns: resolution patterns (time to resolve, hearings needed, which case types settle or get transferred, locations that repeat).\n"
    . "- population_observations: observations about the parties and hearings (no-shows, cases waiting for transfer, cancelled / withdrawn cases).\n"
    . "- recommendations: concrete administrative actions for the barangay, each tied to a finding.\n\n"
    . "Return JSON: {\"summary\": string (1-2 sentences), "
    . "\"key_findings\": [{\"title\": string, \"detail\": string}] (3-4 items), "
    . "\"demographic_trends\": [{\"title\": string, \"detail\": string}] (2-3 items), "
    . "\"patterns\": [{\"title\": string, \"detail\": string}] (2-3 items), "
    . "\"population_observations\": [{\"title\": string, \"detail\": string}] (2-3 items), "
    . "\"recommendations\": [{\"action\": string, \"reason\": string, \"priority\": \"high\"|\"medium\"|\"low\"}] (3-4 items)}.\n\n"
    . "DATA:\n" . json_encode($snapshot, JSON_UNESCAPED_UNICODE);

$r = ai_call([['text' => $prompt]], '', ['temperature' => 0.3]);
$parsed = $r['ok'] ? ai_parse_json($r['text']) : null;
if (!is_array($parsed) || empty($parsed['key_findings'])) $out(['success' => false, 'error' => ($r['error'] ?? '') ?: 'The AI service returned an unreadable answer. Please try again.']);

$clean = fn($v) => mb_substr(trim((string)$v), 0, 600);
$items = function ($list) use ($clean): array {
    $res = [];
    foreach (is_array($list) ? $list : [] as $x) {
        if (!is_array($x) || trim((string)($x['title'] ?? '')) === '') continue;
        $res[] = ['title' => $clean($x['title']), 'detail' => $clean($x['detail'] ?? '')];
    }
    return array_slice($res, 0, 5);
};
$recs = [];
foreach (is_array($parsed['recommendations'] ?? null) ? $parsed['recommendations'] : [] as $x) {
    if (!is_array($x) || trim((string)($x['action'] ?? '')) === '') continue;
    $recs[] = ['action' => $clean($x['action']), 'reason' => $clean($x['reason'] ?? ''),
               'priority' => in_array($x['priority'] ?? '', ['high', 'medium', 'low'], true) ? $x['priority'] : 'medium'];
}
$result = [
    'success' => true, 'ai' => true, 'model' => $r['model'] ?? '', 'generated_at' => date('F j, Y g:i A'), 'period' => $p,
    'summary' => $clean($parsed['summary'] ?? ''),
    'key_findings' => $items($parsed['key_findings']),
    'demographic_trends' => $items($parsed['demographic_trends'] ?? []),
    'patterns' => $items($parsed['patterns'] ?? []),
    'population_observations' => $items($parsed['population_observations'] ?? []),
    'recommendations' => array_slice($recs, 0, 5),
];
ai_cache_put($ns, $snapshot, $result);
blt_log_activity('Generate AI Analytics', 'Blotter analytics · ' . $a['range']['label']);
$out($result);
