<?php
/**
 * analytics_data.php — numbers for Blotter Analytics, its AI overview and its printable report.
 * Real data only (blotter, blotter_hearings, blotter_hearing_results, blotter_resolutions, blotter_transfers).
 * Every number follows the selected date range (cases FILED between Start Date and End Date).
 *
 *   $p = blt_analytics_params($_GET);          // from / to (default: last 30 days)
 *   $a = blt_analytics_compute($pdo, $p);
 */
require_once __DIR__ . '/blotter_common.php';

function blt_analytics_params(array $in): array {
    $to = blt_valid_date($in['to'] ?? null) ? $in['to'] : date('Y-m-d');
    $from = blt_valid_date($in['from'] ?? null) ? $in['from'] : date('Y-m-d', strtotime($to . ' -29 days'));
    if ($from > $to) [$from, $to] = [$to, $from];
    return ['from' => $from, 'to' => $to];
}

function blt_analytics_compute(PDO $pdo, array $p): array {
    $from = $p['from'] . ' 00:00:00';
    $to = $p['to'] . ' 23:59:59';
    $rq = function (string $sql, array $args = []) use ($pdo) { $s = $pdo->prepare($sql); $s->execute($args); return $s->fetchAll(PDO::FETCH_ASSOC); };
    $filed = "COALESCE(b.FiledAt, b.CreatedAt)";
    $in = "$filed BETWEEN ? AND ?";
    $q = fn(array $l) => "'" . implode("','", $l) . "'";
    $active = $q(array_diff(blt_active_statuses(), [BLT_ST_FOR_TRANSFER]));

    $t = $rq("SELECT COUNT(*) total,
            SUM(b.Status IN ($active)) active,
            SUM(b.Status IN ('Resolved','Closed')) resolved,
            SUM(b.Status IN ($active) OR b.Status IN ('For Transfer','Transferred')) unresolved,
            SUM(b.Status = 'For Transfer') for_transfer,
            SUM(b.Status = 'Transferred') transferred,
            SUM(b.Status IN ('Cancelled','Withdrawn')) cancelled,
            SUM(b.Status = 'Closed') closed
        FROM blotter b WHERE $in", [$from, $to])[0];
    $t = array_map(fn($v) => (int)$v, $t);
    $decided = $t['resolved'] + $t['transferred'];
    $t['resolution_rate'] = $decided ? round($t['resolved'] / $decided * 100, 1) : null;

    // Resolution time: filing → resolution, for cases filed in the range that were resolved.
    $rt = $rq("SELECT TIMESTAMPDIFF(MINUTE, $filed, r.resolved_at) m FROM blotter b JOIN blotter_resolutions r ON r.blotter_id = b.BlotterID WHERE $in", [$from, $to]);
    $mins = array_map(fn($r) => max(0, (int)$r['m']), $rt);
    $t['avg_resolution_min'] = $mins ? array_sum($mins) / count($mins) : null;
    $buckets = ['Same day' => 0, '1–3 days' => 0, '4–7 days' => 0, '8–15 days' => 0, '16–30 days' => 0, 'Over 30 days' => 0];
    foreach ($mins as $m) {
        $d = $m / 1440;
        $k = $d < 1 ? 'Same day' : ($d <= 3 ? '1–3 days' : ($d <= 7 ? '4–7 days' : ($d <= 15 ? '8–15 days' : ($d <= 30 ? '16–30 days' : 'Over 30 days'))));
        $buckets[$k]++;
    }

    // Hearings of the cases filed in the range.
    $h = $rq("SELECT COUNT(h.hearing_id) hearings, SUM(h.status = 'Completed') completed, SUM(h.status = 'Scheduled') scheduled, SUM(h.status = 'Cancelled') cancelled_h
              FROM blotter b JOIN blotter_hearings h ON h.blotter_id = b.BlotterID WHERE $in", [$from, $to])[0];
    $t['hearings'] = (int)$h['hearings']; $t['hearings_completed'] = (int)$h['completed']; $t['hearings_scheduled'] = (int)$h['scheduled'];
    $outcomes = $rq("SELECT r.outcome label, COUNT(*) n FROM blotter b JOIN blotter_hearing_results r ON r.blotter_id = b.BlotterID WHERE $in GROUP BY r.outcome ORDER BY n DESC", [$from, $to]);
    $noShow = ['Complainant No Show' => 0, 'Respondent No Show' => 0, 'Both No Show' => 0];
    foreach ($outcomes as $o) if (isset($noShow[$o['label']])) $noShow[$o['label']] = (int)$o['n'];
    $t['no_shows'] = array_sum($noShow);

    // Hearings held before resolution (completed hearings of resolved cases).
    $hb = $rq("SELECT b.BlotterID, (SELECT COUNT(*) FROM blotter_hearings h WHERE h.blotter_id = b.BlotterID AND h.status = 'Completed') n
               FROM blotter b JOIN blotter_resolutions r ON r.blotter_id = b.BlotterID WHERE $in", [$from, $to]);
    $t['avg_hearings_before_resolution'] = $hb ? round(array_sum(array_column($hb, 'n')) / count($hb), 2) : null;

    // Hearing count distribution per case.
    $dist = ['0' => 0, '1' => 0, '2' => 0, '3' => 0, '4+' => 0];
    foreach ($rq("SELECT (SELECT COUNT(*) FROM blotter_hearings h WHERE h.blotter_id = b.BlotterID AND h.status <> 'Cancelled') n FROM blotter b WHERE $in", [$from, $to]) as $r) {
        $n = (int)$r['n']; $dist[$n >= 4 ? '4+' : (string)$n]++;
    }

    // Cases over time (daily up to 92 days, else monthly): filed, resolved, transferred.
    $days = (int)((strtotime($p['to']) - strtotime($p['from'])) / 86400) + 1;
    $monthly = $days > 92;
    $fmt = $monthly ? '%Y-%m' : '%Y-%m-%d';
    $map = function (array $rows) { $o = []; foreach ($rows as $r) $o[$r['k']] = (int)$r['n']; return $o; };
    $fMap = $map($rq("SELECT DATE_FORMAT($filed, '$fmt') k, COUNT(*) n FROM blotter b WHERE $in GROUP BY k", [$from, $to]));
    $rMap = $map($rq("SELECT DATE_FORMAT(r.resolved_at, '$fmt') k, COUNT(*) n FROM blotter b JOIN blotter_resolutions r ON r.blotter_id = b.BlotterID WHERE $in AND r.resolved_at BETWEEN ? AND ? GROUP BY k", [$from, $to, $from, $to]));
    $tMap = $map($rq("SELECT DATE_FORMAT(t.transfer_date, '$fmt') k, COUNT(*) n FROM blotter b JOIN blotter_transfers t ON t.blotter_id = b.BlotterID WHERE $in AND t.transfer_date BETWEEN ? AND ? GROUP BY k", [$from, $to, $p['from'], $p['to']]));
    $labels = []; $sF = []; $sR = []; $sT = [];
    $cur = strtotime($monthly ? date('Y-m-01', strtotime($p['from'])) : $p['from']);
    $end = strtotime($p['to']);
    while ($cur <= $end) {
        $k = date($monthly ? 'Y-m' : 'Y-m-d', $cur);
        $labels[] = date($monthly ? 'M Y' : 'M j', $cur);
        $sF[] = $fMap[$k] ?? 0; $sR[] = $rMap[$k] ?? 0; $sT[] = $tMap[$k] ?? 0;
        $cur = strtotime($monthly ? '+1 month' : '+1 day', $cur);
    }

    $byType = $rq("SELECT COALESCE(NULLIF(b.IncidentType,''),'Not set') label, COUNT(*) n, SUM(b.Status IN ('Resolved','Closed')) resolved, SUM(b.Status IN ('For Transfer','Transferred')) transferred
                   FROM blotter b WHERE $in GROUP BY label ORDER BY n DESC", [$from, $to]);
    $byStatus = $rq("SELECT b.Status label, COUNT(*) n FROM blotter b WHERE $in GROUP BY b.Status ORDER BY n DESC", [$from, $to]);
    $byLocation = $rq("SELECT COALESCE(NULLIF(b.Location,''),'Not set') label, COUNT(*) n FROM blotter b WHERE $in GROUP BY label ORDER BY n DESC LIMIT 8", [$from, $to]);
    $dow = array_fill(0, 7, 0);
    foreach ($rq("SELECT WEEKDAY(b.IncidentDate) d, COUNT(*) n FROM blotter b WHERE $in AND b.IncidentDate IS NOT NULL GROUP BY d", [$from, $to]) as $r) $dow[(int)$r['d']] = (int)$r['n'];
    $hours = array_fill(0, 24, 0);
    foreach ($rq("SELECT HOUR(b.IncidentTime) hr, COUNT(*) n FROM blotter b WHERE $in AND b.IncidentTime IS NOT NULL GROUP BY hr", [$from, $to]) as $r) $hours[(int)$r['hr']] = (int)$r['n'];
    $dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    $recent = $rq("SELECT b.BlotterID, b.CaseNumber, b.IncidentType, b.IncidentTypeOther, b.Status, b.ComplainantName, b.RespondentName, $filed filed_at
                   FROM blotter b WHERE $in ORDER BY $filed DESC LIMIT 10", [$from, $to]);

    return [
        'params' => $p, 'monthly' => $monthly, 'days' => $days,
        'totals' => $t,
        'series' => ['labels' => $labels, 'filed' => $sF, 'resolved' => $sR, 'transferred' => $sT],
        'by_type' => array_map(fn($r) => ['label' => $r['label'], 'n' => (int)$r['n'], 'resolved' => (int)$r['resolved'], 'transferred' => (int)$r['transferred']], $byType),
        'by_status' => array_map(fn($r) => ['label' => $r['label'], 'n' => (int)$r['n']], $byStatus),
        'by_location' => array_map(fn($r) => ['label' => $r['label'], 'n' => (int)$r['n']], $byLocation),
        'outcomes' => array_map(fn($r) => ['label' => $r['label'], 'n' => (int)$r['n']], $outcomes),
        'no_show' => $noShow,
        'hearing_dist' => $dist,
        'resolution_buckets' => $buckets,
        'weekday' => ['labels' => ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], 'data' => $dow, 'busiest' => max($dow) ? $dayNames[array_search(max($dow), $dow, true)] : null],
        'hours' => ['labels' => array_map(fn($x) => date('g A', mktime($x, 0)), range(0, 23)), 'data' => $hours,
                    'busiest' => max($hours) ? date('g A', mktime(array_search(max($hours), $hours, true), 0)) : null],
        'recent' => array_map(fn($r) => ['case_number' => $r['CaseNumber'], 'type' => blt_case_type_label($r), 'status' => $r['Status'],
            'complainant' => $r['ComplainantName'], 'respondent' => $r['RespondentName'], 'filed' => date('M j, Y', strtotime($r['filed_at']))], $recent),
    ];
}

/** Chart.js-ready data (page and printable report use the same). */
function blt_analytics_chart_data(array $a): array {
    $t = $a['totals'];
    return [
        'series' => $a['series'], 'monthly' => $a['monthly'],
        'byType' => ['labels' => array_column($a['by_type'], 'label'), 'data' => array_column($a['by_type'], 'n')],
        'byStatus' => ['labels' => array_column($a['by_status'], 'label'), 'data' => array_column($a['by_status'], 'n')],
        'resolution' => ['labels' => ['Resolved', 'Transferred', 'Still active', 'Cancelled / Withdrawn'], 'data' => [$t['resolved'], $t['transferred'] + $t['for_transfer'], $t['active'], $t['cancelled']]],
        'hearingDist' => ['labels' => array_map(fn($k) => $k . ' hearing' . ($k === '1' ? '' : 's'), array_keys($a['hearing_dist'])), 'data' => array_values($a['hearing_dist'])],
        'noShow' => ['labels' => array_keys($a['no_show']), 'data' => array_values($a['no_show'])],
        'outcomes' => ['labels' => array_column($a['outcomes'], 'label'), 'data' => array_column($a['outcomes'], 'n')],
        'resolutionTime' => ['labels' => array_keys($a['resolution_buckets']), 'data' => array_values($a['resolution_buckets'])],
        'byLocation' => ['labels' => array_column($a['by_location'], 'label'), 'data' => array_column($a['by_location'], 'n')],
        'weekday' => $a['weekday'], 'hours' => $a['hours'],
    ];
}

/** Rule-based insights: shown when AI is unavailable, and used in the report explanations. */
function blt_analytics_rules(array $a): array {
    $t = $a['totals'];
    if (!$t['total']) return ['key_findings' => [['title' => 'No cases', 'detail' => 'No blotter cases were filed in this period.', 'severity' => 'info']], 'trends' => [], 'resolution_patterns' => [], 'actions' => []];
    $f = []; $tr = []; $rp = []; $ac = [];
    $f[] = ['title' => $t['total'] . ' case(s) filed', 'detail' => $t['active'] . ' active, ' . $t['resolved'] . ' resolved, ' . ($t['for_transfer'] + $t['transferred']) . ' for transfer / transferred.', 'severity' => 'info'];
    if ($a['by_type']) $f[] = ['title' => 'Most common: ' . $a['by_type'][0]['label'], 'detail' => $a['by_type'][0]['n'] . ' of ' . $t['total'] . ' cases (' . round($a['by_type'][0]['n'] / $t['total'] * 100) . '%).', 'severity' => 'info'];
    if ($t['resolution_rate'] !== null) $f[] = ['title' => 'Resolution rate ' . $t['resolution_rate'] . '%', 'detail' => $t['resolved'] . ' resolved vs ' . $t['transferred'] . ' transferred among decided cases.', 'severity' => $t['resolution_rate'] >= 60 ? 'good' : 'warning'];
    if ($t['no_shows']) $f[] = ['title' => $t['no_shows'] . ' no-show hearing(s)', 'detail' => 'Complainant ' . $a['no_show']['Complainant No Show'] . ', respondent ' . $a['no_show']['Respondent No Show'] . ', both ' . $a['no_show']['Both No Show'] . '.', 'severity' => 'warning'];

    $s = $a['series']; $n = count($s['labels']);
    if ($n >= 4) {
        $half = intdiv($n, 2);
        $first = array_sum(array_slice($s['filed'], 0, $half)); $second = array_sum(array_slice($s['filed'], $half));
        $dir = $second > $first ? 'up' : ($second < $first ? 'down' : 'stable');
        $tr[] = ['title' => 'Filings ' . ['up' => 'increasing', 'down' => 'decreasing', 'stable' => 'steady'][$dir], 'detail' => 'First half: ' . $first . ', second half: ' . $second . '.', 'direction' => $dir];
    }
    if ($a['weekday']['busiest']) $tr[] = ['title' => 'Most incidents on ' . $a['weekday']['busiest'], 'detail' => 'Peak incident hour ' . ($a['hours']['busiest'] ?? '—') . '.', 'direction' => 'stable'];

    if ($t['avg_resolution_min'] !== null) $rp[] = ['title' => 'Average resolution ' . blt_fmt_duration($t['avg_resolution_min']), 'detail' => 'From filing to settlement for resolved cases.'];
    if ($t['avg_hearings_before_resolution'] !== null) $rp[] = ['title' => $t['avg_hearings_before_resolution'] . ' hearing(s) before resolution', 'detail' => 'Average completed hearings of resolved cases.'];
    foreach (array_slice($a['by_type'], 0, 3) as $ty) {
        if ($ty['n'] >= 2) $rp[] = ['title' => $ty['label'], 'detail' => $ty['resolved'] . ' of ' . $ty['n'] . ' resolved, ' . $ty['transferred'] . ' transferred.'];
    }

    if ($t['for_transfer']) $ac[] = ['action' => 'Transfer the ' . $t['for_transfer'] . ' case(s) waiting for transfer', 'reason' => 'They reached the configured limit.', 'priority' => 'high'];
    if ($t['no_shows']) $ac[] = ['action' => 'Serve notices earlier and confirm receipt', 'reason' => $t['no_shows'] . ' hearing(s) had a no-show.', 'priority' => 'medium'];
    if ($a['by_type']) $ac[] = ['action' => 'Run an awareness drive about ' . $a['by_type'][0]['label'], 'reason' => 'It is the most frequent case type.', 'priority' => 'low'];
    if ($a['by_location'] && $a['by_location'][0]['n'] >= 2) $ac[] = ['action' => 'Increase tanod patrols around ' . $a['by_location'][0]['label'], 'reason' => $a['by_location'][0]['n'] . ' incidents happened there.', 'priority' => 'medium'];
    return ['key_findings' => array_slice($f, 0, 4), 'trends' => array_slice($tr, 0, 3), 'resolution_patterns' => array_slice($rp, 0, 3), 'actions' => array_slice($ac, 0, 4)];
}

/** Aggregated numbers only — this is all the AI ever sees (no names, addresses or contact numbers). */
function blt_analytics_snapshot(array $a): array {
    $t = $a['totals'];
    return [
        'period' => $a['params'], 'days' => $a['days'],
        'totals' => array_diff_key($t, array_flip(['avg_resolution_min'])),
        'average_resolution_time' => blt_fmt_duration($t['avg_resolution_min']),
        'by_case_type' => array_map(fn($d) => [$d['label'], $d['n'], 'resolved' => $d['resolved'], 'transferred' => $d['transferred']], $a['by_type']),
        'status' => array_map(fn($d) => [$d['label'], $d['n']], $a['by_status']),
        'hearing_outcomes' => array_map(fn($d) => [$d['label'], $d['n']], $a['outcomes']),
        'no_show' => $a['no_show'], 'hearings_per_case' => $a['hearing_dist'], 'resolution_time_buckets' => $a['resolution_buckets'],
        'top_locations' => array_map(fn($d) => [$d['label'], $d['n']], $a['by_location']),
        'over_time' => $a['series'],
        'incident_weekday' => array_combine($a['weekday']['labels'], $a['weekday']['data']), 'busiest_incident_hour' => $a['hours']['busiest'],
    ];
}

/* ─────────────────────────────────────────────────────────────────────────────
 * Uniform Blotter Analytics (same behavior as Resident / Household / Legal Document /
 * Disaster / Announcement Analytics): Start / End Date optional — empty = all records.
 *   $p = ra_params($_GET|$_POST);  $a = blt_analytics_uniform($pdo, $p);
 * ───────────────────────────────────────────────────────────────────────────── */
require_once __DIR__ . '/../../residents/backend/resident_analytics_data.php'; // ra_params, ra_range_label, ra_pct

function blt_analytics_uniform(PDO $pdo, array $p): array {
    $open = $p['start'] === '' || $p['end'] === '';
    $from = $p['start']; $to = $p['end'];
    if ($from === '') {
        $min = $pdo->query("SELECT MIN(DATE(COALESCE(FiledAt, CreatedAt))) FROM blotter")->fetchColumn();
        $from = $min ?: date('Y-m-d');
    }
    if ($to === '') $to = max(date('Y-m-d'), $from);
    $a = blt_analytics_compute($pdo, ['from' => $from, 'to' => $to]);
    $a['period'] = $p;
    $a['range'] = ['label' => $p['label'], 'open' => $open, 'from' => $from, 'to' => $to];

    // Every case filed in the range (Case Records table).
    $s = $pdo->prepare("SELECT b.*, (SELECT COUNT(*) FROM blotter_hearings h WHERE h.blotter_id = b.BlotterID AND h.status <> 'Cancelled') hearings
                        FROM blotter b WHERE COALESCE(b.FiledAt, b.CreatedAt) BETWEEN ? AND ? ORDER BY COALESCE(b.FiledAt, b.CreatedAt) DESC, b.BlotterID DESC LIMIT 1000");
    $s->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
    $a['records'] = array_map(fn($r) => [
        'id' => (int)$r['BlotterID'], 'case_number' => $r['CaseNumber'] ?: ('#' . $r['BlotterID']), 'type' => blt_case_type_label($r) ?: '—',
        'complainant' => $r['ComplainantName'] ?: '—', 'respondent' => $r['RespondentName'] ?: '—', 'location' => $r['Location'] ?: '—',
        'incident' => $r['IncidentDate'] ? date('M j, Y', strtotime($r['IncidentDate'])) : '—',
        'filed' => date('M j, Y', strtotime($r['FiledAt'] ?: $r['CreatedAt'])), 'status' => $r['Status'], 'hearings' => (int)$r['hearings'],
    ], $s->fetchAll(PDO::FETCH_ASSOC));

    // Selected period vs the previous period of the same length (only with both dates).
    $a['comparison'] = null;
    if (!$open) {
        $days = (int)((strtotime($to) - strtotime($from)) / 86400) + 1;
        $pe = date('Y-m-d', strtotime($from . ' -1 day')); $ps = date('Y-m-d', strtotime($pe . ' -' . ($days - 1) . ' days'));
        $prev = blt_analytics_compute($pdo, ['from' => $ps, 'to' => $pe])['totals'];
        $t = $a['totals'];
        $a['comparison'] = ['previous_label' => ra_range_label($ps, $pe), 'rows' => [
            ['metric' => 'Cases filed', 'current' => $t['total'], 'previous' => $prev['total']],
            ['metric' => 'Resolved', 'current' => $t['resolved'], 'previous' => $prev['resolved']],
            ['metric' => 'Transferred / for transfer', 'current' => $t['transferred'] + $t['for_transfer'], 'previous' => $prev['transferred'] + $prev['for_transfer']],
            ['metric' => 'Hearings', 'current' => $t['hearings'], 'previous' => $prev['hearings']],
            ['metric' => 'No-shows', 'current' => $t['no_shows'], 'previous' => $prev['no_shows']],
        ]];
    }
    $a['interpretation'] = blt_analytics_interpretation($a);
    return $a;
}

/** Data Interpretation (automatic, no AI) — page and report. */
function blt_analytics_interpretation(array $a): array {
    $t = $a['totals']; $L = $a['range']['label'];
    if (!$t['total']) return ['No blotter cases were filed for ' . $L . '.'];
    $o = [];
    $o[] = $t['total'] . ' case(s) were filed for ' . $L . ': ' . $t['active'] . ' active, ' . $t['resolved'] . ' resolved / closed, '
        . $t['for_transfer'] . ' for transfer, ' . $t['transferred'] . ' transferred and ' . $t['cancelled'] . ' cancelled / withdrawn.';
    if ($a['by_type']) $o[] = 'The most common case type is ' . $a['by_type'][0]['label'] . ' with ' . $a['by_type'][0]['n'] . ' case(s) (' . ra_pct($a['by_type'][0]['n'], $t['total']) . '%).';
    if ($t['resolution_rate'] !== null) $o[] = 'The barangay settled ' . $t['resolution_rate'] . '% of the decided cases (' . $t['resolved'] . ' resolved vs ' . $t['transferred'] . ' transferred).';
    if ($t['avg_resolution_min'] !== null) $o[] = 'Resolved cases took ' . blt_fmt_duration($t['avg_resolution_min']) . ' on average from filing to settlement'
        . ($t['avg_hearings_before_resolution'] !== null ? ', with ' . $t['avg_hearings_before_resolution'] . ' completed hearing(s) per case.' : '.');
    $o[] = $t['hearings'] . ' hearing(s) were set for these cases (' . $t['hearings_completed'] . ' completed, ' . $t['hearings_scheduled'] . ' still scheduled)'
        . ($t['no_shows'] ? '; ' . $t['no_shows'] . ' had a no-show.' : '; no no-shows were recorded.');
    if ($a['by_location'] && $a['by_location'][0]['label'] !== 'Not set') $o[] = 'Most incidents happened at ' . $a['by_location'][0]['label'] . ' (' . $a['by_location'][0]['n'] . ' case(s)).';
    if ($a['weekday']['busiest']) $o[] = 'Incidents happened most on ' . $a['weekday']['busiest'] . ($a['hours']['busiest'] ? ', around ' . $a['hours']['busiest'] : '') . '.';
    if ($t['for_transfer']) $o[] = $t['for_transfer'] . ' case(s) reached the configured limit and are waiting to be transferred.';
    if ($a['comparison']) {
        $c = $a['comparison']['rows'][0]; $x = $c['current'] - $c['previous'];
        $o[] = 'Compared with the previous period (' . $a['comparison']['previous_label'] . '), filings ' . ($x > 0 ? 'increased by ' . $x : ($x < 0 ? 'decreased by ' . abs($x) : 'stayed the same')) . ' (' . $c['previous'] . ' → ' . $c['current'] . ').';
    }
    return $o;
}

/** Key of the saved AI result (aggregated figures only). */
function blt_analytics_ai_snapshot(array $a): array {
    return ['range' => $a['range']['label']] + blt_analytics_snapshot($a) + ['comparison' => $a['comparison']];
}
