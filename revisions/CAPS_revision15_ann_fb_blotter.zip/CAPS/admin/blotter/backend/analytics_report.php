<?php
/**
 * Blotter Analytics Report — opened from Blotter Analytics with ?start&end&mode=print|pdf&ai=1|0.
 * Same shared CAPS report layout (officials report_common.php) and behavior as the Resident, Household,
 * Legal Document, Disaster and Announcement Analytics reports: data / table focused, with interpretation.
 *   ai=0 → "No AI – Data and tables only" (no charts)
 *   ai=1 → supporting charts + the AI Analytics already generated on the page (AI cache — never calls Gemini).
 * Barangay name / logo / address, date range, logged-in user and the present Barangay Captain are included.
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../db.php';
$required_module = 'blotter';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/analytics_data.php';
require_once __DIR__ . '/../../ai_helper.php';
blt_require_report_common();
blt_migrate($pdo);

$mode = report_mode();
$p = ra_params($_GET);
$a = blt_analytics_uniform($pdo, $p);
$t = $a['totals'];
$withAi = ($_GET['ai'] ?? '0') === '1';
$ai = $withAi ? ai_cache_get('blotter_analytics', blt_analytics_ai_snapshot($a)) : null;
$showCharts = $ai !== null;
$set = blt_settings($pdo);

$brgy = report_barangay_profile($pdo);
$bAddr = blt_barangay($pdo)['address'];
$captain = report_current_captain($pdo);
$generatedBy = report_generated_by($pdo);
$generatedRole = ($_SESSION['role'] ?? '') === 'admin' ? 'Administrator' : 'Barangay Staff';
if ($mode !== '') blt_log_activity('Blotter Analytics Report', ($mode === 'pdf' ? 'Saved PDF' : 'Printed') . ' blotter analytics report · ' . $a['range']['label'] . ($ai ? ' · with AI findings' : ''));

$n = fn($v) => number_format((float)$v);
$pc = fn($v, $d) => ra_pct($v, $d) . '%';
$T = max(1, (int)$t['total']);
function bar_table(array $head, array $rows, string $empty = 'None recorded for the selected range.', array $right = []): void {
    if (!$rows) { echo '<p class="empty-note">' . rh($empty) . '</p>'; return; }
    echo '<table><thead><tr>';
    foreach ($head as $i => $h) echo '<th' . (in_array($i, $right, true) ? ' class="num"' : '') . '>' . rh($h) . '</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr' . (($row[0] ?? '') === 'Total' ? ' class="total"' : '') . '>';
        foreach (array_values($row) as $i => $c) echo '<td' . (in_array($i, $right, true) ? ' class="num"' : '') . '>' . rh($c) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
}
$dist = function (array $pairs, int $base) use ($n, $pc): array {
    $rows = []; $sum = 0;
    foreach ($pairs as $k => $v) { $rows[] = [(string)$k, $n($v), $pc($v, $base)]; $sum += $v; }
    if ($rows) $rows[] = ['Total', $n($sum), $pc($sum, $base)];
    return $rows;
};
$kv = fn(array $list) => array_combine(array_column($list, 'label'), array_column($list, 'n')) ?: [];

$title = 'Blotter Analytics Report';
report_head($title, $mode);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<?php report_toolbar($mode, 'blotter_analytics_' . ($p['start'] ?: 'all') . '_to_' . ($p['end'] ?: 'all'), 'landscape'); ?>
<style>
    .brgy-addr{text-align:center;font-size:11px;color:#64748b;margin:-12px 0 14px}
    .report-page{max-width:1100px}
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 24px}
    table.kv th{width:42%;background:transparent;font-size:10.5px;color:#64748b}
    table.kv td{font-weight:700}
    td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
    tr.total td{font-weight:800;border-top:1.5px solid #94a3b8;background:#f8fafc}
    th,td{font-size:10.5px}
    .note{margin:10px 0 0;font-size:11.5px;line-height:1.55;color:#334155}
    .sub{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#0d9488;margin:14px 0 4px}
    .sub:first-child{margin-top:0}
    .grid2{display:grid;grid-template-columns:1fr 1fr;gap:0 20px}
    .chart-wrap{position:relative;height:200px;margin:6px 0 4px}
    .chart-cap{font-size:10px;color:#64748b;margin:0 0 4px}
    ol.interp{margin:0;padding-left:18px;font-size:12px;line-height:1.6}
    .ai-item{padding:6px 0;border-bottom:1px solid #e2e8f0;font-size:12px}
    .ai-item:last-child{border-bottom:0}
    .ai-pri{display:inline-block;padding:1px 6px;border-radius:99px;font-size:9px;font-weight:800;text-transform:uppercase;margin-left:6px}
    .pri-high{background:#fee2e2;color:#b91c1c}.pri-medium{background:#fef3c7;color:#b45309}.pri-low{background:#f1f5f9;color:#475569}
    .section-wrap{page-break-inside:auto;break-inside:auto}
    tr,.chart-wrap,.stat-grid,.signature-block,.certify-line{page-break-inside:avoid;break-inside:avoid}
    h2.section{page-break-after:avoid;break-after:avoid}
</style>
<div class="report-page" id="reportRoot">
    <?php report_letterhead($brgy, 'Office of the Punong Barangay · Blotter / Case Management'); ?>
    <?php if ($bAddr): ?><p class="brgy-addr"><?php echo rh($bAddr); ?></p><?php endif; ?>
    <?php report_title_block($title, 'Cases, hearings, resolutions and transfers · ' . $a['range']['label'], 'Katarungang Pambarangay'); ?>

    <?php report_section_open('Report Information'); ?>
    <div class="info-grid">
        <table class="kv"><tbody>
            <tr><th>Date range</th><td><?php echo rh($a['range']['label']); ?></td></tr>
            <tr><th>Basis</th><td>Cases by date filed</td></tr>
            <tr><th>Cases covered</th><td><?php echo $n($t['total']); ?></td></tr>
            <tr><th>Case limit rule</th><td><?php echo rh(blt_rule_label($set['rule_type'], $set['max_days'], $set['max_hearings']) . ' · then transfer to ' . blt_settings_destination($set)); ?></td></tr>
        </tbody></table>
        <table class="kv"><tbody>
            <tr><th>Generated by</th><td><?php echo rh($generatedBy); ?></td></tr>
            <tr><th>Date generated</th><td><?php echo rh(date('F j, Y g:i A')); ?></td></tr>
            <tr><th>Barangay Captain</th><td><?php echo rh($captain ? 'Hon. ' . $captain['full_name'] : 'Not assigned'); ?></td></tr>
        </tbody></table>
    </div>
    <?php report_section_close(); ?>

    <?php report_section_open('Case Summary'); ?>
    <?php report_stat_cards([
        ['value' => $n($t['total']), 'label' => 'Total Cases', 'variant' => 'a'],
        ['value' => $n($t['active']), 'label' => 'Active', 'variant' => 'b'],
        ['value' => $n($t['resolved']), 'label' => 'Resolved / Closed', 'variant' => 'c'],
        ['value' => $n($t['transferred'] + $t['for_transfer']), 'label' => 'For Transfer / Transferred', 'variant' => 'd'],
    ]); ?>
    <div style="margin-top:12px"></div>
    <?php bar_table(['Indicator', 'Value'], [
        ['Unresolved (active + for transfer + transferred)', $n($t['unresolved'])],
        ['Waiting for transfer / transferred', $n($t['for_transfer']) . ' / ' . $n($t['transferred'])],
        ['Cancelled / withdrawn', $n($t['cancelled'])],
        ['Resolution rate (resolved ÷ decided)', $t['resolution_rate'] !== null ? $t['resolution_rate'] . '%' : '—'],
        ['Average resolution time', blt_fmt_duration($t['avg_resolution_min'])],
        ['Average hearings before resolution', $t['avg_hearings_before_resolution'] ?? '—'],
        ['Hearings (completed / scheduled)', $n($t['hearings']) . ' (' . $n($t['hearings_completed']) . ' / ' . $n($t['hearings_scheduled']) . ')'],
        ['No-show hearings', $n($t['no_shows'])],
    ], '', [1]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Case Types & Status'); ?>
    <p class="sub">Case types</p>
    <?php $rows = array_map(fn($d) => [$d['label'], $n($d['n']), $pc($d['n'], $T), $n($d['resolved']), $n($d['transferred'])], $a['by_type']);
    if ($rows) $rows[] = ['Total', $n($t['total']), $t['total'] ? '100%' : '0%', $n(array_sum(array_column($a['by_type'], 'resolved'))), $n(array_sum(array_column($a['by_type'], 'transferred')))];
    bar_table(['Case type', 'Cases', 'Share', 'Resolved', 'Transferred'], $rows, 'No cases.', [1, 2, 3, 4]); ?>
    <?php if ($showCharts && $a['by_type']): ?>
    <p class="chart-cap">Figure 1. Cases per case type</p>
    <div class="chart-wrap"><canvas id="rc-type"></canvas></div>
    <?php endif; ?>
    <p class="sub">Case status</p>
    <?php bar_table(['Status', 'Cases', 'Share'], $dist($kv($a['by_status']), $T), 'No cases.', [1, 2]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Hearings & Resolution'); ?>
    <div class="grid2">
        <div><p class="sub">Hearing results</p><?php bar_table(['Outcome', 'Hearings', 'Share'], $dist($kv($a['outcomes']), max(1, array_sum(array_column($a['outcomes'], 'n')))), 'No hearing results.', [1, 2]); ?></div>
        <div><p class="sub">No-shows</p><?php bar_table(['No-show', 'Hearings'], array_map(fn($k, $v) => [$k, $n($v)], array_keys($a['no_show']), $a['no_show']), '', [1]); ?></div>
        <div><p class="sub">Hearings per case</p><?php bar_table(['Hearings', 'Cases', 'Share'], $dist(array_combine(array_map(fn($k) => $k . ' hearing' . ($k === '1' ? '' : 's'), array_keys($a['hearing_dist'])), array_values($a['hearing_dist'])), $T), 'No cases.', [1, 2]); ?></div>
        <div><p class="sub">Resolution time (filing → settlement)</p><?php bar_table(['Time', 'Cases', 'Share'], array_sum($a['resolution_buckets']) ? $dist($a['resolution_buckets'], max(1, array_sum($a['resolution_buckets']))) : [], 'No resolved case.', [1, 2]); ?></div>
    </div>
    <?php if ($showCharts && $t['total']): ?>
    <p class="chart-cap">Figure 2. Case outcome (resolved, transferred, still active, cancelled)</p>
    <div class="chart-wrap"><canvas id="rc-res"></canvas></div>
    <?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Trends & Comparison'); ?>
    <?php $rows = [];
    foreach ($a['series']['labels'] as $i => $lbl) {
        $f = $a['series']['filed'][$i]; $r = $a['series']['resolved'][$i]; $x = $a['series']['transferred'][$i];
        if ($f + $r + $x || $a['monthly']) $rows[] = [$lbl, $n($f), $n($r), $n($x)];
    }
    bar_table([$a['monthly'] ? 'Month' : 'Day', 'Filed', 'Resolved', 'Transferred'], $rows, 'No cases in this range.', [1, 2, 3]); ?>
    <?php if ($showCharts && count($a['series']['labels']) > 1): ?>
    <p class="chart-cap">Figure 3. Cases over time</p>
    <div class="chart-wrap"><canvas id="rc-trend"></canvas></div>
    <?php endif; ?>
    <div class="grid2">
        <div><p class="sub">Incidents by day of the week</p><?php bar_table(['Day', 'Incidents', 'Share'], array_sum($a['weekday']['data']) ? $dist(array_combine($a['weekday']['labels'], $a['weekday']['data']), max(1, array_sum($a['weekday']['data']))) : [], 'No incident dates.', [1, 2]); ?></div>
        <div><p class="sub">Top incident locations</p><?php bar_table(['Location', 'Cases', 'Share'], array_map(fn($d) => [$d['label'], $n($d['n']), $pc($d['n'], $T)], $a['by_location']), 'No locations.', [1, 2]); ?></div>
    </div>
    <?php if ($a['comparison']): ?>
    <p class="sub">Selected period vs previous period (<?php echo rh($a['comparison']['previous_label']); ?>)</p>
    <?php bar_table(['Indicator', 'Selected period', 'Previous period', 'Change'], array_map(function ($r) use ($n) { $x = $r['current'] - $r['previous']; return [$r['metric'], $n($r['current']), $n($r['previous']), ($x > 0 ? '+' : '') . $n($x)]; }, $a['comparison']['rows']), '', [1, 2, 3]); ?>
    <?php else: ?><p class="note">Set both a Start Date and an End Date to compare with the previous period of the same length.</p><?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Case Records'); ?>
    <?php bar_table(['Blotter ID', 'Complainant', 'Respondent', 'Case type', 'Incident', 'Location', 'Filed', 'Hearings', 'Status'],
        array_map(fn($r) => [$r['case_number'], $r['complainant'], $r['respondent'], $r['type'], $r['incident'], $r['location'], $r['filed'], $n($r['hearings']), $r['status']], $a['records']),
        'No cases were filed in this range.', [7]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Data Interpretation'); ?>
    <ol class="interp"><?php foreach ($a['interpretation'] as $x): ?><li><?php echo rh($x); ?></li><?php endforeach; ?></ol>
    <?php report_section_close(); ?>

    <?php if ($ai): ?>
    <?php report_section_open('AI Findings'); ?>
        <?php if (!empty($ai['summary'])): ?><p class="note"><?php echo rh($ai['summary']); ?></p><?php endif; ?>
        <?php foreach ([['Key Findings', 'key_findings'], ['Trends', 'demographic_trends'], ['Resolution Patterns', 'patterns'], ['Parties & Hearings Observations', 'population_observations']] as [$lbl, $key]):
            if (empty($ai[$key])) continue; ?>
            <p class="sub"><?php echo rh($lbl); ?></p>
            <?php foreach ($ai[$key] as $f): ?><div class="ai-item"><strong><?php echo rh($f['title']); ?></strong> — <?php echo rh($f['detail']); ?></div><?php endforeach; ?>
        <?php endforeach; ?>
        <?php if (!empty($ai['recommendations'])): ?>
            <p class="sub">Recommended Administrative Actions</p>
            <?php foreach ($ai['recommendations'] as $i => $f): ?><div class="ai-item"><?php echo $i + 1; ?>. <strong><?php echo rh($f['action']); ?></strong><span class="ai-pri pri-<?php echo rh($f['priority']); ?>"><?php echo rh($f['priority']); ?></span><br><span style="color:#64748b"><?php echo rh($f['reason']); ?></span></div><?php endforeach; ?>
        <?php endif; ?>
        <p style="margin:8px 0 0;font-size:10px;color:#64748b">AI-generated (Gemini) · <?php echo rh($ai['generated_at'] ?? ''); ?> · based on the aggregated blotter data of <?php echo rh($a['range']['label']); ?>. Verify against the tables above.</p>
    <?php report_section_close(); ?>
    <?php elseif ($withAi): ?>
    <?php report_section_open('AI Findings'); ?><p class="note">No AI Analytics has been generated for this data yet.</p><?php report_section_close(); ?>
    <?php endif; ?>

    <?php report_certify_and_signatures($brgy['brgy_name'] ?? 'Barangay', $generatedBy, $generatedRole, $captain); ?>
    <?php report_footer_strip($brgy['brgy_name'] ?? 'Barangay'); ?>
</div>
<script>
(function () {
    if (!window.Chart) return;
    Chart.defaults.animation = false;
    Chart.defaults.font.family = 'Arial, Helvetica, sans-serif';
    Chart.defaults.font.size = 10;
    Chart.defaults.color = '#475569';
    const grid = { color: '#e2e8f0' };
    const legend = { position: 'top', align: 'end', labels: { boxWidth: 10 } };
    const a = <?php echo json_encode(['type' => $a['by_type'], 'series' => $a['series'], 'totals' => $t], JSON_UNESCAPED_UNICODE); ?>;
    const el = id => document.getElementById(id);
    if (el('rc-type')) new Chart(el('rc-type'), { type: 'bar', data: { labels: a.type.map(x => x.label), datasets: [
        { label: 'Cases', data: a.type.map(x => x.n), backgroundColor: '#2a78d6', borderRadius: 3, maxBarThickness: 22 },
        { label: 'Resolved', data: a.type.map(x => x.resolved), backgroundColor: '#1baf7a', borderRadius: 3, maxBarThickness: 22 },
        { label: 'Transferred', data: a.type.map(x => x.transferred), backgroundColor: '#e11d48', borderRadius: 3, maxBarThickness: 22 }] },
        options: { maintainAspectRatio: false, plugins: { legend }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
    const t = a.totals;
    if (el('rc-res')) new Chart(el('rc-res'), { type: 'bar', data: { labels: ['Resolved / Closed', 'For transfer / Transferred', 'Still active', 'Cancelled / Withdrawn'],
        datasets: [{ data: [t.resolved, t.transferred + t.for_transfer, t.active, t.cancelled], backgroundColor: ['#1baf7a', '#e11d48', '#eb6834', '#94a3b8'], borderRadius: 3, maxBarThickness: 40 }] },
        options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
    const s = a.series, line = (label, data, color) => ({ label, data, borderColor: color, backgroundColor: color, borderWidth: 2, pointRadius: s.labels.length > 40 ? 0 : 2, tension: 0 });
    if (el('rc-trend')) new Chart(el('rc-trend'), { type: 'line', data: { labels: s.labels, datasets: [line('Filed', s.filed, '#2a78d6'), line('Resolved', s.resolved, '#1baf7a'), line('Transferred', s.transferred, '#e11d48')] },
        options: { maintainAspectRatio: false, plugins: { legend }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
})();
</script>
<?php report_foot(); ?>
