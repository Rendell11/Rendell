<?php
/**
 * Blotter Case Masterlist — opened from Blotter / Case Management (hero Save PDF / Print)
 * with ?mode=pdf|print&tab&status&type&from&to&q. Same filters as the case list (incidents.php,
 * without paging) and the same shared CAPS report layout (officials report_common.php) as the
 * Resident / Household masterlists and the analytics reports: barangay info, filters, summary,
 * table, logged-in user, present Barangay Captain, certification and signatures.
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../db.php';
$required_module = 'blotter';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/blotter_common.php';
blt_require_report_common();
blt_migrate($pdo);

$mode = report_mode();
$tabs = ['all' => 'All Cases', 'active' => 'Active', 'hearing' => 'Hearing Scheduled', 'resolved' => 'Resolved / Closed', 'transfer' => 'For Transfer / Transferred', 'cancelled' => 'Cancelled / Withdrawn'];
$tab = array_key_exists($_GET['tab'] ?? '', $tabs) ? $_GET['tab'] : 'all';
$status = in_array($_GET['status'] ?? '', blt_statuses(), true) ? $_GET['status'] : '';
$type = trim((string)($_GET['type'] ?? ''));
$from = blt_valid_date($_GET['from'] ?? null) ? $_GET['from'] : '';
$to = blt_valid_date($_GET['to'] ?? null) ? $_GET['to'] : '';
$q = mb_substr(trim((string)($_GET['q'] ?? '')), 0, 100);

// Same filters as blotter_cases.php?action=list
$groups = [
    'active' => array_values(array_diff(blt_active_statuses(), [BLT_ST_FOR_TRANSFER])),
    'hearing' => blt_hearing_pending_statuses(),
    'resolved' => [BLT_ST_RESOLVED, BLT_ST_CLOSED],
    'transfer' => [BLT_ST_FOR_TRANSFER, BLT_ST_TRANSFERRED],
    'cancelled' => [BLT_ST_CANCELLED, BLT_ST_WITHDRAWN],
];
$where = ['1=1']; $args = [];
if (isset($groups[$tab])) { $where[] = 'b.Status IN (' . implode(',', array_fill(0, count($groups[$tab]), '?')) . ')'; array_push($args, ...$groups[$tab]); }
if ($status !== '') { $where[] = 'b.Status = ?'; $args[] = $status; }
if ($type !== '') { $where[] = 'b.IncidentType = ?'; $args[] = $type; }
if ($from !== '') { $where[] = 'DATE(COALESCE(b.FiledAt, b.CreatedAt)) >= ?'; $args[] = $from; }
if ($to !== '') { $where[] = 'DATE(COALESCE(b.FiledAt, b.CreatedAt)) <= ?'; $args[] = $to; }
if ($q !== '') {
    $like = '%' . $q . '%';
    $where[] = "(b.CaseNumber LIKE ? OR b.IncidentType LIKE ? OR b.IncidentTypeOther LIKE ? OR b.Location LIKE ? OR b.ComplainantName LIKE ? OR b.RespondentName LIKE ?
                 OR b.BlotterID IN (SELECT blotter_id FROM blotter_parties WHERE CONCAT_WS(' ', first_name, middle_name, last_name) LIKE ?
                                    OR CONCAT_WS(' ', first_name, last_name) LIKE ? OR alias LIKE ? OR plate_number LIKE ?))";
    array_push($args, $like, $like, $like, $like, $like, $like, $like, $like, $like, $like);
}
$s = $pdo->prepare("SELECT b.*, (SELECT COUNT(*) FROM blotter_hearings h WHERE h.blotter_id = b.BlotterID AND h.status <> 'Cancelled') hearings
                    FROM blotter b WHERE " . implode(' AND ', $where) . " ORDER BY COALESCE(b.FiledAt, b.CreatedAt) DESC, b.BlotterID DESC");
$s->execute($args);
$rows = $s->fetchAll(PDO::FETCH_ASSOC);

$byStatus = [];
foreach ($rows as $r) $byStatus[$r['Status']] = ($byStatus[$r['Status']] ?? 0) + 1;
arsort($byStatus);
$cnt = fn(array $list) => count(array_filter($rows, fn($r) => in_array($r['Status'], $list, true)));
$total = count($rows);

$rangeLabel = $from === '' && $to === '' ? 'All dates' : trim(($from ? date('M j, Y', strtotime($from)) : '…') . ' – ' . ($to ? date('M j, Y', strtotime($to)) : '…'));
$filters = array_filter([
    'Cases' => $tabs[$tab], 'Status' => $status ?: null, 'Case type' => $type ?: null, 'Filed' => $rangeLabel, 'Search' => $q !== '' ? '"' . $q . '"' : null,
]);

$brgy = report_barangay_profile($pdo);
$bAddr = blt_barangay($pdo)['address'];
$captain = report_current_captain($pdo);
$generatedBy = report_generated_by($pdo);
$generatedRole = ($_SESSION['role'] ?? '') === 'admin' ? 'Administrator' : 'Barangay Staff';
if ($mode !== '') blt_log_activity('Blotter Masterlist', ($mode === 'pdf' ? 'Saved PDF' : 'Printed') . ' blotter case masterlist (' . $tabs[$tab] . ', ' . $total . ' case(s))');

$n = fn($v) => number_format((float)$v);
$d = fn($v, $f) => $v ? date($f, strtotime((string)$v)) : '—';
$title = 'Blotter Case Masterlist';
report_head($title, $mode);
report_toolbar($mode, 'blotter_masterlist_' . $tab . '_' . date('Ymd'), 'landscape');
?>
<style>
    .brgy-addr{text-align:center;font-size:11px;color:#64748b;margin:-12px 0 14px}
    .report-page{max-width:1100px}
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 24px}
    table.kv th{width:38%;background:transparent;font-size:10.5px;color:#64748b}
    table.kv td{font-weight:700}
    td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
    tr.total td{font-weight:800;border-top:1.5px solid #94a3b8;background:#f8fafc}
    th,td{font-size:10px}
    tr,.stat-grid,.signature-block,.certify-line{page-break-inside:avoid;break-inside:avoid}
    h2.section{page-break-after:avoid;break-after:avoid}
</style>
<div class="report-page" id="reportRoot">
    <?php report_letterhead($brgy, 'Office of the Punong Barangay · Blotter / Case Management'); ?>
    <?php if ($bAddr): ?><p class="brgy-addr"><?php echo rh($bAddr); ?></p><?php endif; ?>
    <?php report_title_block($title, $tabs[$tab] . ' · ' . $rangeLabel, 'Katarungang Pambarangay'); ?>

    <?php report_section_open('Report Information'); ?>
    <div class="info-grid">
        <table class="kv"><tbody>
            <?php foreach ($filters as $k => $v): ?><tr><th><?php echo rh($k); ?></th><td><?php echo rh($v); ?></td></tr><?php endforeach; ?>
            <tr><th>Cases listed</th><td><?php echo $n($total); ?></td></tr>
        </tbody></table>
        <table class="kv"><tbody>
            <tr><th>Generated by</th><td><?php echo rh($generatedBy); ?></td></tr>
            <tr><th>Date generated</th><td><?php echo rh(date('F j, Y g:i A')); ?></td></tr>
            <tr><th>Barangay Captain</th><td><?php echo rh($captain ? 'Hon. ' . $captain['full_name'] : 'Not assigned'); ?></td></tr>
        </tbody></table>
    </div>
    <?php report_section_close(); ?>

    <?php report_section_open('Summary'); ?>
    <?php report_stat_cards([
        ['value' => $n($total), 'label' => 'Cases Listed', 'variant' => 'a'],
        ['value' => $n($cnt($groups['active'])), 'label' => 'Active', 'variant' => 'b'],
        ['value' => $n($cnt($groups['resolved'])), 'label' => 'Resolved / Closed', 'variant' => 'c'],
        ['value' => $n($cnt($groups['transfer'])), 'label' => 'For Transfer / Transferred', 'variant' => 'd'],
    ]); ?>
    <?php if ($byStatus): ?>
    <div style="margin-top:12px"></div>
    <table><thead><tr><th>Status</th><th class="num">Cases</th><th class="num">Share</th></tr></thead><tbody>
        <?php foreach ($byStatus as $k => $v): ?><tr><td><?php echo rh($k); ?></td><td class="num"><?php echo $n($v); ?></td><td class="num"><?php echo round($v / max(1, $total) * 100, 1); ?>%</td></tr><?php endforeach; ?>
        <tr class="total"><td>Total</td><td class="num"><?php echo $n($total); ?></td><td class="num">100%</td></tr>
    </tbody></table>
    <?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Case Masterlist'); ?>
    <?php if (!$rows): ?><p class="empty-note">No cases match the selected filters.</p><?php else: ?>
    <table><thead><tr><th>#</th><th>Blotter ID</th><th>Complainant</th><th>Respondent</th><th>Case type</th><th>Incident</th><th>Location</th><th>Filed</th><th class="num">Hearings</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($rows as $i => $r): ?>
        <tr><td><?php echo $i + 1; ?></td><td><strong><?php echo rh($r['CaseNumber'] ?: '#' . $r['BlotterID']); ?></strong></td>
            <td><?php echo rh($r['ComplainantName'] ?: '—'); ?></td><td><?php echo rh($r['RespondentName'] ?: '—'); ?></td>
            <td><?php echo rh(blt_case_type_label($r) ?: '—'); ?></td>
            <td><?php echo rh($d($r['IncidentDate'], 'M j, Y') . ($r['IncidentTime'] ? ' · ' . date('g:i A', strtotime('2000-01-01 ' . $r['IncidentTime'])) : '')); ?></td>
            <td><?php echo rh($r['Location'] ?: '—'); ?></td><td><?php echo rh($d($r['FiledAt'] ?: $r['CreatedAt'], 'M j, Y')); ?></td>
            <td class="num"><?php echo (int)$r['hearings']; ?></td><td><?php echo rh($r['Status']); ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    <?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_certify_and_signatures($brgy['brgy_name'] ?? 'Barangay', $generatedBy, $generatedRole, $captain); ?>
    <?php report_footer_strip($brgy['brgy_name'] ?? 'Barangay'); ?>
</div>
<?php report_foot(); ?>
