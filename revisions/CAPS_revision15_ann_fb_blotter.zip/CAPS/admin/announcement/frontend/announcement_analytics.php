<?php
/**
 * announcement_analytics.php — Announcement Analytics (View Analytics from ann.php).
 * Same structure / behavior as Resident, Household, Legal Document and Disaster Analytics:
 *   Start / End Date → Apply; empty dates = all records
 *   AI Analytics (manual only), Data Interpretation, summary cards, charts and tables.
 * Focused on actual resident-app usage (views, reach, likes, dislikes, comments);
 * Facebook Page engagement (Meta-style KPIs + graphs) is its own section.
 * Generate AI and Save PDF / Print ask for the channel: Application, Facebook or Both.
 * Save PDF / Print → ../backend/announcement_analytics_report.php (shared CAPS report layout),
 * asking whether to include the AI findings (never generates AI automatically).
 */

require_once __DIR__ . '/partials/analytics_bootstrap.php';
require_once __DIR__ . '/../backend/announcement_analytics_data.php';

$aaParams = ra_params($_GET);
$action = $_GET['action'] ?? '';
$aaData = null;
try {
    $aaData = announcement_analytics_compute($pdo, $aaParams);
    $aaData['interpretation'] = announcement_analytics_interpretation($aaData);
} catch (Throwable $e) {
    error_log('[Announcement analytics] ' . $e->getMessage());
}

// ── AJAX: analytics data / Facebook Page engagement for the selected date range ──
if ($action === 'data' || $action === 'fb') {
    header('Content-Type: application/json; charset=utf-8');
    if (!$aaData) { echo json_encode(['success' => false, 'error' => 'Could not load the announcement analytics.']); exit; }
    if ($action === 'data') {
        echo json_encode(['success' => true] + $aaData, JSON_UNESCAPED_UNICODE);
    } else {
        try {
            echo json_encode(['success' => true] + announcement_fb_compute($aaData, !empty($_GET['refresh'])), JSON_UNESCAPED_UNICODE);
        } catch (Throwable $e) {
            echo json_encode(['success' => false, 'error' => 'Could not read the Facebook Page.']);
        }
    }
    exit;
}
$page_title = 'Announcement Analytics';
?>
<!DOCTYPE html>
<html <?php echo $theme_attrs['html']; ?>>

<head>
    <?php include __DIR__ . '/partials/analytics_head.php'; ?>
    <style>
        .kpi2 { border: 1px solid #eef2f7; border-radius: 20px; padding: 16px 18px; background: #fff }
        .kpi2 .k-label { font-size: 9px; font-weight: 900; text-transform: uppercase; letter-spacing: .08em; color: #64748b }
        .kpi2 .k-value { font-size: 26px; font-weight: 900; color: #0f172a; line-height: 1.1; margin-top: 4px; font-variant-numeric: tabular-nums }
        .kpi2 .k-sub { font-size: 10px; font-weight: 700; color: #94a3b8; margin-top: 2px }
        .chart-card { border: 1px solid #eef2f7; border-radius: 24px; padding: 20px; background: #fff; display: flex; flex-direction: column; min-width: 0 }
        .chart-card h3 { font-size: 14px; font-weight: 900; color: #1e293b }
        .chart-card .c-sub { font-size: 10px; font-weight: 700; color: #94a3b8; margin-top: 2px }
        .chart-box2 { position: relative; height: 250px; margin-top: 14px }
        details.tv { margin-top: 10px }
        details.tv summary { cursor: pointer; font-size: 10px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: .06em }
        table.dt { width: 100%; border-collapse: collapse; font-size: 12px }
        table.dt th { text-align: left; font-size: 9px; text-transform: uppercase; letter-spacing: .06em; color: #94a3b8; font-weight: 900; padding: 8px 10px; border-bottom: 1px solid #eef2f7; background: #f8fafc }
        table.dt td { padding: 8px 10px; border-bottom: 1px solid #f1f5f9; color: #334155; font-weight: 600 }
        table.dt td.num, table.dt th.num { text-align: right; font-variant-numeric: tabular-nums }
        table.dt tr.total td { font-weight: 900; border-top: 1.5px solid #cbd5e1; background: #f8fafc }
        .empty { font-size: 12px; color: #94a3b8; font-style: italic; text-align: center; padding: 40px 10px }
    </style>
</head>

<body <?php echo $theme_attrs['body']; ?>>
    <div class="flex min-h-screen">
        <?php include __DIR__ . '/../../sidebar.php'; ?>

        <div class="flex-1 flex flex-col min-w-0 main-wrapper">
            <?php include __DIR__ . '/../../header.php'; ?>

            <main class="p-4 md:p-6 lg:p-8 space-y-7">
                <section class="rounded-2xl p-6 md:p-8 text-white relative overflow-hidden"
                    style="background: linear-gradient(135deg, var(--accent-700) 0%, var(--accent-600) 50%, var(--accent-700) 100%);">
                    <div class="absolute -right-12 -top-12 w-64 h-64 opacity-10 rounded-full blur-3xl pointer-events-none" style="background: var(--accent-400);"></div>
                    <div class="relative z-10 flex flex-col xl:flex-row xl:items-center xl:justify-between gap-5">
                        <div>
                            <div class="flex items-center gap-2 text-white/60 text-[10px] font-black uppercase tracking-[0.18em] mb-2"><span class="material-symbols-outlined text-base">campaign</span>Announcements</div>
                            <h1 class="text-2xl md:text-3xl font-black tracking-tight leading-none">Announcement Analytics</h1>
                            <p class="text-white/65 text-sm mt-2 font-medium max-w-2xl">Posting activity and how residents use announcements in the barangay app — views, reach, likes, dislikes and comments.</p>
                        </div>
                        <div class="flex flex-wrap items-center gap-3">
                            <button type="button" onclick="openReport('pdf')" class="btn bg-white text-slate-900 hover:bg-slate-100 shadow-lg"><span class="material-symbols-outlined" style="font-size:18px">picture_as_pdf</span>Save PDF</button>
                            <button type="button" onclick="openReport('print')" class="btn bg-white/10 hover:bg-white/20 border border-white/20 text-white"><span class="material-symbols-outlined" style="font-size:18px">print</span>Print</button>
                            <a href="ann.php" class="btn bg-white/10 hover:bg-white/20 border border-white/20 text-white"><span class="material-symbols-outlined" style="font-size:18px">arrow_back</span>Back to Announcements</a>
                        </div>
                    </div>
                </section>

                <!-- Date range -->
                <section class="panel p-5 md:p-6">
                    <form id="rangeForm" class="flex flex-wrap items-end gap-4" onsubmit="applyRange(event)">
                        <div><label for="startDate" class="section-title block mb-1.5">Start Date</label>
                            <input type="date" id="startDate" max="9999-12-31" class="field" value="<?php echo htmlspecialchars($aaParams['start']); ?>"></div>
                        <div><label for="endDate" class="section-title block mb-1.5">End Date</label>
                            <input type="date" id="endDate" max="9999-12-31" class="field" value="<?php echo htmlspecialchars($aaParams['end']); ?>"></div>
                        <button type="submit" class="btn btn-dark"><span class="material-symbols-outlined" style="font-size:16px">filter_alt</span>Apply</button>
                        <button type="button" onclick="clearRange()" class="btn btn-light">Clear</button>
                        <div class="ml-auto text-right">
                            <p class="section-title">Showing</p>
                            <p id="rangeLabel" class="text-sm font-black text-slate-800"></p>
                            <p id="rangeBasis" class="text-[10px] font-bold text-slate-400"></p>
                        </div>
                    </form>
                </section>

                <!-- AI Analytics (manual only) -->
                <section class="panel p-6 md:p-8">
                    <div class="flex flex-wrap items-center justify-between gap-4">
                        <div class="flex items-center gap-3">
                            <span class="material-symbols-outlined text-white bg-indigo-600 p-2 rounded-xl">auto_awesome</span>
                            <div><h2 class="text-lg font-black text-slate-800">AI Analytics</h2>
                                <p id="aiStatus" class="text-[10px] text-slate-400 font-bold">Not generated. AI runs only when you click the button.</p></div>
                        </div>
                        <button type="button" id="aiBtn" onclick="generateAi()" class="btn btn-dark"><span class="material-symbols-outlined" style="font-size:16px">auto_awesome</span><span id="aiBtnText">Generate AI Analytics</span></button>
                    </div>
                    <div id="aiTabs" class="mt-5 flex flex-wrap gap-2"></div>
                    <div id="aiBody" class="mt-5"></div>
                </section>

                <!-- Data Interpretation (directly below AI Analytics) -->
                <div id="raInterp"></div>
                <div id="raBody" class="space-y-7"></div>

                <!-- Facebook Page engagement (Meta-style) -->
                <section class="panel p-6 md:p-8">
                    <div class="flex flex-wrap items-center justify-between gap-3 mb-6">
                        <div class="flex items-center gap-3">
                            <span class="material-symbols-outlined text-white p-2 rounded-xl" style="background:#1877f2">thumb_up</span>
                            <div><h2 class="text-lg font-black text-slate-800">Facebook Page Engagement</h2>
                                <p id="fbStatus" class="text-[10px] text-slate-400 font-bold">Reading the Facebook Page…</p></div>
                        </div>
                        <button type="button" id="fbBtn" onclick="loadFb(true)" class="btn btn-light"><span class="material-symbols-outlined" style="font-size:16px">sync</span>Refresh from Facebook</button>
                    </div>
                    <div id="fbBody"></div>
                </section>
            </main>
        </div>
    </div>

    <!-- Generate AI Analytics: which channel? -->
    <div id="aiScopeModal" class="fixed inset-0 z-[999] hidden bg-slate-900/70 items-center justify-center p-4" onclick="if (event.target === this) closeAiScope()">
        <div class="bg-white rounded-[2rem] shadow-2xl w-full max-w-md p-8" role="dialog" aria-modal="true" aria-labelledby="asTitle">
            <div class="flex items-start justify-between gap-4">
                <div>
                    <h3 id="asTitle" class="text-2xl font-black text-slate-900 tracking-tight">Generate AI Analytics</h3>
                    <p class="text-[11px] font-black text-indigo-600 uppercase tracking-widest mt-1">Which engagement should the AI analyse?</p>
                </div>
                <button type="button" onclick="closeAiScope()" class="p-1 text-slate-400 hover:text-slate-700" aria-label="Close"><span class="material-symbols-outlined">close</span></button>
            </div>
            <div class="space-y-3 mt-6">
                <?php foreach ([['app', 'Application Engagement', 'Resident app: views, reach, likes, dislikes and comments.'], ['fb', 'Facebook Engagement', 'Facebook Page: views, reach, reactions, comments, shares and clicks.'], ['both', 'Both', 'Application and Facebook together, compared.']] as $i => [$v, $l, $h]): ?>
                <label class="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 cursor-pointer hover:border-indigo-300">
                    <input type="radio" name="asScope" value="<?php echo $v; ?>" class="mt-1 text-indigo-600 focus:ring-indigo-500" <?php echo $i === 0 ? 'checked' : ''; ?>>
                    <span><span class="block text-sm font-black text-slate-800"><?php echo $l; ?></span>
                        <span class="block text-[11px] font-semibold text-slate-400"><?php echo $h; ?></span></span>
                </label>
                <?php endforeach; ?>
            </div>
            <div class="flex justify-end gap-3 mt-8">
                <button type="button" onclick="closeAiScope()" class="btn btn-light">Cancel</button>
                <button type="button" onclick="confirmAiScope()" class="btn btn-dark"><span class="material-symbols-outlined" style="font-size:16px">auto_awesome</span>Generate</button>
            </div>
        </div>
    </div>

    <!-- Save PDF / Print: which channel + include AI findings? -->
    <div id="reportModal" class="fixed inset-0 z-[999] hidden bg-slate-900/70 items-center justify-center p-4" onclick="if (event.target === this) closeReport()">
        <div class="bg-white rounded-[2rem] shadow-2xl w-full max-w-md p-8" role="dialog" aria-modal="true" aria-labelledby="rmTitle">
            <div class="flex items-start justify-between gap-4">
                <div>
                    <h3 id="rmTitle" class="text-2xl font-black text-slate-900 tracking-tight">Save as PDF</h3>
                    <p class="text-[11px] font-black text-indigo-600 uppercase tracking-widest mt-1">Announcement Analytics Report</p>
                    <p id="rmRange" class="text-xs font-bold text-slate-400 mt-1"></p>
                </div>
                <button type="button" onclick="closeReport()" class="p-1 text-slate-400 hover:text-slate-700" aria-label="Close"><span class="material-symbols-outlined">close</span></button>
            </div>
            <p class="text-sm font-bold text-slate-700 mt-6 mb-3">Which engagement to include?</p>
            <div class="grid grid-cols-3 gap-2">
                <?php foreach ([['app', 'Application'], ['fb', 'Facebook'], ['both', 'Both']] as $i => [$v, $l]): ?>
                <label class="flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 cursor-pointer hover:border-indigo-300 text-sm font-black text-slate-800">
                    <input type="radio" name="rmScope" value="<?php echo $v; ?>" class="text-indigo-600 focus:ring-indigo-500" <?php echo $i === 0 ? 'checked' : ''; ?>><?php echo $l; ?>
                </label>
                <?php endforeach; ?>
            </div>
            <p class="text-sm font-bold text-slate-700 mt-6 mb-3">Include AI findings in the report?</p>
            <div class="space-y-3">
                <label class="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 cursor-pointer hover:border-indigo-300">
                    <input type="radio" name="rmAi" value="0" class="mt-1 text-indigo-600 focus:ring-indigo-500" checked>
                    <span><span class="block text-sm font-black text-slate-800">No AI – Data and tables only</span>
                        <span class="block text-[11px] font-semibold text-slate-400">Summary, statistics, tables and data interpretation.</span></span>
                </label>
                <label class="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 cursor-pointer hover:border-indigo-300">
                    <input type="radio" name="rmAi" value="1" class="mt-1 text-indigo-600 focus:ring-indigo-500">
                    <span><span class="block text-sm font-black text-slate-800">Include AI – Data, charts, and AI explanation</span>
                        <span class="block text-[11px] font-semibold text-slate-400">Uses the AI Analytics already generated on this page.</span></span>
                </label>
            </div>
            <p id="rmError" class="hidden mt-4 text-xs font-bold text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-3 py-2">Please generate AI Analytics first.</p>
            <div class="flex justify-end gap-3 mt-8">
                <button type="button" onclick="closeReport()" class="btn btn-light">Cancel</button>
                <button type="button" onclick="continueReport()" class="btn btn-dark">Continue</button>
            </div>
        </div>
    </div>

    <script src="assets/analytics_report.js"></script>
    <script>
        const COLORS = { s1: '#2a78d6', s2: '#eb6834', s3: '#1baf7a', like: '#e11d48', dislike: '#64748b', comment: '#6366f1', muted: '#94a3b8', grid: '#eef2f7' };
        const STATUS_COLORS = { ACTIVE: '#1baf7a', SCHEDULED: '#2a78d6', ENDED: '#94a3b8', EXPIRED: '#eb6834', DRAFT: '#cbd5e1' };
        const EXTRA = ['#2a78d6', '#eb6834', '#1baf7a', '#6366f1', '#eab308', '#ec4899', '#14b8a6', '#64748b'];
        const charts = {};
        let DATA = <?php echo json_encode($aaData ? ['success' => true] + $aaData : null, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?>;
        let AA_AI = null;
        const esc = AnalyticsReport.esc, num = AnalyticsReport.num;
        const pct = (v, d) => d ? (Math.round(Number(v || 0) / d * 1000) / 10) + '%' : '0%';
        const sum = o => Object.values(o).reduce((s, v) => s + Number(v || 0), 0);
        const rate = v => v === null || v === undefined ? '—' : v + '%';
        function fmtDate(d) {
            if (!d) return '—';
            const dt = new Date(String(d).replace(' ', 'T'));
            return isNaN(dt) ? d : dt.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
        }
        if (window.Chart) {
            Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";
            Chart.defaults.font.size = 11;
            Chart.defaults.color = '#64748b';
            Chart.defaults.plugins.tooltip.backgroundColor = '#0f172a';
            Chart.defaults.plugins.tooltip.padding = 10;
        }

        /* ───────── Rendering helpers (same as the other analytics pages) ───────── */
        function kpi(label, value, sub) { return `<div class="kpi2"><p class="k-label">${esc(label)}</p><p class="k-value">${esc(value)}</p>${sub ? `<p class="k-sub">${esc(sub)}</p>` : ''}</div>`; }
        function card(id, title, sub, opts = {}) {
            return `<div class="chart-card ${opts.span || ''}"><h3>${esc(title)}</h3><p class="c-sub">${esc(sub)}</p>
                ${opts.empty ? `<p class="empty">${esc(opts.empty)}</p>` : `<div class="chart-box2"><canvas id="${id}" role="img" aria-label="${esc(title)}"></canvas></div>`}
                ${opts.table ? `<details class="tv"><summary>View table</summary><div class="mt-2 overflow-x-auto">${opts.table}</div></details>` : ''}</div>`;
        }
        function table(head, rows, numCols = []) {
            if (!rows.length) return '<p class="empty">No data for the selected range.</p>';
            return `<table class="dt"><thead><tr>${head.map((h, i) => `<th class="${numCols.includes(i) ? 'num' : ''}">${esc(h)}</th>`).join('')}</tr></thead><tbody>` +
                rows.map(r => `<tr class="${r[0] === 'Total' ? 'total' : ''}">${r.map((c, i) => `<td class="${numCols.includes(i) ? 'num' : ''}">${esc(c)}</td>`).join('')}</tr>`).join('') + '</tbody></table>';
        }
        function distRows(obj, base) {
            const rows = Object.entries(obj).map(([k, v]) => [k, num(v), pct(v, base)]);
            if (rows.length) rows.push(['Total', num(sum(obj)), pct(sum(obj), base)]);
            return rows;
        }
        function section(icon, title, sub, inner) {
            return `<section class="panel p-6 md:p-8"><div class="flex items-center gap-3 mb-6"><span class="material-symbols-outlined text-white bg-primary p-2 rounded-xl">${icon}</span>
                <div><h2 class="text-lg font-black text-slate-800">${esc(title)}</h2><p class="text-[10px] text-slate-400 font-bold">${esc(sub)}</p></div></div>${inner}</section>`;
        }
        const axisCount = { beginAtZero: true, ticks: { precision: 0 }, grid: { color: COLORS.grid }, border: { display: false } };
        const noGrid = { grid: { display: false }, border: { display: false } };
        const legendTop = { position: 'top', align: 'end', labels: { boxWidth: 10, boxHeight: 10 } };
        function mk(id, cfg) { const el = document.getElementById(id); if (!el) return; cfg.options = Object.assign({ maintainAspectRatio: false }, cfg.options || {}); charts[id] = new Chart(el, cfg); }
        function donut(id, obj, colorOf, base) {
            const e = Object.entries(obj).filter(([, v]) => v > 0);
            mk(id, { type: 'doughnut', data: { labels: e.map(x => x[0]), datasets: [{ data: e.map(x => x[1]), backgroundColor: e.map((x, i) => colorOf(x[0], i)), borderColor: '#fff', borderWidth: 2 }] },
                options: { cutout: '62%', plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, boxHeight: 10 } }, tooltip: { callbacks: { label: c => ` ${c.label}: ${num(c.raw)} (${pct(c.raw, base)})` } } } } });
        }
        const annRow = a => [a.title, a.category, fmtDate(a.date_posted), a.status, num(a.views), num(a.reach), num(a.likes), num(a.dislikes), num(a.comments), rate(a.rate)];
        const ANN_HEAD = ['Announcement', 'Category', 'Posted', 'Status', 'Views', 'Reach', '❤️ Likes', '👎 Dislikes', '💬 Comments', 'Eng. Rate'];

        /* ───────── Page ───────── */
        function render() {
            Object.values(charts).forEach(c => c.destroy());
            for (const k in charts) delete charts[k];
            const body = document.getElementById('raBody');
            document.getElementById('raInterp').innerHTML = '';
            if (!DATA) { body.innerHTML = '<section class="panel p-8"><p class="empty">Unable to load the announcement analytics.</p></section>'; return; }
            const d = DATA, s = d.summary, a = d.app, T = s.total;
            document.getElementById('rangeLabel').textContent = d.range.label;
            document.getElementById('rangeBasis').textContent = d.range.open ? 'All announcements on file' : 'Announcements posted within the range';

            let html = section('campaign', 'Announcement Summary', 'Posting status and resident-app usage · ' + d.range.label,
                `<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
                    ${kpi('Total Announcements', num(T), d.comparison ? (T - s.prev_total >= 0 ? '+' : '') + (T - s.prev_total) + ' vs previous period' : s.per_week + ' per week')}
                    ${kpi('Active / Posted', num(s.active), num(T - s.draft) + ' posted in total')}
                    ${kpi('Scheduled', num(s.scheduled), 'waiting to go live')}
                    ${kpi('Expired / Ended', num(s.expired + s.ended), num(s.expired) + ' expired · ' + num(s.ended) + ' ended')}
                    ${kpi('Drafts', num(s.draft), num(s.with_images) + ' with photos')}
                    ${kpi('Views (App)', num(a.views), a.avg_views + ' average per announcement')}
                    ${kpi('Reach', num(a.reach), a.reach_rate !== null ? a.reach_rate + '% of ' + num(a.residents) + ' residents' : 'unique residents')}
                    ${kpi('❤️ Likes', num(a.likes), a.like_ratio !== null ? a.like_ratio + '% of reactions' : 'no reactions yet')}
                    ${kpi('👎 Dislikes', num(a.dislikes), 'resident reactions')}
                    ${kpi('💬 Comments', num(a.comments), 'resident comments')}
                    ${kpi('Engagement Rate', rate(a.engagement_rate), num(a.engagement) + ' interactions ÷ views')}
                    ${kpi('Viewed', num(a.viewed) + ' / ' + num(T), 'announcements opened at least once')}
                    ${kpi('Busiest Day', a.busiest_day || '—', a.busiest_hour ? 'around ' + a.busiest_hour : 'no activity yet')}
                    ${kpi('Facebook Posted', num(s.fb_posted), num(s.fb_queued) + ' queued')}
                </div>`);

            const catRows = d.by_category_engagement.map(c => [c.category, num(c.posts), num(c.views), num(c.likes), num(c.dislikes), num(c.comments),
                c.views ? rate(Math.round((c.likes + c.dislikes + c.comments) / c.views * 1000) / 10) : '—']);
            if (catRows.length) catRows.push(['Total', num(T), num(a.views), num(a.likes), num(a.dislikes), num(a.comments), rate(a.engagement_rate)]);
            html += section('donut_large', 'Status & Categories', 'Announcement status and engagement per category',
                `<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    ${card('c-status', 'Announcement Status', 'Active, scheduled, ended, expired, draft', { empty: T ? '' : 'No announcements in this range.', table: table(['Status', 'Announcements', 'Share'], distRows(d.by_status, T), [1, 2]) })}
                    ${card('c-cat', 'Engagement by Category', 'Views and reactions per category', { span: 'lg:col-span-2', empty: T ? '' : 'No announcements in this range.' })}
                </div>
                <div class="mt-6 chart-card"><h3>Category Performance</h3><p class="c-sub">Posts and resident-app engagement per category</p>
                    <div class="mt-3 overflow-x-auto">${table(['Category', 'Posts', 'Views', 'Likes', 'Dislikes', 'Comments', 'Eng. Rate'], catRows, [1, 2, 3, 4, 5, 6])}</div></div>`);

            html += section('leaderboard', 'Most Viewed & Most Engaged', 'Top announcements in the resident app',
                `<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    ${card('c-top', 'Most Viewed (Top 10)', 'Views and reach per announcement', { empty: d.most_viewed.length ? '' : 'No announcement has been viewed yet.' })}
                    ${card('c-react', 'Likes vs Dislikes', 'Share of all reactions', { empty: (a.likes + a.dislikes) ? '' : 'No reactions yet.' })}
                </div>
                <div class="mt-6 chart-card"><h3>Most Viewed</h3><p class="c-sub">Top 10 by views</p><div class="mt-3 overflow-x-auto">${table(ANN_HEAD, d.most_viewed.map(annRow), [4, 5, 6, 7, 8, 9])}</div></div>
                <div class="mt-6 chart-card"><h3>Most Engaged</h3><p class="c-sub">Top 10 by likes + dislikes + comments</p><div class="mt-3 overflow-x-auto">${table(ANN_HEAD, d.most_engaged.map(annRow), [4, 5, 6, 7, 8, 9])}</div></div>`);

            let comparison = '';
            if (d.comparison) comparison = `<div class="chart-card lg:col-span-2"><h3>Selected Period vs Previous Period</h3><p class="c-sub">Previous period: ${esc(d.comparison.previous_label)}</p>
                <div class="chart-box2"><canvas id="c-compare"></canvas></div>
                <div class="mt-3 overflow-x-auto">${table(['Indicator', 'Selected', 'Previous', 'Change'], d.comparison.rows.map(r => [r.metric, num(r.current), num(r.previous), (r.current - r.previous > 0 ? '+' : '') + num(r.current - r.previous)]), [1, 2, 3])}</div></div>`;
            const act = d.activity, actTotal = sum(act.weekday);
            const hourRows = Object.entries(act.hours).filter(([, v]) => v > 0).map(([k, v]) => [k, num(v), pct(v, actTotal)]);
            html += section('insights', 'Engagement Trends', 'When residents viewed, reacted and commented',
                `<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    ${card('c-activity', 'Audience Interaction over Time', 'Per ' + act.granularity + ': views, likes, dislikes, comments', { span: 'lg:col-span-2', empty: act.labels.length > 1 && actTotal ? '' : 'No resident activity in this range yet.' })}
                    ${card('c-weekday', 'Interaction by Day of Week', 'All views, reactions and comments', { empty: actTotal ? '' : 'No activity.', table: table(['Day', 'Interactions', 'Share'], distRows(act.weekday, actTotal), [1, 2]) })}
                    ${card('c-hours', 'Interaction by Hour', 'Time of day residents are most active', { empty: actTotal ? '' : 'No activity.', table: table(['Hour', 'Interactions', 'Share'], hourRows, [1, 2]) })}
                    ${card('c-posted', 'Announcements Posted over Time', 'Per ' + d.trend.granularity, { span: 'lg:col-span-2', empty: d.trend.labels.length > 1 && T ? '' : 'Not enough data for a trend.' })}
                    ${comparison}
                </div>`);

            const perf = d.announcements.slice().sort((x, y) => String(y.date_posted).localeCompare(String(x.date_posted)));
            html += section('calendar_month', 'Performance by Date', 'Every announcement in the range, newest first',
                `<div class="overflow-x-auto max-h-[520px] overflow-y-auto">${table(ANN_HEAD, perf.map(annRow), [4, 5, 6, 7, 8, 9])}</div>`);

            document.getElementById('raInterp').innerHTML = section('fact_check', 'Data Interpretation', 'Automatic summary of the announcement figures (no AI) · ' + d.range.label,
                `<ol class="list-decimal pl-5 space-y-2 text-sm text-slate-600 font-medium">${(d.interpretation || []).map(x => `<li>${esc(x)}</li>`).join('')}</ol>`);
            body.innerHTML = html;

            if (!window.Chart) return;
            if (T) donut('c-status', d.by_status, k => STATUS_COLORS[k] || COLORS.muted, T);
            if (T) mk('c-cat', { type: 'bar', data: { labels: d.by_category_engagement.map(c => c.category), datasets: [
                { label: 'Views', data: d.by_category_engagement.map(c => c.views), backgroundColor: COLORS.s1, borderRadius: 4, maxBarThickness: 22 },
                { label: 'Likes', data: d.by_category_engagement.map(c => c.likes), backgroundColor: COLORS.like, borderRadius: 4, maxBarThickness: 22 },
                { label: 'Dislikes', data: d.by_category_engagement.map(c => c.dislikes), backgroundColor: COLORS.dislike, borderRadius: 4, maxBarThickness: 22 },
                { label: 'Comments', data: d.by_category_engagement.map(c => c.comments), backgroundColor: COLORS.comment, borderRadius: 4, maxBarThickness: 22 }] },
                options: { plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
            if (d.most_viewed.length) mk('c-top', { type: 'bar', data: { labels: d.most_viewed.map(x => x.title.length > 28 ? x.title.slice(0, 27) + '…' : x.title), datasets: [
                { label: 'Views', data: d.most_viewed.map(x => x.views), backgroundColor: COLORS.s1, borderRadius: 4, maxBarThickness: 16 },
                { label: 'Reach', data: d.most_viewed.map(x => x.reach), backgroundColor: COLORS.s3, borderRadius: 4, maxBarThickness: 16 }] },
                options: { indexAxis: 'y', plugins: { legend: legendTop }, scales: { x: axisCount, y: noGrid } } });
            if (a.likes + a.dislikes) donut('c-react', { 'Likes': a.likes, 'Dislikes': a.dislikes }, k => k === 'Likes' ? COLORS.like : COLORS.dislike, a.likes + a.dislikes);
            if (act.labels.length > 1 && actTotal) mk('c-activity', { type: 'line', data: { labels: act.labels, datasets: [
                ['Views', act.series.views, COLORS.s1], ['Likes', act.series.likes, COLORS.like], ['Dislikes', act.series.dislikes, COLORS.dislike], ['Comments', act.series.comments, COLORS.comment]]
                .map(([l, v, c]) => ({ label: l, data: v, borderColor: c, backgroundColor: c, borderWidth: 2, pointRadius: act.labels.length > 40 ? 0 : 3, tension: 0 })) },
                options: { interaction: { mode: 'index', intersect: false }, plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
            if (actTotal) mk('c-weekday', { type: 'bar', data: { labels: Object.keys(act.weekday), datasets: [{ label: 'Interactions', data: Object.values(act.weekday), backgroundColor: COLORS.s1, borderRadius: 4, maxBarThickness: 36 }] },
                options: { plugins: { legend: { display: false } }, scales: { x: noGrid, y: axisCount } } });
            if (actTotal) mk('c-hours', { type: 'bar', data: { labels: Object.keys(act.hours), datasets: [{ label: 'Interactions', data: Object.values(act.hours), backgroundColor: COLORS.s2, borderRadius: 3, maxBarThickness: 14 }] },
                options: { plugins: { legend: { display: false } }, scales: { x: noGrid, y: axisCount } } });
            if (d.trend.labels.length > 1 && T) mk('c-posted', { type: 'line', data: { labels: d.trend.labels, datasets: [
                { label: 'Announcements posted', data: d.trend.datasets[0].data, borderColor: COLORS.s1, backgroundColor: COLORS.s1, borderWidth: 2, pointRadius: d.trend.labels.length > 40 ? 0 : 3, tension: 0 }] },
                options: { plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
            if (d.comparison) mk('c-compare', { type: 'bar', data: { labels: d.comparison.rows.map(r => r.metric), datasets: [
                { label: 'Selected period', data: d.comparison.rows.map(r => r.current), backgroundColor: COLORS.s1, borderRadius: 4, maxBarThickness: 40 },
                { label: 'Previous period', data: d.comparison.rows.map(r => r.previous), backgroundColor: COLORS.muted, borderRadius: 4, maxBarThickness: 40 }] },
                options: { plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
        }

        /* ───────── Facebook Page engagement (Meta-style) ───────── */
        const FBC = { blue: '#1877f2', green: '#42b72a', yellow: '#f7b928', gray: '#94a3b8', app: '#0d9488' };
        const fbCharts = {};
        let FB = null;
        function fbChart(id, cfg) { const el = document.getElementById(id); if (!el) return; cfg.options = Object.assign({ maintainAspectRatio: false }, cfg.options || {}); fbCharts[id] = new Chart(el, cfg); }
        async function loadFb(refresh) {
            if (!DATA) return;
            const btn = document.getElementById('fbBtn'), st = document.getElementById('fbStatus');
            btn.disabled = true; st.textContent = 'Reading the Facebook Page…';
            try {
                const q = new URLSearchParams({ action: 'fb', start: DATA.period.start || '', end: DATA.period.end || '' });
                if (refresh) q.set('refresh', '1');
                const j = await (await fetch('announcement_analytics.php?' + q.toString(), { credentials: 'same-origin' })).json();
                if (!j.success) throw new Error(j.error || 'Could not read the Facebook Page.');
                FB = j;
                st.textContent = (j.available ? 'Fetched ' + (j.fetched_at || '') + ' · ' : '') + num(j.posted) + ' announcement(s) posted to the Page · ' + DATA.range.label;
            } catch (e) { FB = null; st.textContent = e.message; }
            renderFb();
            btn.disabled = false;
        }
        function renderFb() {
            Object.values(fbCharts).forEach(c => c.destroy());
            for (const k in fbCharts) delete fbCharts[k];
            const box = document.getElementById('fbBody');
            if (!FB) { box.innerHTML = '<p class="empty">Facebook engagement could not be loaded.</p>'; return; }
            const t = FB.totals, ins = FB.insights_available, posts = FB.posts || [];
            const v = x => ins ? num(x) : '—';
            const interp = `<div class="chart-card mt-6"><h3>Facebook Interpretation</h3><p class="c-sub">Automatic summary of the Facebook figures (no AI)</p>
                <ol class="list-decimal pl-5 space-y-2 text-sm text-slate-600 font-medium mt-3">${(FB.interpretation || []).map(x => `<li>${esc(x)}</li>`).join('')}</ol></div>`;
            const kpis = `<div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                ${kpi('Views', v(t.impressions), 'times the posts were shown')}
                ${kpi('Reach', v(t.reach), 'unique people who saw them')}
                ${kpi('Engagement', num(t.engagement), t.rate !== null && t.rate !== undefined ? t.rate + '% of reach' : 'reactions + comments + shares + clicks')}
                ${kpi('Posted to Page', num(FB.posted), num(FB.queued) + ' queued · ' + num(FB.not_posted) + ' not posted')}
                ${kpi('👍 Reactions', num(t.reactions), '')}
                ${kpi('💬 Comments', num(t.comments), '')}
                ${kpi('↗ Shares', num(t.shares), '')}
                ${kpi('Clicks', v(t.clicks), ins ? '' : 'needs read_insights')}</div>`;
            if (!FB.available || !posts.length) {
                box.innerHTML = kpis + `<p class="text-xs font-bold text-amber-700 bg-amber-50 border border-amber-100 rounded-xl px-3 py-2 mt-4">${esc(FB.error || 'No Facebook engagement data for this date range.')}</p>` + interp;
                return;
            }
            const byDate = FB.by_date || [], a = DATA.app;
            const topRows = posts.map(p => [p.title, fmtDate(p.date_posted), p.impressions === null ? '—' : num(p.impressions), p.reach === null ? '—' : num(p.reach),
                num(p.reactions), num(p.comments), num(p.shares), p.clicks === null ? '—' : num(p.clicks), num(p.engagement), p.rate === null ? '—' : p.rate + '%']);
            box.innerHTML = kpis
                + (FB.error ? `<p class="text-xs font-bold text-amber-700 bg-amber-50 border border-amber-100 rounded-xl px-3 py-2 mt-4">${esc(FB.error)}</p>` : '')
                + `<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
                    ${card('fb-time', 'Performance over Time', 'By posting date' + (ins ? ': reach and engagement' : ': engagement'), { span: 'lg:col-span-2', empty: byDate.length > 1 ? '' : 'Posts on one date only — see the per-post chart.' })}
                    ${card('fb-mix', 'Engagement Breakdown', 'Reactions, comments, shares and clicks', { empty: t.engagement ? '' : 'No engagement yet.' })}
                    ${card('fb-post', 'Engagement per Post', 'Top posts, stacked by interaction', { span: 'lg:col-span-2' })}
                    ${card('fb-reach', ins ? 'Views & Reach per Post' : 'Reactions per Post', ins ? 'Times shown vs unique people' : 'Views / reach need read_insights')}
                    ${card('fb-vs', 'Resident App vs Facebook', 'Same announcements, both channels', { span: 'lg:col-span-3' })}
                </div>
                <div class="chart-card mt-6"><h3>Top Facebook Posts</h3><p class="c-sub">Sorted by engagement</p>
                    <div class="mt-3 overflow-x-auto max-h-[420px] overflow-y-auto">${table(['Announcement', 'Posted', 'Views', 'Reach', 'Reactions', 'Comments', 'Shares', 'Clicks', 'Engagement', 'Eng. Rate'], topRows, [2, 3, 4, 5, 6, 7, 8, 9])}</div></div>`
                + interp;
            if (!window.Chart) return;
            const short = x => x.length > 22 ? x.slice(0, 21) + '…' : x;
            const top = posts.slice(0, 10);
            const bar = (label, data, color) => ({ label, data, backgroundColor: color, borderRadius: 4, maxBarThickness: 22 });
            if (byDate.length > 1) fbChart('fb-time', { type: 'line', data: { labels: byDate.map(x => fmtDate(x.date)), datasets: [
                ...(ins ? [{ label: 'Reach', data: byDate.map(x => x.reach), borderColor: FBC.blue, backgroundColor: 'rgba(24,119,242,.12)', fill: true, borderWidth: 2, tension: .3, pointRadius: 3 }] : []),
                { label: 'Engagement', data: byDate.map(x => x.engagement), borderColor: FBC.green, backgroundColor: FBC.green, borderWidth: 2, tension: .3, pointRadius: 3 }] },
                options: { interaction: { mode: 'index', intersect: false }, plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
            if (t.engagement) {
                const mix = Object.entries(FB.mix).filter(([, x]) => x > 0), mc = { Reactions: FBC.blue, Comments: FBC.green, Shares: FBC.yellow, Clicks: FBC.gray };
                fbChart('fb-mix', { type: 'doughnut', data: { labels: mix.map(x => x[0]), datasets: [{ data: mix.map(x => x[1]), backgroundColor: mix.map(x => mc[x[0]]), borderColor: '#fff', borderWidth: 2 }] },
                    options: { cutout: '62%', plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, boxHeight: 10 } }, tooltip: { callbacks: { label: c => ` ${c.label}: ${num(c.raw)} (${pct(c.raw, t.engagement)})` } } } } });
            }
            fbChart('fb-post', { type: 'bar', data: { labels: top.map(p => short(p.title)), datasets: [
                bar('Reactions', top.map(p => p.reactions), FBC.blue), bar('Comments', top.map(p => p.comments), FBC.green),
                bar('Shares', top.map(p => p.shares), FBC.yellow), bar('Clicks', top.map(p => p.clicks || 0), FBC.gray)] },
                options: { plugins: { legend: legendTop }, scales: { x: Object.assign({ stacked: true }, noGrid), y: Object.assign({ stacked: true }, axisCount) } } });
            fbChart('fb-reach', { type: 'bar', data: { labels: top.map(p => short(p.title)), datasets: ins
                ? [bar('Views', top.map(p => p.impressions || 0), FBC.blue), bar('Reach', top.map(p => p.reach || 0), '#8ab4f8')]
                : [bar('Reactions', top.map(p => p.reactions), FBC.blue)] },
                options: { indexAxis: 'y', plugins: { legend: legendTop }, scales: { x: axisCount, y: noGrid } } });
            fbChart('fb-vs', { type: 'bar', data: { labels: ['Views', 'Reach', 'Reactions', 'Comments', 'Total engagement'], datasets: [
                bar('Resident app', [a.views, a.reach, a.likes + a.dislikes, a.comments, a.engagement], FBC.app),
                bar('Facebook', [ins ? t.impressions : 0, ins ? t.reach : 0, t.reactions, t.comments, t.engagement], FBC.blue)] },
                options: { plugins: { legend: legendTop }, scales: { x: noGrid, y: axisCount } } });
        }

        /* ───────── Date range ───────── */
        async function applyRange(e) {
            if (e) e.preventDefault();
            const p = { start: document.getElementById('startDate').value, end: document.getElementById('endDate').value };
            if (p.start && p.end && p.start > p.end) { alert('The Start Date must be on or before the End Date.'); return; }
            const q = new URLSearchParams(p);
            history.replaceState({}, '', location.pathname + '?' + q.toString());
            document.getElementById('raBody').style.opacity = '.5';
            try {
                const r = await fetch('announcement_analytics.php?action=data&' + q.toString(), { credentials: 'same-origin' });
                const j = await r.json();
                if (!j.success) throw new Error(j.error || 'Unable to load the announcement analytics.');
                DATA = j;
            } catch (err) { alert(err.message); }
            document.getElementById('raBody').style.opacity = '';
            render(); resetAi(); loadCachedAi(); loadFb(false);
        }
        function clearRange() { document.getElementById('startDate').value = ''; document.getElementById('endDate').value = ''; applyRange(); }

        /* ───────── AI Analytics (only on click · Application / Facebook / Both) ───────── */
        const SCOPES = { app: 'Application', fb: 'Facebook', both: 'Both' };
        let AI_BY = {}, AI_SHOWN = null;
        function resetAi() {
            AI_BY = {}; AI_SHOWN = null; AA_AI = null;
            document.getElementById('aiBody').innerHTML = '';
            document.getElementById('aiTabs').innerHTML = '';
            document.getElementById('aiStatus').textContent = 'Not generated for this date range. AI runs only when you click the button.';
            document.getElementById('aiBtnText').textContent = 'Generate AI Analytics';
        }
        function renderAiTabs() {
            const keys = Object.keys(SCOPES).filter(k => AI_BY[k]);
            document.getElementById('aiTabs').innerHTML = keys.length > 1 ? keys.map(k => `<button type="button" onclick="showAi('${k}')"
                class="px-3 py-1.5 rounded-xl text-[11px] font-black uppercase tracking-wider border ${k === AI_SHOWN ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300'}">${SCOPES[k]}</button>`).join('') : '';
        }
        function showAi(k) { if (AI_BY[k]) { renderAi(AI_BY[k]); renderAiTabs(); } }
        function renderAi(x) {
            const k = x.scope || 'app';
            AI_BY[k] = x; AI_SHOWN = k; AA_AI = x;
            document.getElementById('aiStatus').textContent = (x.scope_label || SCOPES[k]) + ' engagement · generated ' + (x.generated_at || '') + ' · ' + (x.period?.label || '') + (x.cached ? ' · saved result' : '');
            document.getElementById('aiBtnText').textContent = 'Generate AI Analytics';
            const group = (title, icon, list) => list && list.length ? `<div class="rounded-2xl border border-indigo-100 bg-indigo-50/40 p-5"><div class="flex items-center gap-2 mb-3"><span class="material-symbols-outlined text-indigo-600">${icon}</span><h5 class="text-[10px] font-black uppercase tracking-widest text-indigo-700">${esc(title)}</h5></div>
                <ul class="space-y-2">${list.map(f => `<li class="text-xs leading-relaxed text-slate-600"><strong class="text-slate-800">${esc(f.title)}</strong> — ${esc(f.detail)}</li>`).join('')}</ul></div>` : '';
            const recs = (x.recommendations || []).map((f, i) => `<li class="text-xs leading-relaxed text-slate-600"><strong class="text-slate-800">${i + 1}. ${esc(f.action)}</strong>
                <span class="ml-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${f.priority === 'high' ? 'bg-rose-100 text-rose-700' : f.priority === 'low' ? 'bg-slate-100 text-slate-600' : 'bg-amber-100 text-amber-700'}">${esc(f.priority)}</span><br>${esc(f.reason)}</li>`).join('');
            document.getElementById('aiBody').innerHTML =
                `<p class="text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-2">${esc(SCOPES[k])} Engagement</p>` +
                (x.summary ? `<p class="text-sm font-semibold text-slate-700 mb-5">${esc(x.summary)}</p>` : '') +
                `<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">${group('Key Findings', 'insights', x.key_findings)}${group('Engagement Trends', 'trending_up', x.demographic_trends)}
                 ${group('Significant Changes / Patterns', 'timeline', x.patterns)}${group('Audience & Channel Observations', 'groups', x.population_observations)}</div>` +
                (recs ? `<div class="rounded-2xl border border-indigo-100 bg-white p-5 mt-4"><div class="flex items-center gap-2 mb-3"><span class="material-symbols-outlined text-indigo-600">task_alt</span><h5 class="text-[10px] font-black uppercase tracking-widest text-indigo-700">Recommended Actions</h5></div><ul class="space-y-3">${recs}</ul></div>` : '') +
                '<p class="text-[10px] text-slate-400 font-bold mt-4">AI-generated from aggregated announcement figures only. Verify against the tables below.</p>';
            renderAiTabs();
        }
        async function aiRequest(cachedOnly, scope) {
            const fd = new FormData();
            fd.append('csrf_token', CSRF_TOKEN);
            fd.append('start', DATA?.period?.start || '');
            fd.append('end', DATA?.period?.end || '');
            fd.append('scope', scope);
            if (cachedOnly) fd.append('cached_only', '1');
            const r = await fetch('../backend/announcement_ai_summary.php', { method: 'POST', body: fd, credentials: 'same-origin' });
            let j = null; try { j = await r.json(); } catch (e) { throw new Error('The AI service returned an invalid response.'); }
            if (!j || !j.success) throw new Error(j?.error || 'AI Analytics is unavailable right now.');
            return j;
        }
        function generateAi() {
            if (!DATA) return;
            const m = document.getElementById('aiScopeModal'); m.classList.remove('hidden'); m.classList.add('flex');
        }
        function closeAiScope() { const m = document.getElementById('aiScopeModal'); m.classList.add('hidden'); m.classList.remove('flex'); }
        async function confirmAiScope() {
            const scope = document.querySelector('input[name="asScope"]:checked')?.value || 'app';
            closeAiScope();
            const btn = document.getElementById('aiBtn');
            btn.disabled = true;
            document.getElementById('aiBtnText').textContent = 'Generating…';
            document.getElementById('aiStatus').textContent = 'Generating AI Analytics (' + SCOPES[scope] + ') for ' + DATA.range.label + '…';
            try { renderAi(await aiRequest(false, scope)); }
            catch (e) { document.getElementById('aiStatus').textContent = e.message; document.getElementById('aiBtnText').textContent = 'Generate AI Analytics'; }
            btn.disabled = false;
        }
        async function loadCachedAi() {
            if (!DATA) return;
            // Saved results only (no Gemini call); shows the Application result first.
            for (const k of ['both', 'fb', 'app']) { try { const j = await aiRequest(true, k); if (j.ai) renderAi(j); } catch (e) { } }
        }

        /* ───────── Save PDF / Print ───────── */
        let _reportMode = 'pdf';
        function openReport(mode) {
            _reportMode = mode;
            document.getElementById('rmTitle').textContent = mode === 'pdf' ? 'Save as PDF' : 'Print';
            document.getElementById('rmRange').textContent = DATA ? DATA.range.label : '';
            document.querySelector('input[name="rmAi"][value="0"]').checked = true;
            document.querySelector('input[name="rmScope"][value="app"]').checked = true;
            document.getElementById('rmError').classList.add('hidden');
            const m = document.getElementById('reportModal'); m.classList.remove('hidden'); m.classList.add('flex');
        }
        function closeReport() { const m = document.getElementById('reportModal'); m.classList.add('hidden'); m.classList.remove('flex'); }
        function continueReport() {
            const withAi = document.querySelector('input[name="rmAi"]:checked')?.value === '1';
            const scope = document.querySelector('input[name="rmScope"]:checked')?.value || 'app';
            // Never generates AI here — only uses the analysis already generated on this page for that channel.
            if (withAi && !AI_BY[scope]) {
                const e = document.getElementById('rmError');
                e.textContent = 'Please generate AI Analytics first' + (Object.keys(AI_BY).length ? ' for ' + SCOPES[scope] + ' engagement.' : '.');
                e.classList.remove('hidden'); return;
            }
            const q = new URLSearchParams({ mode: _reportMode, start: DATA?.period?.start || '', end: DATA?.period?.end || '', scope, ai: withAi ? '1' : '0' });
            closeReport();
            window.open('../backend/announcement_analytics_report.php?' + q.toString(), '_blank');
        }
        document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeReport(); closeAiScope(); } });
        document.querySelectorAll('input[name="rmAi"], input[name="rmScope"]').forEach(r => r.addEventListener('change', () => document.getElementById('rmError').classList.add('hidden')));

        render(); loadCachedAi(); loadFb(false);
    </script>
</body>

</html>
