<?php
/**
 * announcement_analytics_data.php
 * Shared data layer for the Announcement (Meta) Analytics page
 * (frontend/announcement_analytics.php) and its AI endpoint
 * (backend/announcement_ai_summary.php).
 *
 *  - announcement_analytics_collect()  → posting statistics from the database
 *  - announcement_fb_metrics()         → Facebook views / reach / engagement for
 *                                         announcements that were posted to the Page
 *
 * An announcement belongs to the range when its date_posted falls inside it.
 */

require_once __DIR__ . '/disaster_analytics_data.php'; // date-range + bucket helpers

if (!function_exists('announcement_status_label')) {
    /**
     * Same status rules as the Announcement Archive table in ann.php.
     * @return string ACTIVE | SCHEDULED | EXPIRED | ENDED | DRAFT
     */
    function announcement_status_label(array $a, string $today): string
    {
        $status = $a['status'] ?? '';
        if ($status === 'Ended') {
            return 'ENDED';
        }
        if ($status === 'Draft') {
            return (!empty($a['date_end']) && $a['date_end'] <= $today) ? 'ENDED' : 'DRAFT';
        }
        if ($status === 'Scheduled') {
            return 'SCHEDULED';
        }
        if (!empty($a['date_end']) && $a['date_end'] < $today) {
            return 'EXPIRED';
        }
        return 'ACTIVE';
    }
}

if (!function_exists('announcement_ref')) {
    function announcement_ref(array $a): string
    {
        $year = !empty($a['created_at']) ? date('Y', strtotime($a['created_at'])) : date('Y', strtotime($a['date_posted'] ?? 'now'));
        return 'ANN-' . $year . '-' . str_pad((string) (int) ($a['ann_id'] ?? 0), 4, '0', STR_PAD_LEFT);
    }
}

if (!function_exists('announcement_analytics_collect')) {
    function announcement_analytics_collect(PDO $pdo, string $start, string $end): array
    {
        $today = date('Y-m-d');
        $buckets = disaster_analytics_buckets($start, $end);
        $bucketFmt = $buckets['granularity'] === 'day' ? 'Y-m-d' : 'Y-m';
        $days = (int) (new DateTime($start))->diff(new DateTime($end))->days + 1;
        $prevEnd = (new DateTime($start))->modify('-1 day')->format('Y-m-d');
        $prevStart = (new DateTime($start))->modify('-' . $days . ' days')->format('Y-m-d');

        $stmt = $pdo->prepare(
            "SELECT a.id, a.ann_id, a.title, a.category, a.category_other, a.status, a.date_posted,
                    a.date_start, a.date_end, a.sms_sent, a.fb_post_id, a.fb_pending, a.created_at,
                    COUNT(at.id) AS attachment_count, COALESCE(SUM(at.is_image), 0) AS image_count
               FROM announcements a
               LEFT JOIN announcement_attachments at ON at.announcement_id = a.id
              WHERE a.deleted_at IS NULL AND a.date_posted BETWEEN :s AND :e
              GROUP BY a.id
              ORDER BY a.date_posted DESC, a.created_at DESC"
        );
        $stmt->execute([':s' => $start, ':e' => $end]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM announcements WHERE deleted_at IS NULL AND date_posted BETWEEN :s AND :e");
        $stmt->execute([':s' => $prevStart, ':e' => $prevEnd]);
        $prevTotal = (int) $stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM announcements WHERE deleted_at IS NOT NULL AND date_posted BETWEEN :s AND :e");
        $stmt->execute([':s' => $start, ':e' => $end]);
        $trashed = (int) $stmt->fetchColumn();

        $byStatus = ['ACTIVE' => 0, 'SCHEDULED' => 0, 'EXPIRED' => 0, 'ENDED' => 0, 'DRAFT' => 0];
        $byCategory = [];
        $weekday = array_fill_keys(['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], 0);
        $trendAll = array_fill_keys($buckets['keys'], 0);
        $trendFb = array_fill_keys($buckets['keys'], 0);
        $fb = ['posted' => 0, 'queued' => 0, 'not_posted' => 0];
        $withAttach = 0;
        $withImages = 0;
        $smsSent = 0;
        $durations = [];
        $list = [];

        foreach ($rows as $a) {
            $label = announcement_status_label($a, $today);
            $byStatus[$label]++;

            $cat = $a['category'] ?: 'General';
            if ($cat === 'Health') {
                $cat = 'Health Advisory';
            }
            $byCategory[$cat] = ($byCategory[$cat] ?? 0) + 1;

            $weekday[date('D', strtotime($a['date_posted']))]++;
            $key = date($bucketFmt, strtotime($a['date_posted']));
            if (isset($trendAll[$key])) {
                $trendAll[$key]++;
            }

            if (!empty($a['fb_post_id'])) {
                $fb['posted']++;
                if (isset($trendFb[$key])) {
                    $trendFb[$key]++;
                }
            } elseif (!empty($a['fb_pending']) && $a['status'] === 'Scheduled') {
                $fb['queued']++;
            } else {
                $fb['not_posted']++;
            }

            if ((int) $a['attachment_count'] > 0) {
                $withAttach++;
            }
            if ((int) $a['image_count'] > 0) {
                $withImages++;
            }
            if (!empty($a['sms_sent'])) {
                $smsSent++;
            }
            if (!empty($a['date_start']) && !empty($a['date_end']) && $a['date_end'] >= $a['date_start']) {
                $durations[] = (strtotime($a['date_end']) - strtotime($a['date_start'])) / 86400 + 1;
            }

            $list[] = [
                'id' => (int) $a['id'],
                'ref' => announcement_ref($a),
                'title' => $a['title'],
                'category' => ($a['category'] === 'Others' && !empty($a['category_other'])) ? $a['category_other'] : $cat,
                'date_posted' => $a['date_posted'],
                'status' => $label,
                'fb_post_id' => $a['fb_post_id'] ?: null,
                'attachments' => (int) $a['attachment_count'],
            ];
        }
        arsort($byCategory);

        $total = count($rows);
        $weeks = max(1, $days / 7);

        return [
            'range' => [
                'start' => $start,
                'end' => $end,
                'days' => $days,
                'label' => date('M j, Y', strtotime($start)) . ' – ' . date('M j, Y', strtotime($end)),
                'prev_start' => $prevStart,
                'prev_end' => $prevEnd,
            ],
            'summary' => [
                'total' => $total,
                'prev_total' => $prevTotal,
                'active' => $byStatus['ACTIVE'],
                'scheduled' => $byStatus['SCHEDULED'],
                'ended' => $byStatus['ENDED'],
                'expired' => $byStatus['EXPIRED'],
                'draft' => $byStatus['DRAFT'],
                'fb_posted' => $fb['posted'],
                'fb_queued' => $fb['queued'],
                'with_attachments' => $withAttach,
                'with_images' => $withImages,
                'sms_sent' => $smsSent,
                'trashed' => $trashed,
                'per_week' => round($total / $weeks, 1),
                'avg_duration_days' => $durations ? round(array_sum($durations) / count($durations), 1) : null,
                'top_category' => $byCategory ? array_key_first($byCategory) : null,
            ],
            'trend' => [
                'granularity' => $buckets['granularity'],
                'labels' => $buckets['labels'],
                'datasets' => [
                    ['label' => 'Announcements posted', 'data' => array_values($trendAll)],
                    ['label' => 'Posted to Facebook', 'data' => array_values($trendFb)],
                ],
            ],
            'by_status' => $byStatus,
            'by_category' => $byCategory,
            'weekday' => $weekday,
            'facebook' => $fb,
            'announcements' => $list,
        ];
    }
}

if (!function_exists('announcement_fb_metrics')) {
    /**
     * Pulls views (impressions), reach (unique impressions), reactions, comments,
     * shares and clicks for the given announcements from the Facebook Graph API.
     *
     * Results are cached per post for 30 minutes (backend/cache/fb_metrics_cache.json)
     * so opening the page repeatedly does not hammer the Graph API. At most $limit
     * of the most recent posts are queried per request.
     *
     * @param  array $posts list of ['id','ref','title','fb_post_id','date_posted']
     * @return array ['available'=>bool,'error'=>?string,'totals'=>array,'posts'=>array,'fetched_at'=>string]
     */
    function announcement_fb_metrics(array $posts, bool $forceRefresh = false, int $limit = 40): array
    {
        $empty = ['impressions' => 0, 'reach' => 0, 'reactions' => 0, 'comments' => 0, 'shares' => 0, 'clicks' => 0];
        $posts = array_values(array_filter($posts, static fn($p) => !empty($p['fb_post_id'])));
        $out = ['available' => false, 'error' => null, 'insights_available' => false, 'totals' => $empty, 'posts' => [], 'fetched_at' => date('M j, Y g:i A'), 'limited' => count($posts) > $limit];

        if (!$posts) {
            $out['error'] = 'None of the announcements in this date range were posted to the Facebook Page.';
            return $out;
        }
        $posts = array_slice($posts, 0, $limit);

        if (!defined('SOE_LIB_INCLUDE')) {
            define('SOE_LIB_INCLUDE', true);
        }
        try {
            require_once __DIR__ . '/fb_helper.php';
            $token = fb_get_page_token();
        } catch (Throwable $e) {
            $out['error'] = 'Facebook is not connected, so views/reach cannot be read. An admin can reconnect it in Settings → Facebook.';
            return $out;
        }

        $cacheDir = __DIR__ . '/cache';
        $cacheFile = $cacheDir . '/fb_metrics_cache.json';
        $cache = [];
        if (is_file($cacheFile)) {
            $cache = json_decode((string) @file_get_contents($cacheFile), true) ?: [];
        }
        $ttl = 1800;
        $lastError = null;
        $dirty = false;

        foreach ($posts as $p) {
            $pid = (string) $p['fb_post_id'];
            $m = null;

            if (!$forceRefresh && isset($cache[$pid]) && (time() - (int) ($cache[$pid]['t'] ?? 0)) < $ttl) {
                $m = $cache[$pid]['m'];
            } else {
                $res = fb_graph_request('GET', '/' . rawurlencode($pid), [
                    'fields' => 'shares,reactions.summary(total_count).limit(0),comments.summary(total_count).limit(0),permalink_url',
                    'access_token' => $token,
                ]);
                if (!$res['success']) {
                    $lastError = $res['data']['error']['message'] ?? 'Facebook request failed.';
                    continue;
                }
                $d = $res['data'];
                $m = [
                    'reactions' => (int) ($d['reactions']['summary']['total_count'] ?? 0),
                    'comments' => (int) ($d['comments']['summary']['total_count'] ?? 0),
                    'shares' => (int) ($d['shares']['count'] ?? 0),
                    'impressions' => null,
                    'reach' => null,
                    'clicks' => null,
                    'permalink' => $d['permalink_url'] ?? null,
                ];

                // Insights need the read_insights permission — optional.
                $ins = fb_graph_request('GET', '/' . rawurlencode($pid) . '/insights', [
                    'metric' => 'post_impressions,post_impressions_unique,post_clicks',
                    'access_token' => $token,
                ]);
                if ($ins['success']) {
                    foreach ($ins['data']['data'] ?? [] as $row) {
                        $val = (int) ($row['values'][0]['value'] ?? 0);
                        if ($row['name'] === 'post_impressions') {
                            $m['impressions'] = $val;
                        } elseif ($row['name'] === 'post_impressions_unique') {
                            $m['reach'] = $val;
                        } elseif ($row['name'] === 'post_clicks') {
                            $m['clicks'] = $val;
                        }
                    }
                }
                $cache[$pid] = ['t' => time(), 'm' => $m];
                $dirty = true;
            }

            $engagement = $m['reactions'] + $m['comments'] + $m['shares'] + (int) ($m['clicks'] ?? 0);
            $out['posts'][] = [
                'id' => $p['id'],
                'ref' => $p['ref'] ?? '',
                'title' => $p['title'] ?? '',
                'date_posted' => $p['date_posted'] ?? null,
                'engagement' => $engagement,
                'rate' => !empty($m['reach']) ? round($engagement / $m['reach'] * 100, 1) : null,
            ] + $m;

            foreach (['reactions', 'comments', 'shares'] as $k) {
                $out['totals'][$k] += (int) $m[$k];
            }
            foreach (['impressions', 'reach', 'clicks'] as $k) {
                if ($m[$k] !== null) {
                    $out['totals'][$k] += (int) $m[$k];
                    $out['insights_available'] = true;
                }
            }
        }

        if ($dirty) {
            if (!is_dir($cacheDir)) {
                @mkdir($cacheDir, 0775, true);
                @file_put_contents($cacheDir . '/.htaccess', "Require all denied\nDeny from all\n");
            }
            @file_put_contents($cacheFile, json_encode($cache));
        }

        usort($out['posts'], static fn($a, $b) => $b['engagement'] <=> $a['engagement']);
        $out['available'] = (bool) $out['posts'];
        if (!$out['available']) {
            $out['error'] = 'Could not read the Facebook metrics: ' . ($lastError ?? 'unknown error');
        } elseif ($lastError) {
            $out['error'] = 'Some posts could not be read from Facebook: ' . $lastError;
        }

        $t = $out['totals'];
        $out['totals']['engagement'] = $t['reactions'] + $t['comments'] + $t['shares'] + $t['clicks'];
        $out['totals']['rate'] = $t['reach'] > 0 ? round($out['totals']['engagement'] / $t['reach'] * 100, 1) : null;
        $out['totals']['posts_read'] = count($out['posts']);

        return $out;
    }
}

/* ─────────────────────────────────────────────────────────────────────────────
 * App-focused Announcement Analytics (same behavior as Resident / Household /
 * Legal Document Analytics). Start / End Date optional — empty = all records.
 * Engagement comes from the barangay resident app:
 *   views     = residents who opened the announcement (announcement_reads)
 *   reach     = unique residents who viewed, reacted or commented
 *   likes ❤️ / dislikes 👎 (announcement_reactions), comments 💬 (announcement_comments)
 *   engagement rate = (likes + dislikes + comments) ÷ views
 * Facebook Page engagement is its own section (announcement_fb_compute).
 * ───────────────────────────────────────────────────────────────────────────── */
require_once __DIR__ . '/ann_engagement_helper.php';
require_once __DIR__ . '/../../residents/backend/resident_analytics_data.php'; // ra_params, ra_range_label, ra_pct

if (!function_exists('announcement_analytics_compute')) {
    function announcement_analytics_compute(PDO $pdo, array $p): array
    {
        ann_engagement_migrate($pdo);
        $start = $p['start']; $end = $p['end'];
        if ($start === '' || $end === '') {
            $min = $pdo->query("SELECT MIN(date_posted) FROM announcements WHERE deleted_at IS NULL")->fetchColumn();
            if ($start === '') $start = $min ?: date('Y-m-d');
            if ($end === '') $end = max(date('Y-m-d'), (string)($pdo->query("SELECT MAX(date_posted) FROM announcements WHERE deleted_at IS NULL")->fetchColumn() ?: date('Y-m-d')));
            if ($start > $end) $start = $end;
        }
        $d = announcement_analytics_collect($pdo, $start, $end);
        $open = $p['start'] === '' || $p['end'] === '';
        $d['period'] = $p;
        $d['range']['label'] = $p['label'];
        $d['range']['open'] = $open;

        // ── Engagement per announcement (resident app) ──
        $ids = array_column($d['announcements'], 'id');
        $counts = ann_engagement_counts($pdo, $ids);
        $reachPer = array_fill_keys($ids, 0);
        $reachAll = 0;
        if ($ids) {
            $in = implode(',', array_map('intval', $ids));
            $u = "SELECT announcement_id a, resident_id r FROM announcement_reads WHERE announcement_id IN ($in)
                  UNION SELECT announcement_id, resident_id FROM announcement_reactions WHERE announcement_id IN ($in)
                  UNION SELECT announcement_id, resident_id FROM announcement_comments WHERE deleted_at IS NULL AND announcement_id IN ($in)";
            foreach ($pdo->query("SELECT a, COUNT(DISTINCT r) n FROM ($u) x GROUP BY a") as $r) $reachPer[(int)$r['a']] = (int)$r['n'];
            $reachAll = (int)$pdo->query("SELECT COUNT(DISTINCT r) FROM ($u) x")->fetchColumn();
        }
        $tot = ['views' => 0, 'likes' => 0, 'dislikes' => 0, 'comments' => 0];
        foreach ($d['announcements'] as &$a) {
            $c = $counts[$a['id']] ?? ['views' => 0, 'likes' => 0, 'dislikes' => 0, 'comments' => 0];
            $a += $c;
            $a['reach'] = $reachPer[$a['id']] ?? 0;
            $a['engagement'] = $c['likes'] + $c['dislikes'] + $c['comments'];
            $a['rate'] = $c['views'] ? round($a['engagement'] / $c['views'] * 100, 1) : null;
            foreach ($tot as $k => $v) $tot[$k] += $c[$k];
        }
        unset($a);
        $engagement = $tot['likes'] + $tot['dislikes'] + $tot['comments'];
        try {
            $residents = (int)$pdo->query("SELECT COUNT(*) FROM residents WHERE (IsDeceased = 0 OR IsDeceased IS NULL)")->fetchColumn();
        } catch (Throwable $e) { $residents = 0; }
        $n = count($d['announcements']);
        $d['app'] = $tot + [
            'reach' => $reachAll, 'engagement' => $engagement,
            'engagement_rate' => $tot['views'] ? round($engagement / $tot['views'] * 100, 1) : null,
            'avg_views' => $n ? round($tot['views'] / $n, 1) : 0,
            'residents' => $residents,
            'reach_rate' => $residents ? round($reachAll / $residents * 100, 1) : null,
            'like_ratio' => ($tot['likes'] + $tot['dislikes']) ? round($tot['likes'] / ($tot['likes'] + $tot['dislikes']) * 100, 1) : null,
            'viewed' => count(array_filter($d['announcements'], fn($a) => $a['views'] > 0)),
        ];
        $sorted = $d['announcements'];
        usort($sorted, fn($x, $y) => [$y['views'], $y['engagement']] <=> [$x['views'], $x['engagement']]);
        $d['most_viewed'] = array_slice(array_values(array_filter($sorted, fn($a) => $a['views'] > 0)), 0, 10);
        usort($sorted, fn($x, $y) => [$y['engagement'], $y['views']] <=> [$x['engagement'], $x['views']]);
        $d['most_engaged'] = array_slice(array_values(array_filter($sorted, fn($a) => $a['engagement'] > 0)), 0, 10);

        // Engagement by category
        $byCat = [];
        foreach ($d['announcements'] as $a) {
            $k = $a['category'];
            $byCat[$k] = $byCat[$k] ?? ['category' => $k, 'posts' => 0, 'views' => 0, 'likes' => 0, 'dislikes' => 0, 'comments' => 0];
            $byCat[$k]['posts']++;
            foreach (['views', 'likes', 'dislikes', 'comments'] as $f) $byCat[$k][$f] += $a[$f];
        }
        usort($byCat, fn($x, $y) => $y['views'] <=> $x['views']);
        $d['by_category_engagement'] = array_values($byCat);

        // ── Interaction activity over time (when residents viewed / reacted / commented) ──
        $buckets = disaster_analytics_buckets($start, $end);
        $fmt = $buckets['granularity'] === 'day' ? '%Y-%m-%d' : '%Y-%m';
        $series = ['views' => array_fill_keys($buckets['keys'], 0), 'likes' => array_fill_keys($buckets['keys'], 0), 'dislikes' => array_fill_keys($buckets['keys'], 0), 'comments' => array_fill_keys($buckets['keys'], 0)];
        $weekday = array_fill_keys(['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], 0);
        $hours = array_fill(0, 24, 0);
        $args = [$start . ' 00:00:00', $end . ' 23:59:59'];
        $q = function (string $sql) use ($pdo, $args) { $s = $pdo->prepare($sql); $s->execute($args); return $s->fetchAll(PDO::FETCH_ASSOC); };
        foreach ([['views', "SELECT read_at t FROM announcement_reads WHERE read_at BETWEEN ? AND ?"],
                  ['likes', "SELECT COALESCE(updated_at, created_at) t FROM announcement_reactions WHERE reaction = 'like' AND COALESCE(updated_at, created_at) BETWEEN ? AND ?"],
                  ['dislikes', "SELECT COALESCE(updated_at, created_at) t FROM announcement_reactions WHERE reaction = 'dislike' AND COALESCE(updated_at, created_at) BETWEEN ? AND ?"],
                  ['comments', "SELECT created_at t FROM announcement_comments WHERE deleted_at IS NULL AND created_at BETWEEN ? AND ?"]] as [$k, $sql]) {
            try {
                foreach ($q($sql) as $r) {
                    $ts = strtotime($r['t']);
                    $key = date($buckets['granularity'] === 'day' ? 'Y-m-d' : 'Y-m', $ts);
                    if (isset($series[$k][$key])) $series[$k][$key]++;
                    $weekday[date('D', $ts)]++;
                    $hours[(int)date('G', $ts)]++;
                }
            } catch (Throwable $e) { /* table missing */ }
        }
        $d['activity'] = ['granularity' => $buckets['granularity'], 'labels' => $buckets['labels'],
            'series' => array_map('array_values', $series), 'weekday' => $weekday,
            'hours' => array_combine(array_map(fn($h) => date('g A', mktime($h, 0)), range(0, 23)), $hours)];
        $peakH = max($hours) ? array_search(max($hours), $hours, true) : null;
        $d['app']['busiest_hour'] = $peakH !== null ? date('g A', mktime($peakH, 0)) : null;
        $d['app']['busiest_day'] = max($weekday) ? array_search(max($weekday), $weekday, true) : null;

        // ── Selected vs previous period ──
        $d['comparison'] = null;
        if (!$open) {
            $ps = $d['range']['prev_start'] . ' 00:00:00'; $pe = $d['range']['prev_end'] . ' 23:59:59';
            $prevOne = function (string $sql) use ($pdo, $ps, $pe) { try { $s = $pdo->prepare($sql); $s->execute([$ps, $pe]); return (int)$s->fetchColumn(); } catch (Throwable $e) { return 0; } };
            $d['comparison'] = ['previous_label' => ra_range_label($d['range']['prev_start'], $d['range']['prev_end']), 'rows' => [
                ['metric' => 'Announcements posted', 'current' => $d['summary']['total'], 'previous' => $d['summary']['prev_total']],
                ['metric' => 'Views (app)', 'current' => array_sum($series['views']), 'previous' => $prevOne("SELECT COUNT(*) FROM announcement_reads WHERE read_at BETWEEN ? AND ?")],
                ['metric' => 'Likes', 'current' => array_sum($series['likes']), 'previous' => $prevOne("SELECT COUNT(*) FROM announcement_reactions WHERE reaction = 'like' AND COALESCE(updated_at, created_at) BETWEEN ? AND ?")],
                ['metric' => 'Dislikes', 'current' => array_sum($series['dislikes']), 'previous' => $prevOne("SELECT COUNT(*) FROM announcement_reactions WHERE reaction = 'dislike' AND COALESCE(updated_at, created_at) BETWEEN ? AND ?")],
                ['metric' => 'Comments', 'current' => array_sum($series['comments']), 'previous' => $prevOne("SELECT COUNT(*) FROM announcement_comments WHERE deleted_at IS NULL AND created_at BETWEEN ? AND ?")],
            ]];
        }
        return $d;
    }
}

if (!function_exists('announcement_analytics_snapshot')) {
    /** Aggregated figures only (no names) — what the AI sees and the key of its saved result. */
    function announcement_analytics_snapshot(array $d): array
    {
        $slim = fn($a) => array_intersect_key($a, array_flip(['title', 'category', 'date_posted', 'status', 'views', 'reach', 'likes', 'dislikes', 'comments', 'rate']));
        return [
            'date_range' => $d['range']['label'], 'posting' => $d['summary'], 'app' => $d['app'],
            'by_status' => $d['by_status'], 'by_category' => $d['by_category'], 'by_category_engagement' => $d['by_category_engagement'],
            'most_viewed' => array_map($slim, $d['most_viewed']), 'most_engaged' => array_map($slim, $d['most_engaged']),
            'activity' => ['labels' => $d['activity']['labels'], 'series' => $d['activity']['series'], 'weekday' => $d['activity']['weekday']],
            'facebook_posting' => $d['facebook'], 'comparison' => $d['comparison'],
        ];
    }
}

if (!function_exists('announcement_analytics_interpretation')) {
    function announcement_analytics_interpretation(array $d): array
    {
        $s = $d['summary']; $a = $d['app'];
        if (!$s['total']) return ['No announcements were posted for ' . $d['range']['label'] . '.'];
        $out = [];
        $out[] = $s['total'] . ' announcement(s) were posted for ' . $d['range']['label'] . ': ' . $s['active'] . ' active, ' . $s['scheduled'] . ' scheduled, '
            . $s['expired'] . ' expired, ' . $s['ended'] . ' ended and ' . $s['draft'] . ' draft' . ($s['top_category'] ? '; most were ' . $s['top_category'] . '.' : '.');
        $out[] = 'In the resident app they were viewed ' . number_format($a['views']) . ' time(s) (average ' . $a['avg_views'] . ' per announcement) and reached '
            . number_format($a['reach']) . ' unique resident(s)' . ($a['reach_rate'] !== null ? ' (' . $a['reach_rate'] . '% of ' . number_format($a['residents']) . ' residents)' : '') . '.';
        $out[] = 'Residents gave ' . number_format($a['likes']) . ' like(s), ' . number_format($a['dislikes']) . ' dislike(s) and ' . number_format($a['comments']) . ' comment(s)'
            . ($a['engagement_rate'] !== null ? ' — an engagement rate of ' . $a['engagement_rate'] . '% of views' : '') . ($a['like_ratio'] !== null ? '; ' . $a['like_ratio'] . '% of reactions were likes.' : '.');
        if ($d['most_viewed']) $out[] = 'The most viewed announcement is "' . $d['most_viewed'][0]['title'] . '" with ' . $d['most_viewed'][0]['views'] . ' view(s).';
        if ($d['most_engaged']) $out[] = 'The most engaged announcement is "' . $d['most_engaged'][0]['title'] . '" with ' . $d['most_engaged'][0]['engagement'] . ' interaction(s).';
        $unseen = $s['total'] - $a['viewed'];
        if ($unseen > 0) $out[] = $unseen . ' announcement(s) have not been viewed by any resident in the app yet.';
        if ($a['busiest_day']) $out[] = 'Residents interact most on ' . $a['busiest_day'] . ($a['busiest_hour'] ? ', around ' . $a['busiest_hour'] : '') . '.';
        $out[] = $d['facebook']['posted'] . ' announcement(s) were also posted to the Facebook Page.';
        if ($d['comparison']) {
            $c = $d['comparison']['rows'][1]; $x = $c['current'] - $c['previous'];
            $out[] = 'Compared with the previous period (' . $d['comparison']['previous_label'] . '), app views ' . ($x > 0 ? 'increased by ' . $x : ($x < 0 ? 'decreased by ' . abs($x) : 'stayed the same')) . ' (' . $c['previous'] . ' → ' . $c['current'] . ').';
        }
        return $out;
    }
}

/* ─────────────────────────────────────────────────────────────────────────────
 * Facebook Page engagement (Meta-style) + Application / Facebook / Both scope
 * for AI Analytics and Save PDF / Print.
 * ───────────────────────────────────────────────────────────────────────────── */
if (!function_exists('announcement_scope')) {
    /** app | fb | both */
    function announcement_scope($v): string
    {
        return in_array($v, ['app', 'fb', 'both'], true) ? $v : 'app';
    }
    function announcement_scope_label(string $scope): string
    {
        return ['app' => 'Application', 'fb' => 'Facebook', 'both' => 'Application & Facebook'][$scope] ?? 'Application';
    }
}

if (!function_exists('announcement_fb_compute')) {
    /**
     * Facebook Page metrics for the announcements in the range (cached 30 min by
     * announcement_fb_metrics) plus a Meta-style breakdown: engagement mix and
     * performance by posting date.
     */
    function announcement_fb_compute(array $d, bool $refresh = false): array
    {
        $fb = announcement_fb_metrics($d['announcements'], $refresh);
        $t = $fb['totals'];
        $fb['mix'] = ['Reactions' => (int)$t['reactions'], 'Comments' => (int)$t['comments'], 'Shares' => (int)$t['shares'], 'Clicks' => (int)$t['clicks']];
        $byDate = [];
        foreach ($fb['posts'] as $x) {
            $k = $x['date_posted'] ? date('Y-m-d', strtotime($x['date_posted'])) : '—';
            $byDate[$k] = $byDate[$k] ?? ['date' => $k, 'posts' => 0, 'impressions' => 0, 'reach' => 0, 'reactions' => 0, 'comments' => 0, 'shares' => 0, 'clicks' => 0, 'engagement' => 0];
            $byDate[$k]['posts']++;
            foreach (['impressions', 'reach', 'reactions', 'comments', 'shares', 'clicks', 'engagement'] as $f) $byDate[$k][$f] += (int)($x[$f] ?? 0);
        }
        ksort($byDate);
        $fb['by_date'] = array_values($byDate);
        $fb['posted'] = (int)$d['facebook']['posted'];
        $fb['queued'] = (int)$d['facebook']['queued'];
        $fb['not_posted'] = (int)$d['facebook']['not_posted'];
        $fb['interpretation'] = announcement_fb_interpretation($d, $fb);
        return $fb;
    }
}

if (!function_exists('announcement_fb_interpretation')) {
    function announcement_fb_interpretation(array $d, array $fb): array
    {
        $out = [];
        $out[] = $fb['posted'] . ' of ' . $d['summary']['total'] . ' announcement(s) for ' . $d['range']['label'] . ' were posted to the Facebook Page'
            . ($fb['queued'] ? ' and ' . $fb['queued'] . ' are queued with a schedule.' : '.');
        if (!$fb['available']) {
            $out[] = $fb['error'] ?: 'Facebook metrics are not available.';
            return $out;
        }
        $t = $fb['totals'];
        if ($fb['insights_available']) {
            $out[] = 'The posts were shown ' . number_format($t['impressions']) . ' time(s) (views) and reached ' . number_format($t['reach']) . ' unique people on Facebook.';
        } else {
            $out[] = 'Views and reach need the Page "read_insights" permission, so only reactions, comments and shares are counted.';
        }
        $out[] = 'People reacted ' . number_format($t['reactions']) . ' time(s), commented ' . number_format($t['comments']) . ' time(s) and shared ' . number_format($t['shares'])
            . ' time(s)' . ($t['clicks'] ? ', with ' . number_format($t['clicks']) . ' click(s)' : '') . ' — ' . number_format($t['engagement']) . ' engagement(s) in total'
            . ($t['rate'] !== null ? ' (' . $t['rate'] . '% engagement rate on reach).' : '.');
        if ($fb['posts']) {
            $top = $fb['posts'][0];
            $out[] = 'The best-performing Facebook post is "' . $top['title'] . '" with ' . number_format($top['engagement']) . ' engagement(s).';
        }
        $a = $d['app'];
        $out[] = 'Compared with the resident app: ' . number_format($a['views']) . ' app view(s) and ' . number_format($a['engagement']) . ' app interaction(s) vs '
            . ($fb['insights_available'] ? number_format($t['impressions']) . ' Facebook view(s)' : 'Facebook views not available') . ' and ' . number_format($t['engagement']) . ' Facebook engagement(s).';
        return $out;
    }
}

if (!function_exists('announcement_ai_key')) {
    /**
     * Key of the saved AI result for a scope. Based on the app data only, so the
     * report finds the analysis even after the 30-minute Facebook cache refreshes.
     */
    function announcement_ai_key(array $d, string $scope): array
    {
        return ['scope' => $scope] + announcement_analytics_snapshot($d);
    }
    /** Aggregated data the AI reads for a scope (no names of residents). */
    function announcement_ai_data(array $d, string $scope, ?array $fb): array
    {
        $out = ['scope' => announcement_scope_label($scope), 'date_range' => $d['range']['label']];
        if ($scope !== 'fb') $out['application'] = announcement_analytics_snapshot($d);
        if ($scope !== 'app' && $fb) {
            $slim = fn($p) => array_intersect_key($p, array_flip(['title', 'date_posted', 'impressions', 'reach', 'reactions', 'comments', 'shares', 'clicks', 'engagement', 'rate']));
            $out['facebook'] = ['available' => $fb['available'], 'note' => $fb['error'], 'insights_available' => $fb['insights_available'],
                'posted' => $fb['posted'], 'queued' => $fb['queued'], 'not_posted' => $fb['not_posted'], 'totals' => $fb['totals'],
                'top_posts' => array_map($slim, array_slice($fb['posts'], 0, 15)), 'by_date' => $fb['by_date']];
            if ($scope === 'fb') $out['announcements_posted_in_range'] = $d['summary']['total'];
        }
        return $out;
    }
}
