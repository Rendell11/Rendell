<?php
/**
 * announcement_ai_summary.php — AI Analytics for Announcement Analytics (JSON, POST).
 * scope = app  → the barangay resident app (posts, views, reach, likes, dislikes, comments)
 *         fb   → the Facebook Page (views, reach, reactions, comments, shares, clicks)
 *         both → both channels, compared
 * Same behavior as the Resident / Household / Legal Document analytics:
 *   - called ONLY when "Generate AI Analytics" is clicked (never automatically)
 *   - start, end (optional — empty = all records), scope, csrf_token
 *   - cached_only=1 → return an analysis generated before for the same data (no Gemini call)
 * Only aggregated figures are sent (no resident data). The result is cached by data snapshot,
 * so the Save PDF / Print report can include it without calling Gemini again.
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_permission($pdo, 'announcements', 'read');
require_once __DIR__ . '/csrf_helper.php';
require_once __DIR__ . '/../../ai_helper.php';
require_once __DIR__ . '/announcement_analytics_data.php';

header('Content-Type: application/json; charset=utf-8');
$out = function (array $d, int $code = 200) { http_response_code($code); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; };

if ($_SERVER['REQUEST_METHOD'] !== 'POST') $out(['success' => false, 'error' => 'Method not allowed.'], 405);
if (!verify_csrf_token($_POST['csrf_token'] ?? '')) $out(['success' => false, 'error' => 'Your session has expired. Please refresh the page and try again.'], 403);

try {
    $p = ra_params($_POST);
    $d = announcement_analytics_compute($pdo, $p);
} catch (Throwable $e) {
    error_log('[Announcement AI] data: ' . $e->getMessage());
    $out(['success' => false, 'error' => 'Could not read the announcement records.'], 500);
}

$scope = announcement_scope($_POST['scope'] ?? 'app');
$snapshot = announcement_ai_key($d, $scope);
$ns = 'announcement_analytics';
if (!empty($_POST['cached_only'])) {
    $c = ai_cache_get($ns, $snapshot);
    $out($c ? $c + ['cached' => true] : ['success' => true, 'none' => true, 'scope' => $scope]);
}
if (!$d['summary']['total']) $out(['success' => false, 'error' => 'There are no announcements for ' . $d['range']['label'] . ', so there is nothing to analyse.']);
$fb = null;
if ($scope !== 'app') {
    $fb = announcement_fb_compute($d);
    if (!$fb['available'] && $scope === 'fb') $out(['success' => false, 'error' => 'Facebook engagement is not available: ' . ($fb['error'] ?: 'no data') . ' Choose Application instead.']);
}
if (ai_api_key() === '') $out(['success' => false, 'error' => 'AI is not configured. Set GEMINI_API_KEY in the CAPS .env file.']);

$focus = [
    'app' => "Focus ONLY on the barangay's own resident app: announcements posted, views (residents who opened them), reach (unique residents), likes, dislikes, comments, engagement rate, most viewed / most engaged announcements and interaction trends. ",
    'fb' => "Focus ONLY on the barangay Facebook Page: announcements posted to the Page, views (impressions), reach (unique people), reactions, comments, shares, clicks, engagement rate, best-performing posts and performance by posting date. ",
    'both' => "Cover BOTH channels and compare them: the barangay resident app (views, reach, likes, dislikes, comments) and the Facebook Page (views, reach, reactions, comments, shares, clicks). Say which channel reaches and engages residents better, with figures. ",
][$scope];
$prompt = "You are a data analyst for a Philippine barangay office. Analyze ONLY the aggregated announcement data below for the date range: " . $d['range']['label'] . ". "
    . $focus
    . "Do not invent numbers or names; cite the actual figures and percentages. Keep each detail to one or two short sentences. If the data is thin (e.g. few views), say so briefly.\n"
    . "- key_findings: the most important facts (volume, views, reach, engagement, top announcements / posts).\n"
    . "- demographic_trends: engagement trends over time, comparison with the previous period.\n"
    . "- patterns: which categories / kinds of announcements or posts get more engagement; weak ones.\n"
    . "- population_observations: audience and channel observations (reach, " . ($scope === 'both' ? 'app vs Facebook' : ($scope === 'fb' ? 'reactions vs comments vs shares' : 'reach vs residents')) . ").\n"
    . "- recommendations: practical actions to improve how residents are informed and engaged, each tied to a finding.\n\n"
    . "Return JSON: {\"summary\": string (1-2 sentences), "
    . "\"key_findings\": [{\"title\": string, \"detail\": string}] (3-4 items), "
    . "\"demographic_trends\": [{\"title\": string, \"detail\": string}] (2-3 items), "
    . "\"patterns\": [{\"title\": string, \"detail\": string}] (2-3 items), "
    . "\"population_observations\": [{\"title\": string, \"detail\": string}] (2-3 items), "
    . "\"recommendations\": [{\"action\": string, \"reason\": string, \"priority\": \"high\"|\"medium\"|\"low\"}] (3-4 items)}.\n\n"
    . "DATA:\n" . json_encode(announcement_ai_data($d, $scope, $fb), JSON_UNESCAPED_UNICODE);

$r = ai_call([['text' => $prompt]], '', ['temperature' => 0.3]);
$parsed = $r['ok'] ? ai_parse_json($r['text']) : null;
if (!is_array($parsed) || empty($parsed['key_findings'])) $out(['success' => false, 'error' => ($r['error'] ?? '') ?: 'The AI service returned an unreadable answer. Please try again.']);

$clean = fn($v) => mb_substr(trim((string)$v), 0, 600);
$items = function ($list) use ($clean): array {
    $res = [];
    foreach (is_array($list) ? $list : [] as $x) {
        if (!is_array($x) || trim((string)($x['title'] ?? '')) === '') continue;
        $res[] = ['title' => $clean($x['title']), 'detail' => $clean($x['detail'] ?? '')];
    }
    return array_slice($res, 0, 5);
};
$recs = [];
foreach (is_array($parsed['recommendations'] ?? null) ? $parsed['recommendations'] : [] as $x) {
    if (!is_array($x) || trim((string)($x['action'] ?? '')) === '') continue;
    $recs[] = ['action' => $clean($x['action']), 'reason' => $clean($x['reason'] ?? ''),
               'priority' => in_array($x['priority'] ?? '', ['high', 'medium', 'low'], true) ? $x['priority'] : 'medium'];
}
$result = [
    'success' => true, 'ai' => true, 'model' => $r['model'] ?? '', 'generated_at' => date('F j, Y g:i A'), 'period' => $p,
    'scope' => $scope, 'scope_label' => announcement_scope_label($scope),
    'summary' => $clean($parsed['summary'] ?? ''),
    'key_findings' => $items($parsed['key_findings']),
    'demographic_trends' => $items($parsed['demographic_trends'] ?? []),
    'patterns' => $items($parsed['patterns'] ?? []),
    'population_observations' => $items($parsed['population_observations'] ?? []),
    'recommendations' => array_slice($recs, 0, 5),
];
ai_cache_put($ns, $snapshot, $result);
try {
    require_once __DIR__ . '/../../activity_log_helper.php';
    log_activity('Announcements', 'Generate AI Analytics', 'Generated announcement AI analytics (' . announcement_scope_label($scope) . ') for ' . $d['range']['label']);
} catch (Throwable $e) { /* optional */ }
$out($result);
