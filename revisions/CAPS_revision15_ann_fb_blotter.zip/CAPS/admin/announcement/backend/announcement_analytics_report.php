<?php
/**
 * Announcement Analytics Report — opened from Announcement Analytics with ?start&end&scope&mode=print|pdf&ai=1|0.
 *   scope=app  → resident app engagement · scope=fb → Facebook Page engagement · scope=both → both + comparison
 * Same shared CAPS report layout (officials report_common.php) and behavior as the Resident,
 * Household and Legal Document Analytics reports: data / table focused, with interpretation.
 *   ai=0 → "No AI – Data and tables only" (no charts)
 *   ai=1 → supporting charts + the AI Analytics already generated on the page (AI cache — never calls Gemini).
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_permission($pdo, 'announcements', 'read');
require_once __DIR__ . '/../../ai_helper.php';
require_once __DIR__ . '/../../officials/backend/report_common.php';
require_once __DIR__ . '/announcement_analytics_data.php';

$mode = report_mode();
$p = ra_params($_GET);
$d = announcement_analytics_compute($pdo, $p);
$s = $d['summary']; $a = $d['app'];
$scope = announcement_scope($_GET['scope'] ?? 'app');
$showApp = $scope !== 'fb';
$fb = $scope !== 'app' ? announcement_fb_compute($d) : null;
$withAi = ($_GET['ai'] ?? '0') === '1';
$ai = $withAi ? ai_cache_get('announcement_analytics', announcement_ai_key($d, $scope)) : null;
$showCharts = $ai !== null;
$notes = $showApp ? announcement_analytics_interpretation($d) : [];
$fbNotes = $fb ? $fb['interpretation'] : [];
$scopeLabel = announcement_scope_label($scope);

$brgy = report_barangay_profile($pdo);
$bAddr = trim((string)($brgy['address'] ?? '')) ?: implode(', ', array_filter([
    $brgy['barangay_name'] ?? '', $brgy['municipality_name'] ?? '', $brgy['province_name'] ?? '', $brgy['region_name'] ?? '',
], fn($x) => trim((string)$x) !== ''));
$captain = report_current_captain($pdo);
$generatedBy = report_generated_by($pdo);
$generatedRole = ($_SESSION['role'] ?? '') === 'admin' ? 'Administrator' : 'Barangay Staff';
if ($mode !== '') {
    try {
        require_once __DIR__ . '/../../activity_log_helper.php';
        log_activity('Announcements', 'Announcement Analytics Report', ($mode === 'pdf' ? 'Saved PDF' : 'Printed') . ' announcement analytics report (' . $scopeLabel . ') · ' . $d['range']['label'] . ($ai ? ' · with AI findings' : ''));
    } catch (Throwable $e) { /* optional */ }
}

$n = fn($v) => number_format((float)$v);
$pc = fn($v, $t) => ra_pct($v, $t) . '%';
$T = max(1, (int)$s['total']);
function aar_table(array $head, array $rows, string $empty = 'No data for the selected range.', array $right = []): void {
    if (!$rows) { echo '<p class="empty-note">' . rh($empty) . '</p>'; return; }
    echo '<table><thead><tr>';
    foreach ($head as $i => $h) echo '<th' . (in_array($i, $right, true) ? ' class="num"' : '') . '>' . rh($h) . '</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr' . (($row[0] ?? '') === 'Total' ? ' class="total"' : '') . '>';
        foreach (array_values($row) as $i => $c) echo '<td' . (in_array($i, $right, true) ? ' class="num"' : '') . '>' . rh($c) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
}
$dist = function (array $counts, int $base) use ($n, $pc): array {
    $rows = [];
    foreach ($counts as $k => $v) $rows[] = [ucfirst(strtolower((string)$k)), $n($v), $pc($v, $base)];
    if ($rows) $rows[] = ['Total', $n(array_sum($counts)), $pc(array_sum($counts), $base)];
    return $rows;
};
$annRow = fn($x) => [$x['ref'], $x['title'], $x['category'], date('M j, Y', strtotime($x['date_posted'])), $n($x['views']), $n($x['reach']), $n($x['likes']), $n($x['dislikes']), $n($x['comments']), $x['rate'] !== null ? $x['rate'] . '%' : '—'];
$annHead = ['Ref.', 'Announcement', 'Category', 'Posted', 'Views', 'Reach', 'Likes', 'Dislikes', 'Comments', 'Eng. rate'];

$title = 'Announcement Analytics Report';
$fbT = $fb['totals'] ?? [];
$fbv = fn($v) => $fb && $fb['insights_available'] ? $n($v) : '—';
report_head($title, $mode);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<?php report_toolbar($mode, 'announcement_analytics_' . $scope . '_' . ($p['start'] ?: 'all') . '_to_' . ($p['end'] ?: 'all'), 'landscape'); ?>
<style>
    .brgy-addr{text-align:center;font-size:11px;color:#64748b;margin:-12px 0 14px}
    .report-page{max-width:1100px}
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 24px}
    table.kv th{width:42%;background:transparent;font-size:10.5px;color:#64748b}
    table.kv td{font-weight:700}
    td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
    tr.total td{font-weight:800;border-top:1.5px solid #94a3b8;background:#f8fafc}
    th,td{font-size:10.5px}
    .note{margin:10px 0 0;font-size:11.5px;line-height:1.55;color:#334155}
    .sub{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#0d9488;margin:14px 0 4px}
    .sub:first-child{margin-top:0}
    .chart-wrap{position:relative;height:200px;margin:6px 0 4px}
    .chart-cap{font-size:10px;color:#64748b;margin:0 0 4px}
    ol.interp{margin:0;padding-left:18px;font-size:12px;line-height:1.6}
    .ai-item{padding:6px 0;border-bottom:1px solid #e2e8f0;font-size:12px}
    .ai-item:last-child{border-bottom:0}
    .ai-pri{display:inline-block;padding:1px 6px;border-radius:99px;font-size:9px;font-weight:800;text-transform:uppercase;margin-left:6px}
    .pri-high{background:#fee2e2;color:#b91c1c}.pri-medium{background:#fef3c7;color:#b45309}.pri-low{background:#f1f5f9;color:#475569}
    .section-wrap{page-break-inside:auto;break-inside:auto}
    tr,.chart-wrap,.stat-grid,.signature-block,.certify-line{page-break-inside:avoid;break-inside:avoid}
    h2.section{page-break-after:avoid;break-after:avoid}
</style>
<div class="report-page" id="reportRoot">
    <?php report_letterhead($brgy, 'Office of the Punong Barangay · Announcements'); ?>
    <?php if ($bAddr): ?><p class="brgy-addr"><?php echo rh($bAddr); ?></p><?php endif; ?>
    <?php report_title_block($title, ['app' => 'Resident app engagement and announcement statistics', 'fb' => 'Facebook Page engagement of the announcements', 'both' => 'Resident app and Facebook Page engagement'][$scope] . ' · ' . $d['range']['label'], 'Announcements'); ?>

    <?php report_section_open('Report Information'); ?>
    <div class="info-grid">
        <table class="kv"><tbody>
            <tr><th>Date range</th><td><?php echo rh($d['range']['label']); ?></td></tr>
            <tr><th>Channel</th><td><?php echo rh($scopeLabel); ?></td></tr>
            <tr><th>Basis</th><td>Announcements by date posted<?php echo $showApp ? '; app interactions' : ''; ?><?php echo $fb ? '; Facebook Page metrics' : ''; ?></td></tr>
            <tr><th>Announcements covered</th><td><?php echo $n($s['total']); ?></td></tr>
        </tbody></table>
        <table class="kv"><tbody>
            <tr><th>Generated by</th><td><?php echo rh($generatedBy); ?></td></tr>
            <tr><th>Date generated</th><td><?php echo rh(date('F j, Y g:i A')); ?></td></tr>
            <tr><th>Barangay Captain</th><td><?php echo rh($captain ? 'Hon. ' . $captain['full_name'] : 'Not assigned'); ?></td></tr>
        </tbody></table>
    </div>
    <?php if ($showApp): ?><p class="note">App: Views = residents who opened the announcement in the app · Reach = unique residents who viewed, reacted or commented · Engagement rate = (likes + dislikes + comments) ÷ views.</p><?php endif; ?>
    <?php if ($fb): ?><p class="note">Facebook: Views = times the post was shown · Reach = unique people who saw it · Engagement = reactions + comments + shares + clicks · Engagement rate = engagement ÷ reach.</p><?php endif; ?>
    <?php report_section_close(); ?>

    <?php if ($showApp): ?>

    <?php report_section_open('App Engagement Summary'); ?>
    <?php report_stat_cards([
        ['value' => $n($s['total']), 'label' => 'Announcements', 'variant' => 'a'],
        ['value' => $n($a['views']), 'label' => 'App Views', 'variant' => 'b'],
        ['value' => $n($a['reach']), 'label' => 'Residents Reached', 'variant' => 'c'],
        ['value' => $a['engagement_rate'] !== null ? $a['engagement_rate'] . '%' : '—', 'label' => 'Engagement Rate', 'variant' => 'd'],
    ]); ?>
    <div style="margin-top:12px"></div>
    <?php aar_table(['Indicator', 'Value'], [
        ['Likes ❤ / Dislikes / Comments', $n($a['likes']) . ' / ' . $n($a['dislikes']) . ' / ' . $n($a['comments'])],
        ['Average views per announcement', $a['avg_views']],
        ['Reach (share of residents)', $a['reach_rate'] !== null ? $a['reach_rate'] . '% of ' . $n($a['residents']) : '—'],
        ['Likes among reactions', $a['like_ratio'] !== null ? $a['like_ratio'] . '%' : '—'],
        ['Announcements viewed at least once', $n($a['viewed']) . ' of ' . $n($s['total'])],
        ['Busiest interaction day / hour', ($a['busiest_day'] ?: '—') . ' / ' . ($a['busiest_hour'] ?: '—')],
        ['Posts per week', $s['per_week']],
        ['With attachments / images', $n($s['with_attachments']) . ' / ' . $n($s['with_images'])],
    ], '', [1]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Announcement Status & Categories'); ?>
    <p class="sub">Status</p>
    <?php aar_table(['Status', 'Announcements', 'Share'], $dist($d['by_status'], $T), 'No announcements.', [1, 2]); ?>
    <p class="sub">Engagement by category</p>
    <?php aar_table(['Category', 'Posts', 'Views', 'Likes', 'Dislikes', 'Comments'], array_map(fn($c) => [$c['category'], $n($c['posts']), $n($c['views']), $n($c['likes']), $n($c['dislikes']), $n($c['comments'])], $d['by_category_engagement']), 'No announcements.', [1, 2, 3, 4, 5]); ?>
    <?php if ($showCharts && $d['by_category_engagement']): ?>
    <p class="chart-cap">Figure 1. Views and interactions by category</p>
    <div class="chart-wrap"><canvas id="rc-cat"></canvas></div>
    <?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Most Viewed & Most Engaged'); ?>
    <p class="sub">Most viewed announcements</p>
    <?php aar_table($annHead, array_map($annRow, $d['most_viewed']), 'No views recorded yet.', [4, 5, 6, 7, 8, 9]); ?>
    <p class="sub">Most engaged announcements</p>
    <?php aar_table($annHead, array_map($annRow, $d['most_engaged']), 'No likes, dislikes or comments yet.', [4, 5, 6, 7, 8, 9]); ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Engagement Trends'); ?>
    <?php $rows = [];
    foreach ($d['activity']['labels'] as $i => $lbl) {
        $v = $d['activity']['series']['views'][$i]; $l = $d['activity']['series']['likes'][$i]; $x = $d['activity']['series']['dislikes'][$i]; $c = $d['activity']['series']['comments'][$i];
        if ($v + $l + $x + $c || $d['activity']['granularity'] === 'month') $rows[] = [$lbl, $n($v), $n($l), $n($x), $n($c)];
    }
    aar_table([$d['activity']['granularity'] === 'day' ? 'Day' : 'Month', 'Views', 'Likes', 'Dislikes', 'Comments'], $rows, 'No resident interactions in this range.', [1, 2, 3, 4]); ?>
    <?php if ($showCharts && count($d['activity']['labels']) > 1): ?>
    <p class="chart-cap">Figure 2. Resident interactions over time</p>
    <div class="chart-wrap"><canvas id="rc-trend"></canvas></div>
    <?php endif; ?>
    <p class="sub">Interactions by day of the week</p>
    <?php aar_table(['Day', 'Interactions', 'Share'], $dist($d['activity']['weekday'], max(1, array_sum($d['activity']['weekday']))), 'No interactions.', [1, 2]); ?>
    <?php if ($d['comparison']): ?>
    <p class="sub">Selected period vs previous period (<?php echo rh($d['comparison']['previous_label']); ?>)</p>
    <?php aar_table(['Indicator', 'Selected period', 'Previous period', 'Change'], array_map(function ($r) use ($n) { $x = $r['current'] - $r['previous']; return [$r['metric'], $n($r['current']), $n($r['previous']), ($x > 0 ? '+' : '') . $n($x)]; }, $d['comparison']['rows']), '', [1, 2, 3]); ?>
    <?php else: ?><p class="note">Set both a Start Date and an End Date to compare with the previous period of the same length.</p><?php endif; ?>
    <?php report_section_close(); ?>

    <?php report_section_open('Announcement Performance by Date'); ?>
    <?php aar_table($annHead, array_map($annRow, $d['announcements']), 'No announcements in this range.', [4, 5, 6, 7, 8, 9]); ?>
    <?php report_section_close(); ?>

    <?php endif; /* app sections */ ?>

    <?php if ($fb): ?>
    <?php report_section_open('Facebook Page Engagement'); ?>
    <?php report_stat_cards([
        ['value' => $fbv($fbT['impressions']), 'label' => 'FB Views', 'variant' => 'a'],
        ['value' => $fbv($fbT['reach']), 'label' => 'FB Reach', 'variant' => 'b'],
        ['value' => $n($fbT['engagement']), 'label' => 'FB Engagement', 'variant' => 'c'],
        ['value' => $fbT['rate'] !== null ? $fbT['rate'] . '%' : '—', 'label' => 'Engagement Rate', 'variant' => 'd'],
    ]); ?>
    <div style="margin-top:12px"></div>
    <?php aar_table(['Indicator', 'Value'], [
        ['Posted to the Page / queued / not posted', $n($fb['posted']) . ' / ' . $n($fb['queued']) . ' / ' . $n($fb['not_posted'])],
        ['Reactions', $n($fbT['reactions'])],
        ['Comments', $n($fbT['comments'])],
        ['Shares', $n($fbT['shares'])],
        ['Clicks', $fbv($fbT['clicks'])],
        ['Posts read from Facebook', $n($fbT['posts_read'])],
    ], '', [1]); ?>
    <?php if ($fb['error']): ?><p class="note"><?php echo rh($fb['error']); ?></p><?php endif; ?>
    <?php if ($showCharts && $fb['posts']): ?>
    <p class="chart-cap">Figure <?php echo $showApp ? 3 : 1; ?>. Engagement per Facebook post</p>
    <div class="chart-wrap"><canvas id="rc-fbpost"></canvas></div>
    <?php endif; ?>
    <p class="sub">Top Facebook posts</p>
    <?php aar_table(['Announcement', 'Posted', 'Views', 'Reach', 'Reactions', 'Comments', 'Shares', 'Clicks', 'Engagement', 'Eng. rate'], array_map(fn($x) => [
        $x['title'], $x['date_posted'] ? date('M j, Y', strtotime($x['date_posted'])) : '—', $x['impressions'] !== null ? $n($x['impressions']) : '—', $x['reach'] !== null ? $n($x['reach']) : '—',
        $n($x['reactions']), $n($x['comments']), $n($x['shares']), $x['clicks'] !== null ? $n($x['clicks']) : '—', $n($x['engagement']), $x['rate'] !== null ? $x['rate'] . '%' : '—'], $fb['posts']),
        'No Facebook engagement data for this date range.', [2, 3, 4, 5, 6, 7, 8, 9]); ?>
    <p class="sub">Facebook performance by posting date</p>
    <?php aar_table(['Date', 'Posts', 'Views', 'Reach', 'Reactions', 'Comments', 'Shares', 'Engagement'], array_map(fn($x) => [
        $x['date'] === '—' ? '—' : date('M j, Y', strtotime($x['date'])), $n($x['posts']), $fbv($x['impressions']), $fbv($x['reach']), $n($x['reactions']), $n($x['comments']), $n($x['shares']), $n($x['engagement'])], $fb['by_date']),
        'No Facebook engagement data for this date range.', [1, 2, 3, 4, 5, 6, 7]); ?>
    <?php report_section_close(); ?>
    <?php endif; ?>

    <?php if ($fb && $showApp): ?>
    <?php report_section_open('Application vs Facebook'); ?>
    <?php aar_table(['Indicator', 'Resident App', 'Facebook Page'], [
        ['Announcements', $n($s['total']), $n($fb['posted'])],
        ['Views', $n($a['views']), $fbv($fbT['impressions'])],
        ['Reach', $n($a['reach']), $fbv($fbT['reach'])],
        ['Reactions (app: likes + dislikes)', $n($a['likes'] + $a['dislikes']), $n($fbT['reactions'])],
        ['Comments', $n($a['comments']), $n($fbT['comments'])],
        ['Total engagement', $n($a['engagement']), $n($fbT['engagement'])],
        ['Engagement rate', $a['engagement_rate'] !== null ? $a['engagement_rate'] . '% of views' : '—', $fbT['rate'] !== null ? $fbT['rate'] . '% of reach' : '—'],
    ], '', [1, 2]); ?>
    <?php if ($showCharts): ?>
    <p class="chart-cap">Figure 4. Resident app vs Facebook Page</p>
    <div class="chart-wrap"><canvas id="rc-vs"></canvas></div>
    <?php endif; ?>
    <?php report_section_close(); ?>
    <?php endif; ?>

    <?php report_section_open('Data Interpretation'); ?>
    <?php if ($notes): ?><?php if ($fbNotes): ?><p class="sub">Resident app</p><?php endif; ?>
    <ol class="interp"><?php foreach ($notes as $x): ?><li><?php echo rh($x); ?></li><?php endforeach; ?></ol><?php endif; ?>
    <?php if ($fbNotes): ?><?php if ($notes): ?><p class="sub">Facebook Page</p><?php endif; ?>
    <ol class="interp"><?php foreach ($fbNotes as $x): ?><li><?php echo rh($x); ?></li><?php endforeach; ?></ol><?php endif; ?>
    <?php report_section_close(); ?>

    <?php if ($ai): ?>
    <?php report_section_open('AI Findings · ' . $scopeLabel); ?>
        <?php if (!empty($ai['summary'])): ?><p class="note"><?php echo rh($ai['summary']); ?></p><?php endif; ?>
        <?php foreach ([['Key Findings', 'key_findings'], ['Engagement Trends', 'demographic_trends'], ['Significant Changes / Patterns', 'patterns'], ['Audience & Channel Observations', 'population_observations']] as [$lbl, $key]):
            if (empty($ai[$key])) continue; ?>
            <p class="sub"><?php echo rh($lbl); ?></p>
            <?php foreach ($ai[$key] as $f): ?><div class="ai-item"><strong><?php echo rh($f['title']); ?></strong> — <?php echo rh($f['detail']); ?></div><?php endforeach; ?>
        <?php endforeach; ?>
        <?php if (!empty($ai['recommendations'])): ?>
            <p class="sub">Recommended Actions</p>
            <?php foreach ($ai['recommendations'] as $i => $f): ?><div class="ai-item"><?php echo $i + 1; ?>. <strong><?php echo rh($f['action']); ?></strong><span class="ai-pri pri-<?php echo rh($f['priority']); ?>"><?php echo rh($f['priority']); ?></span><br><span style="color:#64748b"><?php echo rh($f['reason']); ?></span></div><?php endforeach; ?>
        <?php endif; ?>
        <p style="margin:8px 0 0;font-size:10px;color:#64748b">AI-generated (Gemini) · <?php echo rh($ai['generated_at'] ?? ''); ?> · based on the aggregated <?php echo rh(strtolower($scopeLabel)); ?> data of <?php echo rh($d['range']['label']); ?>. Verify against the tables above.</p>
    <?php report_section_close(); ?>
    <?php elseif ($withAi): ?>
    <?php report_section_open('AI Findings · ' . $scopeLabel); ?><p class="note">No AI Analytics (<?php echo rh($scopeLabel); ?>) has been generated for this data yet.</p><?php report_section_close(); ?>
    <?php endif; ?>

    <?php report_certify_and_signatures($brgy['brgy_name'] ?? 'Barangay', $generatedBy, $generatedRole, $captain); ?>
    <?php report_footer_strip($brgy['brgy_name'] ?? 'Barangay'); ?>
</div>
<script>
(function () {
    if (!window.Chart) return;
    Chart.defaults.animation = false;
    Chart.defaults.font.family = 'Arial, Helvetica, sans-serif';
    Chart.defaults.font.size = 10;
    Chart.defaults.color = '#475569';
    const grid = { color: '#e2e8f0' };
    const cats = <?php echo json_encode($d['by_category_engagement'], JSON_UNESCAPED_UNICODE); ?>;
    const cEl = document.getElementById('rc-cat');
    if (cEl) new Chart(cEl, { type: 'bar', data: { labels: cats.map(c => c.category), datasets: [
        { label: 'Views', data: cats.map(c => c.views), backgroundColor: '#2a78d6', borderRadius: 3, maxBarThickness: 22 },
        { label: 'Likes + dislikes + comments', data: cats.map(c => c.likes + c.dislikes + c.comments), backgroundColor: '#eb6834', borderRadius: 3, maxBarThickness: 22 }] },
        options: { maintainAspectRatio: false, plugins: { legend: { position: 'top', align: 'end', labels: { boxWidth: 10 } } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
    const act = <?php echo json_encode($d['activity'], JSON_UNESCAPED_UNICODE); ?>;
    const tEl = document.getElementById('rc-trend');
    const line = (label, data, color) => ({ label, data, borderColor: color, backgroundColor: color, borderWidth: 2, pointRadius: act.labels.length > 40 ? 0 : 2, tension: 0 });
    if (tEl) new Chart(tEl, { type: 'line', data: { labels: act.labels, datasets: [line('Views', act.series.views, '#2a78d6'), line('Likes', act.series.likes, '#1baf7a'), line('Dislikes', act.series.dislikes, '#94a3b8'), line('Comments', act.series.comments, '#eb6834')] },
        options: { maintainAspectRatio: false, plugins: { legend: { position: 'top', align: 'end', labels: { boxWidth: 10 } } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
    const fb = <?php echo json_encode($fb ? ['posts' => array_slice($fb['posts'], 0, 12), 'totals' => $fb['totals'], 'insights' => $fb['insights_available']] : null, JSON_UNESCAPED_UNICODE); ?>;
    const short = t => t.length > 24 ? t.slice(0, 23) + '…' : t;
    const bar = (label, data, color) => ({ label, data, backgroundColor: color, borderRadius: 3, maxBarThickness: 22 });
    const opts = { maintainAspectRatio: false, plugins: { legend: { position: 'top', align: 'end', labels: { boxWidth: 10 } } }, scales: { x: { grid: { display: false }, stacked: true }, y: { beginAtZero: true, ticks: { precision: 0 }, grid, stacked: true } } };
    const pEl = document.getElementById('rc-fbpost');
    if (pEl && fb) new Chart(pEl, { type: 'bar', data: { labels: fb.posts.map(x => short(x.title)), datasets: [
        bar('Reactions', fb.posts.map(x => x.reactions), '#1877f2'), bar('Comments', fb.posts.map(x => x.comments), '#42b72a'), bar('Shares', fb.posts.map(x => x.shares), '#f7b928'), bar('Clicks', fb.posts.map(x => x.clicks || 0), '#94a3b8')] }, options: opts });
    const vEl = document.getElementById('rc-vs');
    const app = <?php echo json_encode($showApp ? $a : null); ?>;
    if (vEl && fb && app) new Chart(vEl, { type: 'bar', data: { labels: ['Views', 'Reach', 'Reactions', 'Comments', 'Engagement'], datasets: [
        bar('Resident app', [app.views, app.reach, app.likes + app.dislikes, app.comments, app.engagement], '#0d9488'),
        bar('Facebook', [fb.insights ? fb.totals.impressions : 0, fb.insights ? fb.totals.reach : 0, fb.totals.reactions, fb.totals.comments, fb.totals.engagement], '#1877f2')] },
        options: { maintainAspectRatio: false, plugins: { legend: { position: 'top', align: 'end', labels: { boxWidth: 10 } } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid } } } });
})();
</script>
<?php report_foot(); ?>
