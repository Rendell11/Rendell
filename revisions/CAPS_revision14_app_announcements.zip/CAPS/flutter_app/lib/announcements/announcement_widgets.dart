import 'package:flutter/material.dart';

import '../l10n/app_text.dart';
import '../theme/app_theme.dart';
import 'announcement_api.dart';

/// Colours per category (same idea as the admin announcement badges).
class AnnouncementStyle {
  static Color category(String c) {
    switch (c) {
      case 'Emergency Notice':
        return const Color(0xFFEF4444);
      case 'Health Advisory':
      case 'Health':
        return const Color(0xFF16A34A);
      case 'Community Event':
        return const Color(0xFF8B5CF6);
      case 'General':
        return const Color(0xFF0EA5E9);
      default:
        return const Color(0xFFF59E0B);
    }
  }

  static IconData icon(String c) {
    switch (c) {
      case 'Emergency Notice':
        return Icons.warning_amber_rounded;
      case 'Health Advisory':
      case 'Health':
        return Icons.health_and_safety_outlined;
      case 'Community Event':
        return Icons.event_outlined;
      default:
        return Icons.campaign_outlined;
    }
  }

  static String date(DateTime? d) =>
      d == null ? '—' : '${tr.monthsShort[d.month - 1]} ${d.day}, ${d.year}';

  /// "08:00:00" → "8:00 AM"
  static String time(String? t) {
    if (t == null) return '';
    final p = t.split(':');
    final h = int.tryParse(p[0]) ?? 0;
    final m = p.length > 1 ? p[1] : '00';
    return '${h % 12 == 0 ? 12 : h % 12}:$m ${h < 12 ? 'AM' : 'PM'}';
  }

  /// "Sep 27 – Sep 30, 2026 · 8:00 AM – 5:00 PM" (only the parts that exist).
  static String schedule(Announcement a) {
    final parts = <String>[];
    if (a.dateStart != null || a.dateEnd != null) {
      final s = date(a.dateStart ?? a.dateEnd);
      final e = date(a.dateEnd);
      parts.add(a.dateEnd == null || s == e ? s : '$s – $e');
    }
    if (a.timeStart != null) {
      parts.add(a.timeEnd == null
          ? time(a.timeStart)
          : '${time(a.timeStart)} – ${time(a.timeEnd)}');
    }
    return parts.join(' · ');
  }
}

class AnnouncementPill extends StatelessWidget {
  const AnnouncementPill(this.label, this.color, {super.key, this.icon});

  final String label;
  final Color color;
  final IconData? icon;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .13),
          borderRadius: BorderRadius.circular(50),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: color),
            const SizedBox(width: 4),
          ],
          Flexible(
            child: Text(label.toUpperCase(),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .6,
                    color: color)),
          ),
        ]),
      );
}

/// Network image from the barangay server (works on Flutter web too).
class AnnouncementImage extends StatelessWidget {
  const AnnouncementImage(this.file,
      {super.key, this.height, this.fit = BoxFit.cover});

  final AnnouncementFile file;
  final double? height;
  final BoxFit fit;

  @override
  Widget build(BuildContext context) => Image.network(
        file.fullUrl,
        height: height,
        width: double.infinity,
        fit: fit,
        webHtmlElementStrategy: WebHtmlElementStrategy.fallback,
        errorBuilder: (_, __, ___) => Container(
          height: height ?? 160,
          color: AppColors.surfaceAlt,
          alignment: Alignment.center,
          child: Icon(Icons.broken_image_outlined, color: AppColors.slate400),
        ),
      );
}

/// One photo shown whole (FB style): real aspect ratio, BoxFit.contain,
/// never cropped. Very tall photos are limited to [maxHeight] and
/// letterboxed instead of cut.
class AnnouncementPhoto extends StatelessWidget {
  const AnnouncementPhoto(this.file, {super.key, this.maxHeight = 520});

  final AnnouncementFile file;
  final double maxHeight;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (_, c) {
        final ratio = file.aspectRatio;
        if (ratio == null || !c.maxWidth.isFinite) {
          // Size unknown: let the image size itself, within maxHeight.
          return Container(
            width: double.infinity,
            color: AppColors.surfaceAlt,
            constraints: BoxConstraints(maxHeight: maxHeight),
            child: AnnouncementImage(file, fit: BoxFit.contain),
          );
        }
        final h = (c.maxWidth / ratio).clamp(120.0, maxHeight).toDouble();
        return Container(
          width: double.infinity,
          height: h,
          color: AppColors.surfaceAlt,
          child: AnnouncementImage(file, height: h, fit: BoxFit.contain),
        );
      });
}

/// Height that shows [file] whole at [width] (used by the swipe gallery).
double announcementPhotoHeight(AnnouncementFile file, double width,
    {double maxHeight = 520}) {
  final r = file.aspectRatio ?? 1;
  return (width / r).clamp(160.0, maxHeight).toDouble();
}

/// ❤️ Like · 👎 Dislike · 💬 Comment row (under a post, like Facebook).
/// Tapping the same reaction again removes it.
class AnnouncementEngagementBar extends StatefulWidget {
  const AnnouncementEngagementBar({
    super.key,
    required this.announcement,
    required this.api,
    this.onChanged,
  });

  final Announcement announcement;
  final AnnouncementApi api;
  final ValueChanged<AnnouncementEngagement>? onChanged;

  @override
  State<AnnouncementEngagementBar> createState() =>
      _AnnouncementEngagementBarState();
}

class _AnnouncementEngagementBarState extends State<AnnouncementEngagementBar> {
  late AnnouncementEngagement _e = widget.announcement.engagement;
  bool _busy = false;

  @override
  void didUpdateWidget(covariant AnnouncementEngagementBar old) {
    super.didUpdateWidget(old);
    if (!_busy) _e = widget.announcement.engagement;
  }

  void _set(AnnouncementEngagement e) {
    setState(() => _e = e);
    widget.onChanged?.call(e);
  }

  Future<void> _react(String r) async {
    if (_busy) return;
    final before = _e;
    // Optimistic: same rule as the server.
    var likes = _e.likes - (_e.myReaction == 'like' ? 1 : 0);
    var dislikes = _e.dislikes - (_e.myReaction == 'dislike' ? 1 : 0);
    final mine = _e.myReaction == r ? null : r;
    if (mine == 'like') likes++;
    if (mine == 'dislike') dislikes++;
    _busy = true;
    _set(AnnouncementEngagement(
        likes: likes,
        dislikes: dislikes,
        comments: _e.comments,
        myReaction: mine));
    final res = await widget.api.react(widget.announcement.id, r);
    _busy = false;
    if (!mounted) return;
    if (res.ok && res.data != null) {
      _set(res.data!);
    } else {
      _set(before);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(res.message)));
    }
  }

  void _openComments() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (_) => AnnouncementCommentsSheet(
        announcement: widget.announcement,
        api: widget.api,
        onChanged: (e) {
          if (mounted) _set(e);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        decoration: BoxDecoration(
            border: Border(top: BorderSide(color: AppColors.border))),
        child: Row(children: [
          _btn('❤️', tr.likeLabel, _e.likes, _e.myReaction == 'like',
              const Color(0xFFE11D48), () => _react('like')),
          _btn('👎', tr.dislikeLabel, _e.dislikes, _e.myReaction == 'dislike',
              const Color(0xFF475569), () => _react('dislike')),
          _btn('💬', tr.commentLabel, _e.comments, false, AppColors.primary,
              _openComments),
        ]),
      );

  Widget _btn(String emoji, String label, int count, bool active, Color color,
          VoidCallback onTap) =>
      Expanded(
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            margin: const EdgeInsets.all(2),
            padding: const EdgeInsets.symmetric(vertical: 9),
            decoration: BoxDecoration(
              color: active ? color.withValues(alpha: .10) : Colors.transparent,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Opacity(
                  opacity: active ? 1 : .75,
                  child: Text(emoji, style: const TextStyle(fontSize: 15))),
              const SizedBox(width: 6),
              Flexible(
                child: Text(count > 0 ? '$label · $count' : label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: active ? color : AppColors.slate500)),
              ),
            ]),
          ),
        ),
      );
}

/// 💬 Comments bottom sheet: list (newest first), write, delete own.
class AnnouncementCommentsSheet extends StatefulWidget {
  const AnnouncementCommentsSheet({
    super.key,
    required this.announcement,
    required this.api,
    this.onChanged,
  });

  final Announcement announcement;
  final AnnouncementApi api;
  final ValueChanged<AnnouncementEngagement>? onChanged;

  @override
  State<AnnouncementCommentsSheet> createState() =>
      _AnnouncementCommentsSheetState();
}

class _AnnouncementCommentsSheetState extends State<AnnouncementCommentsSheet> {
  final _ctrl = TextEditingController();
  List<AnnouncementComment> _list = const [];
  bool _loading = true;
  bool _sending = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final res = await widget.api.comments(widget.announcement.id);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _error = res.ok ? null : res.message;
      if (res.ok && res.data != null) {
        _list = res.data!.$1;
        widget.onChanged?.call(res.data!.$2);
      }
    });
  }

  Future<void> _send() async {
    final t = _ctrl.text.trim();
    if (t.isEmpty || _sending) return;
    setState(() => _sending = true);
    final res = await widget.api.addComment(widget.announcement.id, t);
    if (!mounted) return;
    if (res.ok) {
      _ctrl.clear();
      await _load(); // reload so each comment has its "mine" flag
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(res.message)));
    }
    if (mounted) setState(() => _sending = false);
  }

  Future<void> _delete(AnnouncementComment c) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr.deleteCommentConfirm),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(tr.cancel)),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(tr.deleteLabel,
                  style: const TextStyle(color: Color(0xFFE11D48)))),
        ],
      ),
    );
    if (ok != true) return;
    final res = await widget.api.deleteComment(c.id);
    if (!mounted) return;
    if (res.ok) {
      await _load();
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(res.message)));
    }
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding:
            EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * .75,
          child: Column(children: [
            const SizedBox(height: 10),
            Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: AppColors.slate200,
                    borderRadius: BorderRadius.circular(4))),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 10, 6, 6),
              child: Row(children: [
                const Text('💬 ', style: TextStyle(fontSize: 17)),
                Expanded(
                  child: Text(
                      _list.isEmpty
                          ? tr.commentsTitle
                          : '${tr.commentsTitle} (${_list.length})',
                      style: TextStyle(
                          fontSize: 15.5,
                          fontWeight: FontWeight.w900,
                          color: AppColors.slate800)),
                ),
                IconButton(
                    tooltip: tr.close,
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.of(context).pop()),
              ]),
            ),
            Divider(height: 1, color: AppColors.border),
            Expanded(child: _body()),
            Divider(height: 1, color: AppColors.border),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
                child: Row(children: [
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      maxLength: 1000,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: InputDecoration(
                        hintText: tr.writeComment,
                        counterText: '',
                        isDense: true,
                        filled: true,
                        fillColor: AppColors.surfaceAlt,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 11),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(22),
                            borderSide: BorderSide.none),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: _sending ? null : _send,
                    icon: _sending
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : Icon(Icons.send_rounded, color: AppColors.primary),
                  ),
                ]),
              ),
            ),
          ]),
        ),
      );

  Widget _body() {
    if (_loading) {
      return Center(child: CircularProgressIndicator(color: AppColors.primary));
    }
    if (_error != null) {
      return Center(
          child: Text(_error!, style: TextStyle(color: AppColors.slate500)));
    }
    if (_list.isEmpty) {
      return Center(
          child: Text(tr.noCommentsYet,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: AppColors.slate400, fontWeight: FontWeight.w600)));
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      itemCount: _list.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) => _tile(_list[i]),
    );
  }

  Widget _tile(AnnouncementComment c) {
    final initials = c.name
        .trim()
        .split(RegExp(r'\s+'))
        .where((s) => s.isNotEmpty)
        .take(2)
        .map((s) => s[0].toUpperCase())
        .join();
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      CircleAvatar(
        radius: 17,
        backgroundColor: AppColors.primary.withValues(alpha: .12),
        child: Text(initials,
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: AppColors.primary)),
      ),
      const SizedBox(width: 10),
      Expanded(
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 9),
          decoration: BoxDecoration(
              color: AppColors.surfaceAlt,
              borderRadius: BorderRadius.circular(14)),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(c.name,
                style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w800,
                    color: AppColors.slate800)),
            const SizedBox(height: 2),
            Text(c.comment,
                style: TextStyle(
                    fontSize: 13, height: 1.4, color: AppColors.slate800)),
            const SizedBox(height: 4),
            Row(children: [
              Text(c.at,
                  style: TextStyle(fontSize: 10.5, color: AppColors.slate400)),
              if (c.mine) ...[
                const Spacer(),
                InkWell(
                  onTap: () => _delete(c),
                  child: Text(tr.deleteLabel,
                      style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFFE11D48))),
                ),
              ],
            ]),
          ]),
        ),
      ),
    ]);
  }
}
