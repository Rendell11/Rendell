import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/api_config.dart';
import '../l10n/app_text.dart';
import '../services/api_service.dart' show ApiResult;
import '../services/auth_client.dart';

/// A file attached to an announcement (announcement_attachments).
class AnnouncementFile {
  final String name;
  final String url; // relative to ApiConfig.baseUrl
  final String ext;
  final int size;
  final bool isImage;
  final int? width; // real photo size, so it is shown whole (never cropped)
  final int? height;

  const AnnouncementFile({
    required this.name,
    required this.url,
    this.ext = '',
    this.size = 0,
    this.isImage = false,
    this.width,
    this.height,
  });

  /// width ÷ height of the photo, or null when unknown.
  double? get aspectRatio =>
      (width ?? 0) > 0 && (height ?? 0) > 0 ? width! / height! : null;

  String get fullUrl => '${ApiConfig.baseUrl}/$url';

  factory AnnouncementFile.fromJson(Map<String, dynamic> j) => AnnouncementFile(
        name: (j['name'] ?? '').toString(),
        url: (j['url'] ?? '').toString(),
        ext: (j['ext'] ?? '').toString(),
        size: int.tryParse(j['size']?.toString() ?? '') ?? 0,
        isImage: j['is_image'] == true || j['is_image'] == 1,
        width: int.tryParse(j['width']?.toString() ?? ''),
        height: int.tryParse(j['height']?.toString() ?? ''),
      );
}

/// ❤️ / 👎 / 💬 counts of one announcement and this resident's reaction.
class AnnouncementEngagement {
  final int likes;
  final int dislikes;
  final int comments;
  final String? myReaction; // like | dislike | null

  const AnnouncementEngagement(
      {this.likes = 0, this.dislikes = 0, this.comments = 0, this.myReaction});

  factory AnnouncementEngagement.fromJson(Map<String, dynamic> j) {
    int n(String k) => int.tryParse(j[k]?.toString() ?? '') ?? 0;
    final r = j['my_reaction']?.toString();
    final c =
        j['comments']; // the comment/comments actions return the list here
    return AnnouncementEngagement(
      likes: n('likes'),
      dislikes: n('dislikes'),
      comments: c is List ? c.length : n('comments'),
      myReaction: r == 'like' || r == 'dislike' ? r : null,
    );
  }
}

/// One resident comment (announcement_comments).
class AnnouncementComment {
  final int id;
  final String name;
  final String comment;
  final String
      at; // already formatted by the server, e.g. "Sep 30, 2026 5:45 PM"
  final bool mine;

  const AnnouncementComment(
      {required this.id,
      required this.name,
      required this.comment,
      this.at = '',
      this.mine = false});

  factory AnnouncementComment.fromJson(Map<String, dynamic> j) =>
      AnnouncementComment(
        id: int.tryParse(j['id']?.toString() ?? '') ?? 0,
        name: (j['name'] ?? '').toString(),
        comment: (j['comment'] ?? '').toString(),
        at: (j['at'] ?? '').toString(),
        mine: j['mine'] == true,
      );
}

/// One published announcement (`user/backend/announcements.php`).
class Announcement {
  final int id;
  final String title;
  final String category;
  final bool isEmergency;
  final String details;
  final DateTime? datePosted;
  final DateTime? dateStart;
  final DateTime? dateEnd;
  final String? timeStart; // HH:MM:SS
  final String? timeEnd;
  final bool isEnded;
  final bool isNew;
  final List<AnnouncementFile> attachments;
  final AnnouncementEngagement engagement;

  const Announcement({
    required this.id,
    required this.title,
    required this.category,
    this.isEmergency = false,
    this.details = '',
    this.datePosted,
    this.dateStart,
    this.dateEnd,
    this.timeStart,
    this.timeEnd,
    this.isEnded = false,
    this.isNew = false,
    this.attachments = const [],
    this.engagement = const AnnouncementEngagement(),
  });

  List<AnnouncementFile> get images =>
      attachments.where((a) => a.isImage).toList();
  List<AnnouncementFile> get files =>
      attachments.where((a) => !a.isImage).toList();
  AnnouncementFile? get cover => images.isEmpty ? null : images.first;

  Announcement asRead() => copyWith(isNew: false);

  Announcement copyWith({bool? isNew, AnnouncementEngagement? engagement}) =>
      Announcement(
        id: id,
        title: title,
        category: category,
        isEmergency: isEmergency,
        details: details,
        datePosted: datePosted,
        dateStart: dateStart,
        dateEnd: dateEnd,
        timeStart: timeStart,
        timeEnd: timeEnd,
        isEnded: isEnded,
        isNew: isNew ?? this.isNew,
        attachments: attachments,
        engagement: engagement ?? this.engagement,
      );

  factory Announcement.fromJson(Map<String, dynamic> j) {
    DateTime? d(String k) => DateTime.tryParse(j[k]?.toString() ?? '');
    String? s(String k) {
      final v = j[k]?.toString();
      return (v == null || v.isEmpty) ? null : v;
    }

    return Announcement(
      id: int.tryParse(j['id']?.toString() ?? '') ?? 0,
      title: (j['title'] ?? '').toString(),
      category: (j['category'] ?? 'General').toString(),
      isEmergency: j['is_emergency'] == true || j['is_emergency'] == 1,
      details: (j['details'] ?? '').toString(),
      datePosted: d('date_posted'),
      dateStart: d('date_start'),
      dateEnd: d('date_end'),
      timeStart: s('time_start'),
      timeEnd: s('time_end'),
      isEnded: j['is_ended'] == true || j['is_ended'] == 1,
      isNew: j['is_new'] == true || j['is_new'] == 1,
      attachments: (j['attachments'] as List? ?? [])
          .map((e) => AnnouncementFile.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
      engagement: AnnouncementEngagement.fromJson(j),
    );
  }
}

/// HTTP client for `user/backend/announcements.php`.
class AnnouncementApi {
  AnnouncementApi({http.Client? client, String? baseUrl})
      : _client = client ?? AuthClient(),
        _baseUrl = baseUrl ?? ApiConfig.baseUrl;

  final http.Client _client;
  final String _baseUrl;

  Uri _uri([Map<String, String>? q]) =>
      Uri.parse('$_baseUrl/announcements.php').replace(queryParameters: q);

  Future<ApiResult<List<Announcement>>> list(int residentId) async {
    try {
      final res = await _client
          .get(_uri({'action': 'list', 'resident_id': '$residentId'}),
              headers: ApiConfig.headers)
          .timeout(ApiConfig.timeout);
      final body = _decode(res);
      if (res.statusCode == 200 && body['success'] == true) {
        return ApiResult.success((body['data']?['announcements'] as List? ?? [])
            .map((e) => Announcement.fromJson(Map<String, dynamic>.from(e)))
            .toList());
      }
      final msg = body['message']?.toString() ?? '';
      return ApiResult.failure(
          msg.isNotEmpty ? msg : tr.announcementsLoadFailed);
    } on TimeoutException {
      return ApiResult.failure(tr.errTimeout);
    } on http.ClientException {
      return ApiResult.failure(tr.errNoConnection);
    } catch (e) {
      return ApiResult.failure(tr.errGeneric('$e'));
    }
  }

  /// Mark as seen (removes the "New" badge). Best-effort.
  Future<void> markRead(int residentId, int id) async {
    try {
      await _client.post(_uri(), headers: ApiConfig.headers, body: {
        'action': 'read',
        'resident_id': '$residentId',
        'id': '$id',
      }).timeout(const Duration(seconds: 8));
    } catch (_) {}
  }

  /// ❤️ like / 👎 dislike. Sending the same reaction again removes it
  /// (reaction 'none' always removes it).
  Future<ApiResult<AnnouncementEngagement>> react(int id, String reaction) =>
      _engagementCall({'action': 'react', 'id': '$id', 'reaction': reaction});

  /// 💬 Comments of one announcement (newest first) + the current counts.
  Future<ApiResult<(List<AnnouncementComment>, AnnouncementEngagement)>>
      comments(int id) async {
    try {
      final res = await _client
          .get(_uri({'action': 'comments', 'id': '$id'}),
              headers: ApiConfig.headers)
          .timeout(ApiConfig.timeout);
      final body = _decode(res);
      if (res.statusCode == 200 && body['success'] == true) {
        final d = Map<String, dynamic>.from(body['data'] ?? {});
        return ApiResult.success((
          (d['comments'] as List? ?? [])
              .map((e) =>
                  AnnouncementComment.fromJson(Map<String, dynamic>.from(e)))
              .toList(),
          AnnouncementEngagement.fromJson(d),
        ));
      }
      final msg = body['message']?.toString() ?? '';
      return ApiResult.failure(msg.isNotEmpty ? msg : tr.commentsLoadFailed);
    } on TimeoutException {
      return ApiResult.failure(tr.errTimeout);
    } on http.ClientException {
      return ApiResult.failure(tr.errNoConnection);
    } catch (e) {
      return ApiResult.failure(tr.errGeneric('$e'));
    }
  }

  Future<ApiResult<AnnouncementEngagement>> addComment(int id, String text) =>
      _engagementCall({'action': 'comment', 'id': '$id', 'comment': text});

  /// Removes the resident's own comment.
  Future<ApiResult<AnnouncementEngagement>> deleteComment(int commentId) =>
      _engagementCall({'action': 'delete_comment', 'comment_id': '$commentId'});

  Future<ApiResult<AnnouncementEngagement>> _engagementCall(
      Map<String, String> form) async {
    try {
      final res = await _client
          .post(_uri(), headers: ApiConfig.headers, body: form)
          .timeout(ApiConfig.timeout);
      final body = _decode(res);
      if (res.statusCode == 200 && body['success'] == true) {
        final d = body['data'];
        return ApiResult.success(AnnouncementEngagement.fromJson(
            d is Map ? Map<String, dynamic>.from(d) : {}));
      }
      final msg = body['message']?.toString() ?? '';
      return ApiResult.failure(msg.isNotEmpty ? msg : tr.engagementSaveFailed);
    } on TimeoutException {
      return ApiResult.failure(tr.errTimeout);
    } on http.ClientException {
      return ApiResult.failure(tr.errNoConnection);
    } catch (e) {
      return ApiResult.failure(tr.errGeneric('$e'));
    }
  }

  void dispose() => _client.close();

  Map<String, dynamic> _decode(http.Response res) {
    try {
      final d = jsonDecode(res.body);
      return d is Map<String, dynamic> ? d : {};
    } catch (_) {
      return {};
    }
  }
}
