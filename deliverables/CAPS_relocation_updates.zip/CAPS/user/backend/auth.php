<?php
/**
 * user/backend/auth.php
 * ─────────────────────────────────────────────────────────────────────────────
 * Login tokens for the resident app. Loaded by config.php, so every endpoint
 * has these helpers.
 *
 *   • login.php issues a random token (only its SHA-256 hash is stored in
 *     resident_sessions) that expires after AUTH_SESSION_DAYS without use.
 *   • The app sends it on every request as the X-Auth-Token header
 *     (Authorization: Bearer … also works).
 *   • require_resident() checks it and returns the ResidentID of the token —
 *     the resident_id the app sends is ignored, so nobody can read or change
 *     another resident's data by editing it.
 *   • logout.php revokes the token (or every token of the resident).
 * ─────────────────────────────────────────────────────────────────────────────
 */

declare(strict_types=1);

const AUTH_SESSION_DAYS = 30; // sliding: renewed each time the app is used

// Residents who moved to another barangay (status Relocated, see admin/relocation_helper.php)
// keep their account and can still view their history, but cannot start new
// transactions that require residency. Only these endpoints accept their POSTs.
require_once __DIR__ . '/../../admin/relocation_helper.php';
const AUTH_RELOCATED_ALLOWED_POST = ['logout.php', 'change_password.php', 'preferences.php', 'notifications.php', 'announcements.php',
    'profile.php', 'messages.php', 'chat.php'];

function auth_migrate(PDO $pdo): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS resident_sessions (
            id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
            resident_id  INT UNSIGNED NOT NULL,
            token_hash   CHAR(64) NOT NULL,
            device       VARCHAR(120) NULL,
            platform     VARCHAR(20) NULL,
            push_token   VARCHAR(255) NULL COMMENT 'Firebase Cloud Messaging token of this device',
            created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_used_at DATETIME NULL,
            expires_at   DATETIME NOT NULL,
            revoked_at   DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_rs_token (token_hash),
            KEY idx_rs_resident (resident_id, revoked_at),
            KEY idx_rs_push (push_token)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
}

/**
 * Create a session for a resident who just logged in. Returns the plain token.
 * An approved applicant who has not finished Resident Profiling logs in with
 * $residentId = 0 and their resident_accounts.account_id instead.
 */
function auth_issue_token(int $residentId, ?string $device = null, ?string $platform = null, int $accountId = 0): string
{
    $pdo = db();
    auth_migrate($pdo);
    onboarding_migrate($pdo);
    $token = bin2hex(random_bytes(32));
    $pdo->prepare("INSERT INTO resident_sessions (resident_id, account_id, token_hash, device, platform, last_used_at, expires_at)
                   VALUES (?, ?, ?, ?, ?, NOW(), NOW() + INTERVAL " . AUTH_SESSION_DAYS . " DAY)")
        ->execute([$residentId > 0 ? $residentId : null, $accountId > 0 ? $accountId : null, hash('sha256', $token),
                   $device !== null ? mb_substr($device, 0, 120) : null,
                   $platform !== null ? mb_substr($platform, 0, 20) : null]);
    // Housekeeping: drop sessions that ended more than 30 days ago.
    try {
        $pdo->exec("DELETE FROM resident_sessions WHERE expires_at < NOW() - INTERVAL 30 DAY
                    OR revoked_at < NOW() - INTERVAL 30 DAY");
    } catch (Throwable $e) { /* ignore */ }
    return $token;
}

/** Token sent by the app, or ''. */
function auth_request_token(): string
{
    $t = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? '';
    if ($t === '') {
        $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        if (stripos($h, 'Bearer ') === 0) $t = substr($h, 7);
    }
    $t = trim((string) $t);
    return preg_match('/^[a-f0-9]{64}$/', $t) ? $t : '';
}

/** The session row of the current request, or null. */
function auth_session(): ?array
{
    static $cache = false;
    if ($cache !== false) return $cache;
    $token = auth_request_token();
    if ($token === '') return $cache = null;
    $pdo = db();
    auth_migrate($pdo);
    onboarding_migrate($pdo);
    rl_migrate($pdo);
    $s = $pdo->prepare("SELECT s.*, r.access_status, r.IsDeceased, r.ResidentStatus, a.status AS account_status
                        FROM resident_sessions s
                        LEFT JOIN residents r ON r.ResidentID = s.resident_id
                        LEFT JOIN resident_accounts a ON a.account_id = s.account_id
                        WHERE s.token_hash = ? AND s.revoked_at IS NULL AND s.expires_at > NOW() LIMIT 1");
    $s->execute([hash('sha256', $token)]);
    $row = $s->fetch(PDO::FETCH_ASSOC) ?: null;
    if ($row && (int) ($row['resident_id'] ?? 0) > 0) {
        if (($row['access_status'] ?? '') !== 'Active' || !empty($row['IsDeceased'])) {
            $row = null; // account disabled after login
        }
    } elseif ($row && ($row['account_status'] ?? '') !== 'No Profiling') {
        $row = null; // not-yet-profiled account that was disabled (or no account)
    }
    if ($row && (!$row['last_used_at'] || strtotime((string) $row['last_used_at']) < time() - 300)) {
        // Sliding expiry, written at most every 5 minutes.
        $pdo->prepare("UPDATE resident_sessions SET last_used_at = NOW(),
                       expires_at = NOW() + INTERVAL " . AUTH_SESSION_DAYS . " DAY WHERE id = ?")
            ->execute([(int) $row['id']]);
    }
    return $cache = $row;
}

/**
 * The logged-in session for onboarding endpoints: works before AND after
 * Resident Profiling. Returns ['resident_id' => int (0 = not profiled yet),
 * 'account_id' => int], or a 401 response.
 */
function require_session(): array
{
    try {
        $row = auth_session();
    } catch (Throwable $e) {
        error_log('[auth] ' . $e->getMessage());
        respond(false, L('May problema sa server. Subukan muli.', 'Server problem. Please try again.'), null, 500);
    }
    if (!$row) {
        respond(false, L('Nag-expire ang iyong session. Mag-login muli.', 'Your session has expired. Please log in again.'),
            ['auth' => 'required'], 401);
    }
    auth_block_relocated($row);
    return ['resident_id' => (int) ($row['resident_id'] ?? 0), 'account_id' => (int) ($row['account_id'] ?? 0)];
}

/**
 * Relocated resident (moved to another barangay): reading (GET) stays open so the
 * resident can view their own records and history; new requests / transactions
 * that require residency are refused here, on the server, for every endpoint
 * except AUTH_RELOCATED_ALLOWED_POST.
 */
function auth_block_relocated(array $row): void
{
    // Every signed-in response tells the app the current status (view-only while Relocated;
    // access comes back by itself after Move Back to Barangay).
    if ((int) ($row['resident_id'] ?? 0) > 0 && !headers_sent()) {
        header('X-Resident-Status: ' . (($row['ResidentStatus'] ?? 'Active') === RL_RELOCATED ? 'Relocated' : 'Active'));
        header('Access-Control-Expose-Headers: X-Resident-Status, X-Onboarding-Required');
    }
    if (($row['ResidentStatus'] ?? 'Active') !== RL_RELOCATED) return;
    $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if (in_array($method, ['GET', 'HEAD', 'OPTIONS'], true)) return;
    $script = basename((string) ($_SERVER['SCRIPT_FILENAME'] ?? $_SERVER['SCRIPT_NAME'] ?? ''));
    if (in_array($script, AUTH_RELOCATED_ALLOWED_POST, true)) return;
    if (!headers_sent()) {
        header('X-Resident-Status: Relocated');
        header('Access-Control-Expose-Headers: X-Resident-Status');
    }
    respond(false, L('Nakatala kang lumipat na sa ibang barangay. Maaari mo pang tingnan ang iyong mga record, '
        . 'pero hindi ka na makakagawa ng bagong request o transaksyon dito. Makipag-ugnayan sa barangay kung bumalik ka na.',
        'You are recorded as relocated to another barangay. You can still view your records, but you can no longer '
        . 'submit new requests or transactions here. Please contact the barangay office if you have moved back.'),
        ['resident_status' => RL_RELOCATED, 'relocated' => true], 403);
}

/**
 * 403 telling the app to go back to the onboarding screens. The header lets
 * the app's HTTP client react no matter which module made the request.
 */
function auth_onboarding_required(string $step, string $message): void
{
    if (!headers_sent()) {
        header('X-Onboarding-Required: ' . $step);
        header('Access-Control-Expose-Headers: X-Onboarding-Required');
    }
    respond(false, $message, ['auth' => 'onboarding', 'next_step' => $step], 403);
}

/**
 * The logged-in resident, or a 401 response. Also overwrites resident_id in
 * $_GET / $_POST so older code that reads it gets the verified value.
 */
function require_resident(): int
{
    try {
        $row = auth_session();
    } catch (Throwable $e) {
        error_log('[auth] ' . $e->getMessage());
        respond(false, L('May problema sa server. Subukan muli.', 'Server problem. Please try again.'), null, 500);
    }
    if (!$row) {
        respond(false, L('Nag-expire ang iyong session. Mag-login muli.', 'Your session has expired. Please log in again.'),
            ['auth' => 'required'], 401);
    }
    auth_block_relocated($row);
    $rid = (int) ($row['resident_id'] ?? 0);
    if ($rid <= 0) {
        // Approved for profiling (No Profiling): only onboarding.php is open.
        // Dashboard, announcements, household, blotter, documents… all refuse.
        auth_onboarding_required('profiling',
            L('Tapusin muna ang Resident Profiling.', 'Please complete your Resident Profiling first.'));
    }
    // Profiled, but the household step is not done yet (Head without a
    // Household Survey, or a member who has not confirmed the household).
    try {
        // A Relocated resident has no household here: no household onboarding steps.
        $step = ($row['ResidentStatus'] ?? 'Active') === RL_RELOCATED ? 'main'
            : ob_next_step(db(), $rid, (int) ($row['account_id'] ?? 0))['next_step'];
    } catch (Throwable $e) {
        $step = 'main';
        error_log('[auth] next step: ' . $e->getMessage());
    }
    if ($step !== 'main') {
        auth_onboarding_required($step, L('Tapusin muna ang mga hakbang sa sambahayan.', 'Please finish the household steps first.'));
    }
    $_GET['resident_id'] = $_POST['resident_id'] = (string) $rid;
    return $rid;
}
