import 'package:flutter/material.dart';

import '../config/api_config.dart';
import '../l10n/app_text.dart';
import '../theme/app_theme.dart';

/// Shown on modules with new requests while the resident is Relocated:
/// past records stay viewable, new requests are not allowed (the backend
/// refuses them too). Hidden again after Move Back to Barangay.
class RelocatedBanner extends StatelessWidget {
  const RelocatedBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: ApiConfig.relocated,
      builder: (_, relocated, __) => !relocated
          ? const SizedBox.shrink()
          : Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF7ED),
                border: Border.all(color: const Color(0xFFFED7AA)),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.move_up, color: Color(0xFFC2410C), size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(tr.relocatedViewOnly,
                      style: TextStyle(
                          fontSize: 12.5,
                          height: 1.4,
                          fontWeight: FontWeight.w600,
                          color: AppColors.slate800)),
                ),
              ]),
            ),
    );
  }
}

/// FAB that disappears while the resident is Relocated.
Widget activeResidentOnly(Widget child) => ValueListenableBuilder<bool>(
      valueListenable: ApiConfig.relocated,
      builder: (_, relocated, __) => relocated ? const SizedBox.shrink() : child,
    );
