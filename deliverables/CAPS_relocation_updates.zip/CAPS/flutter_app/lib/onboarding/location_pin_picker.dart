import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as gm;
import 'package:latlong2/latlong.dart';

import '../l10n/app_text.dart';
import '../theme/app_theme.dart';

/// Household location pin for Resident Profiling — Google Maps, the app
/// version of the Google map on Admin → Residents:
///
///   • the pin follows the address: when the address changes it is looked up
///     with the same Google Geocoding the admin uses (through
///     `onboarding.php?action=geocode`) and the pin moves there;
///   • the resident can still move it: tap the map, or drag the pin
///     (long-press the pin, then drag it to the house);
///   • "My location" uses the phone's GPS (asks for permission first);
///   • a saved pin is shown when the profile is opened again;
///   • nothing is ever pinned by default — with no saved pin and no address
///     match the map only centres on the barangay and the value stays null.
///
/// [locked] shows a Member the household's existing pin read-only (the
/// server uses the Head's pin for members, like the admin form).
class LocationPinPicker extends StatefulWidget {
  const LocationPinPicker({
    super.key,
    required this.value,
    required this.onChanged,
    required this.address,
    required this.areaQuery,
    required this.geocode,
    this.locked = false,
  });

  final LatLng? value;
  final ValueChanged<LatLng?> onChanged;

  /// Full address of the house (House No., Street, Area, Barangay, City…).
  /// Empty when House No. or Street is still missing.
  final String address;

  /// Barangay, City, Province — only used to centre the map without a pin.
  final String areaQuery;

  /// Address → coordinates, or a message to show.
  final Future<(LatLng?, String)> Function(String query) geocode;
  final bool locked;

  @override
  State<LocationPinPicker> createState() => _LocationPinPickerState();
}

class _LocationPinPickerState extends State<LocationPinPicker> {
  gm.GoogleMapController? _map;
  Timer? _debounce;
  bool _busy = false;
  String? _message;

  static const _fallbackCenter = LatLng(12.8797, 121.7740); // the Philippines
  static const _pinZoom = 18.0;

  static gm.LatLng _g(LatLng p) => gm.LatLng(p.latitude, p.longitude);

  @override
  void didUpdateWidget(LocationPinPicker old) {
    super.didUpdateWidget(old);
    if (widget.value != null && widget.value != old.value) {
      _moveTo(widget.value!, keepZoom: true);
    }
    // Address changed → look it up again (debounced) and move the pin there.
    if (!widget.locked &&
        widget.address != old.address &&
        widget.address.isNotEmpty) {
      _debounce?.cancel();
      _debounce = Timer(
          const Duration(milliseconds: 900), () => _findAddress(quiet: true));
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _map?.dispose();
    super.dispose();
  }

  Future<void> _moveTo(LatLng p, {double? zoom, bool keepZoom = false}) async {
    final c = _map;
    if (c == null) return;
    double z = zoom ?? _pinZoom;
    if (keepZoom) {
      try {
        final cur = await c.getZoomLevel();
        z = cur < 16 ? _pinZoom : cur;
      } catch (_) {}
    }
    try {
      await c.animateCamera(gm.CameraUpdate.newLatLngZoom(_g(p), z));
    } catch (_) {}
  }

  Future<void> _initialCamera() async {
    if (!mounted) return;
    if (widget.value != null) {
      await _moveTo(widget.value!);
      return;
    }
    // No saved pin: centre on the address (placing the pin there, which the
    // resident can adjust) or, without one, on the barangay with no pin.
    if (!widget.locked && widget.address.isNotEmpty) {
      await _findAddress(quiet: true);
      if (widget.value != null) return;
    }
    if (widget.areaQuery.isNotEmpty) {
      final (p, _) = await widget.geocode(widget.areaQuery);
      if (p != null && mounted && widget.value == null) _moveTo(p, zoom: 15);
    }
  }

  Future<void> _findAddress({bool quiet = false}) async {
    if (widget.locked) return;
    if (widget.address.isEmpty) {
      setState(() => _message = tr.locationNotSet);
      return;
    }
    setState(() {
      _busy = true;
      if (!quiet) _message = null;
    });
    final (p, msg) = await widget.geocode(widget.address);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _message = p == null ? msg : null;
    });
    if (p != null) _set(p);
  }

  /// "My location": the phone's GPS (asks for permission first).
  Future<void> _myLocation() async {
    setState(() {
      _busy = true;
      _message = null;
    });
    String? problem;
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        problem = tr.locationServiceOff;
      } else {
        var perm = await Geolocator.checkPermission();
        if (perm == LocationPermission.denied) {
          perm = await Geolocator.requestPermission();
        }
        if (perm == LocationPermission.denied ||
            perm == LocationPermission.deniedForever) {
          problem = tr.locationPermissionDenied;
        } else {
          final pos = await Geolocator.getCurrentPosition(
            locationSettings: const LocationSettings(
                accuracy: LocationAccuracy.high,
                timeLimit: Duration(seconds: 20)),
          );
          if (!mounted) return;
          _set(LatLng(pos.latitude, pos.longitude));
        }
      }
    } catch (_) {
      problem = tr.locationUnavailable;
    }
    if (!mounted) return;
    setState(() {
      _busy = false;
      _message = problem;
    });
  }

  void _set(LatLng p) {
    widget.onChanged(LatLng(double.parse(p.latitude.toStringAsFixed(7)),
        double.parse(p.longitude.toStringAsFixed(7))));
  }

  @override
  Widget build(BuildContext context) {
    final v = widget.value;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(widget.locked ? tr.locationFromHousehold : tr.locationHelp,
            style: TextStyle(
                fontSize: 12, height: 1.4, color: AppColors.slate500)),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: SizedBox(
            height: 260,
            child: Stack(children: [
              gm.GoogleMap(
                initialCameraPosition: gm.CameraPosition(
                    target: _g(v ?? _fallbackCenter),
                    zoom: v != null ? _pinZoom : 6),
                onMapCreated: (c) {
                  _map = c;
                  WidgetsBinding.instance
                      .addPostFrameCallback((_) => _initialCamera());
                },
                mapType: gm.MapType.normal,
                myLocationButtonEnabled: false,
                zoomControlsEnabled: true,
                mapToolbarEnabled: false,
                rotateGesturesEnabled: false,
                tiltGesturesEnabled: false,
                // The map sits inside a scrolling form: let it own its gestures.
                gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
                  Factory<OneSequenceGestureRecognizer>(
                      () => EagerGestureRecognizer()),
                },
                onTap: widget.locked
                    ? null
                    : (p) => _set(LatLng(p.latitude, p.longitude)),
                markers: {
                  if (v != null)
                    gm.Marker(
                      markerId: const gm.MarkerId('household'),
                      position: _g(v),
                      draggable: !widget.locked,
                      icon: widget.locked
                          ? gm.BitmapDescriptor.defaultMarkerWithHue(
                              gm.BitmapDescriptor.hueAzure)
                          : gm.BitmapDescriptor.defaultMarker,
                      onDragEnd: widget.locked
                          ? null
                          : (p) => _set(LatLng(p.latitude, p.longitude)),
                    ),
                },
              ),
              if (_busy)
                const Positioned(
                  top: 10,
                  right: 10,
                  child: SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5)),
                ),
            ]),
          ),
        ),
        const SizedBox(height: 8),
        Text(
            v == null
                ? tr.locationNotSet
                : tr.pinnedAt(v.latitude, v.longitude),
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: v == null ? AppColors.slate400 : AppColors.slate800)),
        if (_message != null) ...[
          const SizedBox(height: 6),
          Text(_message!,
              style: TextStyle(fontSize: 12, color: AppColors.dangerText)),
        ],
        if (!widget.locked) ...[
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            OutlinedButton.icon(
              onPressed: _busy ? null : () => _findAddress(),
              icon: const Icon(Icons.travel_explore, size: 18),
              label: Text(tr.findMyAddress),
            ),
            OutlinedButton.icon(
              onPressed: _busy ? null : _myLocation,
              icon: const Icon(Icons.my_location, size: 18),
              label: Text(tr.useMyLocation),
            ),
            if (v != null)
              TextButton.icon(
                onPressed: () => widget.onChanged(null),
                icon: const Icon(Icons.close, size: 18),
                label: Text(tr.clearPin),
              ),
          ]),
        ],
      ],
    );
  }
}
