/// Central place for the backend base URL.
///
/// Point [baseUrl] at wherever the PHP API in `backend_api/` is served.
///
/// The API lives at CAPS/user/backend/ under your XAMPP htdocs, so the path is
/// `/CAPS/user/backend`. Common host values while developing with XAMPP:
///   * Android emulator ....... http://10.0.2.2/CAPS/user/backend
///   * iOS simulator .......... http://127.0.0.1/CAPS/user/backend
///   * Real device (same wifi)  http://192.168.x.x/CAPS/user/backend
///   * Chrome / web ........... http://localhost/CAPS/user/backend
///
/// You can also override it at build/run time without editing code:
///   flutter run --dart-define=API_BASE_URL=http://192.168.1.10/CAPS/user/backend
import 'package:flutter/foundation.dart';

class ApiConfig {
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2/CAPS/user/backend',
  );

  /// How long to wait for the server before giving up.
  static const Duration timeout = Duration(seconds: 20);

  /// App language ("en" / "fil"), kept in sync by AppSettings. Sent on every
  /// request so the backend answers in the same language as the app.
  static String lang = 'fil';

  /// Login token from login.php, sent on every request (SessionService keeps
  /// it in the secure store). Null when signed out.
  static String? authToken;

  static Map<String, String> get headers => {
        'X-App-Lang': lang,
        if (authToken != null) 'X-Auth-Token': authToken!,
      };

  /// Called once when the server rejects the token (401) while signed in.
  static void Function()? onUnauthorized;

  /// Called once when the server says onboarding is not finished
  /// (`X-Onboarding-Required` on a 403: Resident Profiling, Household Survey
  /// or the household check). The app then goes back to the OnboardingGate.
  static void Function(String step)? onOnboardingRequired;
  static bool _onboardingRedirect = false;

  /// The OnboardingGate is showing again; later 403s may redirect once more.
  static void onboardingHandled() => _onboardingRedirect = false;

  static void checkOnboarding(int statusCode, String? step) {
    if (statusCode != 403 || step == null || step.isEmpty) return;
    if (_onboardingRedirect || authToken == null) return;
    _onboardingRedirect = true;
    onOnboardingRequired?.call(step);
  }

  /// True while the logged-in resident is Relocated (moved to another
  /// barangay): view-only. Follows the X-Resident-Status header the backend
  /// sends on every signed-in response, so a Move Back restores access.
  static final ValueNotifier<bool> relocated = ValueNotifier<bool>(false);

  static void checkResidentStatus(String? status) {
    if (status == 'Relocated') {
      relocated.value = true;
    } else if (status == 'Active') {
      relocated.value = false;
    }
  }

  static void checkStatus(int statusCode) {
    if (statusCode == 401 && authToken != null) {
      authToken = null; // stop the other calls; fire the handler once
      onUnauthorized?.call();
    }
  }
}
