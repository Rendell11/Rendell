<?php
/**
 * admin/relocation_helper.php
 * ─────────────────────────────────────────────────────────────────────────────
 * Residents moving to ANOTHER barangay ("Move" in Households) and coming back
 * ("Move Back to Barangay" in View Resident Information).
 *
 *  • residents.ResidentStatus  'Active' | 'Relocated'   (default 'Active')
 *  • resident_relocations      one row per move out / move back (audit trail):
 *    resident, direction, household left / joined, destination (PSGC names +
 *    codes + ZIP), date, Admin responsible.
 *
 * Moving out never deletes a resident or reuses an ID: the resident keeps their
 * Resident ID, documents and history, is unlinked from the active household and
 * is excluded from the active population (rl_active_sql()). Moves inside the
 * barangay keep using the existing Change Address process.
 * ─────────────────────────────────────────────────────────────────────────────
 */
declare(strict_types=1);

const RL_RELOCATED = 'Relocated';

/** Column + audit table (also in the SQL migration). Safe to call on every request. */
function rl_migrate(PDO $pdo): void
{
    static $done = false;
    if ($done || $pdo->inTransaction()) return;
    $done = true;
    try {
        $have = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'residents' AND COLUMN_NAME = 'ResidentStatus'")->fetchColumn();
        if (!$have) {
            $pdo->exec("ALTER TABLE residents ADD COLUMN ResidentStatus VARCHAR(20) NOT NULL DEFAULT 'Active'");
            try { $pdo->exec("ALTER TABLE residents ADD KEY idx_residents_status (ResidentStatus)"); } catch (Throwable $e) {}
        }
        $pdo->exec("CREATE TABLE IF NOT EXISTS resident_relocations (
            relocation_id     INT UNSIGNED NOT NULL AUTO_INCREMENT,
            resident_id       INT UNSIGNED NOT NULL,
            direction         ENUM('Out','Back') NOT NULL,
            survey_id         INT UNSIGNED NULL COMMENT 'household left (Out) or joined (Back)',
            household_code    VARCHAR(30) NULL,
            household_role    VARCHAR(100) NULL,
            region_name       VARCHAR(150) NULL,
            province_name     VARCHAR(150) NULL,
            municipality_name VARCHAR(150) NULL,
            barangay_name     VARCHAR(150) NULL,
            psgc_region_code       VARCHAR(20) NULL,
            psgc_province_code     VARCHAR(20) NULL,
            psgc_municipality_code VARCHAR(20) NULL,
            psgc_barangay_code     VARCHAR(20) NULL,
            zip_code          VARCHAR(10) NULL,
            address_line      VARCHAR(500) NULL,
            moved_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            moved_by          VARCHAR(150) NULL,
            notes             VARCHAR(500) NULL,
            PRIMARY KEY (relocation_id),
            KEY idx_rr_resident (resident_id, moved_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        // Previous address (the address the resident had before this move) for View Resident
        // Details and for documents that offer Old Address / New Address.
        foreach (['previous_address' => 'VARCHAR(600) NULL', 'previous_address_json' => 'TEXT NULL'] as $col => $def) {
            $c = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = 'resident_relocations' AND COLUMN_NAME = ?");
            $c->execute([$col]);
            if (!(int) $c->fetchColumn()) $pdo->exec("ALTER TABLE resident_relocations ADD COLUMN {$col} {$def}");
        }
    } catch (Throwable $e) {
        error_log('[relocation] migrate: ' . $e->getMessage());
    }
}

/** Address columns of residents that a move replaces (snapshot kept in resident_relocations). */
const RL_ADDRESS_COLUMNS = ['HouseNumber', 'BuildingName', 'StreetName', 'AreaName', 'AreaType', 'Purok', 'BarangayName',
    'CityMunicipalityName', 'ProvinceName', 'RegionName', 'ZipCode', 'PSGCRegionCode', 'PSGCProvinceCode',
    'PSGCMunicipalityCode', 'PSGCBarangayCode', 'Latitude', 'Longitude'];

/** Full address of a resident row (current address on the record). */
function rl_resident_address_text(array $r): string
{
    $parts = [$r['HouseNumber'] ?? '', $r['BuildingName'] ?? '', $r['StreetName'] ?? '', ($r['AreaName'] ?? '') ?: ($r['Purok'] ?? ''),
        $r['BarangayName'] ?? '', $r['CityMunicipalityName'] ?? '', $r['ProvinceName'] ?? '', $r['ZipCode'] ?? ''];
    return implode(', ', array_filter(array_map(static fn($v) => trim((string) $v), $parts), static fn($v) => $v !== ''));
}

/** Snapshot of the address columns of a resident row. */
function rl_address_snapshot(array $r): array
{
    $out = [];
    foreach (RL_ADDRESS_COLUMNS as $c) if (array_key_exists($c, $r)) $out[$c] = $r[$c];
    return $out;
}

/**
 * Old / New address of a resident for documents and records.
 * Returns null when the resident has no relocation history (no selection is shown then).
 * 'old' = the address before the latest move, 'new' = the current address on the record.
 */
function rl_address_options(PDO $pdo, int $rid): ?array
{
    if ($rid <= 0) return null;
    try {
        $s = $pdo->prepare('SELECT * FROM residents WHERE ResidentID = ? LIMIT 1');
        $s->execute([$rid]);
        $r = $s->fetch(PDO::FETCH_ASSOC);
        if (!$r) return null;
        $h = $pdo->prepare("SELECT previous_address FROM resident_relocations WHERE resident_id = ? AND COALESCE(previous_address, '') <> ''
                            ORDER BY moved_at DESC, relocation_id DESC LIMIT 1");
        $h->execute([$rid]);
        $old = (string) ($h->fetchColumn() ?: '');
    } catch (Throwable $e) {
        return null;
    }
    $new = rl_resident_address_text($r);
    if ($old === '' || $old === $new) return null;
    return ['old' => $old, 'new' => $new, 'status' => $r['ResidentStatus'] ?? 'Active'];
}

/** SQL condition: resident is part of the active population (not relocated). */
function rl_active_sql(string $alias = ''): string
{
    $c = $alias !== '' ? $alias . '.' : '';
    return "COALESCE({$c}ResidentStatus, 'Active') <> '" . RL_RELOCATED . "'";
}

function rl_is_relocated(array $resident): bool
{
    return ($resident['ResidentStatus'] ?? 'Active') === RL_RELOCATED;
}

/** The barangay this CAPS install serves (Manage Area default address). */
function rl_home_barangay(PDO $pdo): array
{
    try {
        return $pdo->query("SELECT region_name, province_name, municipality_name, barangay_name, psgc_region_code,
            psgc_province_code, psgc_municipality_code, psgc_barangay_code, zip_code FROM barangay_profile WHERE id = 1 LIMIT 1")
            ->fetch(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        return [];
    }
}

/** Destination / address from the PSGC dropdowns (codes + names + ZIP). */
function rl_address_input(array $p): array
{
    $code = static fn($k) => preg_replace('/\D/', '', (string) ($p[$k] ?? ''));
    $name = static fn($k, $max = 150) => mb_substr(trim(strip_tags((string) ($p[$k] ?? ''))), 0, $max);
    return [
        'psgc_region_code' => $code('region_code'), 'psgc_province_code' => $code('province_code'),
        'psgc_municipality_code' => $code('municipality_code'), 'psgc_barangay_code' => $code('barangay_code'),
        'region_name' => $name('region_name'), 'province_name' => $name('province_name'),
        'municipality_name' => $name('municipality_name'), 'barangay_name' => $name('barangay_name'),
        'zip_code' => $name('zip_code', 10),
        'address_line' => $name('address_line', 300),
    ];
}

function rl_address_text(array $a): string
{
    return implode(', ', array_filter([$a['address_line'] ?? '', $a['barangay_name'] ?? '', $a['municipality_name'] ?? '',
        $a['province_name'] ?? '', $a['zip_code'] ?? ''], static fn($v) => trim((string) $v) !== ''));
}

function rl_log(PDO $pdo, int $rid, string $direction, ?array $hh, string $role, array $addr, string $by, string $notes = '',
                ?array $prev = null): void
{
    $pdo->prepare("INSERT INTO resident_relocations (resident_id, direction, survey_id, household_code, household_role,
            region_name, province_name, municipality_name, barangay_name, psgc_region_code, psgc_province_code,
            psgc_municipality_code, psgc_barangay_code, zip_code, address_line, moved_by, notes, previous_address, previous_address_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
        ->execute([$rid, $direction, $hh ? (int) $hh['SurveyID'] : null, $hh['HouseholdID'] ?? null, $role ?: null,
            $addr['region_name'] ?: null, $addr['province_name'] ?: null, $addr['municipality_name'] ?: null, $addr['barangay_name'] ?: null,
            $addr['psgc_region_code'] ?: null, $addr['psgc_province_code'] ?: null, $addr['psgc_municipality_code'] ?: null,
            $addr['psgc_barangay_code'] ?: null, $addr['zip_code'] ?: null, ($addr['address_line'] ?? '') ?: null, $by, $notes ?: null,
            $prev ? (rl_resident_address_text($prev) ?: null) : null,
            $prev ? json_encode(rl_address_snapshot($prev), JSON_UNESCAPED_UNICODE) : null]);
}

/** Relocation history of one resident, newest first. */
function rl_history(PDO $pdo, int $rid): array
{
    try {
        $s = $pdo->prepare('SELECT * FROM resident_relocations WHERE resident_id = ? ORDER BY moved_at DESC, relocation_id DESC');
        $s->execute([$rid]);
        return $s->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return [];
    }
}

/** Sign the resident out of the app so the new status applies on the next login. */
function rl_revoke_sessions(PDO $pdo, array $ids): void
{
    if (!$ids) return;
    try {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $pdo->prepare("UPDATE resident_sessions SET revoked_at = NOW() WHERE resident_id IN ($in) AND revoked_at IS NULL")->execute($ids);
    } catch (Throwable $e) { /* sessions table optional */ }
}

/**
 * Move residents of household $surveyId to another barangay (caller holds the transaction,
 * household helpers loaded). $moveIds ⊆ the household's head + living members.
 * $newHeadId is required when the Head moves and members stay.
 * Returns ['moved' => n, 'household_status' => 'inactive'|'active', 'new_head' => ?string].
 */
function rl_move_out(PDO $pdo, int $surveyId, array $moveIds, array $dest, ?int $newHeadId, string $by,
                     ?callable $changeHead = null): array
{
    $s = $pdo->prepare('SELECT hs.*, r.* FROM household_survey hs JOIN residents r ON r.ResidentID = hs.ResidentID WHERE hs.SurveyID = ? FOR UPDATE');
    $s->execute([$surveyId]);
    $hh = $s->fetch(PDO::FETCH_ASSOC);
    if (!$hh) throw new RuntimeException('Household not found.');
    if (strtolower((string) ($hh['status'] ?? 'active')) !== 'active' || (int) ($hh['is_removed'] ?? 0) === 1) {
        throw new RuntimeException('This household is already inactive.');
    }
    $headId = (int) $hh['ResidentID'];

    // Destination: a different barangay, chosen from the PSGC lists.
    foreach (['psgc_region_code', 'psgc_province_code', 'psgc_municipality_code', 'psgc_barangay_code'] as $k) {
        if (($dest[$k] ?? '') === '') throw new RuntimeException('Select the destination Region, Province, City/Municipality and Barangay.');
    }
    $home = rl_home_barangay($pdo);
    $current = (string) ($hh['PSGCBarangayCode'] ?? '') ?: (string) ($home['psgc_barangay_code'] ?? '');
    if ($current !== '' && $dest['psgc_barangay_code'] === $current) {
        throw new RuntimeException('The destination is this same barangay. Use Change Address for a move within the barangay.');
    }

    // Who is in the household now (head + living, active members).
    $m = $pdo->prepare('SELECT * FROM residents WHERE (ResidentID = ? OR FamilyHeadID = ?) AND (IsDeceased = 0 OR IsDeceased IS NULL) FOR UPDATE');
    $m->execute([$headId, $headId]);
    $all = [];
    foreach ($m->fetchAll(PDO::FETCH_ASSOC) as $r) $all[(int) $r['ResidentID']] = $r;

    $moveIds = array_values(array_unique(array_map('intval', $moveIds)));
    if (!$moveIds) throw new RuntimeException('Select at least one household member who is moving.');
    foreach ($moveIds as $id) {
        if (!isset($all[$id])) throw new RuntimeException('A selected resident is not a member of this household.');
        if (rl_is_relocated($all[$id])) throw new RuntimeException(hh_full_name($all[$id]) . ' is already marked Relocated.');
    }
    $staying = array_values(array_diff(array_keys($all), $moveIds));
    $headMoves = in_array($headId, $moveIds, true);
    $newHeadName = null;

    if ($headMoves && $staying) {
        if (!$newHeadId || !in_array($newHeadId, $staying, true)) {
            throw new RuntimeException('The Household Head is moving. Choose a new Household Head from the members who stay.');
        }
        // Existing Change Head process first (keeps the household and its Household ID).
        $newHeadName = $changeHead ? $changeHead($hh, $newHeadId) : null;
    }

    $survey = ['SurveyID' => $surveyId, 'HouseholdID' => $hh['HouseholdID']];
    // The new (destination) address becomes the resident's current address; the previous
    // address is kept in resident_relocations (previous_address + snapshot).
    $upd = $pdo->prepare("UPDATE residents SET ResidentStatus = ?, IsHead = 0, FamilyHeadID = NULL,
            HouseNumber = NULL, BuildingName = NULL, StreetName = ?, AreaName = NULL, AreaType = NULL, Purok = NULL,
            BarangayName = ?, CityMunicipalityName = ?, ProvinceName = ?, RegionName = ?, ZipCode = ?,
            PSGCRegionCode = ?, PSGCProvinceCode = ?, PSGCMunicipalityCode = ?, PSGCBarangayCode = ?,
            Latitude = NULL, Longitude = NULL
        WHERE ResidentID = ?");
    foreach ($moveIds as $id) {
        $r = $all[$id];
        $role = $id === $headId ? 'Household Head' : ($r['RelationshipToHead'] ?: 'Member');
        $upd->execute([RL_RELOCATED, ($dest['address_line'] ?? '') ?: null, $dest['barangay_name'], $dest['municipality_name'],
            $dest['province_name'], $dest['region_name'], $dest['zip_code'] ?: null, $dest['psgc_region_code'],
            $dest['psgc_province_code'], $dest['psgc_municipality_code'], $dest['psgc_barangay_code'], $id]);
        rl_log($pdo, $id, 'Out', $survey, $role, $dest, $by, 'Moved to another barangay.', $r);
    }

    $destText = rl_address_text($dest);
    $names = implode(', ', array_map(static fn($id) => hh_full_name($all[$id]), $moveIds));
    if (!$staying) {
        // Everyone moved: the household is kept as Relocated / Inactive (members snapshot stays).
        $pdo->prepare("UPDATE household_survey SET status = 'inactive', is_removed = 1, removal_reason = ?, removal_reason_other = ?,
                           removed_at = NOW(), inactive_since = NOW(), inactive_by = ? WHERE SurveyID = ?")
            ->execute(['Relocated to another barangay: ' . $destText, $destText, $by, $surveyId]);
        log_hh_history($pdo, $surveyId, 'RELOCATED', "Whole household moved to another barangay: {$destText}. Moved: {$names}.", hh_address($hh), $destText);
        $status = 'inactive';
    } else {
        $head = $headMoves ? (int) $newHeadId : $headId;
        sync_hh_members($pdo, $surveyId, $head);
        log_hh_history($pdo, $surveyId, 'MEMBER_RELOCATED', "Moved to another barangay ({$destText}): {$names}. The household stays active.", null, $destText);
        $status = 'active';
    }
    rl_revoke_sessions($pdo, $moveIds);
    return ['moved' => count($moveIds), 'household_status' => $status, 'new_head' => $newHeadName, 'destination' => $destText];
}

/**
 * Bring a Relocated resident back (caller holds the transaction, household helpers loaded).
 * $mode: 'link' (existing household $surveyId, as 'head' only if it has no Head, or 'member')
 *        'new'  (new household: as 'head', or as 'member' of a household with No Head Assigned).
 */
function rl_move_back(PDO $pdo, int $rid, array $addr, string $mode, string $role, int $surveyId, string $relationship, string $by): array
{
    $s = $pdo->prepare('SELECT * FROM residents WHERE ResidentID = ? FOR UPDATE');
    $s->execute([$rid]);
    $r = $s->fetch(PDO::FETCH_ASSOC);
    if (!$r) throw new RuntimeException('Resident not found.');
    if (!rl_is_relocated($r)) throw new RuntimeException('Only residents marked Relocated can be moved back.');
    if ((int) ($r['IsDeceased'] ?? 0) === 1) throw new RuntimeException('This resident is marked deceased.');

    // The address must be in this barangay (Manage Area default).
    $home = rl_home_barangay($pdo);
    if (($home['psgc_barangay_code'] ?? '') === '') throw new RuntimeException('Configure the default barangay address in Manage Area first.');
    if ($addr['psgc_barangay_code'] !== (string) $home['psgc_barangay_code']) {
        throw new RuntimeException('The address must be in ' . ($home['barangay_name'] ?: 'this barangay') . '.');
    }
    $house = trim((string) ($addr['house_no'] ?? ''));
    $street = trim((string) ($addr['street'] ?? ''));
    $area = trim((string) ($addr['area'] ?? ''));
    $rel = mb_substr(trim($relationship), 0, 100);

    // Same address columns as Add Resident (process_resident.php): Purok only when the area is a Purok.
    $setAddr = static function (array $a) use ($pdo, $rid): void {
        $areaType = (string) ($a['area_type'] ?? '');
        $area = (string) ($a['area'] ?? '');
        $pdo->prepare("UPDATE residents SET HouseNumber = ?, BuildingName = ?, StreetName = ?, AreaName = ?, AreaType = ?, Purok = ?,
                BarangayName = ?, CityMunicipalityName = ?, ProvinceName = ?, RegionName = ?, ZipCode = ?, PSGCRegionCode = ?,
                PSGCProvinceCode = ?, PSGCMunicipalityCode = ?, PSGCBarangayCode = ? WHERE ResidentID = ?")
            ->execute([$a['house_no'] ?: null, ($a['building'] ?? '') ?: null, $a['street'] ?: null, $area ?: null, $areaType ?: null,
                ($area !== '' && ($areaType === 'Purok' || $areaType === '')) ? $area : null, $a['barangay_name'],
                $a['municipality_name'], $a['province_name'], $a['region_name'], $a['zip_code'] ?: null, $a['psgc_region_code'],
                $a['psgc_province_code'], $a['psgc_municipality_code'], $a['psgc_barangay_code'], $rid]);
        if (isset($a['lat'], $a['lng']) && $a['lat'] !== null && $a['lng'] !== null) {
            $pdo->prepare('UPDATE residents SET Latitude = ?, Longitude = ? WHERE ResidentID = ?')->execute([$a['lat'], $a['lng'], $rid]);
        }
    };

    if ($mode === 'link') {
        $h = $pdo->prepare('SELECT * FROM household_survey WHERE SurveyID = ? FOR UPDATE');
        $h->execute([$surveyId]);
        $hs = $h->fetch(PDO::FETCH_ASSOC);
        if (!$hs || strtolower((string) ($hs['status'] ?? 'active')) !== 'active' || (int) ($hs['is_removed'] ?? 0) === 1) {
            throw new RuntimeException('Choose an active household in this barangay.');
        }
        $head = null;
        if (!empty($hs['ResidentID'])) {
            $q = $pdo->prepare("SELECT * FROM residents WHERE ResidentID = ? AND IsHead = 1 AND (IsDeceased = 0 OR IsDeceased IS NULL) AND " . rl_active_sql());
            $q->execute([(int) $hs['ResidentID']]);
            $head = $q->fetch(PDO::FETCH_ASSOC) ?: null;
        }
        if ($head && ($head['PSGCBarangayCode'] ?? '') !== '' && $head['PSGCBarangayCode'] !== $home['psgc_barangay_code']) {
            throw new RuntimeException('That household is not in this barangay.');
        }
        if ($role === 'head') {
            if ($head) throw new RuntimeException('That household already has a Head. Add the resident as a Member, or change the Head in Edit Household.');
            $pdo->prepare("UPDATE residents SET ResidentStatus = 'Active', IsHead = 0, FamilyHeadID = NULL WHERE ResidentID = ?")->execute([$rid]);
            $setAddr($addr);
            $fresh = $pdo->prepare('SELECT * FROM residents WHERE ResidentID = ?');
            $fresh->execute([$rid]);
            hh_assign_headless_head($pdo, $surveyId, $fresh->fetch(PDO::FETCH_ASSOC), 'Member');
            $roleText = 'Household Head';
        } else {
            if ($rel === '') throw new RuntimeException('Enter the relationship to the Household Head.');
            if ($head) {
                // Member of the Head: same address as the household (Head's).
                $pdo->prepare("UPDATE residents SET ResidentStatus = 'Active', IsHead = 0, FamilyHeadID = ?, RelationshipToHead = ? WHERE ResidentID = ?")
                    ->execute([(int) $head['ResidentID'], $rel, $rid]);
                $addr = ['house_no' => $head['HouseNumber'] ?? '', 'building' => $head['BuildingName'] ?? '', 'street' => $head['StreetName'] ?? '',
                         'area' => ($head['AreaName'] ?? '') ?: ($head['Purok'] ?? ''), 'area_type' => $head['AreaType'] ?? ''] + $addr;
                // Pin set by Admin, else the Head's location.
                if (($addr['lat'] ?? null) === null) { $addr['lat'] = $head['Latitude']; $addr['lng'] = $head['Longitude']; }
                $setAddr($addr);
                sync_hh_members($pdo, $surveyId, (int) $head['ResidentID']);
            } else {
                // Household with No Head Assigned: recorded as a member until a Head is assigned.
                $pdo->prepare("UPDATE residents SET ResidentStatus = 'Active', IsHead = 0, FamilyHeadID = NULL, RelationshipToHead = ? WHERE ResidentID = ?")
                    ->execute([$rel, $rid]);
                $setAddr($addr);
                $n = $pdo->prepare('SELECT COALESCE(MAX(MemberNumber), 0) + 1 FROM household_survey_members WHERE SurveyID = ?');
                $n->execute([$surveyId]);
                $pdo->prepare("INSERT INTO household_survey_members (SurveyID, ResidentID, MemberNumber, full_name, sex, relationship, civil_status)
                               VALUES (?, ?, ?, ?, ?, ?, ?)")
                    ->execute([$surveyId, $rid, (int) $n->fetchColumn(), hh_full_name($r), $r['Sex'] ?? null, $rel, $r['CivilStatus'] ?? null]);
            }
            $roleText = $rel;
        }
        log_hh_history($pdo, $surveyId, 'MEMBER_RETURNED', hh_full_name($r) . " moved back to the barangay and joined this household as {$roleText}.");
        $joined = $hs;
    } elseif ($mode === 'new') {
        if ($house === '' || $street === '') throw new RuntimeException('Enter the House/Lot/Unit Number and Street for the new household.');
        $pdo->prepare("UPDATE residents SET ResidentStatus = 'Active', IsHead = ?, FamilyHeadID = NULL, RelationshipToHead = ? WHERE ResidentID = ?")
            ->execute([$role === 'head' ? 1 : 0, $role === 'head' ? 'Head of Family' : ($rel ?: 'Member'), $rid]);
        $setAddr($addr);
        if ($role === 'head') {
            // Existing Household creation process (adopts a No-Head household at this address, never duplicates).
            if (hh_find_household_at_address($pdo, ['HouseNumber' => $house, 'StreetName' => $street], $rid)) {
                throw new RuntimeException('A household with a Head already exists at this address. Link the resident to that household instead.');
            }
            $sid = hh_ensure_household_record($pdo, $rid);
            if ($sid <= 0) throw new RuntimeException('The household could not be created.');
            sync_hh_members($pdo, $sid, $rid);
            $roleText = 'Household Head';
        } else {
            if ($rel === '') throw new RuntimeException('Enter the relationship to the (future) Household Head.');
            if (hh_find_household_at_address($pdo, ['HouseNumber' => $house, 'StreetName' => $street], $rid)) {
                throw new RuntimeException('A household with a Head already exists at this address. Link the resident to that household instead.');
            }
            // New household with No Head Assigned (same mechanism as members profiled before a Head).
            hh_sync_unassigned_members($pdo);
            $q = $pdo->prepare("SELECT m.SurveyID FROM household_survey_members m JOIN household_survey hs ON hs.SurveyID = m.SurveyID
                                WHERE m.ResidentID = ? AND COALESCE(hs.status,'active') = 'active' ORDER BY m.SurveyID DESC LIMIT 1");
            $q->execute([$rid]);
            $sid = (int) $q->fetchColumn();
            if ($sid <= 0) throw new RuntimeException('The household could not be created.');
            $roleText = $rel . ' (No Head Assigned yet)';
        }
        $j = $pdo->prepare('SELECT * FROM household_survey WHERE SurveyID = ?');
        $j->execute([$sid]);
        $joined = $j->fetch(PDO::FETCH_ASSOC);
        log_hh_history($pdo, $sid, 'MEMBER_RETURNED', hh_full_name($r) . " moved back to the barangay ({$roleText}).");
    } else {
        throw new RuntimeException('Choose whether to link to an existing household or create a new one.');
    }

    $addr['address_line'] = trim(implode(', ', array_filter([trim((string) ($addr['house_no'] ?? '')), trim((string) ($addr['building'] ?? '')),
        trim((string) ($addr['street'] ?? '')), trim((string) ($addr['area'] ?? ''))])));
    rl_log($pdo, $rid, 'Back', $joined, $roleText, $addr, $by, 'Moved back to the barangay.', $r);
    rl_revoke_sessions($pdo, [$rid]); // the app signs in again and sees the Active status
    return ['household_id' => $joined['HouseholdID'] ?? null, 'survey_id' => (int) ($joined['SurveyID'] ?? 0), 'role' => $roleText];
}
