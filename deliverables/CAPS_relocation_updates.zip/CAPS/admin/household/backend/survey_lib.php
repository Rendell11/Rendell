<?php
/**
 * admin/household/backend/survey_lib.php
 * ─────────────────────────────────────────────────────────────────────────────
 * Configurable Household Survey — shared logic (no auth, no output).
 * Used by the admin builder/responses API (survey_api.php) and the resident
 * app API (user/backend/household_survey.php).
 *
 * Everything the survey shows comes from these tables (no hardcoded questions):
 *
 *   household_surveys          one survey per barangay (title, description)
 *   household_survey_versions  Draft / Published / Inactive versions
 *   household_survey_sections  sections of a version (ordered)
 *   household_survey_questions questions of a section (ordered, typed)
 *   household_survey_options   choices of a choice question (ordered)
 *   household_survey_responses one submission of a household to a version
 *   household_survey_answers   one row per answered question (one row per
 *                              selected option for Checkbox questions)
 *
 * Versioning rules
 *   • A Draft version can be edited freely.
 *   • A Published version WITHOUT responses can still be edited in place.
 *   • A version WITH responses is never changed: editing it creates a new
 *     Draft version (a copy); publishing that one makes the old version
 *     Inactive. Old responses stay linked to the version they answered.
 *   • Only one version is Published per barangay at a time.
 *   • Versions, questions and options that have answers are never deleted
 *     (the foreign keys also refuse it).
 *
 * Existing records: a response points to the household's existing
 * household_survey row (SurveyID) and the Head's residents row — nothing
 * new is created for households or residents.
 * ─────────────────────────────────────────────────────────────────────────────
 */

declare(strict_types=1);

const HS_TYPES = ['short_answer', 'paragraph', 'multiple_choice', 'checkbox', 'dropdown', 'yes_no', 'number', 'date'];
const HS_CHOICE_TYPES = ['multiple_choice', 'checkbox', 'dropdown'];

/** Create the survey tables when missing (same DDL as the migration SQL). */
function hs_migrate(PDO $pdo): void
{
    static $done = false;
    if ($done || $pdo->inTransaction()) return;
    $done = true;
    $have = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME IN ('household_surveys','household_survey_versions','household_survey_sections',
        'household_survey_questions','household_survey_options','household_survey_responses','household_survey_answers')")
        ->fetchColumn();
    if ($have === 7) return;
    foreach (hs_schema_sql() as $sql) {
        $pdo->exec($sql);
    }
}

/** DDL for the 7 survey tables (also written to the migration .sql file). */
function hs_schema_sql(): array
{
    $t = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    return [
        "CREATE TABLE IF NOT EXISTS household_surveys (
            survey_id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
            barangay_id  INT UNSIGNED NOT NULL,
            title        VARCHAR(200) NOT NULL,
            description  TEXT NULL,
            created_by   VARCHAR(150) NULL,
            created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (survey_id),
            KEY idx_hs_barangay (barangay_id)
        ) $t",
        "CREATE TABLE IF NOT EXISTS household_survey_versions (
            version_id      INT UNSIGNED NOT NULL AUTO_INCREMENT,
            survey_id       INT UNSIGNED NOT NULL,
            barangay_id     INT UNSIGNED NOT NULL,
            version_number  INT UNSIGNED NOT NULL,
            status          ENUM('Draft','Published','Inactive') NOT NULL DEFAULT 'Draft',
            based_on_version_id INT UNSIGNED NULL,
            created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            created_by      VARCHAR(150) NULL,
            published_at    DATETIME NULL,
            published_by    VARCHAR(150) NULL,
            inactive_at     DATETIME NULL,
            updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (version_id),
            UNIQUE KEY uq_hsv_number (survey_id, version_number),
            KEY idx_hsv_status (barangay_id, status),
            CONSTRAINT fk_hsv_survey FOREIGN KEY (survey_id) REFERENCES household_surveys (survey_id) ON DELETE RESTRICT
        ) $t",
        "CREATE TABLE IF NOT EXISTS household_survey_sections (
            section_id   INT UNSIGNED NOT NULL AUTO_INCREMENT,
            version_id   INT UNSIGNED NOT NULL,
            title        VARCHAR(200) NOT NULL,
            description  TEXT NULL,
            sort_order   INT NOT NULL DEFAULT 0,
            is_active    TINYINT(1) NOT NULL DEFAULT 1,
            PRIMARY KEY (section_id),
            KEY idx_hss_version (version_id, sort_order),
            CONSTRAINT fk_hss_version FOREIGN KEY (version_id) REFERENCES household_survey_versions (version_id) ON DELETE RESTRICT
        ) $t",
        "CREATE TABLE IF NOT EXISTS household_survey_questions (
            question_id   INT UNSIGNED NOT NULL AUTO_INCREMENT,
            version_id    INT UNSIGNED NOT NULL,
            section_id    INT UNSIGNED NOT NULL,
            question_text VARCHAR(500) NOT NULL,
            help_text     VARCHAR(500) NULL,
            question_type ENUM('short_answer','paragraph','multiple_choice','checkbox','dropdown','yes_no','number','date') NOT NULL,
            is_required   TINYINT(1) NOT NULL DEFAULT 0,
            is_active     TINYINT(1) NOT NULL DEFAULT 1,
            sort_order    INT NOT NULL DEFAULT 0,
            source_question_id INT UNSIGNED NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (question_id),
            KEY idx_hsq_section (section_id, sort_order),
            KEY idx_hsq_version (version_id),
            CONSTRAINT fk_hsq_version FOREIGN KEY (version_id) REFERENCES household_survey_versions (version_id) ON DELETE RESTRICT,
            CONSTRAINT fk_hsq_section FOREIGN KEY (section_id) REFERENCES household_survey_sections (section_id) ON DELETE RESTRICT
        ) $t",
        "CREATE TABLE IF NOT EXISTS household_survey_options (
            option_id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
            question_id  INT UNSIGNED NOT NULL,
            option_label VARCHAR(255) NOT NULL,
            sort_order   INT NOT NULL DEFAULT 0,
            is_active    TINYINT(1) NOT NULL DEFAULT 1,
            PRIMARY KEY (option_id),
            KEY idx_hso_question (question_id, sort_order),
            CONSTRAINT fk_hso_question FOREIGN KEY (question_id) REFERENCES household_survey_questions (question_id) ON DELETE RESTRICT
        ) $t",
        "CREATE TABLE IF NOT EXISTS household_survey_responses (
            response_id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
            barangay_id         INT UNSIGNED NOT NULL,
            survey_id           INT UNSIGNED NOT NULL,
            version_id          INT UNSIGNED NOT NULL,
            household_record_id INT UNSIGNED NOT NULL,
            household_code      VARCHAR(30) NULL,
            respondent_resident_id INT UNSIGNED NULL,
            respondent_name     VARCHAR(255) NULL,
            source              ENUM('app','admin') NOT NULL DEFAULT 'app',
            submitted_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (response_id),
            UNIQUE KEY uq_hsr_household_version (version_id, household_record_id),
            KEY idx_hsr_barangay_date (barangay_id, submitted_at),
            KEY idx_hsr_survey (survey_id),
            KEY idx_hsr_household (household_record_id),
            KEY idx_hsr_resident (respondent_resident_id),
            CONSTRAINT fk_hsr_survey FOREIGN KEY (survey_id) REFERENCES household_surveys (survey_id) ON DELETE RESTRICT,
            CONSTRAINT fk_hsr_version FOREIGN KEY (version_id) REFERENCES household_survey_versions (version_id) ON DELETE RESTRICT,
            CONSTRAINT fk_hsr_household FOREIGN KEY (household_record_id) REFERENCES household_survey (SurveyID) ON DELETE RESTRICT,
            CONSTRAINT fk_hsr_resident FOREIGN KEY (respondent_resident_id) REFERENCES residents (ResidentID) ON DELETE SET NULL
        ) $t",
        "CREATE TABLE IF NOT EXISTS household_survey_answers (
            answer_id     INT UNSIGNED NOT NULL AUTO_INCREMENT,
            response_id   INT UNSIGNED NOT NULL,
            version_id    INT UNSIGNED NOT NULL,
            question_id   INT UNSIGNED NOT NULL,
            option_id     INT UNSIGNED NULL,
            answer_text   TEXT NULL,
            answer_number DECIMAL(18,4) NULL,
            answer_date   DATE NULL,
            PRIMARY KEY (answer_id),
            KEY idx_hsa_response (response_id),
            KEY idx_hsa_question (question_id),
            KEY idx_hsa_option (option_id),
            KEY idx_hsa_version (version_id),
            CONSTRAINT fk_hsa_response FOREIGN KEY (response_id) REFERENCES household_survey_responses (response_id) ON DELETE CASCADE,
            CONSTRAINT fk_hsa_version FOREIGN KEY (version_id) REFERENCES household_survey_versions (version_id) ON DELETE RESTRICT,
            CONSTRAINT fk_hsa_question FOREIGN KEY (question_id) REFERENCES household_survey_questions (question_id) ON DELETE RESTRICT,
            CONSTRAINT fk_hsa_option FOREIGN KEY (option_id) REFERENCES household_survey_options (option_id) ON DELETE RESTRICT
        ) $t",
    ];
}

/** The barangay this CAPS install serves (Manage Area → barangay_profile). */
function hs_barangay_id(PDO $pdo): int
{
    static $id = null;
    if ($id !== null) return $id;
    try {
        $id = (int) ($pdo->query('SELECT id FROM barangay_profile ORDER BY id ASC LIMIT 1')->fetchColumn() ?: 1);
    } catch (Throwable $e) {
        $id = 1;
    }
    return $id;
}

/** Version row (only if it belongs to this barangay), or null. */
function hs_version(PDO $pdo, int $versionId, int $barangayId): ?array
{
    $s = $pdo->prepare('SELECT v.*, s.title AS survey_title, s.description AS survey_description
                        FROM household_survey_versions v JOIN household_surveys s ON s.survey_id = v.survey_id
                        WHERE v.version_id = ? AND v.barangay_id = ?');
    $s->execute([$versionId, $barangayId]);
    return $s->fetch(PDO::FETCH_ASSOC) ?: null;
}

function hs_response_count(PDO $pdo, int $versionId): int
{
    $s = $pdo->prepare('SELECT COUNT(*) FROM household_survey_responses WHERE version_id = ?');
    $s->execute([$versionId]);
    return (int) $s->fetchColumn();
}

/**
 * Can this version's structure be changed in place?
 * Returns null when yes, else the reason.
 */
function hs_edit_block_reason(PDO $pdo, array $version): ?string
{
    if ($version['status'] === 'Inactive') {
        return 'This version is Inactive. Create a new version to make changes.';
    }
    if (hs_response_count($pdo, (int) $version['version_id']) > 0) {
        return 'This version already has responses. Create a new version to make changes.';
    }
    return null;
}

/** Sections → questions → options of a version, ordered. */
function hs_tree(PDO $pdo, int $versionId, bool $activeOnly = false): array
{
    $act = $activeOnly ? ' AND is_active = 1' : '';
    $sec = $pdo->prepare("SELECT * FROM household_survey_sections WHERE version_id = ?$act ORDER BY sort_order, section_id");
    $sec->execute([$versionId]);
    $sections = $sec->fetchAll(PDO::FETCH_ASSOC);

    $q = $pdo->prepare("SELECT * FROM household_survey_questions WHERE version_id = ?$act ORDER BY sort_order, question_id");
    $q->execute([$versionId]);
    $questions = $q->fetchAll(PDO::FETCH_ASSOC);

    $opts = [];
    if ($questions) {
        $ids = array_column($questions, 'question_id');
        $in = implode(',', array_fill(0, count($ids), '?'));
        $o = $pdo->prepare("SELECT * FROM household_survey_options WHERE question_id IN ($in)$act ORDER BY sort_order, option_id");
        $o->execute($ids);
        foreach ($o->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $opts[(int) $row['question_id']][] = [
                'option_id' => (int) $row['option_id'], 'label' => $row['option_label'],
                'sort_order' => (int) $row['sort_order'], 'is_active' => (int) $row['is_active'] === 1,
            ];
        }
    }
    $bySection = [];
    foreach ($questions as $row) {
        $bySection[(int) $row['section_id']][] = [
            'question_id' => (int) $row['question_id'], 'text' => $row['question_text'],
            'help' => $row['help_text'], 'type' => $row['question_type'],
            'required' => (int) $row['is_required'] === 1, 'is_active' => (int) $row['is_active'] === 1,
            'sort_order' => (int) $row['sort_order'],
            'options' => $opts[(int) $row['question_id']] ?? [],
        ];
    }
    return array_map(static fn($s) => [
        'section_id' => (int) $s['section_id'], 'title' => $s['title'], 'description' => $s['description'],
        'sort_order' => (int) $s['sort_order'], 'is_active' => (int) $s['is_active'] === 1,
        'questions' => $bySection[(int) $s['section_id']] ?? [],
    ], $sections);
}

/** The currently Published version of this barangay, or null. */
function hs_published_version(PDO $pdo, int $barangayId): ?array
{
    $s = $pdo->prepare("SELECT v.*, s.title AS survey_title, s.description AS survey_description
                        FROM household_survey_versions v JOIN household_surveys s ON s.survey_id = v.survey_id
                        WHERE v.barangay_id = ? AND v.status = 'Published'
                        ORDER BY v.published_at DESC, v.version_id DESC LIMIT 1");
    $s->execute([$barangayId]);
    return $s->fetch(PDO::FETCH_ASSOC) ?: null;
}

/** Next version number of a survey. */
function hs_next_version_number(PDO $pdo, int $surveyId): int
{
    $s = $pdo->prepare('SELECT COALESCE(MAX(version_number), 0) + 1 FROM household_survey_versions WHERE survey_id = ?');
    $s->execute([$surveyId]);
    return (int) $s->fetchColumn();
}

/** New survey with an empty Draft version 1 and one section. Returns version id. */
function hs_create_survey(PDO $pdo, int $barangayId, string $title, string $description, string $by): int
{
    $pdo->beginTransaction();
    try {
        $pdo->prepare('INSERT INTO household_surveys (barangay_id, title, description, created_by) VALUES (?, ?, ?, ?)')
            ->execute([$barangayId, $title, $description !== '' ? $description : null, $by]);
        $surveyId = (int) $pdo->lastInsertId();
        $pdo->prepare("INSERT INTO household_survey_versions (survey_id, barangay_id, version_number, status, created_by)
                       VALUES (?, ?, 1, 'Draft', ?)")->execute([$surveyId, $barangayId, $by]);
        $versionId = (int) $pdo->lastInsertId();
        $pdo->prepare('INSERT INTO household_survey_sections (version_id, title, sort_order) VALUES (?, ?, 1)')
            ->execute([$versionId, 'Section 1']);
        $pdo->commit();
        return $versionId;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Copy a version into a new Draft (sections, questions and options). Used
 * when a version with responses has to change. Returns the new version id.
 * If the survey already has a Draft, that Draft is returned instead.
 */
function hs_new_version(PDO $pdo, int $fromVersionId, int $barangayId, string $by): int
{
    $from = hs_version($pdo, $fromVersionId, $barangayId);
    if (!$from) throw new RuntimeException('Version not found.');
    $d = $pdo->prepare("SELECT version_id FROM household_survey_versions WHERE survey_id = ? AND status = 'Draft' LIMIT 1");
    $d->execute([(int) $from['survey_id']]);
    if ($existing = $d->fetchColumn()) return (int) $existing;

    $pdo->beginTransaction();
    try {
        $num = hs_next_version_number($pdo, (int) $from['survey_id']);
        $pdo->prepare("INSERT INTO household_survey_versions (survey_id, barangay_id, version_number, status, based_on_version_id, created_by)
                       VALUES (?, ?, ?, 'Draft', ?, ?)")
            ->execute([(int) $from['survey_id'], $barangayId, $num, $fromVersionId, $by]);
        $newId = (int) $pdo->lastInsertId();

        $secIns = $pdo->prepare('INSERT INTO household_survey_sections (version_id, title, description, sort_order, is_active) VALUES (?, ?, ?, ?, ?)');
        $qIns = $pdo->prepare('INSERT INTO household_survey_questions
            (version_id, section_id, question_text, help_text, question_type, is_required, is_active, sort_order, source_question_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $oIns = $pdo->prepare('INSERT INTO household_survey_options (question_id, option_label, sort_order, is_active) VALUES (?, ?, ?, ?)');
        foreach (hs_tree($pdo, $fromVersionId) as $s) {
            $secIns->execute([$newId, $s['title'], $s['description'], $s['sort_order'], $s['is_active'] ? 1 : 0]);
            $sid = (int) $pdo->lastInsertId();
            foreach ($s['questions'] as $q) {
                $qIns->execute([$newId, $sid, $q['text'], $q['help'], $q['type'], $q['required'] ? 1 : 0,
                                $q['is_active'] ? 1 : 0, $q['sort_order'], $q['question_id']]);
                $qid = (int) $pdo->lastInsertId();
                foreach ($q['options'] as $o) {
                    $oIns->execute([$qid, $o['label'], $o['sort_order'], $o['is_active'] ? 1 : 0]);
                }
            }
        }
        $pdo->commit();
        return $newId;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/** Problems that block publishing (empty survey, choice question without choices…). */
function hs_publish_problems(PDO $pdo, int $versionId): array
{
    $problems = [];
    $active = 0;
    foreach (hs_tree($pdo, $versionId, true) as $s) {
        foreach ($s['questions'] as $q) {
            $active++;
            if (in_array($q['type'], HS_CHOICE_TYPES, true) && count($q['options']) < 1) {
                $problems[] = "\"{$q['text']}\" needs at least one choice.";
            }
        }
    }
    if ($active === 0) $problems[] = 'Add at least one active question.';
    return $problems;
}

/**
 * Publish a version. Any other Published version of this barangay becomes
 * Inactive (only one Household Survey is open at a time).
 */
function hs_publish(PDO $pdo, int $versionId, int $barangayId, string $by): void
{
    $v = hs_version($pdo, $versionId, $barangayId);
    if (!$v) throw new RuntimeException('Version not found.');
    if ($v['status'] === 'Published') return;
    if ($problems = hs_publish_problems($pdo, $versionId)) {
        throw new RuntimeException(implode(' ', $problems));
    }
    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE household_survey_versions SET status = 'Inactive', inactive_at = NOW()
                       WHERE barangay_id = ? AND status = 'Published' AND version_id <> ?")
            ->execute([$barangayId, $versionId]);
        $pdo->prepare("UPDATE household_survey_versions SET status = 'Published', published_at = NOW(), published_by = ?, inactive_at = NULL
                       WHERE version_id = ?")->execute([$by, $versionId]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * In-app notification for every current Household Head who still has to
 * answer this version. One notification per Head per version: publishing the
 * same version again never sends a second one. Phone push for these rows is
 * sent by the existing push worker (user/backend/push_lib.php) when Firebase
 * is configured; this function does not claim any phone delivery.
 * Returns the number of new notifications.
 */
function hs_notify_heads(PDO $pdo, array $version): int
{
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS resident_notifications (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            resident_id INT NOT NULL,
            notif_type VARCHAR(50) NOT NULL DEFAULT 'system',
            title VARCHAR(255) NOT NULL,
            message TEXT NOT NULL,
            ref_table VARCHAR(80) NULL,
            ref_id INT UNSIGNED NULL,
            action_url VARCHAR(500) NULL,
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            read_at DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_resident_unread (resident_id, is_read, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Throwable $e) { /* already there */ }

    $versionId = (int) $version['version_id'];
    // Current, living Heads with an active household record of this barangay
    // install, whose household has not answered this version.
    $ins = $pdo->prepare("
        INSERT INTO resident_notifications (resident_id, notif_type, title, message, ref_table, ref_id)
        SELECT r.ResidentID, 'household_survey', ?, ?, 'household_survey_versions', ?
        FROM residents r
        JOIN household_survey hs ON hs.ResidentID = r.ResidentID
             AND COALESCE(hs.status, 'active') = 'active' AND COALESCE(hs.is_removed, 0) = 0
        WHERE r.IsHead = 1 AND (r.IsDeceased = 0 OR r.IsDeceased IS NULL)
          AND NOT EXISTS (SELECT 1 FROM household_survey_responses x
                          WHERE x.version_id = ? AND x.household_record_id = hs.SurveyID)
          AND NOT EXISTS (SELECT 1 FROM resident_notifications n
                          WHERE n.resident_id = r.ResidentID AND n.notif_type = 'household_survey'
                            AND n.ref_table = 'household_survey_versions' AND n.ref_id = ?)
        GROUP BY r.ResidentID");
    $ins->execute([
        'Household Survey Required',
        'Your Barangay has published a new Household Survey (' . $version['survey_title'] . ' — Version '
            . (int) $version['version_number'] . '). Please complete the survey to continue.',
        $versionId, $versionId, $versionId,
    ]);
    return $ins->rowCount();
}

function hs_set_inactive(PDO $pdo, int $versionId, int $barangayId): void
{
    if (!hs_version($pdo, $versionId, $barangayId)) throw new RuntimeException('Version not found.');
    $pdo->prepare("UPDATE household_survey_versions SET status = 'Inactive', inactive_at = NOW() WHERE version_id = ?")
        ->execute([$versionId]);
}

// ═════════════════════════════════════════════════════════════════════════════
//  Responses
// ═════════════════════════════════════════════════════════════════════════════

/** Response of a household to any version of a survey (latest), or null. */
function hs_household_response(PDO $pdo, int $surveyId, int $householdRecordId): ?array
{
    $s = $pdo->prepare('SELECT * FROM household_survey_responses WHERE survey_id = ? AND household_record_id = ?
                        ORDER BY submitted_at DESC LIMIT 1');
    $s->execute([$surveyId, $householdRecordId]);
    return $s->fetch(PDO::FETCH_ASSOC) ?: null;
}

/**
 * The response of a household to one exact version, or null. Completion of a
 * required survey is always checked against the version that is required now.
 */
function hs_household_version_response(PDO $pdo, int $versionId, int $householdRecordId): ?array
{
    $s = $pdo->prepare('SELECT * FROM household_survey_responses WHERE version_id = ? AND household_record_id = ? LIMIT 1');
    $s->execute([$versionId, $householdRecordId]);
    return $s->fetch(PDO::FETCH_ASSOC) ?: null;
}

/**
 * Every response of one household (all surveys and versions, newest first),
 * each with the questions of the version it answered. Matched by the
 * household record (SurveyID) or its Household ID, within this barangay, so
 * a response is found even when it was saved under the household's code.
 */
function hs_household_responses(PDO $pdo, int $householdRecordId, string $householdCode, int $barangayId): array
{
    $s = $pdo->prepare("SELECT response_id FROM household_survey_responses
                        WHERE barangay_id = ? AND (household_record_id = ? OR (? <> '' AND household_code = ?))
                        ORDER BY submitted_at DESC, response_id DESC");
    $s->execute([$barangayId, $householdRecordId, $householdCode, $householdCode]);
    $out = [];
    foreach ($s->fetchAll(PDO::FETCH_COLUMN) as $id) {
        if ($d = hs_response_detail($pdo, (int) $id, $barangayId)) $out[] = $d;
    }
    return $out;
}

/** A published version as the resident app shows it (active questions only). */
function hs_app_version(PDO $pdo, array $version): array
{
    return [
        'version_id' => (int) $version['version_id'],
        'version_number' => (int) $version['version_number'],
        'title' => $version['survey_title'],
        'description' => $version['survey_description'],
        'sections' => array_values(array_filter(
            hs_tree($pdo, (int) $version['version_id'], true),
            static fn($sec) => count($sec['questions']) > 0)),
    ];
}

/**
 * Validate and save a submission. $answers maps question_id => value:
 *   short_answer / paragraph → string
 *   number                   → numeric string
 *   date                     → 'YYYY-MM-DD'
 *   yes_no                   → 'Yes' | 'No'
 *   multiple_choice/dropdown → option_id
 *   checkbox                 → [option_id, …]
 * Returns the response id; throws InvalidArgumentException with a message
 * the resident can read when an answer is missing or invalid.
 */
function hs_submit(PDO $pdo, array $version, array $household, int $residentId, string $respondentName,
                   array $answers, string $source = 'app'): int
{
    $versionId = (int) $version['version_id'];
    $rows = []; // [question_id, option_id, text, number, date]
    foreach (hs_tree($pdo, $versionId, true) as $section) {
        foreach ($section['questions'] as $q) {
            $qid = $q['question_id'];
            $raw = $answers[$qid] ?? $answers[(string) $qid] ?? null;
            $optionIds = array_column($q['options'], 'option_id');
            $labels = array_column($q['options'], 'label', 'option_id');
            $empty = $raw === null || $raw === '' || $raw === [];
            if ($empty) {
                if ($q['required']) throw new InvalidArgumentException("Please answer: {$q['text']}");
                $rows[] = [$qid, null, null, null, null];
                continue;
            }
            switch ($q['type']) {
                case 'short_answer':
                case 'paragraph':
                    $text = trim((string) $raw);
                    if ($text === '' && $q['required']) throw new InvalidArgumentException("Please answer: {$q['text']}");
                    $rows[] = [$qid, null, mb_substr($text, 0, $q['type'] === 'paragraph' ? 5000 : 500), null, null];
                    break;
                case 'number':
                    if (!is_numeric($raw)) throw new InvalidArgumentException("Enter a number for: {$q['text']}");
                    $rows[] = [$qid, null, (string) $raw, (float) $raw, null];
                    break;
                case 'date':
                    $d = DateTime::createFromFormat('Y-m-d', (string) $raw);
                    if (!$d || $d->format('Y-m-d') !== (string) $raw) throw new InvalidArgumentException("Enter a valid date for: {$q['text']}");
                    $rows[] = [$qid, null, (string) $raw, null, (string) $raw];
                    break;
                case 'yes_no':
                    $yn = ucfirst(strtolower((string) $raw));
                    if (!in_array($yn, ['Yes', 'No'], true)) throw new InvalidArgumentException("Answer Yes or No for: {$q['text']}");
                    $rows[] = [$qid, null, $yn, null, null];
                    break;
                case 'multiple_choice':
                case 'dropdown':
                    $oid = (int) (is_array($raw) ? reset($raw) : $raw);
                    if (!in_array($oid, $optionIds, true)) throw new InvalidArgumentException("Choose an option for: {$q['text']}");
                    $rows[] = [$qid, $oid, $labels[$oid], null, null];
                    break;
                case 'checkbox':
                    $picked = array_values(array_unique(array_map('intval', (array) $raw)));
                    foreach ($picked as $oid) {
                        if (!in_array($oid, $optionIds, true)) throw new InvalidArgumentException("Invalid choice for: {$q['text']}");
                    }
                    if (!$picked) {
                        if ($q['required']) throw new InvalidArgumentException("Please answer: {$q['text']}");
                        $rows[] = [$qid, null, null, null, null];
                    }
                    foreach ($picked as $oid) $rows[] = [$qid, $oid, $labels[$oid], null, null];
                    break;
            }
        }
    }

    // Joins the caller's transaction when one is open (e.g. Move Back to Barangay saves the
    // household and its survey together); otherwise uses its own.
    $own = !$pdo->inTransaction();
    if ($own) $pdo->beginTransaction();
    try {
        $pdo->prepare('INSERT INTO household_survey_responses
            (barangay_id, survey_id, version_id, household_record_id, household_code, respondent_resident_id, respondent_name, source)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([(int) $version['barangay_id'], (int) $version['survey_id'], $versionId,
                       (int) $household['SurveyID'], $household['HouseholdID'] ?? null,
                       $residentId ?: null, $respondentName, $source]);
        $responseId = (int) $pdo->lastInsertId();
        $ins = $pdo->prepare('INSERT INTO household_survey_answers
            (response_id, version_id, question_id, option_id, answer_text, answer_number, answer_date)
            VALUES (?, ?, ?, ?, ?, ?, ?)');
        foreach ($rows as [$qid, $oid, $text, $num, $date]) {
            $ins->execute([$responseId, $versionId, $qid, $oid, $text, $num, $date]);
        }
        if ($own) $pdo->commit();
        return $responseId;
    } catch (PDOException $e) {
        if ($own) $pdo->rollBack();
        if ($e->getCode() === '23000' && stripos($e->getMessage(), 'uq_hsr_household_version') !== false) {
            throw new InvalidArgumentException('This household already answered this survey.');
        }
        throw $e;
    }
}

/**
 * One response with the questions of the version it answered (never the
 * latest version), each with its answer.
 */
function hs_response_detail(PDO $pdo, int $responseId, int $barangayId): ?array
{
    $s = $pdo->prepare('SELECT r.*, v.version_number, v.status AS version_status, s.title AS survey_title
                        FROM household_survey_responses r
                        JOIN household_survey_versions v ON v.version_id = r.version_id
                        JOIN household_surveys s ON s.survey_id = r.survey_id
                        WHERE r.response_id = ? AND r.barangay_id = ?');
    $s->execute([$responseId, $barangayId]);
    $resp = $s->fetch(PDO::FETCH_ASSOC);
    if (!$resp) return null;

    $a = $pdo->prepare('SELECT * FROM household_survey_answers WHERE response_id = ? ORDER BY answer_id');
    $a->execute([$responseId]);
    $byQ = [];
    foreach ($a->fetchAll(PDO::FETCH_ASSOC) as $row) $byQ[(int) $row['question_id']][] = $row;

    // All questions of that version (including ones later set inactive) so
    // the response reads exactly as it was submitted.
    $sections = hs_tree($pdo, (int) $resp['version_id']);
    foreach ($sections as &$sec) {
        foreach ($sec['questions'] as &$q) {
            $vals = [];
            foreach ($byQ[$q['question_id']] ?? [] as $row) {
                if ($row['answer_text'] !== null && $row['answer_text'] !== '') $vals[] = $row['answer_text'];
            }
            $q['answered'] = isset($byQ[$q['question_id']]);
            $q['answer'] = $vals;
        }
        unset($q);
        $sec['questions'] = array_values(array_filter($sec['questions'], static fn($q) => $q['answered'] || $q['is_active']));
    }
    unset($sec);
    $resp['sections'] = $sections;
    return $resp;
}
