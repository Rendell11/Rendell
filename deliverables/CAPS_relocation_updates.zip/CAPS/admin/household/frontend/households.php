<?php
declare(strict_types=1);
require_once __DIR__ . '/../backend/households.php';
require_once __DIR__ . '/../../../login/csrf_helper.php';
$csrf = function_exists('csrf_token') ? (string) csrf_token() : (string) ($_SESSION['csrf_token'] ?? '');

$success = isset($_GET['success']);
$error = trim((string) ($_GET['error'] ?? ''));
?>
<!doctype html>
<html <?php echo $theme_attrs['html']; ?>>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Household Management — Barangay Biñang 2nd</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms"></script>
    <link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=DM+Mono:wght@400;500&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700;1,0,-50..200"
        rel="stylesheet">

    <?php if ($googleKey): ?>
        <script>
            window.initCapsHouseholdMap = function () {
                window.__capsHouseholdMapsReady = true;
                if (typeof window.renderHouseholdMap === 'function') window.renderHouseholdMap();
            };
        </script>
        <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=<?= htmlspecialchars($googleKey, ENT_QUOTES, 'UTF-8') ?>&callback=initCapsHouseholdMap"></script>
    <?php else: ?>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="" />
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
    <?php endif; ?>

    <?php include __DIR__ . '/../../theme_head.php'; ?>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: { DEFAULT: 'var(--accent-600)', light: 'var(--accent-500)', dark: 'var(--accent-700)' },
                        accent: { DEFAULT: 'var(--accent-500)', light: 'var(--accent-400)' }
                    },
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        mono: ['"DM Mono"', 'monospace']
                    }
                }
            }
        };
    </script>

    <style>
        :root {
            --sidebar-w: 288px;
            --nav-h: 64px
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--page-bg, #eef2fb);
            -webkit-font-smoothing: antialiased
        }

        .main-wrapper {
            margin-left: var(--sidebar-w);
            width: calc(100% - var(--sidebar-w))
        }

        @media(max-width:1024px) {
            .main-wrapper {
                margin-left: 0;
                width: 100%
            }
        }

        ::-webkit-scrollbar {
            width: 6px;
            height: 6px
        }

        ::-webkit-scrollbar-track {
            background: transparent
        }

        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 99px
        }

        #householdMap {
            height: 430px;
            border-radius: 1.25rem;
            overflow: hidden
        }

        .income-high {
            background: #ecfdf5;
            color: #059669;
            border-color: #a7f3d0
        }

        .income-mid {
            background: #fffbeb;
            color: #d97706;
            border-color: #fde68a
        }

        .income-low {
            background: #fff1f2;
            color: #e11d48;
            border-color: #fecdd3
        }

        html.dark body {
            background: #0f172a;
            color: #e2e8f0
        }

        html.dark .bg-white {
            background: #1e293b !important
        }

        html.dark .bg-slate-50,
        html.dark .bg-slate-50\/50 {
            background: #0f172a !important
        }

        html.dark .bg-slate-100 {
            background: #1e293b !important
        }

        html.dark .text-slate-900 {
            color: #f1f5f9 !important
        }

        html.dark .text-slate-800 {
            color: #e2e8f0 !important
        }

        html.dark .text-slate-700 {
            color: #cbd5e1 !important
        }

        html.dark .text-slate-600 {
            color: #94a3b8 !important
        }

        html.dark .text-slate-500 {
            color: #64748b !important
        }

        html.dark .border-slate-100,
        html.dark .border-slate-200 {
            border-color: #334155 !important
        }

        html.dark .divide-y>*+* {
            border-color: #334155 !important
        }

        html.dark input,
        html.dark select {
            background: #0f172a !important;
            border-color: #334155 !important;
            color: #e2e8f0 !important
        }
    </style>
</head>

<body <?php echo $theme_attrs['body']; ?>>
    <div class="flex min-h-screen">
        <?php include __DIR__ . '/../../sidebar.php'; ?>

        <div class="flex-1 flex flex-col min-w-0 main-wrapper">
            <?php include __DIR__ . '/../../header.php'; ?>

            <main class="p-4 md:p-6 lg:p-8 space-y-8">

                <!-- Same Hero Band as Resident Management -->
                <div class="rounded-2xl p-6 md:p-8 text-white relative overflow-hidden"
                    style="background:linear-gradient(135deg,var(--accent-700) 0%,var(--accent-600) 50%,var(--accent-700) 100%);">
                    <div class="absolute -right-12 -top-12 w-64 h-64 opacity-10 rounded-full blur-3xl pointer-events-none"
                        style="background:var(--accent-400);"></div>
                    <div class="absolute left-1/3 bottom-0 w-48 h-48 opacity-10 rounded-full blur-2xl pointer-events-none"
                        style="background:var(--accent-300);"></div>

                    <div class="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div>
                            <h1 class="text-2xl md:text-3xl font-black tracking-tight leading-none">Household Management
                            </h1>
                            <p class="text-white/60 text-sm mt-2 font-medium">
                                Manage and monitor household data for Barangay Biñang 2nd.
                            </p>
                        </div>

                        <div class="flex flex-wrap gap-3 flex-shrink-0">
                            <a href="analytics_household.php"
                                class="flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all">
                                <span class="material-symbols-outlined text-lg">analytics</span>
                                Analytics
                            </a>
                            <a href="survey_builder.php"
                                class="flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all">
                                <span class="material-symbols-outlined text-lg">quiz</span>
                                Household Survey
                            </a>
                            <a href="survey_responses.php"
                                class="flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all">
                                <span class="material-symbols-outlined text-lg">fact_check</span>
                                Survey Responses
                            </a>
                            <a href="new_household.php"
                                class="flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all">
                                <span class="material-symbols-outlined text-lg">add_home</span>
                                New Household
                            </a>
                        </div>
                    </div>
                </div>

                <?php if ($success): ?>
                    <div
                        class="rounded-2xl border border-emerald-100 bg-emerald-50 px-5 py-4 text-sm font-bold text-emerald-700">
                        Household saved successfully.
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="rounded-2xl border border-rose-100 bg-rose-50 px-5 py-4 text-sm font-bold text-rose-700">
                        <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($headlessHouseholds)): ?>
                    <!-- Households without a Head (their Head became the Head of another household) -->
                    <div class="rounded-2xl border-2 border-amber-200 bg-amber-50 px-6 py-4">
                        <div class="flex items-start gap-3">
                            <span class="material-symbols-outlined text-amber-600">warning</span>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-black text-amber-800"><?= count($headlessHouseholds) ?> household<?= count($headlessHouseholds) === 1 ? ' has' : 's have' ?> no Head and need<?= count($headlessHouseholds) === 1 ? 's' : '' ?> a new Head.</p>
                                <p class="text-xs font-semibold text-amber-700 mt-0.5">Open Edit Household → Change Household Head to assign one. These households were not deleted.</p>
                                <div class="mt-3 flex flex-wrap gap-2">
                                    <?php foreach ($headlessHouseholds as $hl): ?>
                                        <a href="edit_household.php?sid=<?= (int) $hl['SurveyID'] ?>"
                                            class="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-white border border-amber-200 text-[11px] font-black text-amber-800 hover:bg-amber-100">
                                            <span class="font-mono"><?= htmlspecialchars((string) $hl['HouseholdID'], ENT_QUOTES, 'UTF-8') ?></span>
                                            <span class="font-semibold text-amber-700"><?= (int) $hl['MemberCount'] ?> member<?= (int) $hl['MemberCount'] === 1 ? '' : 's' ?></span>
                                            <span class="material-symbols-outlined text-sm">edit</span> Assign Head
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Search / Filter — same visual proportions as Resident Management -->
                <form method="GET" action="" id="filterForm" class="grid grid-cols-12 gap-4">
                    <div class="col-span-12 md:col-span-6 relative">
                        <span
                            class="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-xl">search</span>
                        <input type="text" name="search" id="searchInput"
                            value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>"
                            placeholder="Search by head or member name, contact, street, area, household ID..."
                            class="w-full pl-11 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm focus:outline-none focus:ring-4 focus:ring-indigo-500/5 focus:border-indigo-500 transition-all shadow-sm">
                    </div>
                    <div class="col-span-12 md:col-span-2">
                        <select name="income_class" id="incomeFilter"
                            class="w-full border-slate-200 rounded-2xl py-2.5 text-sm font-bold text-slate-600 focus:ring-indigo-500 transition-all shadow-sm">
                            <option value="">All Income</option>
                            <option value="low" <?= $incomeClass === 'low' ? 'selected' : '' ?>>Low Income</option>
                            <option value="mid" <?= $incomeClass === 'mid' ? 'selected' : '' ?>>Mid Income</option>
                            <option value="high" <?= $incomeClass === 'high' ? 'selected' : '' ?>>High Income</option>
                        </select>
                    </div>
                    <div class="col-span-12 md:col-span-2">
                        <select name="status" id="statusFilter"
                            class="w-full border-slate-200 rounded-2xl py-2.5 text-sm font-bold text-slate-600 focus:ring-indigo-500 transition-all shadow-sm">
                            <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= $statusFilter === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="col-span-12 md:col-span-2">
                        <button type="submit"
                            class="w-full px-5 py-2.5 bg-primary text-white rounded-2xl font-bold text-xs uppercase tracking-wider hover:opacity-90 transition-all shadow-md">
                            Search
                        </button>
                    </div>
                </form>

                <!-- Stats Cards — same Resident Management card styling -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
                        <div
                            class="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center mb-4">
                            <span class="material-symbols-outlined">home</span>
                        </div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Households</p>
                        <h3 class="text-2xl font-bold text-slate-800 mt-1"><?= number_format((int) $totalHH) ?></h3>
                    </div>

                    <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
                        <div
                            class="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center mb-4">
                            <span class="material-symbols-outlined">location_on</span>
                        </div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mapped</p>
                        <h3 class="text-2xl font-bold text-slate-800 mt-1"><?= number_format((int) $mapped) ?></h3>
                    </div>

                    <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
                        <div
                            class="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center mb-4">
                            <span class="material-symbols-outlined">payments</span>
                        </div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Low Income</p>
                        <h3 class="text-2xl font-bold text-slate-800 mt-1"><?= number_format((int) $low) ?></h3>
                        <p class="text-[10px] text-slate-400 font-semibold mt-1" title="Socioeconomic Status: Poor or Low Income (Not Poor)">By Socioeconomic Status (Low)</p>
                    </div>

                    <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
                        <div class="w-10 h-10 bg-sky-50 text-sky-600 rounded-xl flex items-center justify-center mb-4">
                            <span class="material-symbols-outlined">group</span>
                        </div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Avg. Members</p>
                        <h3 class="text-2xl font-bold text-slate-800 mt-1">
                            <?= htmlspecialchars((string) ($avg ?? '0'), ENT_QUOTES, 'UTF-8') ?></h3>
                    </div>
                </div>

                <!-- Map -->
                <div class="bg-white rounded-[32px] shadow-sm border border-slate-100 overflow-hidden">
                    <div
                        class="px-8 py-5 border-b border-slate-50 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                        <div>
                            <h3 class="font-bold text-slate-700">Household Locations</h3>
                            <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                                Uses the latitude/longitude already stored by the Resident Module.
                            </p>
                        </div>
                        <span
                            class="px-3 py-1 bg-indigo-50 text-indigo-700 text-[10px] font-black rounded-full uppercase border border-indigo-100">
                            <?= number_format((int) $mapped) ?> Mapped
                        </span>
                    </div>
                    <div class="p-4">
                        <div id="householdMap">
                            <div class="h-full flex items-center justify-center text-sm font-semibold text-slate-400">
                                Loading Google Maps...
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Household Table -->
                <div class="bg-white rounded-[32px] shadow-sm border border-slate-100 overflow-hidden">
                    <div
                        class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 px-8 py-5 border-b border-slate-50">
                        <div>
                            <h2 class="text-sm font-black text-slate-800 uppercase tracking-tight">Household Master List
                            </h2>
                            <p class="text-[10px] text-slate-400 font-bold mt-0.5">
                                Household records derived from CAPS Resident relationships.
                            </p>
                        </div>
                        <div class="flex items-center gap-2">
                            <button type="button" onclick="openMasterlistReport('print')"
                                class="flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 text-[10px] font-black uppercase text-slate-500 hover:border-indigo-300 hover:text-indigo-600 transition-all">
                                <span class="material-symbols-outlined text-sm">print</span> Print
                            </button>
                            <button type="button" onclick="openMasterlistReport('pdf')"
                                class="flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 text-[10px] font-black uppercase text-slate-500 hover:border-indigo-300 hover:text-indigo-600 transition-all">
                                <span class="material-symbols-outlined text-sm">picture_as_pdf</span> Save PDF
                            </button>
                        </div>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse" id="householdTable">
                            <thead>
                                <tr
                                    class="bg-slate-50/50 text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-50">
                                    <th class="px-8 py-5">Household ID</th>
                                    <th class="px-6 py-5">Household Head</th>
                                    <th class="px-6 py-5">Address</th>
                                    <th class="px-6 py-5">Members</th>
                                    <th class="px-6 py-5" title="Sum of the recorded monthly income of the Head and all household members">Combined Income</th>
                                    <th class="px-6 py-5" title="Income per member compared with the poverty threshold (same as View Household)">Socioeconomic Status</th>
                                    <th class="px-8 py-5 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-50 text-sm">
                                <?php foreach ($headlessRows ?? [] as $hl):
                                    $hlMembers = $hl['Members'] ?? [];
                                    $hlInc = (float) ($hl['CombinedIncome'] ?? 0);
                                    $hlBadge = $hlInc >= 50000 ? 'income-high' : ($hlInc >= 20000 ? 'income-mid' : 'income-low');
                                    $hlSes = hh_socioeconomic_status($hlInc, max(1, count($hlMembers)));
                                    $hlSesBadge = ['Low' => 'income-low', 'Middle' => 'income-mid', 'High' => 'income-high'][$hlSes['tier'] ?? 'Middle'];
                                    ?>
                                    <!-- Household without a Head (kept, never hidden): assign one through Edit Household -->
                                    <tr class="bg-amber-50/40 hover:bg-amber-50 transition-colors">
                                        <td class="px-8 py-5">
                                            <p class="text-[11px] font-black text-indigo-600 uppercase tracking-tight"><?= htmlspecialchars((string) $hl['HouseholdID'], ENT_QUOTES, 'UTF-8') ?></p>
                                            <p class="text-[9px] text-amber-600 font-black uppercase mt-0.5">No Head Assigned</p>
                                        </td>
                                        <td class="px-6 py-5">
                                            <div class="flex items-center gap-3">
                                                <div class="w-9 h-9 bg-amber-100 text-amber-700 rounded-xl flex items-center justify-center shrink-0">
                                                    <span class="material-symbols-outlined text-lg">person_off</span>
                                                </div>
                                                <div>
                                                    <p class="text-sm font-bold text-amber-800 leading-tight">No Head Assigned</p>
                                                    <p class="text-[10px] text-slate-500 font-semibold mt-0.5">
                                                        Members: <?= htmlspecialchars(implode(', ', array_column($hlMembers, 'full_name')) ?: '—', ENT_QUOTES, 'UTF-8') ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-5">
                                            <div class="text-xs font-semibold text-slate-700 max-w-[360px]"><?= htmlspecialchars((string) ($hl['address'] ?: 'No address'), ENT_QUOTES, 'UTF-8') ?></div>
                                        </td>
                                        <td class="px-6 py-5">
                                            <span class="px-2.5 py-0.5 bg-indigo-50 text-indigo-700 text-[10px] font-black rounded-full"><?= count($hlMembers) ?></span>
                                        </td>
                                        <td class="px-6 py-5">
                                            <span class="income-badge px-3 py-1 rounded-lg text-[10px] font-bold uppercase border <?= $hlBadge ?>">₱<?= number_format($hlInc, 2) ?></span>
                                            <p class="text-[9px] font-black uppercase tracking-wider text-slate-400 mt-1.5"><?= htmlspecialchars(hh_income_class($hlInc), ENT_QUOTES, 'UTF-8') ?></p>
                                        </td>
                                        <td class="px-6 py-5">
                                            <span class="income-badge px-3 py-1 rounded-lg text-[10px] font-bold uppercase border <?= $hlSesBadge ?>"><?= htmlspecialchars($hlSes['label'] ?? '—', ENT_QUOTES, 'UTF-8') ?></span>
                                        </td>
                                        <td class="px-8 py-5 text-right">
                                            <div class="flex justify-end gap-1">
                                                <a href="view_household.php?sid=<?= (int) $hl['SurveyID'] ?>"
                                                    class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider text-indigo-600 bg-indigo-50 hover:bg-indigo-100 transition-all" title="View Household">
                                                    <span class="material-symbols-outlined text-base">visibility</span> View
                                                </a>
                                                <a href="edit_household.php?sid=<?= (int) $hl['SurveyID'] ?>"
                                                    class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider text-amber-700 bg-amber-100 hover:bg-amber-200 transition-all" title="Assign a Household Head">
                                                    <span class="material-symbols-outlined text-base">person_add</span> Assign Head
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (!$households && empty($headlessRows)): ?>
                                    <tr>
                                        <td colspan="7"class="text-center py-16 text-slate-400">
                                            <span
                                                class="material-symbols-outlined text-4xl block mb-2 text-slate-200">manage_search</span>
                                            No household records found.
                                        </td>
                                    </tr>
                                <?php else:
                                    foreach ($households as $h):
                                        $name = trim(implode(' ', array_filter([
                                            $h['FirstName'] ?? '',
                                            $h['MiddleName'] ?? '',
                                            $h['LastName'] ?? '',
                                            $h['Suffix'] ?? ''
                                        ])));
                                        $addr = implode(', ', array_filter([
                                            $h['HouseNumber'] ?? '',
                                            $h['BuildingName'] ?? '',
                                            $h['StreetName'] ?? '',
                                            $h['AreaName'] ?? '',
                                            $h['Purok'] ?? '',
                                            $h['BarangayName'] ?? ''
                                        ]));
                                        $isInactiveRow = strtolower((string) ($h['status'] ?? 'active')) === 'inactive';
                                        if ($isInactiveRow) {
                                            // Address/head as recorded on the inactive household.
                                            $addr = (string) ($h['HouseholdAddress'] ?? $addr);
                                            if ($name === '') $name = (string) ($h['head_name'] ?? '');
                                        }
                                        $viewUrl = !empty($h['SurveyID'])
                                            ? 'view_household.php?sid=' . (int) $h['SurveyID']
                                            : 'view_household.php?id=' . (int) $h['ResidentID'];
                                        // Combined Income = Head + all living members' recorded income.
                                        $inc = (float) ($h['CombinedIncome'] ?? $h['TotalHouseholdIncome'] ?? 0);
                                        if ($inc >= 50000) {
                                            $badge = 'income-high';
                                        } elseif ($inc >= 20000) {
                                            $badge = 'income-mid';
                                        } else {
                                            $badge = 'income-low';
                                        }
                                        // Same Income Status as View Household (hh_income_class on the combined income).
                                        $incLabel = hh_income_class($inc);
                                        $rowSes = hh_socioeconomic_status($inc, ((int) ($h['MemberCount'] ?? 0)) + 1);
                                        $sesBadge = ['Low' => 'income-low', 'Middle' => 'income-mid', 'High' => 'income-high'][$rowSes['tier'] ?? 'Middle'];
                                        $initials = strtoupper(
                                            substr((string) ($h['FirstName'] ?? ''), 0, 1) .
                                            substr((string) ($h['LastName'] ?? ''), 0, 1)
                                        );
                                        ?>
                                        <tr class="hover:bg-slate-50/50 transition-colors group">
                                            <td class="px-8 py-5">
                                                <p class="text-[11px] font-black text-indigo-600 uppercase tracking-tight">
                                                    <?= htmlspecialchars((string) $h['HouseholdID'], ENT_QUOTES, 'UTF-8') ?>
                                                </p>
                                                <p class="text-[9px] text-slate-400 font-bold mt-0.5">
                                                    Resident #<?= (int) $h['ResidentID'] ?>
                                                </p>
                                                <?php if ($isInactiveRow): ?>
                                                    <p class="text-[9px] text-rose-500 font-black uppercase mt-0.5">
                                                        Inactive<?= !empty($h['inactive_since']) ? ' since ' . htmlspecialchars(date('M j, Y', strtotime((string) $h['inactive_since'])), ENT_QUOTES, 'UTF-8') : '' ?>
                                                    </p>
                                                <?php endif; ?>
                                            </td>

                                            <td class="px-6 py-5">
                                                <div class="flex items-center gap-3">
                                                    <?php if (resident_photo_url($h['ProfilePhoto'] ?? null)): ?>
                                                        <?= resident_avatar_html($h, 'w-9 h-9 bg-slate-100 text-slate-500 rounded-xl flex items-center justify-center font-bold text-[10px] shrink-0') ?>
                                                    <?php else: ?>
                                                    <div
                                                        class="w-9 h-9 bg-slate-100 text-slate-500 rounded-xl flex items-center justify-center font-bold text-[10px] shrink-0">
                                                        <?= htmlspecialchars($initials ?: 'HH', ENT_QUOTES, 'UTF-8') ?>
                                                    </div>
                                                    <?php endif; ?>
                                                    <div>
                                                        <p class="text-sm font-bold text-slate-700 leading-tight">
                                                            <?= htmlspecialchars($name ?: 'Unknown Head', ENT_QUOTES, 'UTF-8') ?>
                                                        </p>
                                                        <p
                                                            class="text-[10px] text-slate-400 font-bold uppercase tracking-tighter mt-0.5">
                                                            <?= htmlspecialchars((string) ($h['Sex'] ?? '—'), ENT_QUOTES, 'UTF-8') ?>
                                                            ·
                                                            <?= !empty($h['ContactNumber']) ? htmlspecialchars((string) $h['ContactNumber'], ENT_QUOTES, 'UTF-8') : 'No contact' ?>
                                                        </p>
                                                        <?php if (!empty($h['MatchedMembers'])): ?>
                                                            <p class="text-[10px] text-indigo-500 font-bold mt-1">
                                                                Matched member: <?= htmlspecialchars((string) $h['MatchedMembers'], ENT_QUOTES, 'UTF-8') ?>
                                                            </p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>

                                            <td class="px-6 py-5">
                                                <div class="text-xs font-semibold text-slate-700 max-w-[360px]">
                                                    <?= htmlspecialchars($addr ?: 'No address', ENT_QUOTES, 'UTF-8') ?>
                                                </div>
                                            </td>

                                            <td class="px-6 py-5">
                                                <span
                                                    class="px-2.5 py-0.5 bg-indigo-50 text-indigo-700 text-[10px] font-black rounded-full">
                                                    <?= ((int) ($h['MemberCount'] ?? 0)) + 1 ?>
                                                </span>
                                            </td>

                                            <td class="px-6 py-5">
                                                <span
                                                    class="income-badge px-3 py-1 rounded-lg text-[10px] font-bold uppercase border <?= $badge ?>">
                                                    ₱<?= number_format($inc, 2) ?>
                                                </span>
                                                <p class="text-[9px] font-black uppercase tracking-wider text-slate-400 mt-1.5">
                                                    <?= htmlspecialchars($incLabel, ENT_QUOTES, 'UTF-8') ?></p>
                                            </td>

                                            <td class="px-6 py-5">
                                                <span class="income-badge px-3 py-1 rounded-lg text-[10px] font-bold uppercase border <?= $sesBadge ?>"
                                                    title="<?= htmlspecialchars(($rowSes['range'] ?? '') . ' · ₱' . number_format((float) ($rowSes['per_capita'] ?? 0), 2) . ' per member', ENT_QUOTES, 'UTF-8') ?>">
                                                    <?= htmlspecialchars($rowSes['label'] ?? '—', ENT_QUOTES, 'UTF-8') ?>
                                                </span>
                                                <p class="text-[9px] font-black uppercase tracking-wider text-slate-400 mt-1.5"><?= htmlspecialchars(($rowSes['tier'] ?? '') . ' group', ENT_QUOTES, 'UTF-8') ?></p>
                                            </td>

                                            <td class="px-8 py-5 text-right">
                                                <div class="flex justify-end">
                                                    <a href="<?= htmlspecialchars($viewUrl, ENT_QUOTES, 'UTF-8') ?>"
                                                        class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider text-indigo-600 bg-indigo-50 hover:bg-indigo-100 transition-all"
                                                        title="View Household">
                                                        <span class="material-symbols-outlined text-base">visibility</span>
                                                        View
                                                    </a>
                                                    <?php if (!$isInactiveRow && empty($h['is_removed']) && !empty($h['SurveyID'])): ?>
                                                        <button type="button"
                                                            onclick="openMoveHousehold(<?= (int) $h['SurveyID'] ?>, <?= htmlspecialchars(json_encode($name), ENT_QUOTES, 'UTF-8') ?>)"
                                                            class="inline-flex items-center justify-center w-9 h-9 rounded-xl text-amber-700 bg-amber-50 hover:bg-amber-100 transition-all ml-1"
                                                            title="Move to Another Barangay">
                                                            <span class="material-symbols-outlined text-base">move_up</span>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if ($totalPages > 1): ?>
                        <div
                            class="flex flex-col sm:flex-row items-center justify-between gap-3 px-8 py-4 border-t border-slate-50">
                            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                Page <strong class="text-slate-600"><?= (int) $page ?></strong>
                                of <strong class="text-slate-600"><?= (int) $totalPages ?></strong>
                            </p>
                            <nav class="flex items-center gap-1">
                                <?php if ($page > 1): ?>
                                    <a href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&income_class=<?= urlencode($incomeClass) ?>&status=<?= urlencode($statusFilter) ?>"
                                        class="flex items-center gap-1 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider text-slate-500 bg-white border border-slate-200 hover:border-indigo-300 hover:text-indigo-600">
                                        <span class="material-symbols-outlined text-sm">chevron_left</span> Prev
                                    </a>
                                <?php endif; ?>

                                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                                    <a href="?page=<?= $p ?>&search=<?= urlencode($search) ?>&income_class=<?= urlencode($incomeClass) ?>&status=<?= urlencode($statusFilter) ?>"
                                        class="px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all <?= $p === $page ? 'bg-primary text-white shadow-md' : 'text-slate-500 bg-white border border-slate-200 hover:border-indigo-300 hover:text-indigo-600' ?>">
                                        <?= $p ?>
                                    </a>
                                <?php endfor; ?>

                                <?php if ($page < $totalPages): ?>
                                    <a href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&income_class=<?= urlencode($incomeClass) ?>&status=<?= urlencode($statusFilter) ?>"
                                        class="flex items-center gap-1 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider text-slate-500 bg-white border border-slate-200 hover:border-indigo-300 hover:text-indigo-600">
                                        Next <span class="material-symbols-outlined text-sm">chevron_right</span>
                                    </a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>
                </div>

            </main>
        </div>
    </div>

    <!-- Household Details Modal -->
    <div id="modal" class="fixed inset-0 hidden items-center justify-center p-4 bg-slate-900/80 z-[9999]">
        <div class="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-auto p-8 md:p-10">
            <div class="flex justify-between gap-4 border-b border-slate-100 pb-5">
                <div>
                    <p class="text-[10px] font-black uppercase tracking-widest text-slate-400">Household Details</p>
                    <h2 id="mTitle" class="text-2xl font-black text-slate-900 tracking-tight mt-1">Loading...</h2>
                </div>
                <button type="button" onclick="closeModal()"
                    class="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors">
                    <span class="material-symbols-outlined">close</span>
                </button>
            </div>
            <div id="mBody" class="mt-6"></div>
        </div>
    </div>

    <script>
        window.__capsHouseholdMapsReady = false;
        let hmap = null, bounds = null;
        const markerRefs = [];

        async function loadLocations() {
            const r = await fetch('../backend/households.php?action=locations', { headers: { 'Accept': 'application/json' } });
            if (!r.ok) throw new Error('Unable to load household locations.');
            return await r.json();
        }

        window.renderHouseholdMap = async function () {
            const el = document.getElementById('householdMap');
            if (!el) return;
            try {
                const data = await loadLocations();
                const points = (data || []).map(x => ({ x, lat: Number(x.Latitude), lng: Number(x.Longitude) }))
                    .filter(p => Number.isFinite(p.lat) && Number.isFinite(p.lng) && p.lat !== 0 && p.lng !== 0);

                <?php if ($googleKey): ?>
                    if (!window.google || !google.maps) {
                        el.innerHTML = '<div class="h-full flex items-center justify-center text-sm font-semibold text-rose-400">Google Maps failed to load. Check the Google Maps API key.</div>';
                        return;
                    }
                    hmap = new google.maps.Map(el, { center: { lat: 14.7935, lng: 120.9247 }, zoom: 13, mapTypeControl: true, mapTypeControlOptions: { mapTypeIds: ['roadmap', 'satellite'] }, streetViewControl: false, fullscreenControl: true });
                    bounds = new google.maps.LatLngBounds();
                    points.forEach(function (p) {
                        const marker = new google.maps.Marker({ map: hmap, position: { lat: p.lat, lng: p.lng }, title: (p.x.FirstName || '') + ' ' + (p.x.LastName || '') });
                        marker.addListener('click', function () { viewHousehold(Number(p.x.ResidentID)); });
                        markerRefs.push(marker); bounds.extend({ lat: p.lat, lng: p.lng });
                    });
                    if (points.length) hmap.fitBounds(bounds);
                    else hmap.setZoom(13);
                <?php else: ?>
                    if (!window.L) {
                        el.innerHTML = '<div class="h-full flex items-center justify-center text-sm font-semibold text-rose-400">Map library failed to load.</div>';
                        return;
                    }
                    if (hmap) hmap.remove();
                    hmap = L.map(el, { zoomControl: true });
                    const street = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(hmap);
                    const satellite = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: 'Tiles © Esri' });
                    L.control.layers({ 'Map View': street, 'Satellite View': satellite }, null, { position: 'topright' }).addTo(hmap);
                    if (points.length) {
                        const group = L.featureGroup();
                        points.forEach(function (p) { L.marker([p.lat, p.lng]).bindTooltip((p.x.FirstName || '') + ' ' + (p.x.LastName || '')).on('click', function () { viewHousehold(Number(p.x.ResidentID)); }).addTo(group); });
                        group.addTo(hmap); hmap.fitBounds(group.getBounds().pad(0.15));
                    } else { hmap.setView([14.7935, 120.9247], 13); }
                <?php endif; ?>
            } catch (e) {
                console.error(e);
                el.innerHTML = '<div class="h-full flex flex-col items-center justify-center text-sm font-semibold text-rose-400 gap-1"><span>Unable to load household map.</span><small>' + String(e.message || e) + '</small></div>';
            }
        };

        async function viewHousehold(id) {
            const modal = document.getElementById('modal');
            const title = document.getElementById('mTitle');
            const body = document.getElementById('mBody');

            modal.classList.remove('hidden');
            modal.classList.add('flex');
            body.innerHTML = '<div class="py-12 text-center text-slate-400">Loading...</div>';

            try {
                const r = await fetch('../backend/fetch_family.php?head_id=' + encodeURIComponent(id));
                const d = await r.json();

                if (!d.success) {
                    body.innerHTML = '<div class="text-rose-600 font-bold">Unable to load household.</div>';
                    return;
                }

                title.textContent = (d.head.FirstName || '') + ' ' + (d.head.LastName || '');
                const members = [d.head].concat(d.members || []);

                body.innerHTML = `
            <div class="grid md:grid-cols-4 gap-3">
                ${stat('Household ID', d.household_id)}
                ${stat('Members', members.length)}
                ${stat('Combined Income', '₱' + members.reduce((s, m) => s + Number(m.TotalHouseholdIncome || 0), 0).toLocaleString('en-PH', { minimumFractionDigits: 2 }))}
                ${stat('GPS', (d.head.Latitude && d.head.Longitude) ? Number(d.head.Latitude).toFixed(6) + ', ' + Number(d.head.Longitude).toFixed(6) : 'Not set')}
            </div>

            <div class="mt-6 grid md:grid-cols-2 gap-6">
                <div>
                    <h3 class="font-black text-slate-800 mb-2">Address</h3>
                    <p class="text-sm text-slate-500">${esc([
                    d.head.HouseNumber, d.head.BuildingName, d.head.StreetName, d.head.AreaName,
                    d.head.Purok, d.head.BarangayName, d.head.CityMunicipalityName,
                    d.head.ProvinceName, d.head.RegionName, d.head.ZipCode
                ].filter(Boolean).join(', ') || 'No address')}</p>
                </div>
                <div>
                    <h3 class="font-black text-slate-800 mb-2">Household Head</h3>
                    <p class="text-sm text-slate-500">${esc(d.head.Sex || '—')} · ${esc(d.head.CivilStatus || '—')} · ${esc(d.head.ContactNumber || '—')}</p>
                </div>
            </div>

            <div class="mt-7 overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="text-left text-[10px] uppercase tracking-widest text-slate-400 border-b border-slate-100">
                            <th class="p-3">Resident</th>
                            <th class="p-3">Relationship</th>
                            <th class="p-3">Sex</th>
                            <th class="p-3">Age</th>
                            <th class="p-3">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${members.map(function (x, i) {
                    return `
                            <tr class="border-t border-slate-100">
                                <td class="p-3 font-bold text-slate-700">${esc([x.FirstName, x.MiddleName, x.LastName, x.Suffix].filter(Boolean).join(' '))}</td>
                                <td class="p-3 text-slate-600">${i === 0 ? 'Head' : esc(x.RelationshipToHead || 'Member')}</td>
                                <td class="p-3 text-slate-600">${esc(x.Sex || '—')}</td>
                                <td class="p-3 text-slate-600">${x.BirthDate ? age(x.BirthDate) : '—'}</td>
                                <td class="p-3 text-slate-600">${x.IsPWD ? 'PWD ' : ''}${x.IsSenior ? 'Senior' : ''}</td>
                            </tr>
                        `}).join('')}
                    </tbody>
                </table>
            </div>

            <div class="mt-6 flex justify-end">
                <a class="px-5 py-3 rounded-xl bg-primary text-white text-xs font-black uppercase tracking-wider shadow-md hover:opacity-90"
                   href="${d.survey && d.survey.SurveyID ? 'view_household.php?sid=' + encodeURIComponent(d.survey.SurveyID) : 'view_household.php?id=' + encodeURIComponent(id)}">View Full Details</a>
            </div>`;
            } catch (e) {
                console.error(e);
                body.innerHTML = '<div class="text-rose-600 font-bold">Unable to load household.</div>';
            }
        }

        function stat(label, value) {
            return `<div class="p-4 rounded-2xl bg-slate-50 border border-slate-100">
        <div class="text-[10px] font-black uppercase tracking-widest text-slate-400">${esc(label)}</div>
        <div class="font-black text-slate-800 mt-1">${esc(String(value ?? '—'))}</div>
    </div>`;
        }
        function age(value) {
            const birth = new Date(value);
            if (Number.isNaN(birth.getTime())) return '—';
            return Math.floor((Date.now() - birth.getTime()) / 31557600000);
        }
        function esc(value) {
            const d = document.createElement('div');
            d.textContent = value ?? '';
            return d.innerHTML;
        }
        function closeModal() {
            const modal = document.getElementById('modal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
        document.addEventListener('DOMContentLoaded', function () {
            if (window.__capsHouseholdMapsReady) window.renderHouseholdMap();
        });
    </script>

    <!-- Move Household to another barangay: 1 destination → 2 members → 3 summary/confirm -->
    <div id="moveHouseholdModal"
        class="hidden fixed inset-0 z-[100] bg-slate-950/50 backdrop-blur-sm items-center justify-center p-4">
        <div class="w-full max-w-xl rounded-3xl bg-white shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
            <div class="p-6 border-b border-slate-100 flex items-center justify-between">
                <div>
                    <h3 class="font-black text-slate-800">Move to Another Barangay</h3>
                    <p id="moveHouseholdName" class="text-xs text-slate-400 mt-1"></p>
                </div><button type="button" onclick="closeMoveHousehold()"
                    class="w-9 h-9 rounded-xl bg-slate-100 text-slate-500">×</button>
            </div>
            <div class="px-6 pt-4 flex gap-2 text-[10px] font-black uppercase tracking-widest">
                <span data-move-tab="1" class="flex-1 text-center py-2 rounded-xl">1 · Destination</span>
                <span data-move-tab="2" class="flex-1 text-center py-2 rounded-xl">2 · Members</span>
                <span data-move-tab="3" class="flex-1 text-center py-2 rounded-xl">3 · Confirm</span>
            </div>
            <div class="p-6 space-y-4 overflow-y-auto">
                <div id="moveStep1" class="space-y-3">
                    <p class="text-xs text-slate-500 font-semibold">Select the barangay the residents are moving to. For a move inside this barangay, use <b>Change Address</b> in Edit Household.</p>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                        <label class="block"><span class="text-[10px] font-black uppercase tracking-widest text-slate-400">Region</span>
                            <select id="mv_region" class="mt-1 w-full rounded-xl border-slate-200 text-sm"><option value="">Select region</option></select></label>
                        <label class="block"><span class="text-[10px] font-black uppercase tracking-widest text-slate-400">Province</span>
                            <select id="mv_province" class="mt-1 w-full rounded-xl border-slate-200 text-sm" disabled><option value="">Select province</option></select></label>
                        <label class="block"><span class="text-[10px] font-black uppercase tracking-widest text-slate-400">City / Municipality</span>
                            <select id="mv_municipality" class="mt-1 w-full rounded-xl border-slate-200 text-sm" disabled><option value="">Select city/municipality</option></select></label>
                        <label class="block"><span class="text-[10px] font-black uppercase tracking-widest text-slate-400">Barangay</span>
                            <select id="mv_barangay" class="mt-1 w-full rounded-xl border-slate-200 text-sm" disabled><option value="">Select barangay</option></select></label>
                        <label class="block"><span class="text-[10px] font-black uppercase tracking-widest text-slate-400">ZIP Code</span>
                            <input id="mv_zip" maxlength="10" class="mt-1 w-full rounded-xl border-slate-200 text-sm" placeholder="Auto-filled"></label>
                        <label class="block sm:col-span-2"><span class="text-[10px] font-black uppercase tracking-widest text-slate-400">House No. / Street / Subdivision (new address, optional)</span>
                            <input id="mv_address_line" maxlength="300" class="mt-1 w-full rounded-xl border-slate-200 text-sm" placeholder="e.g. 12 Mabini St., Villa Rosa Subd."></label>
                    </div>
                    <p id="mv_zip_note" class="text-[11px] text-slate-400"></p>
                </div>
                <div id="moveStep2" class="hidden space-y-3">
                    <p class="text-xs text-slate-500 font-semibold">Select who is moving. Unselected members stay in this household.</p>
                    <label class="flex items-center gap-2 text-xs font-black text-indigo-600"><input type="checkbox" id="mv_all" class="rounded"> Whole household</label>
                    <div id="mv_members" class="divide-y divide-slate-100 rounded-2xl border border-slate-100"></div>
                    <div id="mv_newhead_box" class="hidden rounded-2xl bg-amber-50 border border-amber-100 p-4 space-y-2">
                        <p class="text-xs font-bold text-amber-800">The Household Head is moving while other members stay. Choose the new Household Head.</p>
                        <select id="mv_newhead" class="w-full rounded-xl border-amber-200 text-sm"></select>
                    </div>
                </div>
                <div id="moveStep3" class="hidden space-y-3">
                    <div id="mv_summary" class="rounded-2xl bg-slate-50 border border-slate-100 p-4 text-sm text-slate-700 space-y-2"></div>
                    <div class="rounded-2xl bg-rose-50 border border-rose-100 p-4 text-xs text-rose-700 font-semibold">
                        The selected residents will be marked <b>Relocated</b> and removed from the active population and household membership. Their Resident IDs, records and history are kept. Their app sessions will be signed out.</div>
                </div>
                <p id="mv_error" class="hidden text-xs font-bold text-rose-600"></p>
            </div>
            <div class="p-6 border-t border-slate-100 flex justify-between gap-2">
                <button type="button" id="mv_back" onclick="moveGo(-1)" class="px-4 py-3 rounded-xl bg-slate-100 text-slate-600 text-xs font-black">Back</button>
                <div class="flex gap-2"><button type="button" onclick="closeMoveHousehold()"
                        class="px-4 py-3 rounded-xl bg-slate-100 text-slate-600 text-xs font-black">Cancel</button><button type="button"
                        id="mv_next" onclick="moveGo(1)"
                        class="px-5 py-3 rounded-xl bg-indigo-600 text-white text-xs font-black">Next</button></div>
            </div>
        </div>
    </div>
    <script>
        (function () {
            const PSGC = '../../residents/backend/psgc_proxy.php', ADDR = '../../residents/backend/address_api.php';
            const $ = id => document.getElementById(id);
            const fixText = v => { let s = String(v ?? ''); if (/[ÃÂâ]/.test(s)) { try { const r = decodeURIComponent(escape(s)); if (r && !/[ÃÂâ]/.test(r)) return r; } catch (e) { } } return s; };
            const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
            let mv = { sid: 0, step: 1, data: null, current: '' };

            async function psgc(action, params) {
                const r = await fetch(PSGC + '?action=' + action + (params ? '&' + new URLSearchParams(params) : ''), { credentials: 'same-origin' });
                const j = await r.json(); if (!j.success) throw new Error(j.message || 'Unable to load the address list.'); return j.data || [];
            }
            function fill(id, rows, ph) {
                const el = $(id); el.innerHTML = '<option value="">' + ph + '</option>';
                rows.forEach(x => { const o = document.createElement('option'); o.value = x.code; o.textContent = fixText(x.name); el.appendChild(o); });
                el.disabled = rows.length === 0;
            }
            function clear(ids) { ids.forEach(([id, ph]) => { const el = $(id); el.innerHTML = '<option value="">' + ph + '</option>'; el.disabled = true; }); }
            async function lookupZip() {
                const m = $('mv_municipality'), note = $('mv_zip_note'); $('mv_zip').value = ''; note.textContent = '';
                if (!m.value) return;
                try {
                    const q = new URLSearchParams({ action: 'zip', municipality: m.value, name: m.selectedOptions[0]?.textContent || '' });
                    const j = await (await fetch(ADDR + '?' + q, { credentials: 'same-origin' })).json();
                    if (j.zip_code) { $('mv_zip').value = j.zip_code; note.textContent = 'ZIP filled automatically.'; }
                    else note.textContent = 'No ZIP code on file for this city/municipality — you may type it.';
                } catch (e) { note.textContent = 'ZIP lookup is unavailable — you may type the ZIP code.'; }
            }
            $('mv_region').addEventListener('change', async e => {
                clear([['mv_province', 'Select province'], ['mv_municipality', 'Select city/municipality'], ['mv_barangay', 'Select barangay']]); $('mv_zip').value = '';
                if (e.target.value) try { fill('mv_province', await psgc('provinces', { reg: e.target.value }), 'Select province'); } catch (err) { showErr(err.message); }
            });
            $('mv_province').addEventListener('change', async e => {
                clear([['mv_municipality', 'Select city/municipality'], ['mv_barangay', 'Select barangay']]); $('mv_zip').value = '';
                if (e.target.value) try { fill('mv_municipality', await psgc('municipalities', { prv: e.target.value }), 'Select city/municipality'); } catch (err) { showErr(err.message); }
            });
            $('mv_municipality').addEventListener('change', async e => {
                clear([['mv_barangay', 'Select barangay']]);
                if (e.target.value) try { fill('mv_barangay', await psgc('barangays', { prv: $('mv_province').value, mun: e.target.value }), 'Select barangay'); } catch (err) { showErr(err.message); }
                lookupZip();
            });

            function showErr(msg) { const e = $('mv_error'); e.textContent = msg || ''; e.classList.toggle('hidden', !msg); }
            function selectedIds() { return [...document.querySelectorAll('.mv-member:checked')].map(c => +c.value); }
            function syncMembers() {
                const all = [...document.querySelectorAll('.mv-member')], ids = selectedIds(), d = mv.data;
                $('mv_all').checked = all.length > 0 && ids.length === all.length;
                const headMoves = ids.includes(d.head_id), staying = d.members.filter(m => !ids.includes(m.id));
                const box = $('mv_newhead_box'), sel = $('mv_newhead'), keep = sel.value;
                box.classList.toggle('hidden', !(headMoves && staying.length));
                sel.innerHTML = '<option value="">Select new Household Head</option>' + staying.map(m => '<option value="' + m.id + '">' + esc(m.name) + ' (' + esc(m.relationship) + ')</option>').join('');
                if (staying.some(m => String(m.id) === keep)) sel.value = keep;
            }
            function renderStep() {
                [1, 2, 3].forEach(n => {
                    $('moveStep' + n).classList.toggle('hidden', mv.step !== n);
                    const t = document.querySelector('[data-move-tab="' + n + '"]');
                    t.className = 'flex-1 text-center py-2 rounded-xl ' + (mv.step === n ? 'bg-indigo-600 text-white' : (mv.step > n ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-50 text-slate-400'));
                });
                $('mv_back').classList.toggle('invisible', mv.step === 1);
                $('mv_next').textContent = mv.step === 3 ? 'Confirm Move' : 'Next';
                $('mv_next').className = 'px-5 py-3 rounded-xl text-white text-xs font-black ' + (mv.step === 3 ? 'bg-rose-600' : 'bg-indigo-600');
            }
            function destination() {
                const t = id => $(id).value ? ($(id).selectedOptions[0]?.textContent || '') : '';
                return {
                    region_code: $('mv_region').value, province_code: $('mv_province').value, municipality_code: $('mv_municipality').value, barangay_code: $('mv_barangay').value,
                    region_name: t('mv_region'), province_name: t('mv_province'), municipality_name: t('mv_municipality'), barangay_name: t('mv_barangay'), zip_code: $('mv_zip').value.trim(),
                    address_line: ($('mv_address_line')?.value || '').trim()
                };
            }
            let busy = false;
            window.moveGo = async function (dir) {
                if (busy) return; showErr('');
                if (dir < 0) { mv.step = Math.max(1, mv.step - 1); return renderStep(); }
                if (mv.step === 1) {
                    const d = destination();
                    if (!d.region_code || !d.province_code || !d.municipality_code || !d.barangay_code) return showErr('Select the Region, Province, City/Municipality and Barangay.');
                    if (mv.data && d.barangay_code === mv.data.current_barangay_code) return showErr('That is this same barangay. Use Change Address in Edit Household for a move within the barangay.');
                    mv.step = 2; return renderStep();
                }
                if (mv.step === 2) {
                    const ids = selectedIds(); if (!ids.length) return showErr('Select at least one member who is moving.');
                    const d = mv.data, staying = d.members.filter(m => !ids.includes(m.id)), headMoves = ids.includes(d.head_id);
                    if (headMoves && staying.length && !$('mv_newhead').value) return showErr('Choose the new Household Head from the members who stay.');
                    const dest = destination(), nh = staying.find(m => String(m.id) === $('mv_newhead').value);
                    const movers = d.members.filter(m => ids.includes(m.id));
                    $('mv_summary').innerHTML =
                        '<div><span class="text-[10px] font-black uppercase tracking-widest text-slate-400">Household</span><div class="font-bold">' + esc(d.household_id) + '</div><div class="text-xs text-slate-500">' + esc(d.address) + '</div></div>' +
                        '<div><span class="text-[10px] font-black uppercase tracking-widest text-slate-400">Moving to</span><div class="font-bold">' + esc([dest.address_line, dest.barangay_name, dest.municipality_name, dest.province_name, dest.region_name].filter(Boolean).join(', ')) + (dest.zip_code ? ' ' + esc(dest.zip_code) : '') + '</div></div>' +
                        '<div><span class="text-[10px] font-black uppercase tracking-widest text-slate-400">Moving (' + movers.length + ')</span><ul class="list-disc ml-5">' + movers.map(m => '<li>' + esc(m.name) + ' <span class="text-xs text-slate-400">' + esc(m.relationship) + '</span></li>').join('') + '</ul></div>' +
                        (staying.length ? '<div><span class="text-[10px] font-black uppercase tracking-widest text-slate-400">Staying (' + staying.length + ')</span><div class="text-xs">' + staying.map(m => esc(m.name)).join(', ') + '</div>' + (nh ? '<div class="text-xs mt-1">New Household Head: <b>' + esc(nh.name) + '</b></div>' : '') + '<div class="text-xs text-emerald-700 font-bold mt-1">The household stays Active.</div></div>'
                            : '<div class="text-xs text-rose-700 font-bold">All members are moving: this household becomes Relocated / Inactive.</div>');
                    mv.step = 3; return renderStep();
                }
                // Step 3: confirm
                const fd = new FormData(), dest = destination();
                fd.append('csrf_token', <?= json_encode($csrf) ?>); fd.append('action', 'move_household'); fd.append('survey_id', mv.sid);
                Object.entries(dest).forEach(([k, v]) => fd.append(k, v));
                selectedIds().forEach(id => fd.append('move_ids[]', id));
                if (!$('mv_newhead_box').classList.contains('hidden')) fd.append('new_head_id', $('mv_newhead').value);
                busy = true; $('mv_next').disabled = true; $('mv_next').textContent = 'Moving…';
                try {
                    const j = await (await fetch('../backend/household_actions.php', { method: 'POST', body: fd, credentials: 'same-origin' })).json();
                    if (!j.success) throw new Error(j.error || 'Unable to move the household.');
                    alert(j.moved + ' resident(s) moved to ' + j.destination + '.' + (j.household_status === 'inactive' ? ' The household is now Relocated / Inactive.' : ' The household stays Active.' + (j.new_head ? ' New Household Head: ' + j.new_head + '.' : '')));
                    location.reload();
                } catch (e) { showErr(e.message); busy = false; $('mv_next').disabled = false; renderStep(); }
            };
            window.openMoveHousehold = async function (sid, name) {
                mv = { sid, step: 1, data: null }; busy = false; showErr('');
                $('moveHouseholdName').textContent = name; $('mv_members').innerHTML = '<p class="p-4 text-xs text-slate-400">Loading members…</p>';
                $('mv_zip').value = ''; if ($('mv_address_line')) $('mv_address_line').value = ''; $('mv_zip_note').textContent = ''; $('mv_newhead_box').classList.add('hidden');
                clear([['mv_province', 'Select province'], ['mv_municipality', 'Select city/municipality'], ['mv_barangay', 'Select barangay']]);
                const m = $('moveHouseholdModal'); m.classList.remove('hidden'); m.classList.add('flex'); renderStep();
                try { if ($('mv_region').options.length <= 1) fill('mv_region', await psgc('regions'), 'Select region'); else $('mv_region').value = ''; } catch (e) { showErr(e.message); }
                try {
                    const fd = new FormData(); fd.append('csrf_token', <?= json_encode($csrf) ?>); fd.append('action', 'move_preview'); fd.append('survey_id', sid);
                    const j = await (await fetch('../backend/household_actions.php', { method: 'POST', body: fd, credentials: 'same-origin' })).json();
                    if (!j.success) throw new Error(j.error || 'Unable to load the household members.');
                    mv.data = j;
                    $('mv_members').innerHTML = j.members.map(x => '<label class="flex items-center gap-3 p-3 text-sm"><input type="checkbox" class="mv-member rounded" value="' + x.id + '"><span class="flex-1"><b>' + esc(x.name) + '</b><span class="block text-xs text-slate-400">' + esc(x.relationship) + (x.age !== null ? ' · ' + x.age + ' yrs' : '') + '</span></span>' + (x.is_head ? '<span class="text-[10px] font-black uppercase text-indigo-600">Head</span>' : '') + '</label>').join('');
                    document.querySelectorAll('.mv-member').forEach(c => c.addEventListener('change', syncMembers));
                    syncMembers();
                } catch (e) { $('mv_members').innerHTML = ''; showErr(e.message); }
            };
            $('mv_all').addEventListener('change', e => { document.querySelectorAll('.mv-member').forEach(c => c.checked = e.target.checked); syncMembers(); });
            window.closeMoveHousehold = function () { const m = $('moveHouseholdModal'); m.classList.add('hidden'); m.classList.remove('flex'); };
        })();
    </script>

    <!-- Masterlist Save PDF / Print: Socioeconomic Status filter -->
    <div id="mlReportModal" class="fixed inset-0 z-[999] hidden bg-slate-900/70 items-center justify-center p-4" onclick="if (event.target === this) closeMasterlistReport()">
        <div class="bg-white rounded-[2rem] shadow-2xl w-full max-w-md p-8" role="dialog" aria-modal="true" aria-labelledby="mlTitle">
            <div class="flex items-start justify-between gap-4">
                <div>
                    <h3 id="mlTitle" class="text-2xl font-black text-slate-900 tracking-tight">Save as PDF</h3>
                    <p class="text-[11px] font-black text-indigo-600 uppercase tracking-widest mt-1">Household Masterlist</p>
                </div>
                <button type="button" onclick="closeMasterlistReport()" class="p-1 text-slate-400 hover:text-slate-700" aria-label="Close">
                    <span class="material-symbols-outlined">close</span></button>
            </div>
            <p class="text-sm font-bold text-slate-700 mt-6 mb-1">Socioeconomic Status</p>
            <p class="text-[11px] font-semibold text-slate-400 mb-3">Choose one or more. Low = Poor / Low Income (Not Poor) · Middle = Lower Middle / Middle / Upper Middle · High = Upper Income / Rich.</p>
            <div class="grid grid-cols-2 gap-3">
                <?php foreach (['low' => 'Low', 'middle' => 'Middle', 'high' => 'High', 'all' => 'All'] as $sv => $sl): ?>
                    <label class="flex items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 cursor-pointer hover:border-indigo-300">
                        <input type="checkbox" name="mlSes" value="<?= $sv ?>" class="rounded text-indigo-600 focus:ring-indigo-500">
                        <span class="text-sm font-black text-slate-800"><?= $sl ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
            <p id="mlError" class="hidden mt-4 text-xs font-bold text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-3 py-2">Select at least one Socioeconomic Status.</p>
            <div class="flex justify-end gap-3 mt-8">
                <button type="button" onclick="closeMasterlistReport()" class="px-6 py-3 rounded-2xl border border-slate-200 text-xs font-black uppercase tracking-wider text-slate-500 hover:text-slate-700">Cancel</button>
                <button type="button" onclick="continueMasterlistReport()" class="px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-wider shadow-lg">Continue</button>
            </div>
        </div>
    </div>
    <script>
        const ML_BASE = <?= json_encode(['status' => $statusFilter, 'search' => $search, 'income_class' => $incomeClass]) ?>;
        let _mlMode = 'pdf';
        const mlBoxes = () => Array.from(document.querySelectorAll('input[name="mlSes"]'));
        function openMasterlistReport(mode) {
            _mlMode = mode;
            document.getElementById('mlTitle').textContent = mode === 'pdf' ? 'Save as PDF' : 'Print';
            mlBoxes().forEach(b => b.checked = b.value === 'all');
            document.getElementById('mlError').classList.add('hidden');
            const m = document.getElementById('mlReportModal'); m.classList.remove('hidden'); m.classList.add('flex');
        }
        function closeMasterlistReport() {
            const m = document.getElementById('mlReportModal'); m.classList.add('hidden'); m.classList.remove('flex');
        }
        // "All" and the single statuses exclude each other; Low + Middle + High = All.
        mlBoxes().forEach(b => b.addEventListener('change', () => {
            const all = mlBoxes().find(x => x.value === 'all');
            if (b.value === 'all' && b.checked) mlBoxes().forEach(x => { if (x !== all) x.checked = false; });
            if (b.value !== 'all' && b.checked) all.checked = false;
            const picked = mlBoxes().filter(x => x.value !== 'all' && x.checked);
            if (picked.length === 3) { picked.forEach(x => x.checked = false); all.checked = true; }
            document.getElementById('mlError').classList.add('hidden');
        }));
        function continueMasterlistReport() {
            const picked = mlBoxes().filter(x => x.checked).map(x => x.value);
            if (!picked.length) { document.getElementById('mlError').classList.remove('hidden'); return; }
            const q = new URLSearchParams(Object.assign({ mode: _mlMode, ses: picked.includes('all') ? 'all' : picked.join(',') }, ML_BASE));
            closeMasterlistReport();
            window.open('../backend/household_generate_report.php?' + q.toString(), '_blank');
        }
        document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMasterlistReport(); });
    </script>
</body>

</html>