<?php
/**
 * relocation_api.php — "Move Back to Barangay" (Residents → View Resident Information).
 *
 *   GET  ?action=options[&q=]   default barangay address + active households in this barangay
 *   GET  ?action=match&house_no=&street=   household at that address (Head + total members) or none
 *   GET  ?action=survey         published Household Survey (answered when the resident returns as Head)
 *   POST action=move_back       bring a Relocated resident back: same address as Add Resident; the
 *                               household is matched by address (none → new household as Head)
 *
 * Only residents with status Relocated can be moved back. Moving out is done in
 * Households → Move (household_actions.php → move_household).
 */
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth_check.php';
require_once __DIR__ . '/../../permission_helper.php';
require_once __DIR__ . '/../../activity_log_helper.php';
require_once __DIR__ . '/../../household/backend/household_common.php';

function rla_out(array $data, int $code = 200): never
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Active household at House No. + Street in this barangay: with a Head, or with No Head Assigned. */
function rla_match(PDO $pdo, string $house, string $street, int $excludeId): ?array
{
    if (trim($house) === '' || trim($street) === '') return null;
    $addr = ['ResidentID' => 0, 'HouseNumber' => $house, 'StreetName' => $street];
    $m = hh_find_household_at_address($pdo, $addr, $excludeId);
    if ($m) {
        $c = $pdo->prepare("SELECT COUNT(*) FROM residents WHERE FamilyHeadID = ? AND ResidentID <> ?
                            AND (IsDeceased = 0 OR IsDeceased IS NULL) AND " . rl_active_sql());
        $c->execute([$m['head_id'], $m['head_id']]);
        return ['survey_id' => (int) $m['survey_id'], 'household_id' => $m['household_id'], 'headless' => false,
            'head_name' => $m['head_name'], 'address' => $m['address'], 'members' => 1 + (int) $c->fetchColumn()];
    }
    $hs = hh_find_headless_survey($pdo, $addr);
    if ($hs) {
        $c = $pdo->prepare('SELECT COUNT(*) FROM household_survey_members WHERE SurveyID = ?');
        $c->execute([(int) $hs['SurveyID']]);
        return ['survey_id' => (int) $hs['SurveyID'], 'household_id' => (string) ($hs['HouseholdID'] ?? ''), 'headless' => true,
            'head_name' => 'No Head Assigned', 'address' => (string) ($hs['address'] ?? ''), 'members' => (int) $c->fetchColumn()];
    }
    return null;
}

try {
    require_permission($pdo, 'residents', 'update');
    require_permission($pdo, 'households', 'update');
} catch (Throwable $e) {
    rla_out(['success' => false, 'message' => 'Access denied.'], 403);
}
hh_ensure_schema($pdo);
rl_migrate($pdo);

$action = (string) ($_REQUEST['action'] ?? '');

try {
    if ($action === 'options' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $home = rl_home_barangay($pdo);
        $q = trim((string) ($_GET['q'] ?? ''));
        $args = [];
        $search = '';
        if ($q !== '') {
            $like = '%' . $q . '%';
            $search = " AND (hs.HouseholdID LIKE ? OR hs.head_name LIKE ? OR hs.address LIKE ?
                        OR CONCAT_WS(' ', h.FirstName, h.LastName) LIKE ? OR CONCAT_WS(' ', h.HouseNumber, h.StreetName) LIKE ?)";
            $args = [$like, $like, $like, $like, $like];
        }
        // Active households: with a living, active Head in this barangay, or with No Head Assigned.
        $s = $pdo->prepare("SELECT hs.SurveyID, hs.HouseholdID, hs.head_name, hs.address, h.ResidentID AS HeadID,
                    h.FirstName, h.MiddleName, h.LastName, h.Suffix, h.HouseNumber, h.StreetName, h.AreaName, h.Purok,
                    h.BarangayName, h.CityMunicipalityName, h.ProvinceName, h.ZipCode, h.PSGCBarangayCode
                FROM household_survey hs
                LEFT JOIN residents h ON h.ResidentID = hs.ResidentID AND h.IsHead = 1
                     AND (h.IsDeceased = 0 OR h.IsDeceased IS NULL) AND " . rl_active_sql('h') . "
                WHERE COALESCE(hs.status, 'active') = 'active' AND COALESCE(hs.is_removed, 0) = 0
                  AND (h.ResidentID IS NULL OR COALESCE(h.PSGCBarangayCode, '') IN ('', ?))" . $search . "
                ORDER BY hs.HouseholdID LIMIT 50");
        $s->execute(array_merge([(string) ($home['psgc_barangay_code'] ?? '')], $args));
        $rows = [];
        foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $headless = empty($r['HeadID']);
            $rows[] = [
                'survey_id' => (int) $r['SurveyID'],
                'household_id' => $r['HouseholdID'],
                'head_name' => $headless ? 'No Head Assigned' : hh_full_name($r),
                'headless' => $headless,
                'address' => $headless ? (string) ($r['address'] ?? '') : hh_address($r),
                'house_no' => $headless ? '' : (string) ($r['HouseNumber'] ?? ''),
                'street' => $headless ? '' : (string) ($r['StreetName'] ?? ''),
                'area' => $headless ? '' : (string) (($r['AreaName'] ?? '') ?: ($r['Purok'] ?? '')),
            ];
        }
        rla_out(['success' => true, 'home' => $home, 'households' => $rows]);
    }

    // Household Survey for a returning Household Head (published survey from the Survey Builder).
    if ($action === 'survey' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        require_once __DIR__ . '/../../household/backend/survey_lib.php';
        $v = hs_published_version($pdo, hs_barangay_id($pdo));
        rla_out(['success' => true, 'survey' => $v ? hs_app_version($pdo, $v) : null]);
    }

    // Same-address check: existing household (with Head, or No Head Assigned) at House No. + Street.
    if ($action === 'match' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        rla_out(['success' => true, 'match' => rla_match($pdo, (string) ($_GET['house_no'] ?? ''), (string) ($_GET['street'] ?? ''),
            (int) ($_GET['resident_id'] ?? 0))]);
    }

    if ($action === 'move_back' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!hh_csrf_verify()) rla_out(['success' => false, 'message' => 'Invalid security token. Reload the page and try again.'], 403);
        $rid = (int) ($_POST['resident_id'] ?? 0);
        if ($rid <= 0) rla_out(['success' => false, 'message' => 'Missing resident.'], 400);
        $role = (string) ($_POST['role'] ?? '');
        if (!in_array($role, ['head', 'member'], true)) rla_out(['success' => false, 'message' => 'Choose Household Head or Member.'], 400);

        // Default barangay (Manage Area) only: Region → Barangay are never taken from the form.
        $home = rl_home_barangay($pdo);
        if (($home['psgc_barangay_code'] ?? '') === '') rla_out(['success' => false, 'message' => 'Configure the default barangay address in Manage Area first.'], 400);
        $addr = [];
        foreach (['region', 'province', 'municipality', 'barangay'] as $k) {
            $addr['psgc_' . $k . '_code'] = (string) ($home['psgc_' . $k . '_code'] ?? '');
            $addr[$k . '_name'] = (string) ($home[$k . '_name'] ?? '');
        }
        $addr['zip_code'] = (string) ($home['zip_code'] ?? '');
        $clip = static fn($k, $max = 150) => mb_substr(trim(strip_tags((string) ($_POST[$k] ?? ''))), 0, $max);
        $addr['house_no'] = $clip('house_no', 50);
        $addr['building'] = $clip('building');
        $addr['street'] = $clip('street');
        $addr['area'] = $clip('area');
        $addr['area_type'] = $clip('area_type', 30);
        if ($addr['house_no'] === '' || $addr['street'] === '') rla_out(['success' => false, 'message' => 'Enter the House/Lot/Unit Number and Street.'], 400);
        $lat = $_POST['latitude'] ?? '';
        $lng = $_POST['longitude'] ?? '';
        if ($lat !== '' && $lng !== '') {
            if (!is_numeric($lat) || !is_numeric($lng) || abs((float) $lat) > 90 || abs((float) $lng) > 180) {
                rla_out(['success' => false, 'message' => 'Invalid map location.'], 400);
            }
            $addr['lat'] = round((float) $lat, 7);
            $addr['lng'] = round((float) $lng, 7);
        } else {
            $addr['lat'] = $addr['lng'] = null;
        }
        $rel = $clip('relationship', 100);
        $answers = json_decode((string) ($_POST['answers'] ?? '{}'), true);
        if (!is_array($answers)) $answers = [];

        $pdo->beginTransaction();
        // The household is decided on the server from the address (never trusted from the form).
        $match = rla_match($pdo, $addr['house_no'], $addr['street'], $rid);
        if ($match && !$match['headless']) {
            if ($role === 'head') throw new RuntimeException('A household with a Head already exists at this address. Register the resident as a Member.');
            $res = rl_move_back($pdo, $rid, $addr, 'link', 'member', $match['survey_id'], $rel, hh_actor_name());
        } elseif ($match) {
            $res = rl_move_back($pdo, $rid, $addr, 'link', $role, $match['survey_id'], $rel, hh_actor_name());
        } else {
            // No household at this address: a new household is created with the resident as Head.
            $role = 'head';
            $res = rl_move_back($pdo, $rid, $addr, 'new', 'head', 0, '', hh_actor_name());
        }

        // Household Head: the Household Survey is required (when a survey is published).
        if ($role === 'head') {
            require_once __DIR__ . '/../../household/backend/survey_lib.php';
            $v = hs_published_version($pdo, hs_barangay_id($pdo));
            if ($v) {
                if ((int) ($_POST['version_id'] ?? 0) !== (int) $v['version_id']) {
                    throw new RuntimeException('The Household Survey was updated. Reopen Move Back and answer it again.');
                }
                $h = $pdo->prepare('SELECT * FROM household_survey WHERE SurveyID = ?');
                $h->execute([(int) $res['survey_id']]);
                $hhRow = $h->fetch(PDO::FETCH_ASSOC) ?: [];
                if (!hs_household_version_response($pdo, (int) $v['version_id'], (int) $res['survey_id'])) {
                    $n = $pdo->prepare('SELECT * FROM residents WHERE ResidentID = ?');
                    $n->execute([$rid]);
                    hs_submit($pdo, $v, $hhRow, $rid, hh_full_name($n->fetch(PDO::FETCH_ASSOC) ?: []), $answers, 'admin');
                }
            }
        }
        $pdo->commit();

        $n = $pdo->prepare('SELECT * FROM residents WHERE ResidentID = ?');
        $n->execute([$rid]);
        $name = hh_full_name($n->fetch(PDO::FETCH_ASSOC) ?: []);
        if (function_exists('log_activity')) {
            log_activity('Residents', 'Move Back to Barangay', "{$name} moved back to the barangay ({$res['role']}, {$res['household_id']}).");
        }
        rla_out(['success' => true] + $res);
    }

    rla_out(['success' => false, 'message' => 'Unknown action.'], 400);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[relocation_api] ' . $action . ': ' . $e->getMessage());
    rla_out(['success' => false, 'message' => (($e instanceof RuntimeException || $e instanceof InvalidArgumentException) && !($e instanceof PDOException)) ? $e->getMessage() : 'The request could not be completed.'], 400);
}
